import { useEffect, useRef, useState } from "react";

export default function Game() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [iframeKey, setIframeKey] = useState(0);

  useEffect(() => {
    const node = containerRef.current;
    if (!node) return;
    // FULL TEARDOWN of any prior iframe: nuke its src first so the contained
    // window/timers/listeners are released before the element is removed.
    try {
      const old = node.querySelector('iframe') as HTMLIFrameElement | null;
      if (old) {
        try { old.srcdoc = ''; } catch { /* noop */ }
        try { old.src = 'about:blank'; } catch { /* noop */ }
      }
    } catch { /* noop */ }
    node.innerHTML = '';
    const iframe = document.createElement('iframe');
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    iframe.style.border = 'none';
    iframe.style.display = 'block';
    iframe.setAttribute('allow', 'autoplay; fullscreen');
    iframe.srcdoc = GAME_HTML;
    node.appendChild(iframe);
    return () => {
      try {
        const ifr = node.querySelector('iframe') as HTMLIFrameElement | null;
        if (ifr) { try { ifr.srcdoc = ''; } catch { /* noop */ } try { ifr.src = 'about:blank'; } catch { /* noop */ } }
        node.innerHTML = '';
      } catch { /* noop */ }
    };
  }, [iframeKey]);

  useEffect(() => {
    let pending = false;
    const onMsg = (e: MessageEvent) => {
      const d = e?.data;
      const isReload = d === 'palworld:reload' || (d && typeof d === 'object' && (d as { type?: string }).type === 'palworld:reload');
      if (!isReload || pending) return;
      // Debounce: ignore duplicate reload signals within the same teardown window
      pending = true;
      setIframeKey(k => k + 1);
      setTimeout(() => { pending = false; }, 800);
    };
    window.addEventListener('message', onMsg);
    return () => window.removeEventListener('message', onMsg);
  }, []);

  return <div ref={containerRef} style={{ width: '100vw', height: '100dvh', overflow: 'hidden', background: '#080c12' }} />;
}

const GAME_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<title>PalWorld Lite</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{background:#080c12;width:100%;max-width:100vw;height:100dvh;overflow:hidden;overflow-x:hidden;font-family:'Courier New',monospace;touch-action:none;user-select:none;display:flex;align-items:center;justify-content:center;}
canvas{display:block!important;visibility:visible!important;opacity:1!important;image-rendering:pixelated;border:2px solid #1a2535;box-shadow:0 0 36px #060a12,inset 0 0 60px rgba(0,0,0,.35);position:relative;z-index:1;background:#1a3320;}
/* Polished HUD text + smoother button feedback */
#hp-label,#plvl-label,#quest-label,#bag-label,#party-label,#inv-eq-label,#biome-label,#zone-badge,#near-label,#hud{text-shadow:0 1px 2px rgba(0,0,0,.85),0 0 4px rgba(0,0,0,.55);}
#hp-bar-outer,#xp-bar-outer,#quest-bar-outer{box-shadow:inset 0 1px 2px rgba(0,0,0,.6),0 1px 2px rgba(0,0,0,.4);}
#bag-panel,#party-panel{box-shadow:0 2px 8px rgba(0,0,0,.55),inset 0 1px 0 rgba(255,255,255,.06);}
.rbtn{box-shadow:0 3px 8px rgba(0,0,0,.55),inset 0 2px 0 rgba(255,255,255,.18),inset 0 -2px 0 rgba(0,0,0,.25);}
.rbtn:active{box-shadow:0 1px 3px rgba(0,0,0,.6),inset 0 1px 0 rgba(0,0,0,.18);}
.bag-slot,.party-slot,.eq-slot{box-shadow:inset 0 1px 0 rgba(255,255,255,.08),0 1px 2px rgba(0,0,0,.4);transition:transform .08s,box-shadow .12s;}
.bag-slot:active,.party-slot:active{transform:scale(.94);}
#rotate-overlay{position:fixed;inset:0;background:#080c12;z-index:300;display:none;flex-direction:column;align-items:center;justify-content:center;gap:16px;}
#rotate-overlay.show{display:flex;}
#rot-icon{font-size:56px;animation:rota 2s ease-in-out infinite alternate;}
@keyframes rota{from{transform:rotate(-25deg);}to{transform:rotate(25deg);}}
#rot-text{color:#4aff78;font-size:15px;letter-spacing:2px;text-align:center;}
/* TOP HUD — horizontal three-column layout */
#top-center{position:fixed;top:max(0px,calc(env(safe-area-inset-top,0px)));left:50%;transform:translateX(-50%);z-index:20;pointer-events:none;display:flex;flex-direction:row;align-items:flex-end;gap:8px;max-width:calc(100vw - 200px);}
#quest-section{display:flex;flex-direction:column;align-items:flex-start;gap:2px;flex-shrink:0;margin-left:max(8px,2vw);}
#hp-section{display:flex;flex-direction:column;align-items:flex-start;gap:1px;flex-shrink:0;}
#hunger-section{display:flex;flex-direction:column;align-items:flex-start;gap:2px;flex-shrink:0;}
#hp-label{color:#ff6060;font-size:9px;letter-spacing:2px;}
#plvl-label{color:#90ccff;font-size:8px;letter-spacing:1px;font-weight:bold;}
#hp-row{display:flex;align-items:center;gap:6px;}
#hp-bar-outer{width:clamp(100px,22vw,138px);height:10px;background:rgba(0,0,0,.6);border:1.5px solid #ff6060;border-radius:5px;overflow:hidden;}
#hp-bar-inner{height:100%;width:100%;background:linear-gradient(90deg,#f44,#f86);transition:width .15s;}
#xp-bar-outer{width:clamp(100px,22vw,138px);height:4px;background:rgba(0,0,0,.5);border:1px solid #90ccff44;border-radius:2px;overflow:hidden;}
#xp-bar-inner{height:100%;width:0%;background:linear-gradient(90deg,#5588ff,#90ccff);transition:width .25s;}
#quest-label{color:#facc15;font-size:8px;letter-spacing:.5px;white-space:normal;word-break:break-word;line-height:1.25;max-height:2.6em;overflow:hidden;width:clamp(82px,17vw,112px);}
#quest-bar-outer{width:clamp(82px,17vw,112px);height:6px;background:rgba(0,0,0,.5);border:1px solid #facc1570;border-radius:3px;overflow:hidden;}
#quest-bar-inner{height:100%;width:0%;background:linear-gradient(90deg,#facc15,#fb923c);transition:width .3s;}
#hud{position:fixed;top:max(12px,calc(env(safe-area-inset-top,10px) + 4px));left:12px;color:#4aff78;font-size:10px;letter-spacing:1px;line-height:1.8;z-index:20;pointer-events:none;}
#near-label{color:#ffe066;min-height:14px;font-size:10px;}
#biome-label{color:#88ffcc;font-size:8px;letter-spacing:1px;margin-top:1px;}
#zone-badge{font-size:9px;letter-spacing:1.5px;font-weight:bold;margin-top:2px;padding:1px 5px;border-radius:4px;transition:color .4s,background .4s;background:rgba(0,0,0,.35);}
#event-banner{position:fixed;top:50px;left:50%;transform:translateX(-50%);background:rgba(10,0,28,.88);border:2px solid #cc44ff;border-radius:10px;padding:5px 16px;font-size:12px;font-family:'Courier New',monospace;color:#fff;pointer-events:none;z-index:45;white-space:nowrap;opacity:0;transition:opacity .4s;max-width:92vw;text-align:center;}
#event-banner.show{opacity:1;}
/* MINIMAP — top-right HUD, premium circular look. Reduced ~22% from
   prior 148px → 116px desktop. Sits between the top-center HP/Hunger
   bar group and the right-side ⭐ button column. Fixed pixel size with
   responsive breakpoints; never overlaps right column or top bars. */
#minimap-wrap{position:fixed;top:max(8px,env(safe-area-inset-top,8px));right:calc(max(10px,env(safe-area-inset-right,10px)) + 102px);z-index:20;pointer-events:none;width:116px;height:116px;max-width:none;max-height:none;min-width:0;min-height:0;border-radius:50%;background:radial-gradient(circle at 30% 30%,#1a3320,#0a160c);border:3px solid #ffd87a;box-shadow:0 0 22px rgba(74,255,120,.55),0 0 0 3px rgba(74,255,120,.16),0 0 38px rgba(74,255,120,.28),0 6px 14px rgba(0,0,0,.7),inset 0 0 12px rgba(0,0,0,.55);overflow:hidden;display:flex;align-items:center;justify-content:center;transform:none;}
#minimap-wrap::after{content:'';position:absolute;inset:0;border-radius:50%;pointer-events:none;box-shadow:inset 0 0 10px rgba(255,255,255,.24);}
#minimap{display:block;background:rgba(0,0,0,.82);border-radius:50%;width:100%;height:100%;transition:transform .25s ease;}
@media (max-width:520px){#minimap-wrap{width:104px;height:104px;right:calc(max(10px,env(safe-area-inset-right,10px)) + 88px);}}
@media (max-width:380px){#minimap-wrap{width:96px;height:96px;right:calc(max(10px,env(safe-area-inset-right,10px)) + 78px);}}
@media (max-height:520px){#minimap-wrap{width:90px;height:90px;right:calc(max(10px,env(safe-area-inset-right,10px)) + 72px);}}
@media (max-height:420px){#minimap-wrap{width:78px;height:78px;right:calc(max(10px,env(safe-area-inset-right,10px)) + 62px);}}
/* BOTTOM BAR */
#bottom-bar{position:fixed;bottom:max(6px,env(safe-area-inset-bottom,6px));left:0;right:0;display:flex;align-items:flex-end;justify-content:center;gap:6px;z-index:20;pointer-events:none;padding:0 clamp(70px,17vw,94px) 0 clamp(112px,28vw,138px);}
#bag-panel{background:rgba(0,0,0,.82);border:1.5px solid rgba(251,146,60,.45);border-radius:8px;padding:3px 5px;pointer-events:all;display:flex;flex-direction:column;align-items:center;gap:2px;opacity:.9;}
#bag-top{display:flex;align-items:center;gap:5px;width:100%;}
#bag-label{color:#fb923c;font-size:7px;letter-spacing:1px;flex:1;text-align:center;}
#inv-btn{background:rgba(251,146,60,.15);border:1px solid rgba(251,146,60,.4);border-radius:4px;color:#fb923c;font-size:9px;padding:1px 5px;cursor:pointer;-webkit-tap-highlight-color:transparent;line-height:1.4;white-space:nowrap;}
#inv-btn:active{background:rgba(251,146,60,.3);}
#bag-slots{display:flex;gap:3px;}
.bag-slot{width:28px;height:28px;border-radius:5px;background:rgba(251,146,60,.08);border:1.5px solid rgba(251,146,60,.28);display:flex;flex-direction:column;align-items:center;justify-content:center;font-size:12px;position:relative;cursor:pointer;-webkit-tap-highlight-color:transparent;}
.bag-slot.has-item{border-color:#fb923c;background:rgba(251,146,60,.18);}
.bag-slot .sq{position:absolute;bottom:1px;right:2px;font-size:6px;color:#facc15;font-weight:bold;pointer-events:none;}
#party-wrap{display:flex;flex-direction:row;align-items:flex-end;gap:4px;pointer-events:all;}
#party-panel{background:rgba(0,0,0,.82);border:1.5px solid rgba(168,85,247,.45);border-radius:8px;padding:3px 5px;display:flex;flex-direction:column;align-items:center;gap:2px;opacity:.9;}
#party-label{color:#a855f7;font-size:7px;letter-spacing:1px;}
#party-slots{display:flex;gap:3px;}
.party-slot{width:30px;height:30px;border-radius:6px;background:rgba(168,85,247,.09);border:1.5px solid rgba(168,85,247,.3);display:flex;align-items:center;justify-content:center;font-size:15px;cursor:pointer;-webkit-tap-highlight-color:transparent;}
/* Premium PNG icon swap (Foxling) — square fits any slot, crisp on mobile */
.pal-img-icon{display:inline-block;width:1.55em;height:1.55em;vertical-align:middle;background-repeat:no-repeat;background-position:center;background-size:contain;image-rendering:auto;pointer-events:none;}
.party-slot .pal-img-icon{width:26px;height:26px;}
.pdx-icon .pal-img-icon{width:30px;height:30px;}
.ppty-e .pal-img-icon{width:24px;height:24px;}
.party-slot.filled{background:rgba(168,85,247,.22);border-color:#a855f7;}
.party-slot.rare{background:rgba(250,180,50,.18);border-color:#facc15;}
.party-slot.active{background:rgba(74,255,120,.2);border-color:#4aff78;box-shadow:0 0 8px #4aff7860;}
.party-slot.fainted{background:rgba(120,120,120,.18);border-color:#555;opacity:.55;}
.party-slot.selected{outline:2px solid #ffe066;outline-offset:1px;}
/* EQ — lives inside inv-panel overlay now */
#inv-eq-row{display:flex;align-items:center;gap:6px;margin-bottom:8px;padding:6px 8px;background:rgba(96,165,250,.05);border:1px solid rgba(96,165,250,.2);border-radius:7px;}
#inv-eq-label{color:#60a5fa;font-size:8px;letter-spacing:1px;white-space:nowrap;flex-shrink:0;}
#inv-eq-slots{display:flex;gap:5px;flex-wrap:wrap;}
.eq-slot{width:30px;height:30px;border-radius:6px;background:rgba(96,165,250,.06);border:1.5px solid rgba(96,165,250,.25);display:flex;align-items:center;justify-content:center;font-size:13px;position:relative;flex-shrink:0;-webkit-tap-highlight-color:transparent;transition:transform .08s,box-shadow .12s,border-color .15s;touch-action:none;}
.eq-slot.has-item{border-color:#60a5fa;background:rgba(96,165,250,.22);box-shadow:0 0 6px #60a5fa40;cursor:grab;}
.eq-slot.has-item:active{transform:scale(.93);}
.eq-slot.is-active{border-color:#facc15;box-shadow:0 0 10px #facc1599,inset 0 0 6px #facc1533;}
.eq-slot.drag-target{outline:2px dashed #4aff78;outline-offset:1px;background:rgba(74,255,120,.18);}
.eq-slot.dragging{opacity:.55;}
.eq-tier{position:absolute;bottom:1px;right:2px;font-size:6px;font-weight:bold;pointer-events:none;}
.eq-tier.tw{color:#a8c8a0;}.eq-tier.tc{color:#e09030;}.eq-tier.ti{color:#dde2ec;}.eq-tier.ts{color:#aabbcc;}
.eq-dur{position:absolute;left:2px;right:2px;bottom:1px;height:3px;background:rgba(0,0,0,.55);border-radius:2px;overflow:hidden;pointer-events:none;}
.eq-dur>i{display:block;height:100%;background:#4aff78;transition:width .2s;}
.eq-slot.brk{border-color:#f87171!important;animation:eqBrk 1s ease-in-out infinite alternate;}
@keyframes eqBrk{from{box-shadow:0 0 4px #f8717188;}to{box-shadow:0 0 10px #f87171dd;}}
/* JOYSTICK / BUTTONS */
#joy-zone{position:fixed;bottom:max(18px,env(safe-area-inset-bottom,18px));left:max(12px,env(safe-area-inset-left,12px));width:min(108px,26vw);height:min(108px,26vw);border-radius:50%;background:rgba(74,255,120,.04);border:2px solid rgba(74,255,120,.18);z-index:20;}
#joy-stick{position:absolute;width:min(42px,10vw);height:min(42px,10vw);border-radius:50%;background:radial-gradient(circle at 35% 35%,rgba(74,255,120,.82),rgba(40,120,50,.55));border:2px solid rgba(74,255,120,.88);box-shadow:0 0 10px rgba(74,255,120,.35);left:50%;top:50%;transform:translate(-50%,-50%);pointer-events:none;}
/* RIGHT-COLUMN MAIN ACTION STACK — sizes UNCHANGED, repositioned.
   Order top→bottom: ⭐ Skill, ✨ Pal Ability, 📘 Paldex, 🔮 Sphere,
   Sphere-row switcher, 🏗 Build, 🪓 Tool Switch, ⚔️ Attack.
   Column now starts at the very top of the screen — sitting BESIDE
   the minimap (which is shifted ~110px in from the right edge), so
   the column uses the full vertical space from top→bottom. Column is
   narrower than the minimap-to-edge gap, so they never overlap. */
#btn-col{
  --rbtn-size:56px;
  --rbtn-font:26px;
  --rbtn-attack:72px;
  --rbtn-attack-font:32px;
  position:fixed;
  top:max(8px,env(safe-area-inset-top,8px));
  bottom:max(12px,env(safe-area-inset-bottom,12px));
  right:max(18px,calc(env(safe-area-inset-right,10px) + 8px));
  display:flex;flex-direction:column;align-items:center;justify-content:space-between;
  gap:8px;
  z-index:25;overflow:visible;pointer-events:auto;
}
/* Unified sizing for every direct child button in the column */
#btn-col > #skill-btn,
#btn-col > #pal-skill-btn,
#btn-col > #pdx-btn,
#btn-col > .rbtn:not(#action-btn),
#btn-col > #switch-btn{
  width:var(--rbtn-size);height:var(--rbtn-size);
  font-size:var(--rbtn-font);
  flex:0 0 auto;
}
/* Attack is REMOVED from the right-column flex flow (position:fixed),
   so the column packs its 7 utility items naturally from the top. */
#btn-col{justify-content:flex-start;gap:10px;}
#btn-col > #action-btn{
  position:fixed;
  width:var(--rbtn-attack);height:var(--rbtn-attack);
  font-size:var(--rbtn-attack-font);
  /* Sits in the bottom-right empty zone — bottom-edge aligned with the
     PARTY box, slightly above the very bottom of the screen, and to the
     LEFT of the Build / Tool-Switch column. Always fully visible. */
  right:max(96px,calc(env(safe-area-inset-right,10px) + 86px));
  bottom:max(10px,calc(env(safe-area-inset-bottom,10px) + 8px));
  margin:0;
}
.rbtn{position:relative;border-radius:50%;display:flex;align-items:center;justify-content:center;cursor:pointer;-webkit-tap-highlight-color:transparent;transition:transform .08s,box-shadow .12s,border-color .12s;touch-action:manipulation;}
.rbtn::before{content:'';position:absolute;inset:-10px;border-radius:50%;}
.rbtn:active{transform:scale(.9);}
#action-btn{position:relative;background:radial-gradient(circle at 35% 35%,#ffd25a,#a85a00);border:3px solid #ffdd66;box-shadow:0 0 32px #ffaa33aa,0 0 0 3px rgba(255,221,102,.26),0 0 52px rgba(255,170,51,.36),0 6px 18px rgba(0,0,0,.65),inset 0 2px 0 rgba(255,255,255,.28),inset 0 -3px 0 rgba(0,0,0,.32);}
#action-btn::before{content:'';position:absolute;inset:-14px;border-radius:50%;}
#action-btn:active{transform:scale(.92);box-shadow:0 0 16px #ffaa3380,0 1px 4px rgba(0,0,0,.6),inset 0 1px 0 rgba(0,0,0,.22),inset 0 0 8px rgba(120,60,0,.5);}
#build-btn{background:rgba(0,0,0,.78);border:1.5px solid #60a5faaa;color:#60a5fa;box-shadow:0 0 12px rgba(96,165,250,.42),0 3px 8px rgba(0,0,0,.55),inset 0 2px 0 rgba(255,255,255,.1);}
#switch-btn{position:relative;border-radius:50%;background:rgba(0,0,0,.82);border:1.5px solid #4aff78aa;color:#4aff78;display:flex;align-items:center;justify-content:center;cursor:pointer;-webkit-tap-highlight-color:transparent;transition:transform .08s,box-shadow .12s;touch-action:manipulation;box-shadow:0 0 12px rgba(74,255,120,.4),0 3px 8px rgba(0,0,0,.55),inset 0 2px 0 rgba(255,255,255,.1);}
#switch-btn::before{content:'';position:absolute;inset:-10px;border-radius:50%;}
#switch-btn:active{transform:scale(.9);}
/* Height-based shrink ladder — gap shrinks first, then sizes step down,
   so the entire 8-item stack always fits between top and bottom. With
   the column now starting at top:8 (beside the minimap), there is much
   more room than before, so the size shelves trigger only on tighter
   landscape phones. The default 56/72 fits down to ~520 vh. */
@media (max-height:520px){
  #btn-col{
    --rbtn-size:50px;
    --rbtn-font:24px;
    --rbtn-attack:64px;
    --rbtn-attack-font:30px;
    gap:7px;
  }
}
@media (max-height:460px){
  #btn-col{
    --rbtn-size:44px;
    --rbtn-font:21px;
    --rbtn-attack:56px;
    --rbtn-attack-font:26px;
    gap:6px;
  }
}
@media (max-height:420px){
  #btn-col{
    --rbtn-size:38px;
    --rbtn-font:18px;
    --rbtn-attack:48px;
    --rbtn-attack-font:22px;
    gap:5px;
  }
}
@media (max-height:380px){
  #btn-col{
    --rbtn-size:32px;
    --rbtn-font:16px;
    --rbtn-attack:40px;
    --rbtn-attack-font:20px;
    gap:4px;
  }
}
/* TOP-LEFT BUTTON ROW — Pause + Quest. Aligned with the top HUD line:
   { PALWORLD } [Pause][Quest] { Mission text } { HP/Hunger }
   Sits at the same vertical level as the PALWORLD label, immediately
   to its right. Buttons stay 42×42 (compact) so the row stays one neat
   horizontal line and never wraps over the gameplay area. */
#top-left-btns{position:fixed;top:max(8px,calc(env(safe-area-inset-top,0px) + 6px));left:max(110px,calc(env(safe-area-inset-left,12px) + 16vw));z-index:30;display:flex;flex-direction:row;gap:8px;pointer-events:auto;}
@media (max-width:520px){#top-left-btns{left:max(100px,calc(env(safe-area-inset-left,12px) + 18vw));}}
@media (max-width:380px){#top-left-btns{left:max(92px,calc(env(safe-area-inset-left,12px) + 22vw));}}
.tl-btn{width:30px;height:30px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:15px;line-height:1;cursor:pointer;-webkit-tap-highlight-color:transparent;background:rgba(0,0,0,.78);border:1.8px solid rgba(96,165,250,.5);color:#cdd6e3;box-shadow:0 0 10px rgba(0,0,0,.45),0 3px 8px rgba(0,0,0,.55),inset 0 1px 0 rgba(255,255,255,.09);transition:transform .08s,background .15s,border-color .15s,box-shadow .15s;touch-action:manipulation;padding:0;}
.tl-btn:active{transform:scale(.9);background:rgba(96,165,250,.18);}
#tl-pause-btn{border-color:rgba(250,204,21,.6);color:#facc15;box-shadow:0 0 10px rgba(250,204,21,.25),0 3px 8px rgba(0,0,0,.55),inset 0 1px 0 rgba(255,255,255,.09);}
#tl-quest-btn{border-color:rgba(74,255,120,.6);color:#4aff78;position:relative;box-shadow:0 0 10px rgba(74,255,120,.28),0 3px 8px rgba(0,0,0,.55),inset 0 1px 0 rgba(255,255,255,.09);}
#tl-quest-btn.has-new::after{content:'';position:absolute;top:-4px;right:-4px;width:12px;height:12px;border-radius:50%;background:#fb923c;box-shadow:0 0 8px #fb923c;border:1.5px solid #1a0f00;}
@media (max-width:380px){.tl-btn{width:42px;height:42px;font-size:20px;}#top-left-btns{gap:8px;}}
#dungeon-cancel-btn{display:none;position:fixed;top:max(8px,calc(env(safe-area-inset-top,0px)+6px));left:50%;transform:translateX(-50%);z-index:35;background:rgba(248,113,113,.18);border:1.8px solid #f87171;border-radius:8px;color:#f87171;font-family:'Courier New',monospace;font-size:10px;letter-spacing:1.5px;padding:5px 14px;cursor:pointer;-webkit-tap-highlight-color:transparent;box-shadow:0 0 12px rgba(248,113,113,.35),0 3px 8px rgba(0,0,0,.55);white-space:nowrap;touch-action:manipulation;}
#dungeon-cancel-btn.show{display:block;}
#dungeon-cancel-btn:active{background:rgba(248,113,113,.38);transform:translateX(-50%) scale(.95);}
#build-menu{position:fixed;top:50%;right:max(88px,18vw);transform:translateY(-50%) scale(.96);background:rgba(6,10,20,.97);border:1.5px solid #60a5fa;border-radius:11px;padding:9px;z-index:82;display:none;flex-direction:column;gap:5px;opacity:0;transition:opacity .15s ease,transform .15s ease;pointer-events:none;max-height:min(78vh,440px);overflow-y:auto;overflow-x:hidden;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;touch-action:pan-y;scrollbar-width:thin;scrollbar-color:#60a5faaa rgba(96,165,250,.08);}
#build-menu.show{display:flex;opacity:1;transform:translateY(-50%) scale(1);pointer-events:auto;}
#build-menu>*{pointer-events:auto;flex-shrink:0;}
#build-menu::-webkit-scrollbar{width:7px;}
#build-menu::-webkit-scrollbar-track{background:rgba(96,165,250,.06);border-radius:4px;}
#build-menu::-webkit-scrollbar-thumb{background:#60a5faaa;border-radius:4px;border:1px solid rgba(0,0,0,.4);}
#build-menu::-webkit-scrollbar-thumb:hover{background:#60a5fa;}
#build-menu-title{position:sticky;top:-9px;margin:-9px -9px 4px -9px;padding:8px 10px 6px;background:linear-gradient(180deg,rgba(6,10,20,.99) 70%,rgba(6,10,20,.0));font-size:10px;letter-spacing:2px;color:#60a5fa;border-bottom:1px solid #60a5fa33;z-index:2;text-align:center;font-family:'Courier New',monospace;}
.bopt{display:flex;align-items:center;gap:7px;background:rgba(96,165,250,.06);border:1px solid #60a5fa28;border-radius:7px;padding:5px 9px;cursor:pointer;color:#ccc;font-size:10px;white-space:nowrap;-webkit-tap-highlight-color:transparent;}
.bopt:active{background:rgba(96,165,250,.2);}
.bopt .bi{font-size:14px;}
#build-cancel-btn{background:rgba(248,113,113,.13);border:1.5px solid #f87171;color:#f87171;font-family:'Courier New',monospace;font-size:11px;padding:9px 18px;border-radius:8px;cursor:pointer;margin-top:4px;width:100%;min-height:40px;touch-action:manipulation;-webkit-tap-highlight-color:transparent;z-index:200;position:relative;}
#build-cancel-btn:active{background:rgba(248,113,113,.3);}
#build-mode-label{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:rgba(96,165,250,.17);border:1.5px solid #60a5fa;border-radius:7px;color:#60a5fa;font-size:11px;letter-spacing:1px;padding:5px 13px;z-index:25;pointer-events:none;display:none;}
#build-mode-label.show{display:block;}
#remove-mode-label{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:rgba(248,113,113,.17);border:1.5px solid #f87171;border-radius:7px;color:#f87171;font-size:11px;letter-spacing:1px;padding:5px 13px;z-index:25;pointer-events:none;display:none;}
#remove-mode-label.show{display:block;}
.overlay{position:fixed;inset:0;background:rgba(0,0,0,.85);z-index:90;display:none;align-items:center;justify-content:center;}
.overlay.show{display:flex;animation:ovFade .18s ease both;}
.overlay .panel{animation:panelPop .22s cubic-bezier(.2,.9,.3,1.2) both;}
@keyframes ovFade{from{opacity:0}to{opacity:1}}
@keyframes panelPop{from{opacity:0;transform:scale(.92)}to{opacity:1;transform:scale(1)}}
.menu-btn:active,.rbtn:active,#switch-btn:active,.sk-btn:active{transform:scale(.93);}
.popup{will-change:transform,opacity;}
#pause-btn{display:none !important;}
/* Pause menu — make the option list scrollable on small / squat screens */
#pause-menu .panel{max-height:86dvh;overflow-y:auto;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;scrollbar-width:thin;}
#pause-menu .panel::-webkit-scrollbar{width:6px;}
#pause-menu .panel::-webkit-scrollbar-thumb{background:rgba(74,255,120,.35);border-radius:3px;}
#pause-menu .panel::-webkit-scrollbar-track{background:transparent;}
.menu-btn{display:block;width:100%;margin:5px 0;padding:9px 10px;background:rgba(0,0,0,.4);border:1.5px solid #4aff7866;border-radius:6px;color:#dff5e3;font:11px Courier New;letter-spacing:2px;cursor:pointer;-webkit-tap-highlight-color:transparent;transition:background .15s,transform .1s,box-shadow .2s;touch-action:pan-y;}
#pause-menu .panel{touch-action:pan-y;}
.menu-btn:hover{background:rgba(74,255,120,.16);box-shadow:0 0 10px rgba(74,255,120,.25);}
.menu-btn:active{transform:scale(.97);}
.menu-btn.play-btn{border-color:#4aff78;color:#4aff78;font-weight:bold;}
.menu-btn.cont-btn{border-color:#60a5fa;color:#9bd0fa;}
.menu-btn.exit-btn{border-color:#f87171;color:#fbb;}
.menu-btn.disabled{opacity:.32;pointer-events:none;}
#start-menu{background:radial-gradient(circle at 50% 32%,#102a1c 0%,#020608 75%);}
#start-menu .panel{border:2px solid #4aff78;text-align:center;min-width:240px;max-width:300px;width:80vw;padding:18px 16px;}
#start-menu h1{color:#4aff78;font-size:22px;letter-spacing:3px;margin:6px 0 2px;text-shadow:0 0 14px rgba(74,255,120,.45);}
#pause-menu .panel{border:2px solid #facc15;text-align:center;min-width:220px;max-width:280px;width:78vw;padding:14px;}
#pause-menu h2{color:#facc15;letter-spacing:3px;margin:4px 0 8px;}
#world-name-input{width:90%;padding:8px;background:#0a1420;border:1.5px solid #4aff7866;border-radius:6px;color:#dff5e3;font:11px Courier New;letter-spacing:1px;margin:8px 0;outline:none;text-align:center;box-sizing:border-box;}
#world-name-input:focus{border-color:#4aff78;box-shadow:0 0 8px rgba(74,255,120,.35);}
.world-item{background:rgba(0,0,0,.4);border:1px solid #60a5fa55;border-radius:6px;padding:7px 9px;margin:5px 0;display:flex;align-items:center;justify-content:space-between;gap:6px;}
.world-item .wname{color:#dbeafe;font-size:11px;letter-spacing:1px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.world-item .wmeta{color:#9bd0fa88;font-size:8px;letter-spacing:1px;margin-top:2px;}
.world-item .wbtn{padding:5px 8px;border-radius:5px;border:1px solid #4aff7866;background:rgba(0,0,0,.35);color:#4aff78;font:10px Courier New;letter-spacing:1px;cursor:pointer;-webkit-tap-highlight-color:transparent;flex-shrink:0;}
.world-item .wbtn.del{border-color:#f8717166;color:#fbb;}
.world-item .wbtn:active{transform:scale(.94);}
.no-worlds{text-align:center;color:#888;font-size:10px;letter-spacing:1px;padding:18px 6px;line-height:1.7;}
#worlds-list::-webkit-scrollbar{width:6px;}
#worlds-list::-webkit-scrollbar-thumb{background:#60a5fa55;border-radius:3px;}
.panel{background:#0a1420;border-radius:13px;padding:14px 16px;position:relative;}
.panel-close{position:absolute;top:9px;right:11px;background:transparent;border:1px solid #333;color:#888;font-family:'Courier New',monospace;font-size:10px;padding:2px 8px;border-radius:5px;cursor:pointer;}
.panel-close:active{background:rgba(255,255,255,.08);}
.panel h2{font-size:12px;letter-spacing:2px;margin-bottom:10px;text-align:center;}
#craft-overlay .panel{border:2px solid #4aff78;min-width:240px;max-width:300px;width:85vw;max-height:88vh;overflow-y:auto;}
#craft-overlay h2{color:#4aff78;}
.cr-row{display:flex;align-items:center;gap:7px;background:rgba(255,255,255,.03);border:1px solid #1a3a1a;border-radius:7px;padding:6px 8px;}
.cr-name{color:#ddd;font-size:11px;flex:1;}
.cr-cost{color:#888;font-size:9px;}
.cr-btn{background:#142814;border:1px solid #4aff78;color:#4aff78;font-family:'Courier New',monospace;font-size:10px;padding:3px 8px;border-radius:5px;cursor:pointer;}
.cr-btn:disabled{opacity:.3;cursor:not-allowed;}
#chest-overlay .panel{border:2px solid #facc15;width:min(360px,92vw);}
#chest-overlay h2{color:#facc15;}
.chest-cols{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
.chest-sec h3{color:#445;font-size:9px;letter-spacing:1px;margin-bottom:4px;}
.c-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:4px;}
.c-cell{aspect-ratio:1;background:rgba(255,255,255,.04);border:1px solid #2a3a1a;border-radius:5px;display:flex;flex-direction:column;align-items:center;justify-content:center;font-size:15px;cursor:pointer;position:relative;}
.c-cell.has-item{border-color:#5a4a10;}
.c-cell.dov{border-color:#facc15;background:rgba(250,204,21,.1);}
.c-cell .cq{position:absolute;bottom:1px;right:2px;font-size:8px;color:#facc15;font-weight:bold;pointer-events:none;}
/* INVENTORY OVERLAY (EXPAND MODE) */
#inv-overlay{position:fixed;inset:0;background:rgba(0,0,0,.88);z-index:92;display:none;align-items:center;justify-content:center;padding:8px;overflow-y:auto;-webkit-overflow-scrolling:touch;opacity:0;transition:opacity .15s ease;}
#inv-overlay.show{display:flex;opacity:1;}
/* Panel is a flex column: header zone never moves, only the active pane scrolls. */
#inv-panel{background:#0a1420;border:2px solid #fb923c;border-radius:13px;padding:10px 12px 12px;position:relative;width:min(340px,94vw);max-height:calc(100dvh - 16px);display:flex;flex-direction:column;overflow:hidden;}
#inv-panel h2{color:#fb923c;font-size:12px;letter-spacing:2px;margin:0 0 6px;text-align:center;padding:2px 0 4px;flex:0 0 auto;}
#inv-panel .panel-close{position:absolute;top:8px;right:10px;z-index:5;}
#inv-grid{display:grid;grid-template-columns:repeat(6,1fr);gap:6px;}
/* INV / PALDEX / TECH tabs — stay in the static header zone */
#inv-tabs{display:flex;gap:4px;margin:2px 0 8px;background:rgba(0,0,0,.35);border:1px solid #2a3550;border-radius:7px;padding:3px;flex:0 0 auto;}
.inv-tab{flex:1;text-align:center;font-family:'Courier New',monospace;font-size:9px;letter-spacing:1px;padding:6px 4px;color:#7a8aa0;background:transparent;border:none;border-radius:5px;cursor:pointer;-webkit-tap-highlight-color:transparent;touch-action:manipulation;font-weight:bold;}
.inv-tab.active{background:rgba(251,146,60,.18);color:#fb923c;box-shadow:inset 0 0 0 1px #fb923c66;}
.inv-tab.tab-pdx.active{background:rgba(168,85,247,.18);color:#c084fc;box-shadow:inset 0 0 0 1px #c084fc66;}
.inv-tab.tab-tch.active{background:rgba(96,165,250,.18);color:#60a5fa;box-shadow:inset 0 0 0 1px #60a5fa66;}
/* Only the active pane scrolls — header (title/close/tabs) stays fixed. */
.inv-tab-pane{display:none;}
.inv-tab-pane.active{display:flex;flex-direction:column;flex:1 1 auto;min-height:0;overflow-y:auto;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;padding-right:4px;}
.inv-tab-pane::-webkit-scrollbar{width:5px;}
.inv-tab-pane::-webkit-scrollbar-thumb{background:#fb923c66;border-radius:3px;}
/* Counters (paldex / tech) stick to the top of their scrolling pane so cards
   never slide UNDER the title block. */
#paldex-meta,#tech-meta{position:sticky;top:0;background:#0a1420;z-index:2;padding:0 0 6px;}
/* PAL INDEX */
#paldex-meta{font-size:9px;color:#aaa;margin-bottom:8px;display:flex;justify-content:space-between;letter-spacing:1px;}
#paldex-meta b{color:#c084fc;}
#paldex-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:6px;}
.pdx-card{background:rgba(20,15,35,.75);border:1px solid #2a2540;border-radius:7px;padding:6px 7px;font-size:9px;color:#cdd;line-height:1.45;position:relative;overflow:hidden;}
.pdx-card.unseen{filter:grayscale(1);opacity:.62;}
.pdx-card.captured{border-color:#4aff78;box-shadow:0 0 6px #4aff7833;}
.pdx-card.seen{border-color:#c084fc66;}
.pdx-card.boss{border-color:#ff666666;}
.pdx-icon{font-size:22px;text-align:center;margin-bottom:2px;line-height:1;}
.pdx-name{color:#fff;font-weight:bold;font-size:10px;text-align:center;margin-bottom:3px;letter-spacing:1px;}
.pdx-row{display:flex;justify-content:space-between;gap:4px;color:#9ab;font-size:8.5px;}
.pdx-row b{color:#dde;font-weight:normal;}
.pdx-tag{display:inline-block;font-size:8px;padding:0 5px;border-radius:8px;margin:0 2px 2px 0;background:rgba(255,255,255,.06);color:#bbc;letter-spacing:0;}
.pdx-tag.aggro{background:rgba(248,113,113,.18);color:#fca5a5;}
.pdx-tag.passive{background:rgba(74,255,120,.13);color:#86efac;}
.pdx-tag.timid{background:rgba(125,211,252,.18);color:#7dd3fc;}
.pdx-tag.rare{background:rgba(192,132,252,.2);color:#c084fc;}
.pdx-tag.boss{background:rgba(255,68,68,.2);color:#ff8a8a;}
.pdx-status{position:absolute;top:4px;right:5px;font-size:8px;letter-spacing:1px;color:#888;}
.pdx-status.s-cap{color:#4aff78;}
.pdx-status.s-seen{color:#c084fc;}
/* TECH TREE */
#tech-meta{display:flex;justify-content:space-between;align-items:center;font-size:10px;color:#9ab;margin-bottom:8px;letter-spacing:1px;}
#tech-meta b{color:#60a5fa;font-size:13px;}
.tech-tier{margin-bottom:9px;}
.tech-tier-h{font-size:9px;color:#60a5fa;letter-spacing:2px;margin-bottom:4px;border-bottom:1px solid #1a3050;padding-bottom:2px;}
.tech-tier-h.locked{color:#555;border-color:#222;}
.tech-tier-h.future{color:#a87bd1;}
.tech-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:5px;}
.tech-cell{background:rgba(20,30,50,.7);border:1px solid #1f3050;border-radius:6px;padding:6px;font-size:9px;color:#bcd;display:flex;flex-direction:column;gap:2px;position:relative;cursor:pointer;-webkit-tap-highlight-color:transparent;touch-action:pan-y;user-select:none;transition:transform .08s ease;}
.tech-cell:active{transform:scale(.96);}
.tech-cell.unl{border-color:#4aff78;background:rgba(20,40,30,.5);box-shadow:0 0 6px #4aff7822;}
.tech-cell.unl .tech-name{color:#86efac;}
.tech-cell.unl .tech-act{color:#4aff78;}
.tech-cell.locked{filter:grayscale(.7);opacity:.7;}
.tech-cell.locked .tech-act{color:#666;}
.tech-cell.future{opacity:.55;border-style:dashed;border-color:#553a73;background:rgba(40,20,55,.4);}
.tech-cell.future .tech-name{color:#a87bd1;}
.tech-name{font-weight:bold;font-size:10px;color:#dde;}
.tech-cost{font-size:8px;color:#7a8;}
.tech-act{font-size:8px;letter-spacing:1px;text-align:right;color:#facc15;font-weight:bold;}
.tech-cell.canbuy{border-color:#facc15;box-shadow:0 0 6px #facc1533;}
.tech-cell.canbuy .tech-act{color:#facc15;}
/* PALDEX side button */
#pdx-btn{width:min(70px,11dvh);height:min(70px,11dvh);border-radius:50%;background:rgba(0,0,0,.82);border:1.5px solid #c084fc66;color:#c084fc;font-size:min(28px,4.4dvh);display:flex;align-items:center;justify-content:center;cursor:pointer;-webkit-tap-highlight-color:transparent;touch-action:manipulation;}
#pdx-btn:active{background:rgba(192,132,252,.18);}
#pdx-btn.has-new{border-color:#c084fc;box-shadow:0 0 10px #c084fc77;animation:skillPulse 1.4s ease-in-out infinite alternate;}
.inv-cell{aspect-ratio:1;background:rgba(251,146,60,.05);border:1.5px solid rgba(251,146,60,.20);border-radius:7px;display:flex;flex-direction:column;align-items:center;justify-content:center;font-size:16px;cursor:pointer;position:relative;-webkit-tap-highlight-color:transparent;transition:transform .08s,border-color .15s,background .15s;box-shadow:inset 0 1px 0 rgba(255,255,255,.04);}
.inv-cell.has-item{border-color:#fb923c;background:rgba(251,146,60,.16);box-shadow:inset 0 1px 0 rgba(255,255,255,.08),0 1px 2px rgba(0,0,0,.35);}
.inv-cell.has-item:active{transform:scale(.93);background:rgba(251,146,60,.26);}
.inv-cell.is-gear{border-color:#60a5fa;background:rgba(96,165,250,.13);box-shadow:inset 0 1px 0 rgba(255,255,255,.10),0 1px 2px rgba(0,0,0,.4);}
.inv-cell.is-gear:active{transform:scale(.93);background:rgba(96,165,250,.24);}
.inv-cell.is-gear-broken{border-color:#f87171;opacity:.65;}
.inv-cell .iq{position:absolute;bottom:2px;right:3px;font-size:8px;color:#facc15;font-weight:bold;pointer-events:none;background:rgba(0,0,0,.55);padding:0 3px;border-radius:3px;line-height:1.2;text-shadow:0 1px 0 #000;}
.inv-cell .gd{position:absolute;left:3px;right:3px;bottom:1px;height:3px;background:#1a1f2e;border-radius:2px;overflow:hidden;pointer-events:none;}
.inv-cell .gd>i{display:block;height:100%;background:#4aff78;}
.inv-cell .eq-mini{position:absolute;top:1px;right:2px;font-size:6px;color:#60a5fa;font-weight:bold;pointer-events:none;text-shadow:0 1px 0 #000;letter-spacing:.5px;}
/* PAL BOX */
#pb-overlay{position:fixed;inset:0;background:rgba(0,0,0,.9);z-index:95;display:none;flex-direction:column;}
#pb-overlay.show{display:flex;}
#pb-hdr{display:flex;align-items:center;justify-content:space-between;padding:8px 14px 6px;border-bottom:1px solid #1a2535;flex-shrink:0;}
#pb-hdr h2{color:#a855f7;font-size:12px;letter-spacing:2px;}
#pb-hdr-close{background:transparent;border:1.5px solid #444;color:#aaa;font-family:'Courier New',monospace;font-size:11px;padding:3px 12px;border-radius:6px;cursor:pointer;}
#pb-hdr-close:active{background:rgba(255,255,255,.08);}
#pb-cols{flex:1;display:flex;gap:0;overflow:hidden;}
#pb-party-col{width:160px;flex-shrink:0;border-right:1px solid #1a2535;padding:8px;display:flex;flex-direction:column;gap:5px;overflow-y:auto;}
.pc-title{color:#4aff78;font-size:9px;letter-spacing:1px;margin-bottom:2px;}
.ppty-slot{display:flex;align-items:center;gap:5px;background:rgba(74,255,120,.04);border:1.5px dashed rgba(74,255,120,.22);border-radius:7px;padding:5px 7px;min-height:42px;cursor:default;transition:all .12s;position:relative;}
.ppty-slot.filled{background:rgba(74,255,120,.1);border-style:solid;border-color:#4aff78;}
.ppty-slot.sel-hi{outline:2px solid #ffe066;outline-offset:1px;}
.ppty-slot.dov{background:rgba(74,255,120,.22);border-color:#4aff78;}
.ppty-e{font-size:16px;}
.ppty-n{font-size:9px;color:#aaa;flex:1;}
.ppty-r{font-size:9px;color:#facc15;}
.ppty-rm{position:absolute;top:3px;right:4px;background:transparent;border:1px solid #333;color:#888;font-size:8px;padding:1px 4px;border-radius:3px;cursor:pointer;-webkit-tap-highlight-color:transparent;}
#pb-stor-col{flex:1;padding:8px;overflow-y:auto;}
.ps-title{color:#a855f7;font-size:9px;letter-spacing:1px;margin-bottom:5px;}
#pb-stor-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:5px;}
.pstor-slot{aspect-ratio:1;background:rgba(168,85,247,.05);border:1.5px dashed rgba(168,85,247,.22);border-radius:7px;display:flex;flex-direction:column;align-items:center;justify-content:center;font-size:18px;gap:1px;cursor:default;transition:all .12s;}
.pstor-slot.filled{background:rgba(168,85,247,.15);border-style:solid;border-color:#a855f7;cursor:pointer;}
.pstor-slot.rare-f{border-color:#facc15;background:rgba(250,204,21,.1);}
.pstor-slot.sel-hi{outline:2px solid #ffe066;outline-offset:1px;}
.pstor-slot.dov{background:rgba(168,85,247,.28);}
.pstor-slot .ssn{font-size:7px;color:#888;}
#pb-base-row{border-top:1px solid #1a2535;padding:7px 12px;display:flex;align-items:center;gap:8px;flex-shrink:0;}
.pb-row-title{color:#fb923c;font-size:9px;letter-spacing:1px;white-space:nowrap;}
#pb-base-slots-wrap{display:flex;gap:5px;flex-wrap:wrap;}
.pbase-slot{width:40px;height:40px;background:rgba(251,146,60,.05);border:1.5px dashed rgba(251,146,60,.25);border-radius:7px;display:flex;align-items:center;justify-content:center;font-size:18px;cursor:pointer;transition:all .12s;-webkit-tap-highlight-color:transparent;}
.pbase-slot.filled{background:rgba(251,146,60,.18);border-style:solid;border-color:#fb923c;}
.pbase-slot.dov{background:rgba(251,146,60,.3);}
#pb-base-info{color:#445;font-size:9px;margin-left:4px;}
#sel-info{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:rgba(255,230,100,.15);border:1.5px solid #ffe066;border-radius:8px;color:#ffe066;font-size:11px;padding:5px 14px;z-index:96;pointer-events:none;display:none;letter-spacing:1px;}
#sel-info.show{display:block;}
#death-screen{position:fixed;inset:0;background:rgba(0,0,0,.9);display:none;flex-direction:column;align-items:center;justify-content:center;z-index:200;}
#death-screen.show{display:flex;}
#dt{color:#f44;font-size:25px;letter-spacing:4px;margin-bottom:8px;text-shadow:0 0 16px #f44;}
#ds{color:#666;font-size:11px;margin-bottom:20px;}
#respawn-btn{background:rgba(74,255,120,.13);border:2px solid #4aff78;color:#4aff78;font-family:'Courier New',monospace;font-size:13px;letter-spacing:2px;padding:8px 24px;border-radius:8px;cursor:pointer;}
.popup{position:fixed;pointer-events:none;font-size:13px;font-weight:bold;font-family:'Courier New',monospace;z-index:50;white-space:nowrap;animation:fU .9s ease-out forwards;}
@keyframes fU{0%{opacity:1;transform:translateY(0) scale(1.14);}100%{opacity:0;transform:translateY(-54px) scale(1);}}
#dg{position:fixed;pointer-events:none;font-size:22px;z-index:300;display:none;transform:translate(-50%,-50%);}
#respawn-overlay{position:fixed;inset:0;background:rgba(0,0,0,0);z-index:180;display:none;flex-direction:column;align-items:center;justify-content:center;gap:12px;transition:background .4s;}
#respawn-overlay.show{display:flex;}
#respawn-overlay.fade{background:rgba(0,0,0,.82);}
#ro-icon{font-size:48px;animation:pulse 1s ease-in-out infinite alternate;}
@keyframes pulse{from{transform:scale(1);}to{transform:scale(1.18);}}
#ro-msg{color:#a8ff78;font-size:14px;letter-spacing:2px;text-align:center;line-height:1.6;}
#ro-sub{color:#4aff78;font-size:10px;letter-spacing:1px;}
#save-indicator{position:fixed;bottom:62px;left:50%;background:rgba(8,16,12,.86);border:1px solid #4aff7866;border-radius:8px;color:#a8ffc1;font-size:10px;letter-spacing:1.5px;padding:5px 14px;z-index:25;pointer-events:none;opacity:0;transform:translate(-50%,8px);transition:opacity .25s ease-out,transform .25s ease-out;box-shadow:0 4px 12px rgba(0,0,0,.5),inset 0 1px 0 rgba(255,255,255,.06),0 0 14px rgba(74,255,120,.18);text-shadow:0 1px 2px rgba(0,0,0,.8);font-weight:bold;}
#save-indicator.show{opacity:1;transform:translate(-50%,0);}
#hit-flash{position:fixed;inset:0;pointer-events:none;z-index:40;opacity:0;background:rgba(255,0,0,.28);transition:opacity .08s;}
#hit-flash.show{opacity:1;}
#storm-flash{position:fixed;inset:0;pointer-events:none;z-index:42;opacity:0;background:radial-gradient(ellipse at 50% 30%,rgba(180,220,255,.92) 0%,rgba(120,180,255,.55) 30%,rgba(50,80,180,.18) 60%,rgba(0,0,0,0) 100%);transition:opacity .12s ease-out;}
#storm-flash.show{opacity:1;}
#storm-flash.fade{opacity:0;transition:opacity .55s ease-in;}
/* SETTINGS */
#settings-btn{display:none !important;}
#settings-overlay .panel{border:2px solid #60a5fa;min-width:230px;max-width:280px;width:82vw;}
#settings-overlay h2{color:#60a5fa;}
.set-row{display:flex;align-items:center;gap:10px;background:rgba(255,255,255,.03);border:1px solid #1a2a3a;border-radius:7px;padding:8px 10px;margin-bottom:6px;}
.set-label{color:#ccc;font-size:11px;flex:1;}
.set-toggle{background:#0a1a2a;border:1.5px solid #60a5fa55;border-radius:14px;width:44px;height:22px;position:relative;cursor:pointer;transition:background .2s;flex-shrink:0;}
.set-toggle.on{background:#1a4a2a;border-color:#4aff78;}
.set-toggle-knob{position:absolute;top:2px;left:2px;width:16px;height:16px;border-radius:50%;background:#60a5fa88;transition:left .2s,background .2s;}
.set-toggle.on .set-toggle-knob{left:24px;background:#4aff78;}
.set-placeholder{color:#444;font-size:9px;letter-spacing:1px;text-align:center;padding:8px 0 4px;border-top:1px solid #1a2535;margin-top:2px;}
#menu-actions{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:8px;}
.menu-act{background:rgba(96,165,250,.08);border:1.5px solid rgba(96,165,250,.4);color:#cdd6e3;font-family:'Courier New',monospace;font-size:11px;letter-spacing:.5px;padding:9px 4px;border-radius:7px;cursor:pointer;-webkit-tap-highlight-color:transparent;transition:transform .08s,background .15s,border-color .15s;text-align:center;}
.menu-act:active{transform:scale(.95);background:rgba(96,165,250,.18);}
.menu-act.danger{color:#fda4a4;border-color:rgba(248,113,113,.45);background:rgba(248,113,113,.08);}
.menu-act.danger:active{background:rgba(248,113,113,.18);}
/* SKILL TREE */
#skill-btn{width:min(70px,11dvh);height:min(70px,11dvh);border-radius:50%;background:rgba(0,0,0,.82);border:1.5px solid #facc1566;color:#facc15;font-size:min(28px,4.4dvh);display:flex;align-items:center;justify-content:center;cursor:pointer;-webkit-tap-highlight-color:transparent;touch-action:manipulation;}
#skill-btn:active{background:rgba(250,204,21,.18);}
#skill-btn.has-pts{border-color:#facc15;box-shadow:0 0 10px #facc1560;animation:skillPulse 1.4s ease-in-out infinite alternate;}
@keyframes skillPulse{from{box-shadow:0 0 6px #facc1540;}to{box-shadow:0 0 16px #facc15aa;}}
/* PAL SPECIAL SKILL BUTTON */
#pal-skill-btn{width:min(78px,12dvh);height:min(78px,12dvh);border-radius:50%;background:rgba(10,0,28,.88);border:2px solid #cc44ff66;color:#cc44ff;font-size:min(30px,4.8dvh);display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;-webkit-tap-highlight-color:transparent;transition:transform .08s,box-shadow .2s,opacity .2s,border-color .2s;touch-action:manipulation;position:relative;gap:1px;}
#pal-skill-btn:active{transform:scale(.83);}
#pal-skill-btn.ready{border-color:#cc44ff;box-shadow:0 0 16px #cc44ff88;animation:palSkPulse 1.2s ease-in-out infinite alternate;}
#pal-skill-btn.no-pal{opacity:.25;pointer-events:none;}
#pal-skill-btn.on-cd{opacity:.55;border-color:#cc44ff33;}
#pal-sk-cd{font-size:min(11px,1.7dvh);color:#cc44ffcc;font-family:'Courier New',monospace;line-height:1;letter-spacing:0;}
@keyframes palSkPulse{from{box-shadow:0 0 8px #cc44ff50;}to{box-shadow:0 0 22px #cc44ffbb;}}
#skill-overlay .panel{border:2px solid #facc15;min-width:270px;max-width:340px;width:90vw;max-height:92dvh;overflow:hidden;border-radius:14px;}
#skill-overlay h2{color:#facc15;font-size:13px;text-align:center;}
.sk-row{display:flex;align-items:center;gap:8px;background:rgba(255,255,255,.03);border:1px solid #2a3a0a;border-radius:9px;padding:8px 10px;margin-bottom:6px;transition:border-color .2s;}
.sk-row:last-child{margin-bottom:0;}
.sk-icon{font-size:20px;min-width:26px;text-align:center;}
.sk-name{flex:1;color:#ddd;font-size:11px;line-height:1.4;}
.sk-desc{color:#666;font-size:8px;}
.sk-stars{font-size:11px;margin-top:2px;letter-spacing:1px;}
.sk-btn{background:#1a1a08;border:1.5px solid #facc15;color:#facc15;font-family:'Courier New',monospace;font-size:9px;padding:6px 10px;border-radius:6px;cursor:pointer;white-space:nowrap;min-width:60px;-webkit-tap-highlight-color:transparent;transition:background .1s,transform .08s;}
.sk-btn:active{transform:scale(.92);background:rgba(250,204,21,.18);}
.sk-btn:disabled{opacity:.28;cursor:not-allowed;}
.sk-btn.maxed{color:#555;border-color:#333;cursor:default;}
/* BOSS GLOW */
@keyframes bossGlow{0%{opacity:.5;}100%{opacity:1;}}
/* RARITY badges */
.party-slot.epic{background:rgba(180,50,255,.22);border-color:#cc44ff;box-shadow:0 0 10px #cc44ff50;}
.party-slot.legendary{background:rgba(255,215,0,.18);border-color:#ffd700;box-shadow:0 0 12px #ffd70060;animation:lgGlow .9s ease-in-out infinite alternate;}
@keyframes lgGlow{from{box-shadow:0 0 6px #ffd70050;}to{box-shadow:0 0 18px #ffd700cc;}}
#stun-flash{position:fixed;inset:0;pointer-events:none;z-index:39;opacity:0;background:rgba(255,215,0,.18);border:3px solid rgba(255,215,0,.5);transition:opacity .1s;}
#stun-flash.show{opacity:1;}
#hunger-row{display:flex;align-items:center;gap:4px;}
#hunger-label{color:#fb923c;font-size:8px;letter-spacing:.5px;}
#hunger-bar-outer{width:clamp(80px,18vw,118px);height:7px;background:rgba(0,0,0,.6);border:1px solid #fb923c88;border-radius:3px;overflow:hidden;}
#hunger-bar-inner{height:100%;width:100%;background:linear-gradient(90deg,#f97316,#fbbf24);transition:width .3s;}
#food-buff-label{color:#4ade80;font-size:7px;letter-spacing:.5px;height:9px;transition:opacity .3s;opacity:0;}
#food-buff-label.show{opacity:1;}
/* CAMPFIRE OVERLAY */
#campfire-overlay .panel{border:2px solid #ff6622;max-width:320px;width:90vw;padding:12px 14px;}
#campfire-overlay h2{color:#ff6622;font-size:13px;margin-bottom:6px;letter-spacing:2px;}
.cf-card{border-radius:7px;padding:7px 6px;}
.cf-card-fire{background:rgba(255,100,30,.1);border:1px solid #ff6622;}
.cf-card-soup{background:rgba(134,239,172,.08);border:1px solid #4ade8055;}
.cf-card-title{font-size:10px;font-weight:bold;margin-bottom:2px;}
.cf-card-recipe{font-size:8px;color:#777;margin-bottom:5px;}
#cf-qty-row{display:flex;align-items:center;gap:3px;margin-bottom:5px;}
#cf-qty-dn,#cf-qty-up{background:rgba(255,255,255,.08);border:1px solid #444;color:#ccc;border-radius:4px;padding:2px 8px;font-size:13px;cursor:pointer;touch-action:manipulation;line-height:1;}
#cf-qty-val{font-size:12px;color:#fff;min-width:18px;text-align:center;flex:1;}
#cf-qty-max{background:rgba(255,180,40,.1);border:1px solid #ff9922;color:#ffb84d;border-radius:4px;padding:2px 5px;font-size:8px;cursor:pointer;touch-action:manipulation;line-height:1;}
#cook-status{color:#ff9922;font-size:9px;text-align:center;min-height:11px;margin-bottom:3px;letter-spacing:1px;}
#cook-progress-wrap{width:100%;height:6px;background:rgba(0,0,0,.5);border:1px solid #ff662244;border-radius:3px;overflow:hidden;margin-bottom:5px;display:none;}
#cook-progress-bar{height:100%;width:0%;background:linear-gradient(90deg,#ff6622,#fbbf24);transition:width .1s;}
#cf-res-strip{display:flex;flex-wrap:wrap;gap:8px;background:rgba(0,0,0,.38);border:1px solid #2a2a2a;border-radius:6px;padding:5px 8px;margin-bottom:9px;font-size:10px;color:#bbb;line-height:1;align-items:center;}
#cf-res-strip span{white-space:nowrap;}
#cf-queue-display{font-size:8px;color:#666;text-align:center;}
#cf-soup-stock{font-size:8px;color:#555;margin-bottom:5px;line-height:1.3;}
.cf-soup-btn{width:100%;padding:5px;background:rgba(134,239,172,.12);border:1px solid #4ade80;border-radius:5px;color:#86efac;font-size:9px;cursor:pointer;letter-spacing:1px;touch-action:manipulation;}
/* SPHERE SWITCHER */
#sphere-switcher{width:min(82px,13dvh);height:min(22px,3dvh);border-radius:6px;background:rgba(0,0,0,.82);border:1.5px solid #a855f744;color:#c084fc;font-size:min(10px,1.6dvh);display:flex;align-items:center;justify-content:center;cursor:pointer;-webkit-tap-highlight-color:transparent;touch-action:manipulation;letter-spacing:1px;margin-top:-4px;}
#sphere-switcher:active{background:rgba(168,85,247,.18);}
/* Sphere row — < AUTO > arrow design */
#sphere-row{display:flex;align-items:center;gap:4px;background:rgba(0,0,0,.85);border:1.5px solid #a855f7aa;border-radius:18px;padding:3px 4px;-webkit-tap-highlight-color:transparent;box-shadow:0 2px 6px rgba(0,0,0,.5),inset 0 1px 0 rgba(255,255,255,.06);}
.sph-arrow{width:min(28px,4.4dvh);height:min(28px,4.4dvh);border-radius:50%;background:rgba(168,85,247,.18);color:#c084fc;font-size:min(18px,2.8dvh);display:flex;align-items:center;justify-content:center;cursor:pointer;font-weight:bold;line-height:1;user-select:none;touch-action:manipulation;transition:transform .08s,background .12s;}
.sph-arrow:active{transform:scale(.84);background:rgba(168,85,247,.42);}
#sphere-label{min-width:min(74px,12dvh);text-align:center;font-family:'Courier New',monospace;font-size:min(11px,1.75dvh);font-weight:bold;color:#e9d5ff;letter-spacing:1px;padding:0 2px;text-shadow:0 1px 2px rgba(0,0,0,.6);}
/* Locked craft / build rows — visible but disabled with tech hint */
.cr-row.tech-locked{opacity:.55;border-color:#3a2a4a;background:rgba(40,20,60,.18);}
.cr-row.tech-locked .cr-name{color:#998;}
.cr-row.tech-locked .cr-cost{color:#a87bd1;font-weight:bold;font-size:8.5px;letter-spacing:.5px;}
.cr-row.tech-locked .cr-btn{background:rgba(168,123,209,.10);border-color:#a87bd1aa;color:#c4a8e0;cursor:not-allowed;opacity:.7;}
.bopt.tech-locked{opacity:.6;cursor:not-allowed;background:rgba(168,123,209,.08);border-color:#a87bd166;color:#c4a8e0;font-style:italic;}
.bopt.tech-locked .bi{filter:grayscale(.5);}
.bopt-tech-hint{font-size:8px;color:#a87bd1;letter-spacing:.5px;margin-left:4px;}
/* BOSS ARENA edge glow + indicator */
#arena-edge{position:fixed;inset:0;pointer-events:none;z-index:18;display:none;border-radius:0;box-shadow:inset 0 0 90px 10px rgba(255,80,40,.45);animation:arenaPulse 1.6s ease-in-out infinite alternate;}
#arena-edge.show{display:block;}
@keyframes arenaPulse{from{box-shadow:inset 0 0 60px 6px rgba(255,80,40,.30);}to{box-shadow:inset 0 0 110px 14px rgba(255,140,40,.55);}}
#arena-warn{position:fixed;left:50%;top:30%;transform:translateX(-50%);z-index:35;background:rgba(0,0,0,.78);border:1.5px solid #ff6644aa;color:#ffaa66;font-family:'Courier New',monospace;font-size:11px;letter-spacing:1.5px;padding:6px 14px;border-radius:6px;display:none;text-align:center;box-shadow:0 0 12px #ff664466;pointer-events:none;}
#arena-warn.show{display:block;animation:arenaWarn .35s ease-out;}
@keyframes arenaWarn{from{opacity:0;transform:translate(-50%,-8px) scale(.92);}to{opacity:1;transform:translateX(-50%) scale(1);}}
#boss-reset-banner{position:fixed;left:50%;top:38%;transform:translateX(-50%);z-index:60;background:linear-gradient(180deg,#220808,#440f0f);border:2px solid #ff4422;color:#ffd699;font-family:'Courier New',monospace;font-size:14px;letter-spacing:3px;padding:14px 22px;border-radius:10px;display:none;text-align:center;box-shadow:0 0 24px #ff442288,0 4px 12px rgba(0,0,0,.7);pointer-events:none;}
#boss-reset-banner.show{display:block;animation:bossReset 2.6s ease-out forwards;}
@keyframes bossReset{0%{opacity:0;transform:translate(-50%,-12px) scale(.85);}15%{opacity:1;transform:translateX(-50%) scale(1.05);}25%{transform:translateX(-50%) scale(1);}80%{opacity:1;transform:translateX(-50%) scale(1);}100%{opacity:0;transform:translate(-50%,-6px) scale(.96);}}
/* INVENTORY DnD */
.inv-cell.drag-over{border-color:#4aff78;background:rgba(74,255,120,.15);}
.inv-cell.dragging{opacity:.4;}
/* BOSS HP BAR (top center, shown during boss engagement) */
#boss-hpbar{position:fixed;top:3px;left:50%;transform:translateX(-50%);z-index:30;pointer-events:none;display:none;flex-direction:column;align-items:center;gap:2px;min-width:180px;max-width:280px;width:50vw;}
#boss-hpbar.show{display:flex;}
#boss-hpbar-name{font-size:10px;letter-spacing:1.5px;font-weight:bold;text-align:center;text-shadow:0 0 8px currentColor;}
#boss-hpbar-outer{width:100%;height:10px;background:rgba(0,0,0,.7);border-radius:5px;overflow:hidden;border:1.5px solid #ff4444;}
#boss-hpbar-inner{height:100%;width:100%;background:linear-gradient(90deg,#aa0000,#ff4422);transition:width .18s;}
#boss-hpbar-phase{font-size:8px;letter-spacing:1px;text-align:center;}
/* ZONE BOSS GLOW ANIMATIONS */
@keyframes fireGlow{0%{box-shadow:0 0 8px #ff440050;}100%{box-shadow:0 0 20px #ff8800cc;}}
@keyframes iceGlow{0%{box-shadow:0 0 8px #44aaffcc;}100%{box-shadow:0 0 20px #88ddffcc;}}
@keyframes rockGlow{0%{box-shadow:0 0 8px #887766cc;}100%{box-shadow:0 0 20px #aabb99cc;}}
/* RUINS */
#ruins-loot-pop{position:fixed;top:38%;left:50%;transform:translateX(-50%);pointer-events:none;z-index:45;}
/* LOADING OVERLAY — shown until world is ready */
#loading-overlay{position:fixed;inset:0;background:radial-gradient(ellipse at center,#0a1a26 0%,#040810 80%);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;transition:opacity .35s ease,visibility .35s ease;}
#loading-overlay.hide{opacity:0;visibility:hidden;pointer-events:none;}
#loading-card{display:flex;flex-direction:column;align-items:center;gap:14px;text-align:center;max-width:340px;}
#loading-title{font-family:'Courier New',monospace;font-size:26px;letter-spacing:6px;color:#4aff78;text-shadow:0 0 14px #4aff7866,0 2px 0 #000;font-weight:bold;}
#loading-sub{font-family:'Courier New',monospace;font-size:11px;letter-spacing:3px;color:#9ab;}
#loading-bar-out{width:260px;max-width:82vw;height:8px;background:rgba(74,255,120,.08);border:1px solid #4aff7855;border-radius:5px;overflow:hidden;position:relative;box-shadow:inset 0 1px 2px rgba(0,0,0,.5);}
#loading-bar-in{height:100%;width:0%;background:linear-gradient(90deg,#4aff78,#22d3ee,#4aff78);background-size:200% 100%;animation:loadBar 1.4s linear infinite;border-radius:4px;transition:width .4s cubic-bezier(.2,.7,.3,1);box-shadow:0 0 10px #4aff7866;}
#loading-pct{font-family:'Courier New',monospace;font-size:10px;letter-spacing:2px;color:#4aff78;margin-top:-4px;font-weight:bold;text-shadow:0 0 6px #4aff7855;}
#loading-stage{font-family:'Courier New',monospace;font-size:11px;letter-spacing:1.5px;color:#9ab;min-height:14px;text-align:center;transition:opacity .2s ease;}
@keyframes loadBar{0%{background-position:0% 0}100%{background-position:200% 0}}
#loading-dots{display:flex;gap:6px;color:#4aff78;font-size:18px;line-height:1;}
#loading-dots span{animation:loadDot 1.2s ease-in-out infinite;opacity:.25;}
#loading-dots span:nth-child(2){animation-delay:.15s;}
#loading-dots span:nth-child(3){animation-delay:.30s;}
#loading-dots span:nth-child(4){animation-delay:.45s;}
#loading-dots span:nth-child(5){animation-delay:.60s;}
@keyframes loadDot{0%,80%,100%{opacity:.25;transform:translateY(0)}40%{opacity:1;transform:translateY(-3px)}}
#loading-tip{font-family:'Courier New',monospace;font-size:10px;letter-spacing:1px;color:#ffd66e;margin-top:4px;min-height:14px;transition:opacity .25s ease;text-align:center;line-height:1.5;padding:0 8px;}
/* Smooth tab-pane scrollbars (PALDEX/TECH) */
.inv-tab-pane{scrollbar-width:thin;scrollbar-color:#60a5fa66 transparent;}
.inv-tab-pane::-webkit-scrollbar{width:5px;}
.inv-tab-pane::-webkit-scrollbar-thumb{background:#60a5fa66;border-radius:3px;}
#pane-pdx,#pane-tch{-webkit-overflow-scrolling:touch;overscroll-behavior:contain;touch-action:pan-y;}
</style>
</head>
<body>
<div id="loading-overlay">
  <div id="loading-card">
    <div id="loading-title">⬡ PALWORLD</div>
    <div id="loading-sub">Loading World...</div>
    <div id="loading-bar-out"><div id="loading-bar-in"></div></div>
    <div id="loading-pct">0%</div>
    <div id="loading-stage">Initializing...</div>
    <div id="loading-dots"><span>•</span><span>•</span><span>•</span><span>•</span><span>•</span></div>
    <div id="loading-tip">🦊 Catch pals to build your team</div>
  </div>
</div>
<div id="rotate-overlay"><div id="rot-icon">📱</div><div id="rot-text">ROTATE DEVICE<br>TO PLAY</div></div>
<div id="top-center">
  <div id="quest-section">
    <div id="quest-label">QUEST —</div>
    <div id="quest-bar-outer"><div id="quest-bar-inner"></div></div>
    <div id="quest-hint" style="color:#cdd6e3;font-size:7px;line-height:1.2;max-width:clamp(82px,17vw,112px);margin-top:2px;text-shadow:0 1px 1px #000;"></div>
  </div>
  <div id="hp-section">
    <div id="hp-row"><div id="hp-label">❤️ HP</div><div id="plvl-label">LV.1</div></div>
    <div id="hp-bar-outer"><div id="hp-bar-inner"></div></div>
    <div id="xp-bar-outer"><div id="xp-bar-inner"></div></div>
  </div>
  <div id="hunger-section">
    <div id="hunger-row"><div id="hunger-label">🍗 HGR</div></div>
    <div id="hunger-bar-outer"><div id="hunger-bar-inner"></div></div>
    <div id="food-buff-label">⚡ FED BUFF</div>
  </div>
</div>
<div id="top-left-btns">
  <button class="tl-btn" id="tl-pause-btn" title="Pause / Menu">⏸️</button>
  <button class="tl-btn" id="tl-quest-btn" title="Quests">📜</button>
</div>
<button id="dungeon-cancel-btn" title="Cancel Dungeon">✕ CANCEL DUNGEON</button>
<div id="hud"><div>⬡ PALWORLD</div><div id="near-label"></div><div id="biome-label">🌿 GRASSLAND</div><div id="zone-badge" style="display:none;color:#4aff78;"></div><div id="time-label" style="color:#ffe066;font-size:9px;letter-spacing:1px;margin-top:1px;">☀️ DAY</div><div id="weather-label" style="color:#ffe066;font-size:9px;letter-spacing:1px;margin-top:1px;">☀️ CLEAR</div></div>
<div id="arena-edge"></div>
<div id="arena-warn">⚠ Enter Arena to Damage Boss</div>
<div id="boss-reset-banner">⚠ BOSS FIGHT RESET ⚠</div>
<div id="boss-hpbar">
  <div id="boss-hpbar-name" style="color:#ff6666">BOSS</div>
  <div id="boss-hpbar-outer"><div id="boss-hpbar-inner"></div></div>
  <div id="boss-hpbar-phase" style="color:#ff8888">PHASE 1</div>
</div>
<div id="event-banner"></div>
<div id="minimap-wrap"><canvas id="minimap" width="84" height="84"></canvas></div>
<div id="bottom-bar">
  <div id="bag-panel">
    <div id="bag-top"><div id="bag-label">BAG</div><div id="inv-btn">⋯ EQ</div></div>
    <div id="bag-slots">
      <div class="bag-slot" id="bag-0"></div><div class="bag-slot" id="bag-1"></div>
      <div class="bag-slot" id="bag-2"></div><div class="bag-slot" id="bag-3"></div>
      <div class="bag-slot" id="bag-4"></div>
    </div>
  </div>
  <div id="party-wrap">
    <div id="party-panel">
      <div id="party-label">PARTY 0/4</div>
      <div id="party-slots">
        <div class="party-slot" id="ps-0"></div><div class="party-slot" id="ps-1"></div>
        <div class="party-slot" id="ps-2"></div><div class="party-slot" id="ps-3"></div>
      </div>
    </div>
  </div>
</div>
<canvas id="gameCanvas"></canvas>
<div id="joy-zone"><div id="joy-stick"></div></div>
<div id="btn-col">
  <div id="skill-btn" title="Skill Tree">🌟</div>
  <div id="pal-skill-btn" class="no-pal" title="Pal Ability"><span id="pal-sk-label">✨</span><span id="pal-sk-cd" style="display:none"></span></div>
  <div id="pdx-btn" title="Pal Index / Tech Tree">📘</div>
  <div class="rbtn" id="capture-btn" title="Sphere Capture" style="opacity:.38">🔮</div>
  <div id="sphere-row">
    <div class="sph-arrow" id="sphere-prev">‹</div>
    <div id="sphere-label">AUTO</div>
    <div class="sph-arrow" id="sphere-next">›</div>
  </div>
  <div class="rbtn" id="build-btn" title="Build">🏗</div>
  <div id="switch-btn" title="Tool Switch">🪓</div>
  <div class="rbtn" id="action-btn" title="Attack">⚔️</div>
</div>
<div id="build-menu">
  <div id="build-menu-title">🏗 BUILD MENU</div>
  <div class="bopt" id="bopt-table"><span class="bi">🔨</span>Craft Table (8🪵 5🪨)</div>
  <div class="bopt" id="bopt-chest"><span class="bi">📦</span>Chest (10🪵)</div>
  <div class="bopt" id="bopt-palbox"><span class="bi">🗃️</span>Pal Box (15🪵 10🪨 5🟠)</div>
  <div class="bopt" id="bopt-campfire"><span class="bi">🔥</span>Campfire (6🪵 4🪨)</div>
  <div class="bopt" id="bopt-repair"><span class="bi">🛠️</span>Repair Bench (20🪵 15🪨 5🩶)</div>
  <div class="bopt" id="bopt-delete"><span class="bi">🗑️</span>Delete Mode</div>
  <button id="build-cancel-btn">✕ Cancel</button>
</div>
<div id="build-mode-label">🏗 TAP GROUND TO PLACE</div>
<div id="remove-mode-label">🗑️ TAP STRUCTURE TO REMOVE</div>
<div class="overlay" id="settings-overlay">
  <div class="panel">
    <h2>☰ MENU</h2><button class="panel-close" id="settings-close">✕</button>
    <div class="set-row">
      <span class="set-label">🔊 Audio</span>
      <div class="set-toggle on" id="snd-toggle"><div class="set-toggle-knob"></div></div>
    </div>
    <div id="menu-actions">
      <button class="menu-act" id="menu-inv">🎒 Inventory</button>
      <button class="menu-act" id="menu-save">💾 Save</button>
      <button class="menu-act" id="menu-help">❓ Help</button>
      <button class="menu-act danger" id="menu-exit">🚪 Exit to Title</button>
    </div>
    <div id="help-panel" style="display:none;font-size:9px;color:#cdd6e3;line-height:1.55;margin-top:8px;background:rgba(0,0,0,.45);border:1px solid rgba(96,165,250,.25);border-radius:6px;padding:7px 9px;letter-spacing:.4px;">
      <b style="color:#90ccff">CONTROLS</b><br>
      • Joystick (bottom-left): move<br>
      • ⚔️ Attack: hit / interact / talk<br>
      • 🪓 Switch: cycle equipped tool<br>
      • 🏗 Build: open build menu<br>
      • 🔮 Capture: throw a Pal sphere<br>
      • ✨ Ability: trigger active Pal skill<br>
      • 🌟 Skill: open skill tree (spend pts)<br>
      • 📘 Paldex: pals & tech tree<br>
      • Sphere ‹ ›: select sphere type<br>
      • Game auto-saves every ~30s.
    </div>
  </div>
</div>
<div class="overlay" id="craft-overlay">
  <div class="panel">
    <h2>⚗️ CRAFTING</h2><button class="panel-close" id="craft-close">✕</button>
    <div class="cr-row"><span class="cr-name">🔮 Pal Sphere</span><span class="cr-cost">5🪵 3🪨 2🟠</span><button class="cr-btn" id="cr-sphere">CRAFT</button></div>
    <div class="cr-row"><span class="cr-name">💠 Advanced Sphere</span><span class="cr-cost">5🔮 3🟠</span><button class="cr-btn" id="cr-adv-sphere">CRAFT</button></div>
    <div class="cr-row"><span class="cr-name">🌀 Ultra Sphere</span><span class="cr-cost">3💠 5🟠</span><button class="cr-btn" id="cr-ultra-sphere">CRAFT</button></div>
    <div class="cr-row"><span class="cr-name">🗡️ Wood Sword</span><span class="cr-cost">6🪵</span><button class="cr-btn" id="cr-sw-wood">EQUIP</button></div>
    <div class="cr-row"><span class="cr-name">⚔️ Stone Sword</span><span class="cr-cost">5🪵 5🪨</span><button class="cr-btn" id="cr-sw-stone">EQUIP</button></div>
    <div class="cr-row"><span class="cr-name">🔱 Copper Sword</span><span class="cr-cost">20🟠 12🪨 12🪵</span><button class="cr-btn" id="cr-sw-copper">EQUIP</button></div>
    <div class="cr-row"><span class="cr-name">⚜️ Iron Sword <span style="font-size:9px;color:#dde2ec;">+10 DMG</span></span><span class="cr-cost">8🪵 18🩶</span><button class="cr-btn" id="cr-sw-iron">EQUIP</button></div>
    <div class="cr-row"><span class="cr-name">🥋 Cloth Armor</span><span class="cr-cost">8🪵 4🪨</span><button class="cr-btn" id="cr-ar-cloth">EQUIP</button></div>
    <div class="cr-row"><span class="cr-name">🛡️ Iron Armor <span style="font-size:9px;color:#dde2ec;">+60 HP</span></span><span class="cr-cost">10🪵 5🟠 20🩶</span><button class="cr-btn" id="cr-ar-iron">EQUIP</button></div>
    <div class="cr-row"><span class="cr-name">🪓 Stone Axe</span><span class="cr-cost">3🪵 3🪨</span><button class="cr-btn" id="cr-ax-stone">EQUIP</button></div>
    <div class="cr-row"><span class="cr-name">🪓 Copper Axe</span><span class="cr-cost">3🪵 3🟠</span><button class="cr-btn" id="cr-ax-copper">EQUIP</button></div>
    <div class="cr-row"><span class="cr-name">🪓 Iron Axe <span style="font-size:9px;color:#dde2ec;">faster</span></span><span class="cr-cost">5🪵 12🩶</span><button class="cr-btn" id="cr-ax-iron">EQUIP</button></div>
    <div class="cr-row"><span class="cr-name">⛏ Stone Pickaxe</span><span class="cr-cost">3🪵 3🪨</span><button class="cr-btn" id="cr-pk-stone">EQUIP</button></div>
    <div class="cr-row"><span class="cr-name">⛏ Copper Pickaxe</span><span class="cr-cost">3🪵 3🟠</span><button class="cr-btn" id="cr-pk-copper">EQUIP</button></div>
    <div class="cr-row"><span class="cr-name">⛏ Iron Pickaxe <span style="font-size:9px;color:#dde2ec;">faster</span></span><span class="cr-cost">5🪵 12🩶</span><button class="cr-btn" id="cr-pk-iron">EQUIP</button></div>
    <div class="cr-row"><span class="cr-name" style="color:#888">🪢 Saddle <span style="font-size:9px;">(drops only from Boss Horse)</span></span><span class="cr-cost" style="color:#666">— RARE —</span></div>
  </div>
</div>
<div class="overlay" id="chest-overlay">
  <div class="panel">
    <h2>📦 CHEST</h2><button class="panel-close" id="chest-close">✕</button>
    <div class="chest-cols">
      <div class="chest-sec"><h3>YOUR BAG</h3><div class="c-grid" id="ch-player"></div></div>
      <div class="chest-sec"><h3>CHEST</h3><div class="c-grid" id="ch-chest"></div></div>
    </div>
  </div>
</div>
<div class="overlay" id="campfire-overlay">
  <div class="panel">
    <h2>🔥 CAMPFIRE</h2><button class="panel-close" id="campfire-close">✕</button>
    <div id="cf-res-strip"></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-bottom:8px;">
      <div class="cf-card cf-card-fire">
        <div class="cf-card-title" style="color:#ff9955;">🍖 Cook Meat</div>
        <div class="cf-card-recipe">1🥩 + 1⬛ → 🍖</div>
        <div id="cf-qty-row">
          <button id="cf-qty-dn">−</button>
          <span id="cf-qty-val">1</span>
          <button id="cf-qty-up">+</button>
          <button id="cf-qty-max">MAX</button>
        </div>
        <button class="cr-btn" id="cf-cook-btn" style="width:100%;padding:5px;font-size:9px;letter-spacing:1px;margin-bottom:0;">🔥 COOK</button>
      </div>
      <div class="cf-card cf-card-soup">
        <div class="cf-card-title" style="color:#86efac;">🍲 Soup</div>
        <div class="cf-card-recipe">5🍄 + 10🍓 → 🍲</div>
        <div id="cf-soup-stock"></div>
        <button class="cf-soup-btn" id="cf-soup-btn">🍲 BREW</button>
      </div>
    </div>
    <div id="cook-status"></div>
    <div id="cook-progress-wrap"><div id="cook-progress-bar"></div></div>
    <div id="cf-queue-display"></div>
  </div>
</div>
<div id="inv-overlay">
  <div id="inv-panel">
    <h2 id="inv-panel-title">🎒 MENU</h2><button class="panel-close" id="inv-close">✕</button>
    <div id="inv-tabs">
      <button class="inv-tab tab-inv active" data-tab="inv">🎒 BAG</button>
      <button class="inv-tab tab-pdx" data-tab="pdx">📘 PALDEX</button>
      <button class="inv-tab tab-tch" data-tab="tch">🔬 TECH</button>
    </div>
    <div class="inv-tab-pane active" id="pane-inv">
      <div id="inv-eq-row">
        <div id="inv-eq-label">⚔ EQUIPPED</div>
        <div id="inv-eq-slots">
          <div class="eq-slot" id="eq-weapon" title="Weapon">✊</div>
          <div class="eq-slot" id="eq-armor" title="Armor (tap to unequip)">👕</div>
          <div class="eq-slot has-item" id="eq-axe" title="Axe">🪓<span class="eq-tier tw" id="eq-axe-tier">W</span></div>
          <div class="eq-slot has-item" id="eq-pick" title="Pickaxe">⛏<span class="eq-tier tw" id="eq-pick-tier">W</span></div>
        </div>
      </div>
      <div id="inv-grid"></div>
    </div>
    <div class="inv-tab-pane" id="pane-pdx">
      <div id="paldex-meta"><span>📘 <b id="pdx-count">0</b> / <span id="pdx-total">0</span> DISCOVERED</span><span>🎯 <b id="pdx-cap-count">0</b> CAPTURED</span></div>
      <div id="paldex-grid"></div>
    </div>
    <div class="inv-tab-pane" id="pane-tch">
      <div id="tech-meta"><span>🔬 TECH POINTS</span><b id="tech-pts">0</b></div>
      <div id="tech-list"></div>
    </div>
  </div>
</div>
<div id="pb-overlay">
  <div id="pb-hdr"><h2>🗃️ PAL BOX</h2><button id="pb-hdr-close">✕ CLOSE</button></div>
  <div id="pb-cols">
    <div id="pb-party-col">
      <div class="pc-title">PARTY (max 4)</div>
      <div class="ppty-slot" id="pp-0" data-idx="0"></div>
      <div class="ppty-slot" id="pp-1" data-idx="1"></div>
      <div class="ppty-slot" id="pp-2" data-idx="2"></div>
      <div class="ppty-slot" id="pp-3" data-idx="3"></div>
    </div>
    <div id="pb-stor-col">
      <div class="ps-title">STORAGE (<span id="pb-cnt">0</span>/<span id="pb-cap">10</span>)</div>
      <div id="pb-stor-grid"></div>
    </div>
  </div>
  <div id="pb-base-row">
    <div class="pb-row-title">BASE WORKERS</div>
    <div id="pb-base-slots-wrap"></div>
    <div id="pb-base-info"></div>
  </div>
</div>
<div id="sel-info"></div>
<div id="death-screen"><div id="dt">YOU DIED</div><div id="ds">Your pals await…</div><button id="respawn-btn" onclick="respawn()">▶ RESPAWN AT BASE</button><button class="menu-btn exit-btn" style="margin-top:10px;max-width:220px;" onclick="exitToMenu()">⏏ RETURN TO MENU</button></div>
<div class="overlay" id="start-menu">
  <div class="panel">
    <h1>⬡ PALWORLD LITE</h1>
    <div style="color:#9bd6a3;font-size:10px;margin-bottom:14px;letter-spacing:2px;">— SURVIVE • TAME • THRIVE —</div>
    <button class="menu-btn play-btn" onclick="startNewGame()">▶ NEW GAME</button>
    <button class="menu-btn cont-btn" id="continue-btn" onclick="continueGame()">↺ CONTINUE</button>
    <div style="color:#3a5a40;font-size:9px;margin-top:14px;letter-spacing:1px;">v1.0</div>
  </div>
</div>
<div class="overlay" id="pause-menu">
  <div class="panel">
    <h2>⏸ PAUSED</h2>
    <button class="menu-btn play-btn" onclick="closePauseMenu()">▶ RESUME</button>
    <button class="menu-btn cont-btn" onclick="pauseToSettings()">⚙ SETTINGS</button>
    <button class="menu-btn cont-btn" id="pm-save-btn" type="button">💾 SAVE</button>
    <button class="menu-btn cont-btn" id="pm-audio-btn" type="button">🔊 AUDIO: ON</button>
    <button class="menu-btn cont-btn" id="pm-help-btn" type="button">❓ HELP</button>
    <button class="menu-btn exit-btn" onclick="exitToMenu()">⏏ EXIT TO MENU</button>
    <div id="pm-help-panel" style="display:none;font-size:9px;color:#cdd6e3;line-height:1.55;margin-top:8px;background:rgba(0,0,0,.45);border:1px solid rgba(96,165,250,.25);border-radius:6px;padding:7px 9px;letter-spacing:.4px;text-align:left;">
      <b style="color:#90ccff">CONTROLS</b><br>
      • Joystick (bottom-left): move<br>
      • ⚔️ Attack: hit / interact / talk<br>
      • 🪓 Switch: cycle equipped tool<br>
      • 🏗 Build: open build menu<br>
      • 🔮 Sphere: throw a Pal sphere<br>
      • ✨ Ability: trigger active Pal skill<br>
      • 🌟 Star: open skill tree (spend pts)<br>
      • 📘 Paldex: pals & tech tree<br>
      • Sphere ‹ ›: select sphere type<br>
      • 📜 Quest button: daily / challenge missions<br>
      • Game auto-saves every ~30s.
    </div>
  </div>
</div>
<div class="overlay" id="quest-overlay">
  <div class="panel" style="border:2px solid #4aff78;min-width:240px;max-width:340px;width:88vw;max-height:88dvh;overflow-y:auto;">
    <h2 style="color:#4aff78;letter-spacing:2px;">📜 QUESTS</h2>
    <button class="panel-close" id="quest-close" type="button">✕</button>
    <div id="quest-overlay-body" style="display:flex;flex-direction:column;gap:6px;margin-top:4px;"></div>
    <div id="quest-empty" style="display:none;color:#888;font-size:9px;text-align:center;padding:14px 4px;letter-spacing:1px;">No active quests right now.<br>Check back soon!</div>
  </div>
</div>
<div class="overlay" id="create-world-overlay">
  <div class="panel" style="border:2px solid #4aff78;text-align:center;min-width:240px;max-width:300px;width:80vw;">
    <h2 style="color:#4aff78;letter-spacing:2px;">✨ CREATE WORLD</h2>
    <input id="world-name-input" maxlength="24" placeholder="Enter World Name (optional)" autocomplete="off">
    <button class="menu-btn play-btn" onclick="confirmCreateWorld()">✚ CREATE</button>
    <button class="menu-btn exit-btn" onclick="cancelCreateWorld()">✕ CANCEL</button>
  </div>
</div>
<div class="overlay" id="worlds-overlay">
  <div class="panel" style="border:2px solid #60a5fa;min-width:260px;max-width:340px;width:84vw;">
    <h2 style="color:#60a5fa;letter-spacing:2px;text-align:center;">🌍 SELECT WORLD</h2>
    <div id="worlds-list" style="max-height:50vh;overflow-y:auto;margin:6px 0 10px;"></div>
    <button class="menu-btn exit-btn" onclick="closeWorldsOverlay()">✕ BACK</button>
  </div>
</div>
<div class="overlay" id="confirm-overlay" style="z-index:95;">
  <div class="panel" style="border:2px solid #f87171;text-align:center;min-width:230px;max-width:300px;width:78vw;">
    <h2 style="color:#f87171;letter-spacing:2px;">⚠ DELETE WORLD?</h2>
    <div id="confirm-msg" style="color:#fbb;font-size:11px;margin:8px 0;letter-spacing:1px;"></div>
    <button class="menu-btn exit-btn" onclick="confirmYes()">✓ DELETE</button>
    <button class="menu-btn play-btn" onclick="confirmNo()">✕ CANCEL</button>
  </div>
</div>
<div id="dg"></div>
<div id="respawn-overlay">
  <div id="ro-icon">🏠</div>
  <div id="ro-msg">RESPAWNING AT BASE</div>
  <div id="ro-sub">returning to pal box...</div>
</div>
<div id="save-indicator">💾 SAVED</div>
<div id="hit-flash"></div>
<div id="storm-flash"></div>
<div id="stun-flash"></div>
<div class="overlay" id="skill-overlay">
  <div class="panel" style="padding:0;overflow:hidden;">
    <div style="background:linear-gradient(135deg,#1a1200,#0d1a0d);padding:12px 16px 10px;border-bottom:1px solid #facc1530;">
      <h2 style="margin:0 0 4px;letter-spacing:3px">🌟 SKILL TREE</h2>
      <div id="skill-lvl-display" style="color:#90ccff;font-size:9px;letter-spacing:2px;text-align:center"></div>
      <div id="skill-pts" style="font-size:11px;text-align:center;margin-top:4px;min-height:18px"></div>
      <button class="panel-close" id="skill-close" style="top:10px;right:10px">✕</button>
    </div>
    <div style="padding:10px 12px;max-height:60vh;overflow-y:auto">
      <div id="skill-rows"></div>
    </div>
    <div style="padding:8px 12px 12px;border-top:1px solid #2a3a2a;">
      <div style="color:#445;font-size:8px;letter-spacing:1px;margin-bottom:5px;text-transform:uppercase">Active Stats</div>
      <div id="skill-stats" style="color:#ccc;font-size:10px;line-height:2"></div>
    </div>
  </div>
</div>

<script>
'use strict';
// ─── DIAGNOSTIC ERROR OVERLAY (renders any uncaught error visibly) ───
window.__GAME_ERR__=null;
window.addEventListener('error',function(ev){
  window.__GAME_ERR__=(ev&&ev.error&&ev.error.stack)||(ev&&ev.message)||'unknown error';
});
window.addEventListener('unhandledrejection',function(ev){window.__GAME_ERR__=String(ev.reason);});
// ─── ROBUST RELOAD ─── srcdoc iframes can mis-handle location.reload() leaving
// stale globals/timers/listeners (the root cause of world re-entry corruption).
// Ask the React parent to fully destroy + recreate the iframe for a clean slate.
window.__reloadGame=function(){
  try{
    if(window.parent && window.parent !== window){
      try{window.parent.postMessage('palworld:reload','*');}catch(_e){}
      // Fallback: if parent doesn't recreate within 350ms, do a normal reload
      setTimeout(function(){try{location.reload();}catch(_e){}},350);
    }else{
      location.reload();
    }
  }catch(e){try{location.reload();}catch(_e){}}
};
// One-shot init-failure auto-retry: if init throws and the loading screen had
// to be force-hidden, retry once with a clean iframe before giving up.
window.__INIT_RETRIED__=false;
window.__retryIfInitFailed=function(){
  if(window.__INIT_RETRIED__)return;
  if(window.__GAME_ERR__){
    window.__INIT_RETRIED__=true;
    try{sessionStorage.setItem('palworld_init_retried','1');}catch(_e){}
    window.__reloadGame();
  }
};
try{if(sessionStorage.getItem('palworld_init_retried')==='1'){window.__INIT_RETRIED__=true;sessionStorage.removeItem('palworld_init_retried');}}catch(_e){}
// ─── LOADING SCREEN — rotates tips, hidden when world is ready ───
(function(){
  const tips=[
    '🦊 Catch pals to build your team',
    '⚔️ Storm bosses spawn in plains',
    '🔥 Build campfires to survive cold nights',
    '🔬 Upgrade tech to unlock better tools',
    '🎯 Weaken pals before throwing a sphere',
    '🏠 Place a Pal Box to set your respawn',
    '🌧️ Rain helps crops but slows movement',
    '⛏ Iron tools mine ore 3× faster',
    '📘 New pals are auto-added to your Paldex',
    '🌟 Level up to earn Skill + Tech points',
  ];
  let i=Math.floor(Math.random()*tips.length);
  const el=document.getElementById('loading-tip');
  if(el){
    el.textContent=tips[i];
    window.__LOAD_TIP_TIMER__=setInterval(function(){
      const e=document.getElementById('loading-tip');if(!e||e.closest('.hide'))return;
      e.style.opacity='0';
      setTimeout(function(){i=(i+1)%tips.length;e.textContent=tips[i];e.style.opacity='1';},250);
    },2200);
  }
  // Safety net: even if init throws, never trap user behind the loading screen forever.
  // Also: if init genuinely failed, attempt one clean retry before exposing a broken world.
  window.__LOAD_FORCE_HIDE__=setTimeout(function(){
    if(window.__GAME_ERR__&&!window.__INIT_RETRIED__){window.__retryIfInitFailed();return;}
    window.hideLoadingScreen&&window.hideLoadingScreen();
  },8000);
})();
// Staged progress API — call setLoadProgress(pct, label) to update bar + stage text.
window.setLoadProgress=function(pct,label){
  try{
    const bar=document.getElementById('loading-bar-in');
    const pctEl=document.getElementById('loading-pct');
    const stEl=document.getElementById('loading-stage');
    if(bar)bar.style.width=Math.max(0,Math.min(100,pct))+'%';
    if(pctEl)pctEl.textContent=Math.round(pct)+'%';
    if(stEl&&typeof label==='string'){
      stEl.style.opacity='0';
      setTimeout(function(){stEl.textContent=label;stEl.style.opacity='1';},90);
    }
  }catch(_e){}
};
window.hideLoadingScreen=function(){
  const ov=document.getElementById('loading-overlay');if(!ov||ov.classList.contains('hide'))return;
  ov.classList.add('hide');
  if(window.__LOAD_TIP_TIMER__)clearInterval(window.__LOAD_TIP_TIMER__);
  if(window.__LOAD_FORCE_HIDE__)clearTimeout(window.__LOAD_FORCE_HIDE__);
  // Remove from DOM after fade so it can never block input
  setTimeout(function(){if(ov&&ov.parentNode)ov.parentNode.removeChild(ov);},420);
};
// ═══════════════════════════════
// SOUND SYSTEM
// ═══════════════════════════════
let sndEnabled=true;
let _AC=null;
const _sndCD={};
const _SND_CD={atk:150,hit:200,throw:300,pop:200,wood:160,stone:160,copper:160,paldeath:400,pickup:120,patatk:200};
function _getAC(){if(!_AC){try{_AC=new(window.AudioContext||window.webkitAudioContext)();}catch(e){return null;}}if(_AC.state==='suspended')_AC.resume();return _AC;}
function _canPlay(id){const now=performance.now();if(_sndCD[id]&&_sndCD[id]>now)return false;_sndCD[id]=now+(_SND_CD[id]||150);return true;}
function _pt(){return 0.9+Math.random()*0.2;}
function playSnd(id){
  if(!sndEnabled||!_canPlay(id))return;
  const ac=_getAC();if(!ac)return;
  const t=ac.currentTime;
  try{
    if(id==='atk'){
      const o=ac.createOscillator(),g=ac.createGain();
      o.type='square';o.frequency.setValueAtTime(180*_pt(),t);o.frequency.exponentialRampToValueAtTime(60,t+.09);
      g.gain.setValueAtTime(.1,t);g.gain.exponentialRampToValueAtTime(.001,t+.09);
      o.connect(g);g.connect(ac.destination);o.start(t);o.stop(t+.09);
    }else if(id==='hit'){
      const o=ac.createOscillator(),g=ac.createGain();
      const nb=ac.createBuffer(1,Math.floor(ac.sampleRate*.09),ac.sampleRate);
      const nd=nb.getChannelData(0);for(let i=0;i<nd.length;i++)nd[i]=(Math.random()*2-1)*.35;
      const ns=ac.createBufferSource();ns.buffer=nb;
      const ng=ac.createGain();ng.gain.setValueAtTime(.14,t);ng.gain.exponentialRampToValueAtTime(.001,t+.09);
      o.type='sawtooth';o.frequency.setValueAtTime(110*_pt(),t);o.frequency.exponentialRampToValueAtTime(40,t+.13);
      g.gain.setValueAtTime(.14,t);g.gain.exponentialRampToValueAtTime(.001,t+.13);
      o.connect(g);g.connect(ac.destination);ns.connect(ng);ng.connect(ac.destination);
      o.start(t);o.stop(t+.13);ns.start(t);ns.stop(t+.09);
    }else if(id==='throw'){
      const nb=ac.createBuffer(1,Math.floor(ac.sampleRate*.22),ac.sampleRate);
      const nd=nb.getChannelData(0);for(let i=0;i<nd.length;i++)nd[i]=(Math.random()*2-1)*.5;
      const ns=ac.createBufferSource();ns.buffer=nb;
      const f=ac.createBiquadFilter();f.type='bandpass';f.frequency.setValueAtTime(600,t);f.frequency.exponentialRampToValueAtTime(2600,t+.22);f.Q.value=1.2;
      const g=ac.createGain();g.gain.setValueAtTime(.001,t);g.gain.linearRampToValueAtTime(.11,t+.06);g.gain.exponentialRampToValueAtTime(.001,t+.22);
      ns.connect(f);f.connect(g);g.connect(ac.destination);ns.start(t);ns.stop(t+.22);
    }else if(id==='pop'){
      const o=ac.createOscillator(),g=ac.createGain();
      o.type='sine';o.frequency.setValueAtTime(560*_pt(),t);o.frequency.exponentialRampToValueAtTime(80,t+.18);
      g.gain.setValueAtTime(.16,t);g.gain.exponentialRampToValueAtTime(.001,t+.18);
      o.connect(g);g.connect(ac.destination);o.start(t);o.stop(t+.18);
    }else if(id==='wood'){
      const o=ac.createOscillator(),g=ac.createGain();
      o.type='triangle';o.frequency.setValueAtTime(230*_pt(),t);o.frequency.exponentialRampToValueAtTime(90,t+.11);
      g.gain.setValueAtTime(.11,t);g.gain.exponentialRampToValueAtTime(.001,t+.11);
      o.connect(g);g.connect(ac.destination);o.start(t);o.stop(t+.11);
    }else if(id==='stone'){
      const nb=ac.createBuffer(1,Math.floor(ac.sampleRate*.1),ac.sampleRate);
      const nd=nb.getChannelData(0);for(let i=0;i<nd.length;i++)nd[i]=(Math.random()*2-1)*.45;
      const ns=ac.createBufferSource();ns.buffer=nb;
      const f=ac.createBiquadFilter();f.type='lowpass';f.frequency.value=700;
      const g=ac.createGain();g.gain.setValueAtTime(.13,t);g.gain.exponentialRampToValueAtTime(.001,t+.1);
      ns.connect(f);f.connect(g);g.connect(ac.destination);ns.start(t);ns.stop(t+.1);
    }else if(id==='copper'){
      const o=ac.createOscillator(),g=ac.createGain();
      o.type='sine';o.frequency.setValueAtTime(1100*_pt(),t);o.frequency.exponentialRampToValueAtTime(280,t+.26);
      g.gain.setValueAtTime(.09,t);g.gain.exponentialRampToValueAtTime(.001,t+.26);
      o.connect(g);g.connect(ac.destination);o.start(t);o.stop(t+.26);
    }else if(id==='paldeath'){
      const o=ac.createOscillator(),g=ac.createGain();
      o.type='sine';o.frequency.setValueAtTime(380*_pt(),t);o.frequency.exponentialRampToValueAtTime(70,t+.28);
      g.gain.setValueAtTime(.09,t);g.gain.exponentialRampToValueAtTime(.001,t+.28);
      o.connect(g);g.connect(ac.destination);o.start(t);o.stop(t+.28);
    }else if(id==='pickup'){
      const o=ac.createOscillator(),g=ac.createGain();
      o.type='sine';const p1=840*_pt();o.frequency.setValueAtTime(p1,t);o.frequency.setValueAtTime(p1*1.25,t+.04);
      g.gain.setValueAtTime(.07,t);g.gain.exponentialRampToValueAtTime(.001,t+.18);
      o.connect(g);g.connect(ac.destination);o.start(t);o.stop(t+.18);
    }else if(id==='patatk'){
      const o=ac.createOscillator(),g=ac.createGain();
      o.type='sawtooth';o.frequency.setValueAtTime(260*_pt(),t);o.frequency.exponentialRampToValueAtTime(100,t+.07);
      g.gain.setValueAtTime(.06,t);g.gain.exponentialRampToValueAtTime(.001,t+.07);
      o.connect(g);g.connect(ac.destination);o.start(t);o.stop(t+.07);
    }else if(id==='click'){
      const o=ac.createOscillator(),g=ac.createGain();
      o.type='triangle';o.frequency.setValueAtTime(620*_pt(),t);o.frequency.exponentialRampToValueAtTime(420,t+.05);
      g.gain.setValueAtTime(.05,t);g.gain.exponentialRampToValueAtTime(.001,t+.06);
      o.connect(g);g.connect(ac.destination);o.start(t);o.stop(t+.06);
    }
  }catch(e){}
}
// ── Audio warm-up (runs always, no snd-btn dependency)
(function(){const warmUp=()=>{_getAC();};document.addEventListener('touchstart',warmUp,{once:true,passive:true});document.addEventListener('mousedown',warmUp,{once:true});})();

// ─── WEATHER SOUND SYSTEM ─────────────────────────────────────────────
const _WXSnd=(function(){
  let _rSrc=null,_rGain=null,_stGain=null,_ready=false;
  function _mkNoise(ac,dur){
    const sr=ac.sampleRate,b=ac.createBuffer(1,Math.floor(sr*dur),sr),d=b.getChannelData(0);
    for(let i=0;i<d.length;i++)d[i]=(Math.random()*2-1);return b;
  }
  function _init(){
    const ac=_getAC();if(!ac||_ready)return;
    try{
      const rSrc=ac.createBufferSource();rSrc.buffer=_mkNoise(ac,3);rSrc.loop=true;
      const rbpf=ac.createBiquadFilter();rbpf.type='bandpass';rbpf.frequency.value=1800;rbpf.Q.value=0.55;
      _rGain=ac.createGain();_rGain.gain.value=0;
      rSrc.connect(rbpf);rbpf.connect(_rGain);_rGain.connect(ac.destination);rSrc.start();
      _rSrc=rSrc;
      const stSrc=ac.createBufferSource();stSrc.buffer=_mkNoise(ac,5);stSrc.loop=true;
      const slpf=ac.createBiquadFilter();slpf.type='lowpass';slpf.frequency.value=220;
      _stGain=ac.createGain();_stGain.gain.value=0;
      stSrc.connect(slpf);slpf.connect(_stGain);_stGain.connect(ac.destination);stSrc.start();
      _ready=true;
    }catch(e){_ready=false;}
  }
  function setAlpha(state,alpha){
    if(!sndEnabled){if(_rGain)_rGain.gain.value=0;if(_stGain)_stGain.gain.value=0;return;}
    _init();if(!_ready)return;
    const tR=(state==='Rain')?0.13*alpha:(state==='Storm')?0.07*alpha:0;
    const tS=(state==='Storm')?0.18*alpha:0;
    _rGain.gain.value=tR;_stGain.gain.value=tS;
  }
  function thunder(){
    if(!sndEnabled)return;const ac=_getAC();if(!ac)return;const t=ac.currentTime;
    try{
      // ── LAYER 1: Instant powerful boom (no delay) ──
      // Low sawtooth sweep → the main rolling thunder
      const o=ac.createOscillator(),og=ac.createGain();
      o.type='sawtooth';o.frequency.setValueAtTime(78,t);o.frequency.exponentialRampToValueAtTime(22,t+2.2);
      og.gain.setValueAtTime(0,t);og.gain.linearRampToValueAtTime(0.50,t+0.025);og.gain.exponentialRampToValueAtTime(0.001,t+2.2);
      o.connect(og);og.connect(ac.destination);o.start(t);o.stop(t+2.2);
      // Noise underlayer for crack body
      const nb=ac.createBuffer(1,Math.floor(ac.sampleRate*0.12),ac.sampleRate);
      const nd=nb.getChannelData(0);for(let i=0;i<nd.length;i++)nd[i]=(Math.random()*2-1);
      const ns=ac.createBufferSource();ns.buffer=nb;
      const nlp=ac.createBiquadFilter();nlp.type='lowpass';nlp.frequency.value=600;
      const ng=ac.createGain();ng.gain.setValueAtTime(0.80,t);ng.gain.exponentialRampToValueAtTime(0.001,t+0.12);
      ns.connect(nlp);nlp.connect(ng);ng.connect(ac.destination);ns.start(t);ns.stop(t+0.12);
      // ── LAYER 3: Optional heavy ground hit (30% chance, +80ms) ──
      if(Math.random()<0.30){
        const td=t+0.080;
        const o2=ac.createOscillator(),og2=ac.createGain();
        o2.type='sawtooth';o2.frequency.setValueAtTime(55,td);o2.frequency.exponentialRampToValueAtTime(14,td+1.6);
        og2.gain.setValueAtTime(0,td);og2.gain.linearRampToValueAtTime(0.38,td+0.020);og2.gain.exponentialRampToValueAtTime(0.001,td+1.6);
        o2.connect(og2);og2.connect(ac.destination);o2.start(td);o2.stop(td+1.6);
        // Low rumble noise for extra weight
        const rb=ac.createBuffer(1,Math.floor(ac.sampleRate*0.20),ac.sampleRate);
        const rd=rb.getChannelData(0);for(let i=0;i<rd.length;i++)rd[i]=(Math.random()*2-1);
        const rs=ac.createBufferSource();rs.buffer=rb;
        const rlp=ac.createBiquadFilter();rlp.type='lowpass';rlp.frequency.value=180;
        const rg=ac.createGain();rg.gain.setValueAtTime(0.45,td);rg.gain.exponentialRampToValueAtTime(0.001,td+0.20);
        rs.connect(rlp);rlp.connect(rg);rg.connect(ac.destination);rs.start(td);rs.stop(td+0.20);
      }
    }catch(e){}
  }
  return{setAlpha,thunder};
})();

// ── Settings panel
function openSettings(){gamePaused=true;document.getElementById('settings-overlay').classList.add('show');_syncSndToggle();}
function closeSettings(){
  // Don't unpause if pause menu is also showing
  const pmShown=document.getElementById('pause-menu').classList.contains('show');
  const smShown=document.getElementById('start-menu').classList.contains('show');
  gamePaused=pmShown||smShown;
  document.getElementById('settings-overlay').classList.remove('show');
}
// ── Start / Pause / Exit menu system
function _refreshContinueBtn(){try{const has=listWorlds().length>0;const c=document.getElementById('continue-btn');if(c)c.classList.toggle('disabled',!has);}catch(e){}}
function startNewGame(){
  playSnd('click');
  document.getElementById('start-menu').classList.remove('show');
  const inp=document.getElementById('world-name-input');if(inp)inp.value='';
  document.getElementById('create-world-overlay').classList.add('show');
  setTimeout(()=>{try{inp&&inp.focus();}catch(e){}},150);
}
function cancelCreateWorld(){
  playSnd('click');
  document.getElementById('create-world-overlay').classList.remove('show');
  document.getElementById('start-menu').classList.add('show');
}
function confirmCreateWorld(){
  playSnd('click');
  const inp=document.getElementById('world-name-input');
  const id=createWorld(inp?inp.value:'');
  setActiveWorld(id);
  document.getElementById('create-world-overlay').classList.remove('show');
  // Reload to start fresh, clean state (parent-mediated full iframe reset)
  window.__reloadGame();
}
function continueGame(){
  playSnd('click');
  document.getElementById('start-menu').classList.remove('show');
  renderWorldsList();
  document.getElementById('worlds-overlay').classList.add('show');
}
function closeWorldsOverlay(){
  playSnd('click');
  document.getElementById('worlds-overlay').classList.remove('show');
  document.getElementById('start-menu').classList.add('show');
}
function _fmtPlayTime(ms){
  if(!ms||ms<60000)return '0m';
  const m=Math.floor(ms/60000);
  if(m<60)return m+'m';
  const h=Math.floor(m/60);return h+'h '+(m%60)+'m';
}
function _fmtAgo(ts){
  if(!ts)return '';
  const s=Math.floor((Date.now()-ts)/1000);
  if(s<60)return 'just now';
  const m=Math.floor(s/60);if(m<60)return m+'m ago';
  const h=Math.floor(m/60);if(h<24)return h+'h ago';
  const d=Math.floor(h/24);return d+'d ago';
}
function renderWorldsList(){
  const list=document.getElementById('worlds-list');
  if(!list)return;
  const worlds=listWorlds().slice().sort((a,b)=>(b.lastPlayed||0)-(a.lastPlayed||0));
  if(worlds.length===0){list.innerHTML='<div class="no-worlds">— No worlds found —<br><span style="font-size:9px">Tap BACK, then NEW GAME.</span></div>';return;}
  list.innerHTML='';
  for(const w of worlds){
    const row=document.createElement('div');row.className='world-item';
    const left=document.createElement('div');left.style.flex='1';left.style.minWidth='0';
    const nm=document.createElement('div');nm.className='wname';nm.textContent='🌍 '+w.name;left.appendChild(nm);
    const meta=document.createElement('div');meta.className='wmeta';meta.textContent='Lv '+(w.level||1)+' · '+_fmtPlayTime(w.playMs)+' · '+_fmtAgo(w.lastPlayed);left.appendChild(meta);
    const playBtn=document.createElement('button');playBtn.className='wbtn';playBtn.textContent='▶ PLAY';
    playBtn.addEventListener('click',()=>{playSnd('click');setActiveWorld(w.id);window.__reloadGame();});
    const delBtn=document.createElement('button');delBtn.className='wbtn del';delBtn.textContent='🗑';
    delBtn.addEventListener('click',()=>askDeleteWorld(w.id,w.name));
    row.appendChild(left);row.appendChild(playBtn);row.appendChild(delBtn);
    list.appendChild(row);
  }
}
let _pendingDeleteId=null;
function askDeleteWorld(id,name){
  playSnd('click');
  _pendingDeleteId=id;
  document.getElementById('confirm-msg').textContent='"'+name+'" will be permanently lost.';
  document.getElementById('confirm-overlay').classList.add('show');
}
function confirmYes(){
  playSnd('click');
  if(_pendingDeleteId){deleteWorldById(_pendingDeleteId);_pendingDeleteId=null;}
  document.getElementById('confirm-overlay').classList.remove('show');
  renderWorldsList();
  // If deleting last world, jump back to start menu
  if(listWorlds().length===0){
    document.getElementById('worlds-overlay').classList.remove('show');
    _refreshContinueBtn();
    document.getElementById('start-menu').classList.add('show');
  }
}
function confirmNo(){
  playSnd('click');
  _pendingDeleteId=null;
  document.getElementById('confirm-overlay').classList.remove('show');
}
function openPauseMenu(){
  if(document.getElementById('start-menu').classList.contains('show'))return;
  if(PL.dead)return;
  playSnd('click');
  gamePaused=true;
  document.getElementById('pause-menu').classList.add('show');
}
function closePauseMenu(){
  playSnd('click');
  document.getElementById('pause-menu').classList.remove('show');
  gamePaused=false;
}
function pauseToSettings(){
  playSnd('click');
  document.getElementById('pause-menu').classList.remove('show');
  openSettings();
}
function exitToMenu(){
  playSnd('click');
  try{saveGame();}catch(e){}
  clearActiveWorld();
  // Reload for a clean slate so leftover state doesn't leak into next world
  window.__reloadGame();
}
function _syncSndToggle(){const t=document.getElementById('snd-toggle');if(t)t.classList.toggle('on',sndEnabled);const pmA=document.getElementById('pm-audio-btn');if(pmA)pmA.textContent=sndEnabled?'🔊 AUDIO: ON':'🔇 AUDIO: OFF';}
function openQuestOverlay(){const ov=document.getElementById('quest-overlay');if(!ov)return;try{playSnd('click');}catch(e){}const tracker=document.getElementById('prog-tracker');const body=document.getElementById('quest-overlay-body');const empty=document.getElementById('quest-empty');if(tracker&&body&&tracker.parentNode!==body){body.appendChild(tracker);}if(empty&&tracker)empty.style.display=tracker.children.length?'none':'block';ov.classList.add('show');const qb=document.getElementById('tl-quest-btn');if(qb)qb.classList.remove('has-new');}
function closeQuestOverlay(){const ov=document.getElementById('quest-overlay');if(!ov)return;try{playSnd('click');}catch(e){}ov.classList.remove('show');}
function flagQuestNew(){const qb=document.getElementById('tl-quest-btn');const ov=document.getElementById('quest-overlay');if(qb&&ov&&!ov.classList.contains('show'))qb.classList.add('has-new');}
(function(){
  function _openS(e){if(e&&e.cancelable)e.preventDefault();openSettings();}
  const sClose=document.getElementById('settings-close');
  sClose.addEventListener('click',closeSettings);
  sClose.addEventListener('touchstart',e=>{e.preventDefault();closeSettings();},{passive:false});
  const sndT=document.getElementById('snd-toggle');
  function _togSnd(e){if(e&&e.cancelable)e.preventDefault();sndEnabled=!sndEnabled;_syncSndToggle();try{if(typeof saveGame==='function'&&activeWorldId)saveGame();}catch(_e){}}
  sndT.addEventListener('click',_togSnd);
  sndT.addEventListener('touchstart',_togSnd,{passive:false});
  // Close on backdrop click
  document.getElementById('settings-overlay').addEventListener('click',e=>{if(e.target===document.getElementById('settings-overlay'))closeSettings();});
  // ── Menu shortcut buttons (Inventory / Save / Help / Exit) ──
  function _wireMenu(id,fn){const b=document.getElementById(id);if(!b)return;b.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();fn();});b.addEventListener('touchstart',e=>{e.preventDefault();e.stopPropagation();fn();},{passive:false});}
  _wireMenu('menu-inv',()=>{closeSettings();try{openInvOverlay('inv');}catch(e){}});
  _wireMenu('menu-save',()=>{try{saveGame();spawnPop&&spawnPop('💾 Game saved','#4aff78');}catch(e){}});
  _wireMenu('menu-help',()=>{const h=document.getElementById('help-panel');if(!h)return;h.style.display=h.style.display==='none'?'block':'none';});
  _wireMenu('menu-exit',()=>{if(confirm('Exit to title screen? (game will be saved first)')){try{exitToMenu();}catch(e){location.reload();}}});
  // ── New top-left buttons (Pause + Quest + Dungeon Cancel) ──
  _wireMenu('tl-pause-btn',()=>openPauseMenu());
  _wireMenu('tl-quest-btn',()=>openQuestOverlay());
  _wireMenu('dungeon-cancel-btn',()=>{if(typeof cancelDungeon==='function')cancelDungeon();});
  // ── Pause-menu extras (Save / Audio / Help) — SCROLL-SAFE bindings.
  // touchstart does NOT preventDefault, allowing the panel to pan-y scroll
  // through the button. fn() fires only on a clean tap (no drag) via touchend.
  function _wireMenuScrollSafe(id,fn){
    const b=document.getElementById(id);if(!b)return;
    let sy=0,sx=0,moved=false;
    b.addEventListener('touchstart',e=>{const t=e.changedTouches[0];sy=t.clientY;sx=t.clientX;moved=false;},{passive:true});
    b.addEventListener('touchmove',e=>{const t=e.changedTouches[0];if(Math.abs(t.clientY-sy)>8||Math.abs(t.clientX-sx)>8)moved=true;},{passive:true});
    b.addEventListener('touchend',e=>{if(!moved){e.preventDefault();e.stopPropagation();fn();}},{passive:false});
    b.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();fn();});
  }
  _wireMenuScrollSafe('pm-save-btn',()=>{try{saveGame();spawnPop&&spawnPop('💾 Game saved','#4aff78');}catch(e){}});
  _wireMenuScrollSafe('pm-audio-btn',()=>{sndEnabled=!sndEnabled;_syncSndToggle();try{if(typeof saveGame==='function'&&activeWorldId)saveGame();}catch(_e){}});
  _wireMenuScrollSafe('pm-help-btn',()=>{const h=document.getElementById('pm-help-panel');if(!h)return;h.style.display=h.style.display==='none'?'block':'none';});
  // ── Panel-level scroll arbiter — suppresses click on inline-onclick buttons
  // (Resume / Settings / Exit) when the user dragged to scroll the panel. ──
  (function(){
    const panel=document.querySelector('#pause-menu .panel');if(!panel)return;
    let sy=0,sx=0,dragged=false,touching=false;
    panel.addEventListener('touchstart',e=>{const t=e.changedTouches[0];sy=t.clientY;sx=t.clientX;dragged=false;touching=true;},{passive:true,capture:true});
    panel.addEventListener('touchmove',e=>{const t=e.changedTouches[0];if(Math.abs(t.clientY-sy)>8||Math.abs(t.clientX-sx)>8)dragged=true;},{passive:true,capture:true});
    panel.addEventListener('touchend',()=>{setTimeout(()=>{touching=false;dragged=false;},350);},{passive:true,capture:true});
    panel.addEventListener('click',e=>{if(touching&&dragged){e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();}},{capture:true});
  })();
  // ── Quest overlay close + backdrop ──
  _wireMenu('quest-close',()=>closeQuestOverlay());
  const qov=document.getElementById('quest-overlay');
  if(qov)qov.addEventListener('click',e=>{if(e.target===qov)closeQuestOverlay();});
  // initial audio label sync
  try{_syncSndToggle();}catch(e){}
})();

// ═══════════════════════════════
// SCREEN SHAKE + HIT STOP
// ═══════════════════════════════
let _shakeT=0,_shakeAmp=0;
let _hitStopT=0;
function doShake(amp){if(typeof gamePaused!=='undefined'&&gamePaused)return;const a=Math.min(amp,11);if(_shakeT>0&&_shakeAmp>=a)return;_shakeAmp=a;_shakeT=80;}
function lightShake(amp){if(typeof gamePaused!=='undefined'&&gamePaused)return;const a=Math.min(amp||3,4);if(_shakeT>0&&_shakeAmp>=a)return;_shakeAmp=a;_shakeT=55;}
function doHitStop(ms=70){if(typeof gamePaused!=='undefined'&&gamePaused)return;_hitStopT=Math.min(ms,140);}
function updShake(dt){
  if(_shakeT>0){
    _shakeT=Math.max(0,_shakeT-dt);
    const f=_shakeT/80;
    const sx=(_shakeAmp*f*(Math.random()-.5)*2).toFixed(2);
    const sy=(_shakeAmp*f*(Math.random()-.5)*2).toFixed(2);
    canvas.style.transform='translate('+sx+'px,'+sy+'px)';
  }else if(_shakeT===0&&canvas.style.transform){
    canvas.style.transform='';
  }
}

// ═══════════════════════════════
// ORIENTATION
// ═══════════════════════════════
let gamePaused=false;
function checkOri(){const p=window.innerHeight>window.innerWidth;gamePaused=p;document.getElementById('rotate-overlay').classList.toggle('show',p);}
checkOri();window.addEventListener('resize',()=>{checkOri();resizeCanvas();});
// MOBILE RESUME / VISIBILITY FIX — when tab/app comes back, repaint immediately
// and reset the timestep so the first post-resume dt isn't a giant jump.
(function _wireResume(){
  function _onResume(){
    try{checkOri();}catch(_e){}
    try{resizeCanvas();}catch(_e){}
    // Reset frame timestamp so gameLoop's dt is clamped on next frame
    try{lastT=0;}catch(_e){}
    // Force a redraw on the very next frame
    try{requestAnimationFrame(function(){
      try{ctx.setTransform(1,0,0,1,0,0);ctx.globalAlpha=1;ctx.clearRect(0,0,VW,VH);}catch(_e){}
    });}catch(_e){}
  }
  document.addEventListener('visibilitychange',function(){if(!document.hidden)_onResume();});
  window.addEventListener('pageshow',_onResume);
  window.addEventListener('focus',_onResume);
  window.addEventListener('orientationchange',function(){setTimeout(_onResume,120);});
})();

// ═══════════════════════════════
// CANVAS
// ═══════════════════════════════
const canvas=document.getElementById('gameCanvas'),ctx=canvas.getContext('2d');
let VW=0,VH=0;
let _vignetteGrad=null;
function resizeCanvas(){VW=Math.min(window.innerWidth,700);VH=Math.min(window.innerHeight,470);canvas.width=VW;canvas.height=VH;canvas.style.width=VW+'px';canvas.style.height=VH+'px';_vignetteGrad=null;}
resizeCanvas();
function drawAtmosphere(){
  // Subtle vignette + day warmth — cached gradient for perf
  if(!_vignetteGrad){
    _vignetteGrad=ctx.createRadialGradient(VW/2,VH/2,Math.min(VW,VH)*0.35,VW/2,VH/2,Math.max(VW,VH)*0.78);
    _vignetteGrad.addColorStop(0,'rgba(0,0,0,0)');
    _vignetteGrad.addColorStop(0.65,'rgba(0,0,0,0.06)');
    _vignetteGrad.addColorStop(1,'rgba(0,0,0,0.32)');
  }
  ctx.fillStyle=_vignetteGrad;ctx.fillRect(0,0,VW,VH);
  // Daytime warm tint (only during day phase)
  if(typeof TimeSys!=='undefined'&&TimeSys.phase==='day'){
    ctx.fillStyle='rgba(255,210,140,0.045)';ctx.fillRect(0,0,VW,VH);
  }
}

// ═══════════════════════════════
// BIOME SYSTEM
// ═══════════════════════════════
// Large continuous biome regions via Voronoi seed points
// Biomes: 0=Grassland, 1=Rocky, 2=Copper, 3=Forest
const BIOMES=[
  {id:0,name:'🌿 GRASSLAND',colors:['#1e4a14','#2d5a1e'],dotColors:['#255218','#336622'],mmColor:'#2a6a18'},
  {id:1,name:'🪨 ROCKY',colors:['#3a3a2a','#4a4a36'],dotColors:['#555545','#606050'],mmColor:'#665544'},
  {id:2,name:'🟠 COPPER',colors:['#4a2e0a','#5a3812'],dotColors:['#6a4018','#7a5020'],mmColor:'#a05820'},
  {id:3,name:'🌲 DENSE FOREST',colors:['#0e2e0a','#1a3e12'],dotColors:['#142a10','#1e3a18'],mmColor:'#1a5010'},
  {id:4,name:'☠️ DANGER ZONE',colors:['#1a0808','#240d0d'],dotColors:['#3a0e0e','#4a1212'],mmColor:'#881111'},
  {id:5,name:'🌾 HIGHLAND PLAINS',colors:['#5a6a1a','#6e7e26'],dotColors:['#7a8830','#8a983c'],mmColor:'#9aaa3a'},
  {id:6,name:'🧊 ICE',colors:['#1e3a5a','#2a4e72'],dotColors:['#2e5882','#3a6a96'],mmColor:'#4488cc'},
  {id:7,name:'🔥 FIRE',colors:['#5a1a08','#7a2a0e'],dotColors:['#8a2010','#a83010'],mmColor:'#cc3311'},
];

// ── REGION-BASED BIOME GENERATION ──────────────────────────────────────────
// Layout matches reference image:
//   CENTER         → Grassland (0)
//   UPPER ring     → Rocky (1)        LOWER ring → Dense Forest (3)
//   WEST outer     → Copper (2)       NW outer   → Highland Plains (5)
//   NE outer       → Ice (6)          EAST outer → Fire (7)
//   DEEP SOUTH     → Danger Zone (4)
// Uses angle+distance from center for clean, large, connected regions.
// Organic noise added only at border zones to avoid straight geometry edges.
const TILE=32,COLS=384,ROWS=288,MAP_W=COLS*TILE,MAP_H=ROWS*TILE,ZOOM=1.65;
// Zones: 0=Starter(center), 1=Mid, 2=Danger(edge) — kept for boss zone compat
function getZoneType(wx2,wy2){const dx=(wx2/MAP_W-0.5)*2,dy=(wy2/MAP_H-0.5)*2;const nd=Math.max(Math.abs(dx),Math.abs(dy));if(nd<0.25)return 0;if(nd<0.55)return 1;return 2;}
const ZONE_NAMES=['🌱 STARTER ZONE','⚔️ MID ZONE','☠️ DANGER ZONE'];
const ZONE_COLORS=['#4aff78','#facc15','#ff4444'];
function getBiomeAt(wx2,wy2){
  // Normalize to -0.5..0.5 with center=0
  const fx=wx2/MAP_W-0.5,fy=wy2/MAP_H-0.5;
  const dist=Math.hypot(fx,fy);
  // Screen-space angle: 0=East, π/2=South(down), -π/2=North(up), ±π=West
  const angle=Math.atan2(fy,fx);
  // Soft organic noise — only perturbs borders, never changes region cores
  const n=(Math.sin(wx2/160+wy2/120)*0.5+Math.cos(wx2/100-wy2/150)*0.5)*0.024;
  const nd=dist+n;          // noisy distance
  const na=angle+n*0.8;     // noisy angle (slight sector wobble)
  const PI=Math.PI;
  // ── Grassland: center core ──────────────────────────────────────────────
  if(nd<0.13)return 0;
  // ── Danger Zone: deep south outer edge ──────────────────────────────────
  if(nd>0.65)return 4;                       // extreme outer everywhere
  if(nd>0.54&&fy>0.10)return 4;             // southern outer wedge
  // ── Inner ring (nd 0.13-0.28): Rocky=north / Dense Forest=south ─────────
  if(nd<0.28)return(fy+n*0.3<0)?1:3;
  // ── Outer sectors by angle (nd >= 0.28) ────────────────────────────────
  const a=na;
  if(a>PI*0.76||a<-PI*0.78)return 2;                          // West → Copper
  if(a>=-PI*0.78&&a<-PI*0.52)return 5;                        // NW  → Highland Plains
  if(a>=-PI*0.52&&a<-PI*0.16)return 1;                        // N   → Rocky
  if(a>=-PI*0.16&&a<PI*0.16)return nd<0.42?1:6;               // NE  → Rocky close-in, Ice far
  if(a>=PI*0.16&&a<PI*0.52)return nd<0.42?3:7;                // E   → Forest close-in, Fire far
  return 3;                                                    // S   → Dense Forest (before Danger)
}
// Pre-compute biome per tile for performance
const biomeMap=[];
for(let r=0;r<ROWS;r++){biomeMap[r]=[];for(let c=0;c<COLS;c++)biomeMap[r][c]=getBiomeAt(c*TILE,r*TILE);}

// Get biome at player position (tile coords)
function getPlayerBiome(){
  const c=Math.floor(PL.x/TILE),r=Math.floor(PL.y/TILE);
  if(c<0||r<0||c>=COLS||r>=ROWS)return 0;
  return biomeMap[r][c];
}
let _lastBiomeId=-1,_curZone=-1;
// Biome entry notification cooldown — prevents popup spam at borders
let _biomeNotifId=-1,_biomeNotifCD=0;
const BIOME_NOTIF_CD=12000; // ms between biome entry popups
const BIOME_ENTRY_MSGS=[
  '🌿 Grassland','⛰️ Rocky Highlands','🪨 Copper Flats',
  '🌲 Dense Forest','☠️ Entering DANGER ZONE — beware!','🏔️ Highland Plains','❄️ Ice Fields','🔥 Fire Wastes',
];
const BIOME_ENTRY_COLORS=['#4aff78','#aabb88','#cc9944','#44bb44','#ff4444','#88cc88','#88ccff','#ff6622'];

// ═══════════════════════════════
// DAY / NIGHT CYCLE (lightweight)
// ═══════════════════════════════
// Full cycle ≈ 7 minutes. Phases: Day(50%≈3.5m) → Evening(10%≈42s) → Night(30%≈2.1m) → Dawn(10%≈42s)
const DAY_LEN=420000; // 7 minutes per full cycle (immersive pacing)
const TimeSys={t:0,phase:'day',label:'☀️ DAY'};
let _lastTimePhase='';
function _phaseFromT(t){
  const f=(t%DAY_LEN)/DAY_LEN; // 0..1
  if(f<0.50)return 'day';
  if(f<0.60)return 'evening';
  if(f<0.90)return 'night';
  return 'dawn';
}
// 0 = full bright, 1 = deepest night — used for overlay alpha
// Smooth ease-in/out everywhere to avoid abrupt brightness jumps.
function _ease(x){return x*x*(3-2*x);} // smoothstep
function getNightFactor(){
  const f=(TimeSys.t%DAY_LEN)/DAY_LEN;
  if(f<0.50)return 0;                                      // day = bright
  if(f<0.60)return _ease((f-0.50)/0.10)*0.58;              // evening fade-in
  if(f<0.90){                                              // night plateau with gentle peak
    const np=(f-0.60)/0.30; // 0..1 across night
    return 0.58+Math.sin(np*Math.PI)*0.12;                 // 0.58..0.70..0.58
  }
  return Math.max(0,0.58*(1-_ease((f-0.90)/0.10)));        // dawn fade-out
}
function isNight(){return TimeSys.phase==='night';}
function updTime(dt){
  TimeSys.t+=dt;
  const ph=_phaseFromT(TimeSys.t);
  if(ph!==TimeSys.phase){
    TimeSys.phase=ph;
    TimeSys.label=ph==='day'?'☀️ DAY':ph==='evening'?'🌇 EVENING':ph==='night'?'🌙 NIGHT':'🌅 DAWN';
    if(ph!==_lastTimePhase){
      _lastTimePhase=ph;
      const el=document.getElementById('time-label');
      if(el){el.textContent=TimeSys.label;el.style.color=ph==='night'?'#88aaff':ph==='evening'?'#ff9944':ph==='dawn'?'#ffcc66':'#ffe066';}
      if(ph==='night')spawnPop('🌙 Night falls — pals grow restless...','#88aaff');
      else if(ph==='day')spawnPop('☀️ Dawn breaks','#ffe066');
    }
  }
}
function drawDayNightOverlay(){
  const nf=getNightFactor();
  if(nf<=0.001)return;
  // Evening = warm orange tint, Night = cool dark blue
  const ph=TimeSys.phase;
  if(ph==='evening'||ph==='dawn'){
    ctx.fillStyle='rgba(255,120,40,'+(nf*0.30).toFixed(3)+')';
    ctx.fillRect(0,0,VW,VH);
  }else{
    ctx.fillStyle='rgba(8,12,40,'+(nf*0.55).toFixed(3)+')';
    ctx.fillRect(0,0,VW,VH);
  }
}

// ═══════════════════════════════
// WEATHER SYSTEM — gameplay-driven, mobile-friendly
// ═══════════════════════════════
const WEATHER_STATES=['Clear','Rain','Fog','Storm','Heat'];
const WEATHER_ICONS={Clear:'☀',Rain:'🌧',Fog:'🌫',Storm:'⚡',Heat:'🔥',Night:'🌙',BloodMoon:'🌕'};
const WEATHER_COLORS={Clear:'#ffe066',Rain:'#88ccff',Fog:'#cdd5dc',Storm:'#cc88ff',Heat:'#ff9944',Night:'#88aaff',BloodMoon:'#ff4444'};
const WX={
  state:'Clear',
  alpha:0,
  t:0,
  dur:180000,
  rainParts:[],
  lightningT:5000,
  flashAlpha:0,
  grassT:0,
  _popShown:true,
  // New: post-rain rainbow timer (ms remaining)
  rainbowT:0,
  // New: ground lightning strikes — array of {x,y,phase,life} where phase 0 = warning marker, 1 = bolt, 2 = afterglow
  bolts:[],
  // New: heat shimmer offset
  heatT:0,
  // New: blood moon flag for current night
  bloodMoon:false,
  _lastNightPhase:false,
  // New: smooth color tween for HUD label
  _hudCol:'#ffe066'
};
const WX_MIN_DUR=90000;
const WX_MAX_DUR=240000;
function _wxPickNext(){
  // Weighted pool: Clear=4, Rain=2, Fog=2, Heat=2, Storm=1
  const pool=['Clear','Clear','Clear','Clear','Rain','Rain','Fog','Fog','Heat','Heat','Storm'];
  let s;let tries=0;
  do{s=pool[Math.floor(Math.random()*pool.length)];tries++;}while(s===WX.state&&tries<8);
  return s;
}
// ─── Public helpers used by other systems ───
function wxActive(s){return WX.state===s&&WX.alpha>0.30;}
function wxMoveSpdMul(){return wxActive('Clear')?1.05:1;}
function wxHungerMul(){
  // Rain = slower drain, Storm = faster (cold), Heat = much faster (thirst)
  if(wxActive('Heat'))return 1.35;
  if(wxActive('Storm'))return 1.30;
  if(wxActive('Rain'))return 0.85;
  return 1;
}
function wxPalDmgMul(elem){
  if(!elem)return 1;
  if(wxActive('Heat')){if(elem==='fire')return 1.25;if(elem==='ice')return 0.80;}
  if(wxActive('Rain')){if(elem==='fire')return 0.80;if(elem==='electric'||elem==='storm')return 1.20;}
  if(wxActive('Storm')){if(elem==='electric'||elem==='storm')return 1.30;if(elem==='fire')return 0.85;}
  if(WX.bloodMoon&&isNight&&isNight()){if(elem==='dark')return 1.20;}
  return 1;
}
function wxAggroMul(){
  // Fog hides player a bit — pals notice you later
  if(wxActive('Fog'))return 0.75;
  if(WX.bloodMoon&&isNight&&isNight())return 1.20;
  return 1;
}
function wxHarvestBonus(type){
  // Clear = +1 wood ~30% chance; Rain = +1 to wood/stone ~25% (wet abundant growth)
  if(wxActive('Clear')&&type==='wood'&&Math.random()<0.30)return 1;
  if(wxActive('Rain')&&(type==='wood'||type==='stone')&&Math.random()<0.25)return 1;
  if(wxActive('Heat')&&(type==='copper'||type==='coal')&&Math.random()<0.30)return 1; // rocky/desert loot bonus
  return 0;
}
function wxRareSpawnBoost(){return wxActive('Fog')?1:0;}
// Trigger a ground lightning strike near player (warning marker → bolt)
function _wxSpawnBolt(){
  if(WX.bolts.length>=2)return;
  const margin=60;
  const sx=margin+Math.random()*(VW-margin*2);
  const sy=margin+Math.random()*(VH-margin*2);
  WX.bolts.push({x:sx,y:sy,phase:0,life:900}); // warning ~0.9s
}
function updWeather(dt){
  if(!dt)return;
  WX.grassT+=dt*0.0012;
  WX.heatT+=dt*0.001;
  // Sync blood moon flag with night phase (rare ~6%)
  const _curNight=(typeof isNight==='function')&&isNight();
  if(_curNight&&!WX._lastNightPhase){
    WX.bloodMoon=Math.random()<0.06;
    if(WX.bloodMoon&&typeof spawnPop==='function')setTimeout(()=>spawnPop('🌕 Blood Moon rises…','#ff4444'),400);
  }else if(!_curNight&&WX._lastNightPhase){
    WX.bloodMoon=false;
  }
  WX._lastNightPhase=_curNight;
  // Lightning countdown (storm only, once intensity is up)
  if(WX.state==='Storm'&&WX.alpha>0.35){
    WX.lightningT=Math.max(0,WX.lightningT-dt);
    if(WX.lightningT<=0){
      WX.flashAlpha=0.60;
      _WXSnd.thunder();
      WX.lightningT=4000+Math.random()*8000;
      if(typeof doShake==='function')doShake(3);
      // ~50% chance the flash is paired with a ground strike
      if(Math.random()<0.55)_wxSpawnBolt();
    }
  }
  // Update ground bolts
  for(let i=WX.bolts.length-1;i>=0;i--){
    const b=WX.bolts[i];b.life-=dt;
    if(b.phase===0&&b.life<=0){b.phase=1;b.life=140;if(typeof doShake==='function')doShake(4);}
    else if(b.phase===1&&b.life<=0){b.phase=2;b.life=350;}
    else if(b.phase===2&&b.life<=0){WX.bolts.splice(i,1);}
  }
  if(WX.flashAlpha>0)WX.flashAlpha=Math.max(0,WX.flashAlpha-dt*0.0035);
  // Rainbow lifetime decay (post-rain)
  if(WX.rainbowT>0)WX.rainbowT=Math.max(0,WX.rainbowT-dt);
  // Rain/storm particles (screen-space only, capped for mobile)
  if((WX.state==='Rain'||WX.state==='Storm')&&WX.alpha>0.1){
    const cap=WX.state==='Storm'?90:60;
    const add=WX.state==='Storm'?3:2;
    for(let i=0;i<add;i++){
      if(WX.rainParts.length>=cap)break;
      WX.rainParts.push({
        x:Math.random()*VW,y:-8,
        vx:WX.state==='Storm'?(-2.2-Math.random()*1.5):(-0.4-Math.random()*0.6),
        vy:5+Math.random()*4,
        len:WX.state==='Storm'?(9+Math.random()*5):(5+Math.random()*3)
      });
    }
  }
  // Advance particle positions, remove off-screen
  for(let i=WX.rainParts.length-1;i>=0;i--){
    const p=WX.rainParts[i];p.x+=p.vx;p.y+=p.vy;
    if(p.y>VH+12||p.x<-24)WX.rainParts.splice(i,1);
  }
  // Advance state timer → trigger transition at end of duration
  WX.t+=dt;
  const FADE=2500;
  if(WX.t>=WX.dur){
    const prev=WX.state;
    WX.state=_wxPickNext();
    WX.t=0;WX.alpha=0;
    WX.dur=WX_MIN_DUR+Math.random()*(WX_MAX_DUR-WX_MIN_DUR);
    WX.rainParts=[];WX.flashAlpha=0;WX.bolts=[];
    WX.lightningT=3500+Math.random()*5500;
    WX._popShown=false;
    // Rare rainbow after rain
    if(prev==='Rain'&&WX.state==='Clear'&&Math.random()<0.45){
      WX.rainbowT=30000;
      if(typeof spawnPop==='function')setTimeout(()=>spawnPop('🌈 A rainbow appears!','#ffcc66'),800);
    }
  }
  // Smooth fade-in / plateau / fade-out
  if(WX.state==='Clear'){
    WX.alpha=Math.max(0,WX.alpha-dt*0.001);
  }else if(WX.t<FADE){
    WX.alpha=WX.t/FADE;
  }else if(WX.t>WX.dur-FADE){
    WX.alpha=Math.max(0,(WX.dur-WX.t)/FADE);
  }else{
    WX.alpha=1;
  }
  // Pop notification once per weather event (after fade-in starts)
  if(!WX._popShown&&WX.alpha>0.35&&WX.state!=='Clear'){
    WX._popShown=true;
    const msgs={
      Rain:'🌧 Rain begins to fall.',
      Fog:'🌫 Thick fog covers the land.',
      Storm:'⚡ A storm is raging!',
      Heat:'🔥 Scorching heat today.'
    };
    if(typeof spawnPop==='function')spawnPop(msgs[WX.state]||'',WEATHER_COLORS[WX.state]||'#88ccff');
  }
  // Pop "Clear skies" once when transitioning back to clear (after fade-out of last state)
  if(WX.state==='Clear'&&!WX._popShown&&WX.alpha<0.05){
    WX._popShown=true;
    if(typeof spawnPop==='function')spawnPop('☀ Clear skies today.','#ffe066');
  }
  // Update HUD weather label — Night/Blood Moon take priority when no active weather
  const el=document.getElementById('weather-label');
  if(el){
    let label,targetCol;
    if(WX.bloodMoon&&_curNight&&WX.alpha<0.3){label='🌕 BLOOD MOON';targetCol=WEATHER_COLORS.BloodMoon;}
    else if(_curNight&&WX.alpha<0.3){label='🌙 NIGHT';targetCol=WEATHER_COLORS.Night;}
    else if(WX.state==='Clear'||WX.alpha<0.08){label='☀ CLEAR';targetCol=WEATHER_COLORS.Clear;}
    else {label=(WEATHER_ICONS[WX.state]||'')+' '+WX.state.toUpperCase();targetCol=WEATHER_COLORS[WX.state]||'#ffffff';}
    if(el.textContent!==label)el.textContent=label;
    // Smooth color tween via lerpHex if available, else swap
    if(typeof lerpHex==='function'&&WX._hudCol&&targetCol&&WX._hudCol!==targetCol){
      try{WX._hudCol=lerpHex(WX._hudCol,targetCol,Math.min(1,dt*0.004));}catch(e){WX._hudCol=targetCol;}
    } else {WX._hudCol=targetCol;}
    el.style.color=WX._hudCol;
    el.style.transition='text-shadow .3s';
    el.style.textShadow=(WX.state==='Storm'&&WX.alpha>0.3)?'0 0 6px #cc88ff':(WX.bloodMoon&&_curNight)?'0 0 6px #ff4444':'0 1px 2px rgba(0,0,0,.85)';
  }
  _WXSnd.setAlpha(WX.state,WX.alpha);
}
function drawWeatherEffects(){
  const a=WX.alpha;
  // Blood moon red veil — even when Clear
  if(WX.bloodMoon&&typeof isNight==='function'&&isNight()){
    ctx.fillStyle='rgba(120,10,10,0.16)';
    ctx.fillRect(0,0,VW,VH);
  }
  // Rainbow (post-rain) — drawn even when Clear
  if(WX.rainbowT>0){
    const ra=Math.min(1,WX.rainbowT/3000)*Math.min(1,(30000-WX.rainbowT)/3000);
    ctx.save();ctx.globalAlpha=Math.max(0,Math.min(0.55,ra*0.55));
    const cx=VW*0.50,cy=VH*1.05,rad=Math.min(VW,VH)*0.85;
    const bands=[['#ff5566',rad],['#ffaa55',rad*0.96],['#ffe066',rad*0.92],['#66dd88',rad*0.88],['#66bbff',rad*0.84],['#aa77ff',rad*0.80]];
    ctx.lineWidth=4;
    for(const [c,r] of bands){ctx.strokeStyle=c;ctx.beginPath();ctx.arc(cx,cy,r,Math.PI*1.10,Math.PI*1.90);ctx.stroke();}
    ctx.restore();
  }
  if(a<0.02||WX.state==='Clear')return;
  if(WX.state==='Rain'||WX.state==='Storm'){
    // Slight dark/blue overlay during rain
    ctx.fillStyle='rgba(18,28,50,'+(a*0.20).toFixed(3)+')';
    ctx.fillRect(0,0,VW,VH);
    // Rain streaks
    ctx.save();ctx.lineWidth=1;
    for(const p of WX.rainParts){
      ctx.strokeStyle='rgba(120,165,225,'+(a*0.60).toFixed(3)+')';
      ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(p.x+p.vx*2,p.y-p.len);ctx.stroke();
    }
    ctx.restore();
    // Cheap puddle ripples — 2 fixed positions, sine pulse
    if(WX.state==='Rain'){
      const T=Date.now()*0.003;
      ctx.save();ctx.strokeStyle='rgba(140,180,220,'+(a*0.35).toFixed(3)+')';ctx.lineWidth=1;
      for(let i=0;i<2;i++){
        const px=VW*(0.30+i*0.40),py=VH*0.78;
        const r=4+((T+i*1.7)%1)*8;
        ctx.beginPath();ctx.arc(px,py,r,0,Math.PI*2);ctx.stroke();
      }
      ctx.restore();
    }
  }
  if(WX.state==='Fog'){
    // Three drifting radial fog blobs
    const T=Date.now()*0.00028;
    for(let i=0;i<3;i++){
      const ox=Math.sin(T+i*1.35)*95,oy=Math.cos(T*0.75+i*0.85)*55;
      const gr=ctx.createRadialGradient(VW/2+ox,VH/2+oy,25,VW/2+ox,VH/2+oy,VW*0.65);
      gr.addColorStop(0,'rgba(175,198,218,'+(a*0.16*(i===1?1.5:1)).toFixed(3)+')');
      gr.addColorStop(1,'rgba(155,182,208,0)');
      ctx.fillStyle=gr;ctx.fillRect(0,0,VW,VH);
    }
    // Flat veil + edge vignette (reduced visibility)
    ctx.fillStyle='rgba(160,188,208,'+(a*0.15).toFixed(3)+')';
    ctx.fillRect(0,0,VW,VH);
    const vg=ctx.createRadialGradient(VW/2,VH/2,Math.min(VW,VH)*0.30,VW/2,VH/2,Math.min(VW,VH)*0.70);
    vg.addColorStop(0,'rgba(160,188,208,0)');
    vg.addColorStop(1,'rgba(120,150,170,'+(a*0.45).toFixed(3)+')');
    ctx.fillStyle=vg;ctx.fillRect(0,0,VW,VH);
  }
  if(WX.state==='Storm'){
    // Purple-dark storm tint
    ctx.fillStyle='rgba(52,16,88,'+(a*0.18).toFixed(3)+')';
    ctx.fillRect(0,0,VW,VH);
    // Ground lightning strikes (warning marker → bolt → afterglow)
    for(const b of WX.bolts){
      if(b.phase===0){
        // Pulsing warning ring
        const k=1-(b.life/900);
        ctx.save();
        ctx.strokeStyle='rgba(255,240,120,'+(0.45+0.45*Math.sin(k*18)).toFixed(3)+')';
        ctx.lineWidth=2;ctx.beginPath();ctx.arc(b.x,b.y,16+k*6,0,Math.PI*2);ctx.stroke();
        ctx.fillStyle='rgba(255,240,120,'+(0.18+0.18*Math.sin(k*18)).toFixed(3)+')';
        ctx.beginPath();ctx.arc(b.x,b.y,10,0,Math.PI*2);ctx.fill();
        ctx.restore();
      } else if(b.phase===1){
        // Jagged bolt downward
        ctx.save();ctx.strokeStyle='#fafcff';ctx.lineWidth=3;
        ctx.shadowColor='#aaccff';ctx.shadowBlur=12;
        ctx.beginPath();let x=b.x,y=0;ctx.moveTo(x,y);
        while(y<b.y){y+=10+Math.random()*14;x+=(Math.random()-0.5)*20;ctx.lineTo(x,y);}
        ctx.stroke();ctx.restore();
      } else if(b.phase===2){
        // Afterglow scorch ring
        const ag=b.life/350;
        ctx.save();
        const gr=ctx.createRadialGradient(b.x,b.y,2,b.x,b.y,28);
        gr.addColorStop(0,'rgba(255,240,180,'+(ag*0.45).toFixed(3)+')');
        gr.addColorStop(1,'rgba(255,200,120,0)');
        ctx.fillStyle=gr;ctx.fillRect(b.x-30,b.y-30,60,60);
        ctx.restore();
      }
    }
    // Lightning flash
    if(WX.flashAlpha>0.01){
      ctx.fillStyle='rgba(215,215,255,'+WX.flashAlpha.toFixed(3)+')';
      ctx.fillRect(0,0,VW,VH);
    }
  }
  if(WX.state==='Heat'){
    // Warm orange tint
    ctx.fillStyle='rgba(255,140,40,'+(a*0.14).toFixed(3)+')';
    ctx.fillRect(0,0,VW,VH);
    // Cheap heat shimmer — 4 horizontal warped bands
    ctx.save();
    for(let i=0;i<4;i++){
      const y=VH*(0.55+i*0.10)+Math.sin(WX.heatT*1.2+i)*4;
      const gr=ctx.createLinearGradient(0,y,VW,y);
      gr.addColorStop(0,'rgba(255,200,140,0)');
      gr.addColorStop(0.5,'rgba(255,200,140,'+(a*0.12).toFixed(3)+')');
      gr.addColorStop(1,'rgba(255,200,140,0)');
      ctx.fillStyle=gr;ctx.fillRect(0,y-2,VW,4);
    }
    ctx.restore();
    // Subtle top sun glow
    const sg=ctx.createRadialGradient(VW*0.5,-20,10,VW*0.5,-20,VW*0.6);
    sg.addColorStop(0,'rgba(255,220,120,'+(a*0.18).toFixed(3)+')');
    sg.addColorStop(1,'rgba(255,220,120,0)');
    ctx.fillStyle=sg;ctx.fillRect(0,0,VW,VH);
  }
}

// ═══════════════════════════════
// WORLD
// ═══════════════════════════════
const visW=()=>VW/ZOOM,visH=()=>VH/ZOOM;
const cam={x:0,y:0};
function updateCamera(px,py){cam.x+=(px-visW()/2-cam.x)*.12;cam.y+=(py-visH()/2-cam.y)*.12;cam.x=Math.max(0,Math.min(cam.x,MAP_W-visW()));cam.y=Math.max(0,Math.min(cam.y,MAP_H-visH()));}
const wx=x=>(x-cam.x)*ZOOM,wy=y=>(y-cam.y)*ZOOM;
function onScreen(x,y,w,h){const sx=wx(x),sy=wy(y);return sx+w*ZOOM>0&&sx<VW&&sy+h*ZOOM>0&&sy<VH;}

const worldMap=[];
for(let r=0;r<ROWS;r++){worldMap[r]=[];for(let c=0;c<COLS;c++)worldMap[r][c]=(Math.sin(c*1.1+r*.8)+Math.cos(r*1.5+c*.6))>.75?1:0;}

// Smooth biome transition colors using lerp
function lerpHex(a,b,t){
  const ar=parseInt(a.slice(1,3),16),ag=parseInt(a.slice(3,5),16),ab2=parseInt(a.slice(5,7),16);
  const br=parseInt(b.slice(1,3),16),bg=parseInt(b.slice(3,5),16),bb=parseInt(b.slice(5,7),16);
  const rr=Math.round(ar+(br-ar)*t),rg=Math.round(ag+(bg-ag)*t),rb=Math.round(ab2+(bb-ab2)*t);
  return '#'+rr.toString(16).padStart(2,'0')+rg.toString(16).padStart(2,'0')+rb.toString(16).padStart(2,'0');
}

function drawWorld(){
  const sc=Math.max(0,Math.floor(cam.x/TILE)),sr=Math.max(0,Math.floor(cam.y/TILE));
  const ec=Math.min(COLS-1,Math.ceil((cam.x+visW())/TILE)),er=Math.min(ROWS-1,Math.ceil((cam.y+visH())/TILE));
  const ts=TILE*ZOOM;
  for(let r=sr;r<=er;r++){
    for(let c=sc;c<=ec;c++){
      const bId=biomeMap[r][c];
      const biome=BIOMES[bId];
      const t=worldMap[r][c];
      const sx=wx(c*TILE),sy=wy(r*TILE);
      const zoneId=zoneBiomeMap[r][c];
      if(zoneId>=0){
        // Boss zone — use zone-specific colors blended with biome
        const bz=BOSS_ZONES[zoneId];
        ctx.fillStyle=t?bz.tileColor1:bz.tileColor2;ctx.fillRect(sx,sy,ts+.5,ts+.5);
        // Subtle overlay shimmer
        const shimmer=0.06+0.04*Math.sin(Date.now()*0.0008+c*0.4+r*0.3);
        ctx.globalAlpha=shimmer;ctx.fillStyle=bz.overlayColor;ctx.fillRect(sx,sy,ts+.5,ts+.5);ctx.globalAlpha=1;
      } else {
        // Mottle: occasionally swap to alternate biome color for natural variation
        const jr=(c*7+r*13)%7;
        const useAlt=jr===0||jr===3;
        ctx.fillStyle=useAlt?(t?biome.colors[1]:biome.colors[0]):(t?biome.colors[0]:biome.colors[1]);
        ctx.fillRect(sx,sy,ts+.5,ts+.5);
      }
      ctx.fillStyle=zoneId>=0?'rgba(255,255,255,0.04)':(t?biome.dotColors[0]:biome.dotColors[1]);
      const sd=c*31+r*17,dot=ZOOM*2;
      for(let i=0;i<4;i++)ctx.fillRect(sx+((sd*(i+3)*7)%(TILE-4))*ZOOM,sy+((sd*(i+1)*13)%(TILE-4))*ZOOM,dot,dot);
      // Grass tufts + flowers (grass/forest biomes only, performance-light)
      if(zoneId<0&&(bId===0||bId===3)){
        const rnd=sRand(c*131+r*71);
        if(rnd<0.20){
          ctx.fillStyle=biome.dotColors[0];
          const gx=sx+((sd*5)%(TILE-8))*ZOOM,gy=sy+((sd*9)%(TILE-8))*ZOOM;
          ctx.fillRect(gx,gy+2*ZOOM,1.4*ZOOM,3*ZOOM);
          ctx.fillRect(gx+2*ZOOM,gy+ZOOM,1.4*ZOOM,4*ZOOM);
          ctx.fillRect(gx+4*ZOOM,gy+2*ZOOM,1.4*ZOOM,3*ZOOM);
          // Lighter grass tip for depth
          ctx.fillStyle='rgba(160,220,120,.55)';
          ctx.fillRect(gx+2*ZOOM,gy+ZOOM,1.4*ZOOM,1*ZOOM);
        } else if(rnd<0.235){
          const fc=['#ffe066','#f9a8d4','#a78bfa','#fca5a5'][(sd>>>0)%4];
          const fx=sx+((sd*3)%(TILE-6))*ZOOM,fy=sy+((sd*11)%(TILE-6))*ZOOM;
          ctx.fillStyle=fc;
          ctx.fillRect(fx,fy-ZOOM,ZOOM,ZOOM);
          ctx.fillRect(fx-ZOOM,fy,ZOOM,ZOOM);
          ctx.fillRect(fx+ZOOM,fy,ZOOM,ZOOM);
          ctx.fillRect(fx,fy+ZOOM,ZOOM,ZOOM);
          ctx.fillStyle='#fff8b0';
          ctx.fillRect(fx,fy,ZOOM,ZOOM);
        } else if(rnd<0.26){
          // Small bush/plant clump
          ctx.fillStyle=bId===3?'rgba(20,60,18,.7)':'rgba(40,90,30,.65)';
          const bx=sx+((sd*9)%(TILE-8))*ZOOM,by=sy+((sd*7)%(TILE-8))*ZOOM;
          ctx.fillRect(bx,by+ZOOM,3*ZOOM,2*ZOOM);
          ctx.fillRect(bx+2*ZOOM,by,3*ZOOM,2*ZOOM);
          ctx.fillRect(bx+1*ZOOM,by-ZOOM,2*ZOOM,1*ZOOM);
          ctx.fillStyle='rgba(140,200,100,.4)';
          ctx.fillRect(bx+1*ZOOM,by,1*ZOOM,1*ZOOM);
        }
      }
      // Light pebbles for rocky/copper biomes
      else if(zoneId<0&&(bId===1||bId===2||bId===4)){
        const rnd=sRand(c*97+r*53);
        if(rnd<0.14){
          ctx.fillStyle=bId===2?'rgba(180,110,40,.45)':'rgba(120,128,140,.5)';
          const px2=sx+((sd*7)%(TILE-4))*ZOOM,py2=sy+((sd*5)%(TILE-4))*ZOOM;
          ctx.fillRect(px2,py2,1.6*ZOOM,1.6*ZOOM);
          ctx.fillRect(px2+2*ZOOM,py2+ZOOM,1.4*ZOOM,1.4*ZOOM);
          // Pebble highlight
          ctx.fillStyle='rgba(220,220,230,.35)';
          ctx.fillRect(px2,py2,0.8*ZOOM,0.8*ZOOM);
        } else if(rnd<0.18){
          // Tiny pebble cluster
          ctx.fillStyle='rgba(90,96,108,.55)';
          const px3=sx+((sd*11)%(TILE-6))*ZOOM,py3=sy+((sd*13)%(TILE-6))*ZOOM;
          ctx.fillRect(px3,py3,1*ZOOM,1*ZOOM);
          ctx.fillRect(px3+2*ZOOM,py3+ZOOM,1*ZOOM,1*ZOOM);
        }
      }
      // Forest biome: occasional dark roots / leaf litter for depth
      if(zoneId<0&&bId===3){
        const rrnd=sRand(c*157+r*89);
        if(rrnd<0.10){
          ctx.fillStyle='rgba(28,46,20,.65)';
          const rx2=sx+((sd*4)%(TILE-10))*ZOOM,ry2=sy+((sd*8)%(TILE-10))*ZOOM;
          ctx.fillRect(rx2,ry2,3.2*ZOOM,1.4*ZOOM);
          ctx.fillRect(rx2+2*ZOOM,ry2+1*ZOOM,3.2*ZOOM,1.4*ZOOM);
        }
      }
    }
  }
}

// ═══════════════════════════════
// WORLD OBJECTS
// ═══════════════════════════════
const OBJ_DEF={tree:{w:28,h:40,hitW:14,hitH:10,hitOY:30,tool:'axe'},stone:{w:26,h:22,hitW:22,hitH:14,hitOY:8,tool:'pickaxe'},copper:{w:24,h:20,hitW:20,hitH:12,hitOY:8,tool:'pickaxe'},coal:{w:22,h:18,hitW:18,hitH:12,hitOY:6,tool:'pickaxe'},iron:{w:26,h:22,hitW:22,hitH:14,hitOY:8,tool:'pickaxe'},berryBush:{w:24,h:20,hitW:18,hitH:10,hitOY:12,tool:null},mushroom:{w:16,h:18,hitW:12,hitH:8,hitOY:12,tool:null}};
function sRand(n){const x=Math.sin(n)*43758.5453;return x-Math.floor(x);}
const objects=[];let _sd=7;

// Biome-based resource spawn rates
// Grassland: balanced. Rocky: more stone. Copper: more copper. Forest: more trees. Danger: sparse.
const BIOME_SPAWN_WEIGHTS={
  0:{tree:1.0,stone:0.6,copper:0.3,coal:0.1,iron:0.0, berryBush:0.06,mushroom:0.0},
  1:{tree:0.4,stone:1.6,copper:0.5,coal:0.8,iron:1.85,berryBush:0.0, mushroom:1.2},
  2:{tree:0.5,stone:0.6,copper:1.8,coal:0.5,iron:0.0, berryBush:0.0, mushroom:0.0},
  3:{tree:1.8,stone:0.4,copper:0.2,coal:0.1,iron:0.0, berryBush:1.6, mushroom:0.0},
  4:{tree:0.3,stone:1.2,copper:1.4,coal:1.4,iron:0.0, berryBush:0.0, mushroom:0.0},
  5:{tree:0.20,stone:0.50,copper:0.15,coal:0.10,iron:0.0,berryBush:0.0,mushroom:0.0},
  6:{tree:0.10,stone:1.40,copper:0.20,coal:0.30,iron:0.0,berryBush:0.0,mushroom:0.0},
  7:{tree:0.10,stone:0.80,copper:0.60,coal:1.60,iron:0.0,berryBush:0.0,mushroom:0.0},
};
function getBiomeTileId(col,row){if(col<0||row<0||col>=COLS||row>=ROWS)return 0;return biomeMap[row][col];}

// Place resources with biome weighting
const RESOURCE_COUNTS={tree:340,stone:280,copper:160,coal:110,iron:80,berryBush:88,mushroom:55};
for(const [type,count] of Object.entries(RESOURCE_COUNTS)){
  let placed=0,tries=0;const def=OBJ_DEF[type];
  while(placed<count&&tries<8000){tries++;
    const col=1+Math.floor(sRand(_sd++)*(COLS-2)),row=1+Math.floor(sRand(_sd++)*(ROWS-2));
    // Avoid center spawn area
    if(Math.abs(col-COLS/2)<5&&Math.abs(row-ROWS/2)<5)continue;
    const bId=getBiomeTileId(col,row);
    const weight=BIOME_SPAWN_WEIGHTS[bId][type];
    // Probability rejection based on weight
    if(sRand(_sd++)<(1-weight*0.56))continue;
    const ox=col*TILE+(TILE-def.w)/2,oy=row*TILE+(TILE-def.h);
    if(objects.some(o=>Math.hypot(o.x-ox,o.y-oy)<38))continue;
    if(type==='berryBush'){objects.push({type,x:ox,y:oy,hp:1,maxHp:1,shakeT:0,harvested:false,respawnT:0,sizeVar:0.82+sRand(ox*5+oy*7)*0.36});}else if(type==='mushroom'){objects.push({type,x:ox,y:oy,hp:1,maxHp:1,shakeT:0,harvested:false,respawnT:0,sizeVar:0.78+sRand(ox*9+oy*3)*0.44});}else{objects.push({type,x:ox,y:oy,hp:3,maxHp:3,shakeT:0});}placed++;
  }
}
objects.sort((a,b)=>a.y-b.y);

// ═══════════════════════════════
// RUINS & RARE LOOT SPOTS
// ═══════════════════════════════
const RUIN_EMOJIS=['🏛','🗿','⛩','🏚','🗼','🏺'];
const ruins=[];
(function spawnRuins(){
  const COUNT=22;
  for(let i=0;i<COUNT;i++){
    let rx,ry,tries=0;
    do{
      rx=TILE*4+Math.random()*(MAP_W-TILE*8);
      ry=TILE*4+Math.random()*(MAP_H-TILE*8);
      tries++;
    }while(tries<30&&(Math.hypot(rx-MAP_W/2,ry-MAP_H/2)<280||ruins.some(r=>Math.hypot(r.x-rx,r.y-ry)<200)));
    const lootTable=['wood','stone','copper','coal','sphere'];
    const loot=lootTable[Math.floor(Math.random()*lootTable.length)];
    const qty=1+Math.floor(Math.random()*4);
    ruins.push({x:rx,y:ry,emoji:RUIN_EMOJIS[i%RUIN_EMOJIS.length],looted:false,loot,qty,glow:Math.random()*Math.PI*2});
  }
})();

let _ruinLootCooldown=0;
function checkRuinLoot(){
  if(_ruinLootCooldown>0)return;
  for(const r of ruins){
    if(r.looted)continue;
    if(Math.hypot(r.x-PL.x,r.y-PL.y)<36){
      r.looted=true;
      _ruinLootCooldown=2000;
      iAdd(playerInv,r.loot,r.qty);updResUI();
      const emoji=IEMOJI[r.loot]||r.loot;
      popAt('✨ +'+r.qty+emoji+' (Ruins)','#ffe066',r.x,r.y-20);
      spawnPop('🏛 Ruin looted! +'+r.qty+emoji,'#ffe066');
      // 30% chance of a rare pal appearing
      if(Math.random()<0.30){
        const rareDefs=PAL_TYPES.filter(p=>p.rare);
        const rd=rareDefs[Math.floor(Math.random()*rareDefs.length)];
        const lv=Math.max(1,PL.level+Math.floor(Math.random()*2));
        wildPals.push({def:rd,x:r.x+Math.random()*60-30,y:r.y+Math.random()*60-30,hp:rd.baseHp+lv*2,maxHp:rd.baseHp+lv*2,level:lv,xp:0,xpNeeded:xpToNext(lv),dead:false,id:Math.random(),aF:0,aT:0,shakeT:0,vx:0,vy:0,wT:2000,abCD:rd.ability.cd,skCD:rd.special?.cd||9999,rarity:'rare',dmgBonus:0,sizeBonus:0});
        spawnPop('⭐ Rare Pal from ruins!','#ffd700');
      }
      return;
    }
  }
}

function drawRuins(){
  for(const r of ruins){
    if(!onScreen(r.x-20,r.y-20,40,40))continue;
    const z=ZOOM,sx=wx(r.x),sy=wy(r.y);
    if(!r.looted){
      // Loot glow
      const pulse=0.55+0.35*Math.sin(Date.now()*0.002+r.glow);
      ctx.globalAlpha=pulse*0.55;
      ctx.fillStyle='rgba(255,220,60,0.5)';ctx.beginPath();ctx.arc(sx,sy,18*z,0,Math.PI*2);ctx.fill();
      ctx.globalAlpha=1;
    }
    ctx.font=\`\${Math.round(16*z)}px serif\`;ctx.textAlign='center';
    ctx.globalAlpha=r.looted?0.28:0.85;
    ctx.fillText(r.emoji,sx,sy+4*z);
    ctx.globalAlpha=1;
    ctx.textAlign='left';
  }
}

function updObjectShake(dt){for(const o of objects){if(o.shakeT>0)o.shakeT=Math.max(0,o.shakeT-dt);}}
function getHB(o){const d=OBJ_DEF[o.type];return{x:o.x+(d.w-d.hitW)/2,y:o.y+d.hitOY,w:d.hitW,h:d.hitH};}
function rOv(ax,ay,aw,ah,bx,by,bw,bh){return ax<bx+bw&&ax+aw>bx&&ay<by+bh&&ay+ah>by;}
function moveWithColl(e,dx,dy,hw,hh){
  const py0=e.y-hh/2,nx=e.x+dx;
  if(!objects.some(o=>{const h=getHB(o);return rOv(nx-hw/2,py0,hw,hh,h.x,h.y,h.w,h.h)})&&
     !structures.some(s=>rOv(nx-hw/2,py0,hw,hh,s.x-s.hw,s.y-s.hh,s.hw*2,s.hh*2)))
    e.x=Math.max(hw/2,Math.min(nx,MAP_W-hw/2));
  const px0=e.x-hw/2,ny=e.y+dy;
  if(!objects.some(o=>{const h=getHB(o);return rOv(px0,ny-hh/2,hw,hh,h.x,h.y,h.w,h.h)})&&
     !structures.some(s=>rOv(px0,ny-hh/2,hw,hh,s.x-s.hw,s.y-s.hh,s.hw*2,s.hh*2)))
    e.y=Math.max(hh/2,Math.min(ny,MAP_H-hh/2));
}
function nearestObj(px,py){let best=null,bd=Infinity;for(const o of objects){const h=getHB(o),cx=h.x+h.w/2,cy=h.y+h.h/2,d=Math.hypot(px-cx,py-cy);if(d<52&&d<bd){bd=d;best=o;}}return best;}
function hitObject(o){o.shakeT=175;o.shakeAngle=(o.shakeAngle||0)+Math.PI*(0.5+Math.random()*0.5);}
function shakeOff(o){if(o.shakeT<=0)return{sx:0,sy:0};const frac=o.shakeT/175,amp=3*frac;return{sx:Math.cos(o.shakeAngle||0)*amp,sy:Math.sin(o.shakeAngle||0)*amp};}

function drawTree(o,hi){
  const{sx:sh,sy:sv}=shakeOff(o);
  const x=o.x+sh,y=o.y+sv,z=ZOOM;
  if(o._sc===undefined)o._sc=0.82+sRand(o.x*7+o.y*13)*0.38;
  const sc=o._sc;
  // Layered ground shadow
  ctx.fillStyle='rgba(0,0,0,.16)';
  ctx.beginPath();ctx.ellipse(wx(o.x+14),wy(o.y+41),13*z*sc,5*z*sc,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='rgba(0,0,0,.32)';
  ctx.beginPath();ctx.ellipse(wx(o.x+14),wy(o.y+40),10*z*sc,3.5*z*sc,0,0,Math.PI*2);ctx.fill();
  // Trunk: 3-color shading + bark texture line
  ctx.fillStyle='#2c1808';ctx.fillRect(wx(x+10),wy(y+26),8*z,14*z);
  ctx.fillStyle='#5c3d1e';ctx.fillRect(wx(x+11),wy(y+26),5*z,14*z);
  ctx.fillStyle='#7a5a30';ctx.fillRect(wx(x+12),wy(y+27),1.4*z,11*z);
  ctx.fillStyle='#3a2410';ctx.fillRect(wx(x+10),wy(y+33),8*z,1*z);
  const sway=Math.sin(Date.now()*0.0018+o.x*0.013)*1.2;
  const cx=x+14;
  const g=hi?['#5dff70','#3ed452','#2bb43e','#176a24']:['#5fb83c','#3a8a26','#2a6e1d','#13501a'];
  // Darkest base layer
  ctx.fillStyle=g[3];
  ctx.beginPath();
  ctx.arc(wx(cx-3),wy(y+22),12*z*sc,0,Math.PI*2);
  ctx.arc(wx(cx+5),wy(y+22),11*z*sc,0,Math.PI*2);
  ctx.fill();
  // Mid layer with sway
  ctx.fillStyle=g[2];
  ctx.beginPath();
  ctx.arc(wx(cx-3+sway*.4),wy(y+18),10*z*sc,0,Math.PI*2);
  ctx.arc(wx(cx+4+sway*.4),wy(y+15),11*z*sc,0,Math.PI*2);
  ctx.arc(wx(cx+sway*.4),wy(y+10),10*z*sc,0,Math.PI*2);
  ctx.fill();
  // Inner shadow accent (depth)
  ctx.fillStyle='rgba(0,0,0,.18)';
  ctx.beginPath();ctx.arc(wx(cx+3+sway*.3),wy(y+19),3.6*z*sc,0,Math.PI*2);ctx.fill();
  // Bright leaf layer
  ctx.fillStyle=g[1];
  ctx.beginPath();
  ctx.arc(wx(cx-1+sway),wy(y+8),8*z*sc,0,Math.PI*2);
  ctx.arc(wx(cx+5+sway),wy(y+12),7*z*sc,0,Math.PI*2);
  ctx.fill();
  // Brightest cluster + extra small highlight cluster for richness
  ctx.fillStyle=g[0];
  ctx.beginPath();ctx.arc(wx(cx-2+sway*1.4),wy(y+6),3.4*z*sc,0,Math.PI*2);ctx.fill();
  ctx.beginPath();ctx.arc(wx(cx+5+sway*1.2),wy(y+9),2.2*z*sc,0,Math.PI*2);ctx.fill();
  // Top specular highlight
  ctx.fillStyle=hi?'rgba(255,255,255,.6)':'rgba(255,255,255,.36)';
  ctx.beginPath();ctx.arc(wx(cx-3+sway*1.4),wy(y+5),1.5*z*sc,0,Math.PI*2);ctx.fill();
}
function _drawRock(o,hi,p){
  const{sx:sh,sy:sv}=shakeOff(o);
  const x=o.x+sh,y=o.y+sv,z=ZOOM;
  // Optional warm aura (e.g. copper)
  if(p.aura){
    ctx.fillStyle=p.aura;
    ctx.beginPath();ctx.arc(wx(o.x+13),wy(o.y+12),17*z,0,Math.PI*2);ctx.fill();
  }
  // Layered ground shadow
  ctx.fillStyle='rgba(0,0,0,.18)';
  ctx.beginPath();ctx.ellipse(wx(o.x+13),wy(o.y+23),15*z,5.5*z,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='rgba(0,0,0,.36)';
  ctx.beginPath();ctx.ellipse(wx(o.x+13),wy(o.y+22),12*z,4.5*z,0,0,Math.PI*2);ctx.fill();
  ctx.beginPath();
  [[x+4,y+20],[x+2,y+12],[x+8,y+4],[x+18,y+3],[x+24,y+10],[x+24,y+18],[x+16,y+22]].forEach(([px,py],i)=>{i===0?ctx.moveTo(wx(px),wy(py)):ctx.lineTo(wx(px),wy(py));});
  ctx.closePath();
  ctx.fillStyle=hi?p.lite:p.base;ctx.fill();
  ctx.lineJoin='round';ctx.strokeStyle=p.outline;ctx.lineWidth=1.4*z;ctx.stroke();
  ctx.beginPath();
  [[x+8,y+5],[x+18,y+4],[x+22,y+10],[x+14,y+8]].forEach(([px,py],i)=>{i===0?ctx.moveTo(wx(px),wy(py)):ctx.lineTo(wx(px),wy(py));});
  ctx.closePath();
  ctx.fillStyle=hi?p.glow:p.hi;ctx.fill();
  ctx.fillStyle=p.spec;
  ctx.fillRect(wx(x+6),wy(y+13),1.4*z,1.4*z);
  ctx.fillRect(wx(x+15),wy(y+15),1.4*z,1.4*z);
  ctx.fillRect(wx(x+19),wy(y+9),1.4*z,1.4*z);
  ctx.strokeStyle=p.crack;ctx.lineWidth=z;
  ctx.beginPath();ctx.moveTo(wx(x+13),wy(y+6));ctx.lineTo(wx(x+10),wy(y+14));ctx.lineTo(wx(x+14),wy(y+18));ctx.stroke();
}
const _STONE_PAL ={base:'#7a8494',lite:'#b0b8c8',hi:'#9aa4b4',glow:'#d0d8e8',outline:'#2e3540',crack:'#3a4050',spec:'rgba(255,255,255,.22)'};
const _COPPER_PAL={base:'#c87820',lite:'#ff9a3c',hi:'#e09030',glow:'#ffcc66',outline:'#5a2a08',crack:'#3a1a00',spec:'rgba(255,220,140,.55)',aura:'rgba(255,160,50,0.10)'};
const _COAL_PAL  ={base:'#101012',lite:'#2c2c30',hi:'#1c1c20',glow:'#444',  outline:'#000',  crack:'#000',  spec:'rgba(180,180,200,.22)'};
const _IRON_PAL  ={base:'#8a92a0',lite:'#bcc4d2',hi:'#aab2c0',glow:'#dde4f0',outline:'#1f242c',crack:'#3a4048',spec:'rgba(220,230,240,.62)'};
function drawStone(o,hi){_drawRock(o,hi,_STONE_PAL);}
function drawCopper(o,hi){_drawRock(o,hi,_COPPER_PAL);}
function drawCoal(o,hi){_drawRock(o,hi,_COAL_PAL);}
function drawIron(o,hi){_drawRock(o,hi,_IRON_PAL);}
function drawObjHP(o){if(o.hp===o.maxHp)return;const d=OBJ_DEF[o.type],z=ZOOM,sx=wx(o.x),sy=wy(o.y-9),bw=d.w*z,bh=4*z;ctx.fillStyle='#111';ctx.fillRect(sx,sy,bw,bh);const p=o.hp/o.maxHp;ctx.fillStyle=p>.6?'#4aff60':p>.3?'#fc0':'#f44';ctx.fillRect(sx,sy,Math.round(bw*p),bh);ctx.strokeStyle='#000';ctx.lineWidth=.5;ctx.strokeRect(sx,sy,bw,bh);}
function renderObj(o,hi){if(!onScreen(o.x,o.y,OBJ_DEF[o.type].w,OBJ_DEF[o.type].h))return;if(o.type==='tree')drawTree(o,hi);else if(o.type==='stone')drawStone(o,hi);else if(o.type==='copper')drawCopper(o,hi);else if(o.type==='coal')drawCoal(o,hi);else if(o.type==='iron')drawIron(o,hi);drawObjHP(o);}

// ═══════════════════════════════
// STRUCTURES
// ═══════════════════════════════
const STRUCT_DEF={
  craftTable:{emoji:'🔨',label:'Craft Table',w:36,h:30,hw:16,hh:12,color:'#2a1a08',border:'#c8a060'},
  chest:{emoji:'📦',label:'Chest',w:30,h:26,hw:14,hh:11,color:'#2a2008',border:'#facc15'},
  palbox:{emoji:'🗃️',label:'Pal Box',w:34,h:28,hw:15,hh:12,color:'#0e0222',border:'#a855f7'},
  campfire:{emoji:'🔥',label:'Campfire',w:28,h:22,hw:12,hh:9,color:'#1a0800',border:'#ff6622'},
  repair_bench:{emoji:'🛠️',label:'Repair Bench',w:34,h:28,hw:15,hh:11,color:'#2a1810',border:'#dde2ec'},
};
const STRUCT_REFUND={craftTable:{wood:4,stone:2},chest:{wood:5},palbox:{wood:7,stone:5,copper:2},campfire:{wood:3,stone:2},repair_bench:{wood:10,stone:8,iron:2}};
const BASE_RADIUS=340;
const structures=[];
const INTERACT_R=58;
function placementValid(type,x,y){
  const d=STRUCT_DEF[type];
  if(x<60||y<60||x>MAP_W-60||y>MAP_H-60)return false;
  if(objects.some(o=>{const h=getHB(o);return rOv(x-d.hw,y-d.hh,d.hw*2,d.hh*2,h.x,h.y,h.w,h.h);}))return false;
  if(structures.some(s=>rOv(x-d.hw,y-d.hh,d.hw*2,d.hh*2,s.x-s.hw,s.y-s.hh,s.hw*2,s.hh*2)))return false;
  return true;
}
function placeStruct(type,x,y){structures.push({type,x,y,hw:STRUCT_DEF[type].hw,hh:STRUCT_DEF[type].hh,chestInv:type==='chest'?createInv(8):null});if(type==='craftTable')questProg('build_table');}
function nearestStruct(px,py){let best=null,bd=Infinity;for(const s of structures){const d=Math.hypot(px-s.x,py-s.y);if(d<INTERACT_R&&d<bd){bd=d;best=s;}}return best;}
function getPB(){return structures.find(s=>s.type==='palbox')||null;}
function drawStruct(s,hi){
  const d=STRUCT_DEF[s.type],z=ZOOM,sx=wx(s.x)-d.w/2*z,sy=wy(s.y)-d.h*z;
  if(s.type==='palbox'){ctx.strokeStyle='rgba(200,80,80,.22)';ctx.lineWidth=1.5*z;ctx.setLineDash([5*z,5*z]);ctx.beginPath();ctx.arc(wx(s.x),wy(s.y),BASE_RADIUS*z,0,Math.PI*2);ctx.stroke();ctx.setLineDash([]);ctx.fillStyle='rgba(200,60,60,.04)';ctx.beginPath();ctx.arc(wx(s.x),wy(s.y),BASE_RADIUS*z,0,Math.PI*2);ctx.fill();}
  ctx.fillStyle='rgba(0,0,0,.28)';ctx.beginPath();ctx.ellipse(wx(s.x),wy(s.y),d.hw*z,5*z,0,0,Math.PI*2);ctx.fill();
  if(removeMode){ctx.globalAlpha=.32;ctx.fillStyle='#f44';ctx.fillRect(sx,sy,d.w*z,d.h*z);ctx.globalAlpha=1;}
  ctx.fillStyle=d.color;ctx.globalAlpha=removeMode?.75:1;ctx.fillRect(sx,sy,d.w*z,d.h*z);ctx.globalAlpha=1;
  ctx.strokeStyle=removeMode?'#f87171':(hi?'#fff':d.border);ctx.lineWidth=(removeMode||hi)?2*z:1.5*z;ctx.strokeRect(sx,sy,d.w*z,d.h*z);
  ctx.font=\`\${Math.round(13*z)}px serif\`;ctx.fillText(d.emoji,wx(s.x)-6*z,wy(s.y)-d.h/2*z+4*z);
  if(s.type==='campfire'){const now2=Date.now();const flick=Math.sin(now2*0.012)*2+Math.sin(now2*0.019)*1.5;ctx.globalAlpha=0.35+Math.abs(Math.sin(now2*0.008))*0.25;const gr=ctx.createRadialGradient(wx(s.x),wy(s.y-8),0,wx(s.x),wy(s.y-8),(9+flick)*z);gr.addColorStop(0,'#ffe066');gr.addColorStop(0.5,'#ff7700');gr.addColorStop(1,'rgba(255,60,0,0)');ctx.fillStyle=gr;ctx.beginPath();ctx.arc(wx(s.x),wy(s.y-8),(9+flick)*z,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;}
  if(hi&&!removeMode){ctx.fillStyle='#ccc';ctx.font=\`\${Math.round(6*z)}px Courier New\`;ctx.fillText('['+d.label+']',wx(s.x)-18*z,wy(s.y)+6*z);}
  if(removeMode){ctx.fillStyle='#f87171';ctx.font=\`\${Math.round(6*z)}px Courier New\`;ctx.fillText('[REMOVE]',wx(s.x)-16*z,wy(s.y)+6*z);}
}

// ═══════════════════════════════
// INVENTORY
// ═══════════════════════════════
const STACK=99;
function createInv(n){return Array(n).fill(null);}
const playerInv=createInv(18);
const IEMOJI={wood:'🪵',stone:'🪨',copper:'🟠',coal:'⬛',iron:'🩶',sphere:'🔮',adv_sphere:'💠',ultra_sphere:'🌀',meat:'🍖',rawMeat:'🥩',cookedMeat:'🍖',dragon_horn:'🦴',phoenix_feather:'🪶',crystal_shard:'💎',star_dust:'✨',coin:'🪙',berry:'🍓',mushroom:'🍄',mushroomSoup:'🍲'};
function iCount(arr,type){return arr.reduce((s,c)=>s+(c&&c.type===type?c.qty:0),0);}
function iAdd(arr,type,qty){
  for(const c of arr)if(c&&c.type===type&&c.qty<STACK){const a=Math.min(qty,STACK-c.qty);c.qty+=a;qty-=a;if(qty<=0)return;}
  for(let i=0;i<arr.length;i++)if(!arr[i]){arr[i]={type,emoji:IEMOJI[type]||'❓',qty:Math.min(qty,STACK)};qty-=Math.min(qty,STACK);if(qty<=0)return;}
}
function iRemove(arr,type,qty){for(let i=0;i<arr.length;i++){const c=arr[i];if(c&&c.type===type){const t=Math.min(c.qty,qty);c.qty-=t;qty-=t;if(c.qty<=0)arr[i]=null;if(qty<=0)return true;}}return false;}
function iHas(arr,reqs){for(const[t,q]of Object.entries(reqs))if(iCount(arr,t)<q)return false;return true;}
const inv={get wood(){return iCount(playerInv,'wood');},get stone(){return iCount(playerInv,'stone');},get copper(){return iCount(playerInv,'copper');},get spheres(){return iCount(playerInv,'sphere');},get advSpheres(){return iCount(playerInv,'adv_sphere');},get ultraSpheres(){return iCount(playerInv,'ultra_sphere');},get anyBalls(){return iCount(playerInv,'sphere')+iCount(playerInv,'adv_sphere')+iCount(playerInv,'ultra_sphere');}};

// ═══════════════════════════════
// EQUIPMENT in
// ═══════════════════════════════
const TIER_ORDER=['wood','stone','copper','iron'];
function tierVal(t){return TIER_ORDER.indexOf(t);}
const equipped={weapon:null,armor:null,axe:'wood',pickaxe:'wood'};
const WEAPON_DMG={sword_wood:3,sword_stone:5,sword_copper:7,sword_iron:10};
const WEAPON_EMOJI={sword_wood:'🗡️',sword_stone:'⚔️',sword_copper:'🔱',sword_iron:'⚜️'};
// ── ARMOR ──
const ARMOR_DEF={
  cloth:{hp:20,emoji:'🥋',label:'Cloth Armor',cost:{wood:8,stone:4}},
  iron: {hp:60,emoji:'🛡️',label:'Iron Armor', cost:{wood:10,copper:5,iron:20}},
};
function armorHpBonus(){const a=ARMOR_DEF[equipped.armor];return a?a.hp:0;}
function setArmor(newKey){
  const oldBonus=ARMOR_DEF[equipped.armor]?ARMOR_DEF[equipped.armor].hp:0;
  const newBonus=ARMOR_DEF[newKey]?ARMOR_DEF[newKey].hp:0;
  const delta=newBonus-oldBonus;
  PL.maxHp+=delta;
  if(delta>0)PL.hp=Math.min(PL.hp+delta,PL.maxHp);
  else PL.hp=Math.min(PL.hp,PL.maxHp);
  equipped.armor=newKey||null;
  if(typeof updHPBar==='function')updHPBar();
}
const TOOL_TIER_LABEL={wood:'W',stone:'S',copper:'C',iron:'I'};
const TOOL_TIER_CLS={wood:'tw',stone:'ts',copper:'tc',iron:'ti'};
function getGatherCD(){const tier=equipped[activeTool];return tier==='iron'?160:tier==='copper'?220:tier==='stone'?330:450;}
function weaponDmgBonus(){return WEAPON_DMG[equipped.weapon]||0;}
function _setEqDurBar(el,gearObj){
  let dur=el.querySelector('.eq-dur');
  if(!gearObj){if(dur)dur.remove();return;}
  if(!dur){dur=document.createElement('div');dur.className='eq-dur';dur.innerHTML='<i></i>';el.appendChild(dur);}
  const fill=dur.querySelector('i');
  const pct=Math.max(0,Math.min(1,(gearObj.dur||0)/(gearObj.max||1)));
  fill.style.width=(pct*100).toFixed(0)+'%';
  fill.style.background=gearObj.broken?'#f87171':(pct>0.5?'#4aff78':pct>0.25?'#facc15':'#f87171');
}
function updEquipPanel(){
  const wEl=document.getElementById('eq-weapon');
  if(equipped.weapon){wEl.textContent=WEAPON_EMOJI[equipped.weapon]||'🗡️';wEl.classList.add('has-item');}
  else{wEl.textContent='✊';wEl.classList.remove('has-item');if(activeTool==='sword')activeTool='axe';}
  _setEqDurBar(wEl,equippedId&&equippedId.weapon?_gearById(equippedId.weapon):null);
  const wG=equippedId&&equippedId.weapon?_gearById(equippedId.weapon):null;
  wEl.classList.toggle('brk',!!(wG&&wG.broken));
  wEl.title=equipped.weapon?(GEAR_LABEL[equipped.weapon]||'Weapon')+(wG?' '+(wG.dur||0)+'/'+(wG.max||0):'')+' — tap to unequip / hold to drag':'Empty hand — punch attack';
  const aEl=document.getElementById('eq-armor');
  if(aEl){
    if(equipped.armor){const a=ARMOR_DEF[equipped.armor];aEl.innerHTML=a.emoji+'<span class="eq-tier" style="background:#666;color:#fff">+'+a.hp+'</span>';aEl.classList.add('has-item');aEl.title=a.label+' (+'+a.hp+' HP) — tap to unequip / hold to drag';}
    else{aEl.textContent='👕';aEl.classList.remove('has-item');aEl.title='Armor (none)';}
    _setEqDurBar(aEl,equippedId&&equippedId.armor?_gearById(equippedId.armor):null);
    const aG=equippedId&&equippedId.armor?_gearById(equippedId.armor):null;
    aEl.classList.toggle('brk',!!(aG&&aG.broken));
  }
  // Sync switch-btn icon to current activeTool — empty hand emoji when sword active without weapon
  const sbIcon=activeTool==='axe'?'🪓':activeTool==='pickaxe'?'⛏':(equipped.weapon?(WEAPON_EMOJI[equipped.weapon]||'🗡️'):'✊');
  document.getElementById('switch-btn').textContent=sbIcon;
  ['axe','pickaxe'].forEach(tool=>{
    const id=tool==='axe'?'eq-axe':'eq-pick',tierId=tool==='axe'?'eq-axe-tier':'eq-pick-tier';
    const el=document.getElementById(id),tEl=document.getElementById(tierId);
    const tier=equipped[tool];
    el.className='eq-slot has-item';
    tEl.className='eq-tier '+TOOL_TIER_CLS[tier];
    tEl.textContent=TOOL_TIER_LABEL[tier];
    const tG=equippedId&&equippedId[tool]?_gearById(equippedId[tool]):null;
    _setEqDurBar(el,tG);
    if(tG&&tG.broken)el.classList.add('brk');
    el.title=(tool==='axe'?'Axe ':'Pickaxe ')+(TOOL_TIER_LABEL[tier]||'')+(tG?' '+(tG.dur||0)+'/'+(tG.max||0):'')+(tG?' — tap to unequip / hold to drag':' (basic — craft an upgrade!)');
  });
  // Highlight active tool slot
  ['eq-weapon','eq-axe','eq-pick'].forEach(id=>{const e=document.getElementById(id);if(e)e.classList.remove('is-active');});
  const aid=activeTool==='sword'?'eq-weapon':activeTool==='axe'?'eq-axe':activeTool==='pickaxe'?'eq-pick':null;
  if(aid){const e=document.getElementById(aid);if(e)e.classList.add('is-active');}
}

// ═══════════════════════════════
// PROGRESSION & STATS
// ═══════════════════════════════
const Stats={woodCollected:0,stoneCollected:0,copperCollected:0,palsDefeated:0,palsCaptured:0,deathCount:0,playtime:0};
function addStat(key,amt=1){Stats[key]=(Stats[key]||0)+amt;}
const Upgrades={palBoxCap:{level:0,costs:[0,20,40,80],values:[10,12,14,16],label:'Pal Box Capacity'},baseWorkers:{level:0,costs:[0,5,10,15],values:[2,3,4,5],label:'Base Workers'},playerSpeed:{level:0,costs:[0,30,60,100],values:[1.9,2.1,2.3,2.5],label:'Move Speed'}};
function getUpgradeVal(key){const u=Upgrades[key];return u.values[Math.min(u.level,u.values.length-1)];}
function applyUpgrades(){boxCap=getUpgradeVal('palBoxCap');baseWorkerLimit=getUpgradeVal('baseWorkers');PL.speed=getUpgradeVal('playerSpeed');}

// ═══════════════════════════════
// INVENTORY UI
// ═══════════════════════════════
function updResUI(){renderBagSlots();if(document.getElementById('inv-overlay').classList.contains('show'))renderInvOverlay();}
const _FOOD_TYPES=new Set(['berry','mushroom','mushroomSoup','cookedMeat','rawMeat']);
function renderBagSlots(){const items=playerInv.filter(Boolean).slice(0,5);for(let i=0;i<5;i++){const el=document.getElementById('bag-'+i);el.innerHTML='';el.className='bag-slot'+(items[i]?' has-item':'');if(items[i]){el.textContent=items[i].emoji;const q=document.createElement('span');q.className='sq';q.textContent=items[i].qty;el.appendChild(q);if(_FOOD_TYPES.has(items[i].type)){el.title='Tap to eat';el.style.borderColor='#4ade80aa';}else{el.style.borderColor='';}}}}
// Bag slot quick-eat — attach once at init
for(let _bsi=0;_bsi<5;_bsi++){((_i)=>{const _el=document.getElementById('bag-'+_i);function _tryEat(e){const items=playerInv.filter(Boolean);const item=items[_i];if(item&&_FOOD_TYPES.has(item.type)){e.stopPropagation();e.preventDefault();eatFood(item.type);updResUI();}}_el.addEventListener('click',_tryEat);_el.addEventListener('touchstart',e=>{e.preventDefault();_tryEat(e);},{passive:false});})(_bsi);}
function openInvOverlay(tab){renderInvOverlay();document.getElementById('inv-overlay').classList.add('show');if(typeof switchInvTab==='function')switchInvTab(tab||'inv');}
function closeInvOverlay(){document.getElementById('inv-overlay').classList.remove('show');}
document.getElementById('inv-close').onclick=closeInvOverlay;
document.getElementById('inv-btn').addEventListener('click',()=>openInvOverlay('inv'));
document.getElementById('inv-btn').addEventListener('touchstart',e=>{e.preventDefault();openInvOverlay('inv');},{passive:false});
// PALDEX / TECH side button
(function(){const b=document.getElementById('pdx-btn');if(!b)return;
  const _open=()=>openInvOverlay('pdx');
  b.addEventListener('click',_open);
  b.addEventListener('touchstart',e=>{e.preventDefault();_open();},{passive:false});
})();
// Backdrop tap closes inv-overlay (tapping outside the panel)
(function(){const ov=document.getElementById('inv-overlay');if(!ov)return;
  ov.addEventListener('pointerdown',e=>{if(e.target===ov)closeInvOverlay();});
})();
// Tab switching
document.querySelectorAll('.inv-tab').forEach(t=>{
  const k=t.getAttribute('data-tab');
  const fn=()=>{if(typeof switchInvTab==='function')switchInvTab(k);};
  t.addEventListener('click',fn);
  t.addEventListener('touchstart',e=>{e.preventDefault();fn();},{passive:false});
});
let _invDragIdx=null;
function renderInvOverlay(){
  const g=document.getElementById('inv-grid');g.innerHTML='';
  for(let i=0;i<playerInv.length;i++){
    const c=document.createElement('div'),item=playerInv[i];
    c.className='inv-cell'+(item?' has-item':'');
    c.dataset.idx=i;
    if(item){
      c.textContent=item.emoji;
      // ── GEAR VOUCHER ── unique per crafted instance, tap EQ to equip (swaps with current)
      if(item.isGear){
        const gearObj=(typeof _gearById==='function')?_gearById(item.gearId):null;
        const broken=gearObj?!!gearObj.broken:false;
        c.classList.remove('has-item');c.classList.add('is-gear');
        if(broken)c.classList.add('is-gear-broken');
        c.title=(item.name||item.gearKey||'Gear')+(broken?' (broken — repair at bench)':' — tap EQ to equip');
        if(gearObj){
          const bar=document.createElement('div');bar.className='gd';
          const fill=document.createElement('i');
          const pct=Math.max(0,Math.min(1,(gearObj.dur||0)/(gearObj.max||1)));
          fill.style.width=(pct*100).toFixed(0)+'%';
          fill.style.background=pct>0.5?'#4aff78':pct>0.25?'#facc15':'#f87171';
          bar.appendChild(fill);c.appendChild(bar);
        }
        const tag=document.createElement('span');tag.className='eq-mini';tag.textContent=broken?'BRK':'EQ';c.appendChild(tag);
        const eb=document.createElement('button');eb.textContent=broken?'✗':'EQ';
        eb.style.cssText='position:absolute;bottom:5px;right:2px;font-size:7px;padding:1px 4px;background:'+(broken?'#3a1a1a':'#0a2540')+';border:1px solid '+(broken?'#f87171':'#60a5fa')+';border-radius:3px;color:'+(broken?'#f87171':'#9bd0fa')+';cursor:pointer;line-height:1;font-weight:bold;';
        eb.onclick=(e)=>{
          e.stopPropagation();
          if(broken){spawnPop('🛠 Repair at the bench first','#f87171');return;}
          if(!gearObj){spawnPop('Gear missing','#f87171');return;}
          _removeGearVoucher(item.gearId);
          _equipGear(gearObj);
          spawnPop('✨ Equipped '+(item.emoji||'')+' '+(item.name||item.gearKey||''),'#4aff78');
          if(typeof updEquipPanel==='function')updEquipPanel();
          if(typeof updResUI==='function')updResUI();
          renderInvOverlay();
        };
        c.style.position='relative';c.appendChild(eb);
      }else{
      const q=document.createElement('span');q.className='iq';q.textContent=item.qty;c.appendChild(q);
      if(item.type==='cookedMeat'||item.type==='rawMeat'||item.type==='berry'||item.type==='mushroom'||item.type==='mushroomSoup'){
        const eb=document.createElement('button');eb.textContent='EAT';
        eb.style.cssText='position:absolute;bottom:2px;right:2px;font-size:7px;padding:2px 5px;background:#14532d;border:1px solid #4ade80;border-radius:4px;color:#4ade80;cursor:pointer;line-height:1;touch-action:manipulation;z-index:2;';
        const _doEat=()=>{eatFood(item.type);renderInvOverlay();};
        eb.onclick=(e)=>{e.stopPropagation();e.preventDefault();_doEat();};
        eb.addEventListener('touchstart',(e)=>{e.stopPropagation();e.preventDefault();_doEat();},{passive:false});
        c.style.position='relative';c.appendChild(eb);
        // Tap the cell itself to eat (mobile-friendly)
        const _tapEat=(e)=>{if(e.target===eb)return;_doEat();};
        c.addEventListener('click',_tapEat);
        c.addEventListener('touchend',(e)=>{if(e.target===eb)return;e.preventDefault();_doEat();},{passive:false});
      }
      }
      c.draggable=true;
      c.addEventListener('dragstart',e=>{
        _invDragIdx=i;c.classList.add('dragging');
        try{e.dataTransfer.effectAllowed='move';}catch(_){}
        // For gear vouchers, also expose the gid so eq-slot drop targets work
        if(item.isGear){_dragState.dragging=true;_dragState.gid=item.gearId;try{e.dataTransfer.setData('text/plain',String(item.gearId));}catch(_){}}
      });
      c.addEventListener('dragend',()=>{
        _invDragIdx=null;
        if(item.isGear)setTimeout(()=>{_dragState.dragging=false;_dragState.gid=null;},80);
        document.querySelectorAll('.inv-cell').forEach(el=>el.classList.remove('drag-over','dragging'));
        document.querySelectorAll('.eq-slot').forEach(el=>el.classList.remove('drag-target'));
      });
      // Touch DnD
      c.addEventListener('touchstart',e=>{
        if(e.touches.length!==1)return;
        _invDragIdx=i;c.classList.add('dragging');
        if(item.isGear){_dragState.dragging=true;_dragState.gid=item.gearId;_makeGhost({key:item.gearKey});const t=e.touches[0];_moveGhost(t.clientX,t.clientY);}
      },{passive:true});
      c.addEventListener('touchmove',e=>{if(item.isGear&&_ghost){const tt=e.touches[0];_moveGhost(tt.clientX,tt.clientY);}},{passive:true});
      c.addEventListener('touchend',e=>{
        if(_invDragIdx===null)return;
        const t=e.changedTouches[0];
        const el=document.elementFromPoint(t.clientX,t.clientY);
        // Voucher → eq-slot
        const eqTgt=item.isGear?(el?el.closest('.eq-slot'):null):null;
        if(eqTgt){
          _handleDrop(eqTgt,item.gearId);
          _invDragIdx=null;_killGhost();
          setTimeout(()=>{_dragState.dragging=false;_dragState.gid=null;},80);
          document.querySelectorAll('.inv-cell').forEach(el2=>el2.classList.remove('drag-over','dragging'));
          return;
        }
        const tgt=el?el.closest('.inv-cell'):null;
        if(tgt&&tgt.dataset.idx!==undefined){
          const ti=parseInt(tgt.dataset.idx);
          if(ti!==_invDragIdx){const tmp=playerInv[_invDragIdx];playerInv[_invDragIdx]=playerInv[ti];playerInv[ti]=tmp;renderInvOverlay();}
        }
        _invDragIdx=null;
        if(item.isGear){_killGhost();setTimeout(()=>{_dragState.dragging=false;_dragState.gid=null;},80);}
        document.querySelectorAll('.inv-cell').forEach(el2=>el2.classList.remove('drag-over','dragging'));
      },{passive:true});
    }
    c.addEventListener('dragover',e=>{if(_invDragIdx===null&&!_dragState.gid)return;e.preventDefault();c.classList.add('drag-over');});
    c.addEventListener('dragleave',()=>c.classList.remove('drag-over'));
    c.addEventListener('drop',e=>{
      e.preventDefault();c.classList.remove('drag-over');
      // Equipped-gear → inventory unequip path
      if(_invDragIdx===null&&_dragState.gid){
        for(const k of ['weapon','axe','pickaxe','armor']){
          if(equippedId[k]===_dragState.gid){_unequipFromSlot(k);return;}
        }
        return;
      }
      if(_invDragIdx===null)return;
      const ti=parseInt(c.dataset.idx);
      if(ti===_invDragIdx)return;
      const tmp=playerInv[_invDragIdx];playerInv[_invDragIdx]=playerInv[ti];playerInv[ti]=tmp;
      _invDragIdx=null;renderInvOverlay();
    });
    g.appendChild(c);
  }
}

// ═══════════════════════════════
// DROPPED ITEMS
// ═══════════════════════════════
const droppedItems=[];
const DROP_MAGNET_R=130,DROP_COLLECT_R=26,DROP_LIFETIME=18000,MAX_DROPPED=60;
// ── LOOT BAG (player death drop) ──
const lootBags=[];
const LOOT_BAG_R=30;
const LOOT_BAG_LIFE=300000,LOOT_BAG_MAX=8;
function spawnLootBag(x,y,items){if(!items||!items.length)return;if(lootBags.length>=LOOT_BAG_MAX)lootBags.shift();lootBags.push({x,y,items,id:Math.random(),bobT:Math.random()*Math.PI*2,life:LOOT_BAG_LIFE});}
function updLootBags(dt){for(let i=lootBags.length-1;i>=0;i--){const b=lootBags[i];b.bobT+=dt*0.003;b.life=(b.life||LOOT_BAG_LIFE)-dt;if(b.life<=0){lootBags.splice(i,1);continue;}if(PL.dead)continue;if(Math.hypot(PL.x-b.x,PL.y-b.y)<LOOT_BAG_R){let got=0;for(const it of b.items){if(!it)continue;iAdd(playerInv,it.type,it.qty);got+=it.qty;}playSnd('pickup');spawnPop('🎒 Recovered '+got+' items','#facc15');addPart(b.x,b.y,'#facc15',10);lootBags.splice(i,1);updResUI();saveGame();}}}
function drawLootBags(){const z=ZOOM;for(const b of lootBags){if(!onScreen(b.x-12,b.y-14,24,28))continue;const bob=Math.sin(b.bobT)*2.5*z,sx=wx(b.x),sy=wy(b.y)+bob;ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();ctx.ellipse(sx,wy(b.y)+5*z,9*z,3.5*z,0,0,Math.PI*2);ctx.fill();const pulse=0.6+Math.sin(Date.now()*.005)*0.4;ctx.strokeStyle='rgba(250,204,21,'+pulse.toFixed(2)+')';ctx.lineWidth=1.5*z;ctx.beginPath();ctx.arc(sx,sy,12*z,0,Math.PI*2);ctx.stroke();ctx.font=Math.round(16*z)+'px serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('🎒',sx,sy);ctx.fillStyle='#facc15';ctx.font='bold '+Math.round(6*z)+'px Courier New';ctx.fillText('LOOT',sx,sy-15*z);ctx.textAlign='left';ctx.textBaseline='alphabetic';}}
function spawnDrop(type,qty,x,y){if(droppedItems.length>=MAX_DROPPED){const _ei=droppedItems.findIndex(d=>!d.rare);droppedItems.splice(_ei<0?0:_ei,1);}const a=Math.random()*Math.PI*2,spd=0.6+Math.random()*0.8;droppedItems.push({type,emoji:IEMOJI[type]||'❓',qty,x,y,vx:Math.cos(a)*spd,vy:Math.sin(a)*spd,life:DROP_LIFETIME,bobT:Math.random()*Math.PI*2});}
function updDrops(dt){for(let i=droppedItems.length-1;i>=0;i--){const d=droppedItems[i];d.life-=dt;d.bobT+=dt*0.003;const dist=Math.hypot(PL.x-d.x,PL.y-d.y);if(dist<DROP_MAGNET_R&&!PL.dead){const dx=PL.x-d.x,dy=PL.y-d.y,dn=Math.hypot(dx,dy)||1,pull=Math.max(0.5,(DROP_MAGNET_R-dist)/DROP_MAGNET_R)*4.6;d.vx=dx/dn*pull;d.vy=dy/dn*pull;}else{d.vx*=0.88;d.vy*=0.88;}d.x+=d.vx;d.y+=d.vy;d.x=Math.max(10,Math.min(d.x,MAP_W-10));d.y=Math.max(10,Math.min(d.y,MAP_H-10));if(dist<DROP_COLLECT_R&&!PL.dead){playSnd('pickup');iAdd(playerInv,d.type,d.qty);updResUI();popAt('+'+d.qty+d.emoji,'#4aff78',d.x,d.y);droppedItems.splice(i,1);continue;}if(d.life<=0)droppedItems.splice(i,1);}}
function drawDrops(){const z=ZOOM;for(const d of droppedItems){if(!onScreen(d.x-8,d.y-8,16,16))continue;const bob=Math.sin(d.bobT)*3*z,alpha=d.life<2000?(d.life/2000):1;ctx.globalAlpha=alpha;ctx.fillStyle='rgba(0,0,0,.25)';ctx.beginPath();ctx.ellipse(wx(d.x),wy(d.y)+4*z,6*z,2.5*z,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='rgba(0,0,0,.55)';ctx.beginPath();ctx.arc(wx(d.x),wy(d.y)-2*z+bob,7*z,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#facc1588';ctx.lineWidth=z;ctx.beginPath();ctx.arc(wx(d.x),wy(d.y)-2*z+bob,7*z,0,Math.PI*2);ctx.stroke();ctx.font=\`\${Math.round(9*z)}px serif\`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(d.emoji,wx(d.x),wy(d.y)-2*z+bob);ctx.textAlign='left';ctx.textBaseline='alphabetic';ctx.globalAlpha=1;}}

// ═══════════════════════════════
// PAL TYPES
// ═══════════════════════════════
const PAL_TYPES=[
  {name:'Foxling',emoji:'🦊',rare:false,behavior:'passive',bodyCol:'#e8722a',eyeCol:'#fff',tailCol:'#ffcc44',size:14,baseHp:9,baseDmg:2,
   ability:{name:'Ember',type:'fire',color:'#ff6622',dmg:2,range:55,cd:2200,pc:6},
   helperType:'wood',workSpd:4200,dropType:'wood',biomes:[0,3],
   special:{name:'Ember Ring',emoji:'🔥',color:'#ff7700',dmg:4,range:72,cd:5000,effect:'slow',pc:10,slowTime:2500,slowMult:0.45}},
  {name:'Mossy',emoji:'🌿',rare:false,behavior:'passive',bodyCol:'#2d8a3e',eyeCol:'#fff',tailCol:'#1a5a28',size:13,baseHp:9,baseDmg:2,
   ability:{name:'Vine Strike',type:'nature',color:'#4aff60',dmg:2,range:50,cd:2600,pc:5},
   helperType:'wood',workSpd:4400,dropType:'wood',biomes:[0,3],
   special:{name:'Root Snare',emoji:'🌿',color:'#44ff66',dmg:3,range:65,cd:6000,effect:'stun',pc:9,stunTime:700}},
  {name:'Pebble',emoji:'🪨',rare:false,behavior:'passive',bodyCol:'#8899aa',eyeCol:'#fff',tailCol:'#667788',size:12,baseHp:8,baseDmg:2,
   ability:{name:'Rock Throw',type:'earth',color:'#ccaa88',dmg:2,range:48,cd:2900,pc:4},
   helperType:'stone',workSpd:4600,dropType:'stone',biomes:[1,2],
   special:{name:'Stone Hail',emoji:'🪨',color:'#ccaa88',dmg:3,range:62,cd:4500,effect:'multi',pc:8,hits:3}},
  {name:'Blaze',emoji:'🔥',rare:true,behavior:'aggressive',bodyCol:'#cc2200',eyeCol:'#ffee00',tailCol:'#ff7700',size:15,baseHp:18,baseDmg:3,
   ability:{name:'Inferno',type:'fire',color:'#ff4400',dmg:3,range:65,cd:1900,pc:8},
   helperType:'stone_copper',workSpd:2800,dropType:'copper',biomes:[2],
   special:{name:'Magma Surge',emoji:'🌋',color:'#ff2200',dmg:6,range:78,cd:5500,effect:'shake',pc:14,shake:8}},
  {name:'Frostie',emoji:'❄️',rare:true,behavior:'aggressive',bodyCol:'#44aadd',eyeCol:'#fff',tailCol:'#aaeeff',size:14,baseHp:18,baseDmg:3,
   ability:{name:'Ice Shot',type:'ice',color:'#aaeeff',dmg:3,range:60,cd:2100,pc:7},
   helperType:'stone_copper',workSpd:3000,dropType:'stone',biomes:[1],
   special:{name:'Blizzard',emoji:'❄️',color:'#88ddff',dmg:5,range:75,cd:6000,effect:'slow',pc:12,slowTime:3500,slowMult:0.38}},
  {name:'Stonehorn',emoji:'🦏',rare:false,behavior:'aggressive',bodyCol:'#7a6a5a',eyeCol:'#ffcc88',tailCol:'#5a4a3a',size:15,baseHp:14,baseDmg:3,
   ability:{name:'Headbutt',type:'earth',color:'#c8a888',dmg:3,range:44,cd:2400,pc:5},
   helperType:'stone',workSpd:3800,dropType:'stone',biomes:[1],
   special:{name:'Shockwave',emoji:'💥',color:'#c8a888',dmg:5,range:68,cd:5200,effect:'stun',pc:11,shake:6,stunTime:600}},
  {name:'Coprite',emoji:'🟠',rare:false,behavior:'passive',bodyCol:'#c07820',eyeCol:'#fff',tailCol:'#e09030',size:13,baseHp:12,baseDmg:3,
   ability:{name:'Ore Blast',type:'earth',color:'#ff9933',dmg:3,range:52,cd:2200,pc:5},
   helperType:'stone_copper',workSpd:3500,dropType:'copper',biomes:[2],
   special:{name:'Ore Storm',emoji:'⚡',color:'#ff9933',dmg:4,range:65,cd:4500,effect:'multi',pc:10,hits:3}},
  {name:'Sylvan',emoji:'🧚',rare:true,behavior:'timid',bodyCol:'#44cc66',eyeCol:'#fff',tailCol:'#22aa44',size:12,baseHp:14,baseDmg:2,
   ability:{name:'Leaf Storm',type:'nature',color:'#66ff88',dmg:2,range:58,cd:2000,pc:7},
   helperType:'wood',workSpd:2600,dropType:'wood',biomes:[3],
   special:{name:'Petal Barrage',emoji:'🌸',color:'#66ff88',dmg:4,range:68,cd:4200,effect:'multi',pc:12,hits:4}},
  {name:'DarkFang',emoji:'🐺',rare:true,behavior:'aggressive',bodyCol:'#1a0a2a',eyeCol:'#ff2200',tailCol:'#2e0a1e',size:16,baseHp:26,baseDmg:5,
   ability:{name:'Shadow Bite',type:'dark',color:'#bb22ff',dmg:5,range:62,cd:1600,pc:9},
   helperType:'stone_copper',workSpd:2300,dropType:'copper',biomes:[4],
   special:{name:'Void Howl',emoji:'🌑',color:'#9900ff',dmg:7,range:80,cd:5200,effect:'stun',pc:14,shake:8,stunTime:800}},
  {name:'Voidclaw',emoji:'🦂',rare:true,behavior:'aggressive',bodyCol:'#280020',eyeCol:'#ff6600',tailCol:'#3c0030',size:15,baseHp:24,baseDmg:5,
   ability:{name:'Venom Sting',type:'dark',color:'#ff4400',dmg:5,range:66,cd:1500,pc:10},
   helperType:'stone_copper',workSpd:2500,dropType:'copper',biomes:[4],
   special:{name:'Venom Cloud',emoji:'☠️',color:'#ff4400',dmg:5,range:75,cd:4200,effect:'multi',pc:12,hits:4}},
];
// Helper: mark a wild pal hostile (so passive/timid pals fight back when attacked)
function _makeHostile(wp){if(wp&&!wp.dead){wp.hostile=true;}}

// ═══════════════════════════════
// BOSS TYPES (one per biome)
// ═══════════════════════════════
const BOSS_TYPES=[
  {name:'Golem King',emoji:'🗿',biome:0,bodyCol:'#667766',eyeCol:'#ff6600',tailCol:'#556655',size:24,baseHp:80,baseDmg:6,
   ability:{name:'Ground Slam',type:'earth',color:'#cc9955',dmg:6,range:70,cd:2000,pc:14},boss:true,rare:true},
  {name:'Stonewrath',emoji:'⚙️',biome:1,bodyCol:'#556677',eyeCol:'#ccddff',tailCol:'#445566',size:22,baseHp:70,baseDmg:5,
   ability:{name:'Rock Storm',type:'earth',color:'#aabbcc',dmg:5,range:72,cd:1900,pc:12},boss:true,rare:true},
  {name:'Blazelord',emoji:'🌋',biome:2,bodyCol:'#880000',eyeCol:'#ffee00',tailCol:'#cc2200',size:23,baseHp:75,baseDmg:6,
   ability:{name:'Magma Wave',type:'fire',color:'#ff2200',dmg:6,range:80,cd:1800,pc:14},boss:true,rare:true},
  {name:'Thornlord',emoji:'🌵',biome:3,bodyCol:'#226622',eyeCol:'#ffee44',tailCol:'#2a8822',size:21,baseHp:65,baseDmg:5,
   ability:{name:'Thorn Burst',type:'nature',color:'#44ff44',dmg:5,range:75,cd:2000,pc:12},boss:true,rare:true},
];
const bossPals=[];
const BOSS_MAX=2;
let bossSpawnTimer=75000;

function spawnBoss(){
  if(bossPals.filter(b=>!b.dead).length>=BOSS_MAX)return;
  const biome=Math.floor(Math.random()*4);
  const def=BOSS_TYPES[biome];
  let ox=MAP_W/2,oy=MAP_H/2,tries=0;
  do{const col=Math.floor(Math.random()*(COLS-6))+3;const row=Math.floor(Math.random()*(ROWS-6))+3;ox=col*TILE+Math.random()*TILE;oy=row*TILE+Math.random()*TILE;tries++;}while(Math.hypot(ox-PL.x,oy-PL.y)<200&&tries<30);
  const lv=Math.max(3,PL.level+Math.floor(Math.random()*3));
  const hp=def.baseHp+lv*4;
  bossPals.push({def,x:ox,y:oy,hp,maxHp:hp,level:lv,dead:false,id:Math.random(),aF:0,aT:0,shakeT:0,vx:0,vy:0,wT:0,abCD:def.ability.cd,_deadT:0,isBoss:true});
  spawnPop('⚠️ BOSS: '+def.name+'!','#ff4444');
  if(typeof markSeen==='function')markSeen(def.name);
}

function killBoss(b){
  if(b.dead)return;
  b.dead=true;b._deadT=0;
  playSnd('paldeath');
  for(let i=0;i<4;i++){addPart(b.x+(Math.random()*40-20),b.y+(Math.random()*40-20),'#ffcc44',10);}
  addPart(b.x,b.y,'#ff4444',18);
  const xpGain=b.level*20+100; // boss bonus XP
  gainPlayerXP(xpGain);
  popAt('⭐ BOSS +XP '+xpGain,'#facc15',b.x,b.y-24);
  spawnDrop('copper',3+Math.floor(Math.random()*4),b.x,b.y);
  spawnDrop('stone',2+Math.floor(Math.random()*3),b.x,b.y+12);
  if(Math.random()<0.45){
    const rareDefs=PAL_TYPES.filter(p=>p.rare);
    const rd=rareDefs[Math.floor(Math.random()*rareDefs.length)]||PAL_TYPES[3];
    const lv2=Math.max(1,b.level-2);
    wildPals.push({def:rd,x:b.x+Math.random()*60-30,y:b.y+Math.random()*60-30,hp:rd.baseHp+lv2*2,maxHp:rd.baseHp+lv2*2,level:lv2,xp:0,xpNeeded:xpToNext(lv2),dead:false,id:Math.random(),aF:0,aT:0,shakeT:0,vx:0,vy:0,wT:2000,abCD:rd.ability.cd,rarity:'rare'});
    spawnPop('⭐ Rare Pal spawned!','#facc15');
  }
  spawnPop('💥 BOSS DEFEATED! +'+xpGain+' XP','#ff4444');
  addStat('palsDefeated');questProg('kill');questProg('boss');
  bossSpawnTimer=Math.max(bossSpawnTimer,45000);
  saveGame();
}

// ═══════════════════════════════
// BOSS ZONE SYSTEM (Fire / Rock / Ice)
// ═══════════════════════════════
const BOSS_ZONES=[
  // idx 0: Rocky boss — deep north Rocky biome (angle≈-90°, nd≈0.36) — radius scaled for 20% larger map
  {id:'rocky',name:'⛰️ Rocky Zone',centerFx:0.50,centerFy:0.14,radius:720,
   tileColor1:'#2a2418',tileColor2:'#38321e',overlayColor:'rgba(140,120,60,0.16)',mmColor:'#776644',vigColor:'rgba(100,80,20,0.26)',
   boss:{name:'Stone Golem',emoji:'🗿',bodyCol:'#556644',eyeCol:'#ffcc44',tailCol:'#445533',size:30,baseHp:140,baseDmg:9,
     ability:{name:'Boulder Crush',type:'earth',color:'#cc9933',dmg:9,range:80,cd:2400,pc:18},
     special:{name:'Earthquake',type:'earth',color:'#ffaa22',dmg:14,range:140,cd:7000,pc:20},
     boss:true,rare:true}},
  // idx 1: Ice boss — far east-northeast Ice biome (nd≈0.44, angle≈-10°)
  {id:'ice',name:'❄️ Ice Zone',centerFx:0.93,centerFy:0.42,radius:620,
   tileColor1:'#0a1830',tileColor2:'#0e2240',overlayColor:'rgba(60,160,255,0.16)',mmColor:'#4488bb',vigColor:'rgba(20,100,200,0.28)',
   boss:{name:'Frost Drake',emoji:'🦕',bodyCol:'#224466',eyeCol:'#88eeff',tailCol:'#1a3355',size:26,baseHp:110,baseDmg:7,
     ability:{name:'Ice Shard',type:'ice',color:'#88ddff',dmg:7,range:95,cd:2000,pc:14},
     special:{name:'Blizzard',type:'ice',color:'#aaeeff',dmg:11,range:130,cd:5500,pc:16},
     boss:true,rare:true}},
  // idx 2: Fire boss — far east-southeast Fire biome (nd≈0.44, angle≈40°)
  {id:'fire',name:'🔥 Fire Zone',centerFx:0.84,centerFy:0.78,radius:620,
   tileColor1:'#3a1200',tileColor2:'#4a1a06',overlayColor:'rgba(255,60,0,0.18)',mmColor:'#cc2200',vigColor:'rgba(210,40,0,0.30)',
   boss:{name:'Inferno Beast',emoji:'🐲',bodyCol:'#8a0000',eyeCol:'#ffee00',tailCol:'#cc1100',size:28,baseHp:120,baseDmg:8,
     ability:{name:'Flame Breath',type:'fire',color:'#ff4400',dmg:7,range:88,cd:2200,pc:16},
     special:{name:'Magma Eruption',type:'fire',color:'#ff6600',dmg:12,range:120,cd:6000,pc:18},
     boss:true,rare:true}},
  // idx 3: Forest boss — deep south Dense Forest biome (nd≈0.38, angle≈108°)
  {id:'forest',name:'🌲 Forest Zone',centerFx:0.38,centerFy:0.86,radius:640,
   tileColor1:'#0a1e08',tileColor2:'#0f2a0c',overlayColor:'rgba(30,120,20,0.18)',mmColor:'#1a5e12',vigColor:'rgba(10,80,5,0.28)',
   boss:{name:'Forest Titan',emoji:'🦎',bodyCol:'#224a18',eyeCol:'#aaff44',tailCol:'#1a3a10',size:28,baseHp:130,baseDmg:8,
     ability:{name:'Vine Whip',type:'nature',color:'#44cc22',dmg:8,range:90,cd:2100,pc:15},
     special:{name:'Root Surge',type:'nature',color:'#66ff44',dmg:13,range:130,cd:6000,pc:18},
     boss:true,rare:true}},
  // idx 4: Danger boss — deep SE Danger Zone corner (nd≈0.55, fy≈0.38 > 0.10)
  {id:'danger',name:'☠️ Danger Zone',centerFx:0.90,centerFy:0.88,radius:660,
   tileColor1:'#1a0808',tileColor2:'#260a0a',overlayColor:'rgba(160,8,8,0.20)',mmColor:'#661111',vigColor:'rgba(150,0,0,0.35)',
   boss:{name:'Death Hydra',emoji:'🐉',bodyCol:'#6a0000',eyeCol:'#ff2200',tailCol:'#550000',size:34,baseHp:200,baseDmg:14,
     ability:{name:'Toxic Bite',type:'poison',color:'#aa2200',dmg:12,range:100,cd:1800,pc:20},
     special:{name:'Chaos Wave',type:'fire',color:'#ff0000',dmg:18,range:160,cd:5000,pc:22},
     boss:true,rare:true}},
];

// Pre-compute zone lookup per tile for drawWorld
const zoneBiomeMap=[];
(function(){
  for(let r=0;r<ROWS;r++){
    zoneBiomeMap[r]=[];
    for(let c=0;c<COLS;c++){
      const wx2=c*TILE,wy2=r*TILE;
      let inZone=-1;
      for(let z=0;z<BOSS_ZONES.length;z++){
        const bz=BOSS_ZONES[z];
        if(Math.hypot(wx2-bz.centerFx*MAP_W,wy2-bz.centerFy*MAP_H)<bz.radius){inZone=z;break;}
      }
      zoneBiomeMap[r][c]=inZone;
    }
  }
})();

function getPlayerBossZone(){
  const c=Math.floor(PL.x/TILE),r=Math.floor(PL.y/TILE);
  if(c<0||r<0||c>=COLS||r>=ROWS)return -1;
  return zoneBiomeMap[r][c];
}

// Zone bosses — one per zone, resurrected on timer (5 zones: Rocky/Ice/Fire/Forest/Danger)
const zoneBossState=[
  {boss:null,respawnTimer:0,zoneIdx:0,defeated:false},
  {boss:null,respawnTimer:0,zoneIdx:1,defeated:false},
  {boss:null,respawnTimer:0,zoneIdx:2,defeated:false},
  {boss:null,respawnTimer:0,zoneIdx:3,defeated:false},
  {boss:null,respawnTimer:0,zoneIdx:4,defeated:false},
];
let _lastBossZone=-1;

function spawnZoneBoss(zoneIdx){
  const zs=zoneBossState[zoneIdx];
  const bz=BOSS_ZONES[zoneIdx];
  const def=bz.boss;
  const lv=Math.max(5,PL.level+3+zoneIdx*2);
  const hp=def.baseHp+lv*6;
  const a=Math.random()*Math.PI*2,r2=80+Math.random()*160;
  const bx=bz.centerFx*MAP_W+Math.cos(a)*r2,by=bz.centerFy*MAP_H+Math.sin(a)*r2;
  zs.boss={def,x:bx,y:by,hp,maxHp:hp,level:lv,dead:false,id:Math.random(),
    aF:0,aT:0,shakeT:0,vx:0,vy:0,wT:0,abCD:def.ability.cd,spCD:def.special.cd*0.5,
    _deadT:0,isBoss:true,zoneIdx,phase:1,_phasePop:false};
  zs.defeated=false;
  zs.respawnTimer=0;
  spawnPop('⚠️ '+bz.name+' BOSS: '+def.name+'!','#ff4444');
  showEventBanner('⚠️ '+bz.name+' — '+def.name+' awakens!','#ff4444',10000);
  if(typeof markSeen==='function')markSeen(def.name);
}

function killZoneBoss(b){
  if(b.dead)return;
  b.dead=true;b._deadT=0;
  const zs=zoneBossState[b.zoneIdx];
  zs.defeated=true;
  zs.respawnTimer=300000+Math.random()*120000;
  const _respMin=Math.round(zs.respawnTimer/60000);
  showEventBanner('💀 '+b.def.name+' DEFEATED — Respawning in ~'+_respMin+' min','#ff8844',6500);
  playSnd('paldeath');
  for(let i=0;i<6;i++){addPart(b.x+(Math.random()*60-30),b.y+(Math.random()*60-30),'#ffcc44',12);}
  addPart(b.x,b.y,'#ff4444',22);
  const xpGain=b.level*25+120;
  gainPlayerXP(xpGain);
  popAt('👑 ZONE BOSS! +XP '+xpGain,'#ffd700',b.x,b.y-30);
  // Big loot drop — base resources + ZONE BOSS rare materials
  spawnDrop('copper',5+Math.floor(Math.random()*5),b.x,b.y);
  spawnDrop('coal',3+Math.floor(Math.random()*4),b.x,b.y+16);
  spawnDrop('stone',4+Math.floor(Math.random()*4),b.x,b.y-16);
  // Coins always, scaled by boss level
  spawnDrop('coin',25+b.level*3+Math.floor(Math.random()*15),b.x+8,b.y);
  // Tiered rare drops by zone — Rocky/Ice/Fire/Forest/Danger
  const _bzIdx=b.zoneIdx;
  if(_bzIdx===0){spawnDrop('crystal_shard',1+Math.floor(Math.random()*2),b.x-8,b.y+10);}                                                                // Rocky → crystal shard
  else if(_bzIdx===1){spawnDrop('crystal_shard',2+Math.floor(Math.random()*2),b.x-8,b.y+10);spawnDrop('phoenix_feather',1,b.x+10,b.y);}                 // Ice → crystals + feather
  else if(_bzIdx===2){spawnDrop('phoenix_feather',1+Math.floor(Math.random()*2),b.x-8,b.y+10);spawnDrop('crystal_shard',1,b.x+10,b.y);}                 // Fire → feather + crystal
  else if(_bzIdx===3){spawnDrop('dragon_horn',1+Math.floor(Math.random()*2),b.x-8,b.y+10);spawnDrop('crystal_shard',1,b.x+10,b.y);}                     // Forest → dragon horn
  else if(_bzIdx===4){spawnDrop('dragon_horn',2+Math.floor(Math.random()*2),b.x-8,b.y+10);spawnDrop('phoenix_feather',1,b.x+10,b.y);spawnDrop('crystal_shard',2+Math.floor(Math.random()*2),b.x,b.y+18);} // Danger → all rarities
  // Star dust always — used for legendary gear crafting
  spawnDrop('star_dust',2+Math.floor(Math.random()*3),b.x+12,b.y-8);
  // Mark rare drops so loot glow draws them gold
  for(let _i=droppedItems.length-1;_i>=0&&_i>droppedItems.length-9;_i--){const _d=droppedItems[_i];if(_d&&['dragon_horn','phoenix_feather','crystal_shard','star_dust'].includes(_d.type)){_d.rare=true;}}
  // Guaranteed epic/legendary pal spawn
  const epicDefs=PAL_TYPES.filter(p=>p.rare);
  const rd=epicDefs[Math.floor(Math.random()*epicDefs.length)]||PAL_TYPES[0];
  const lv2=Math.max(1,b.level-1);
  const rarity=Math.random()<0.30?'legendary':'epic';
  wildPals.push({def:rd,x:b.x+Math.random()*80-40,y:b.y+Math.random()*80-40,hp:rd.baseHp+lv2*3,maxHp:rd.baseHp+lv2*3,level:lv2,xp:0,xpNeeded:xpToNext(lv2),dead:false,id:Math.random(),aF:0,aT:0,shakeT:0,vx:0,vy:0,wT:2500,abCD:rd.ability.cd,skCD:rd.special?.cd||9999,rarity,dmgBonus:2,sizeBonus:4});
  spawnPop('🌟 '+(rarity==='legendary'?'LEGENDARY':'EPIC')+' Pal spawned!','#ffd700');
  spawnPop('💥 ZONE BOSS DEFEATED! +'+xpGain+' XP','#ff4444');
  const bz=BOSS_ZONES[b.zoneIdx];
  showEventBanner('👑 '+bz.name+' BOSS defeated! Rare pal appeared!','#ffd700',14000);
  addStat('palsDefeated');questProg('kill');
  saveGame();
}

function getBossPhase(b){
  const pct=b.hp/b.maxHp;
  if(pct>0.60)return 1;
  if(pct>0.30)return 2;
  return 3;
}

function updZoneBosses(dt){
  // Respawn check
  for(const zs of zoneBossState){
    if(zs.defeated){
      zs.respawnTimer-=dt;
      if(zs.respawnTimer<=0)spawnZoneBoss(zs.zoneIdx);
    } else if(!zs.boss){
      spawnZoneBoss(zs.zoneIdx);
    }
  }

  // Boss zone entry detection
  const curBZ=getPlayerBossZone();
  if(curBZ!==_lastBossZone){
    _lastBossZone=curBZ;
    const zb2=document.getElementById('zone-badge');
    if(curBZ>=0){
      const bz=BOSS_ZONES[curBZ];
      zb2.textContent='⚠️ BOSS AREA: '+bz.name;zb2.style.color='#ff6644';
      showEventBanner('⚠️ ENTERING '+bz.name+' — BOSS AWAITS!','#ff6644',9000);
      doShake(5);
      // Boss notices player on entry: wake up if calm, brief roar/shake/aura
      const _zs=zoneBossState[curBZ];
      if(_zs&&_zs.boss&&!_zs.boss.dead){
        const _b=_zs.boss;
        _b._calm=false;
        _b._noticeT=900; // brief delayed-attack window so player has time to react
        _b.abCD=Math.max(_b.abCD||0,700);
        _b.spCD=Math.max(_b.spCD||0,1800);
        spawnPop('👁 '+_b.def.name+' notices you!','#ff4444');
        try{playSnd('paldeath');}catch(_e){}
        // Roar particle ring at boss
        for(let _pi=0;_pi<14;_pi++){const _pa=_pi/14*Math.PI*2;addPart(_b.x+Math.cos(_pa)*40,_b.y+Math.sin(_pa)*40,'#ff4422',7);}
        addPart(_b.x,_b.y,'#ff8844',16);
        doShake(7);doHitStop(120);
      }
    }
  }

  // Update each boss
  let closestBoss=null,closestDist=Infinity;
  for(const zs of zoneBossState){
    const b=zs.boss;if(!b)continue;
    if(b.dead){b._deadT=(b._deadT||0)+dt;if(b._deadT>1200)zs.boss=null;continue;}

    // Phase check
    const newPhase=getBossPhase(b);
    if(newPhase!==b.phase){
      b.phase=newPhase;
      const pColors=['','#ff8800','#ff3300'];
      const pNames=['','⚡ ENRAGED','🔥 BERSERK'];
      if(newPhase>=2){spawnPop(pNames[newPhase]+' — Phase '+newPhase,'#ff4444');doShake(7);doHitStop(120);}
      showEventBanner((newPhase===2?'⚡ PHASE 2':'🔥 PHASE 3 — BERSERK!')+' '+b.def.name,'#ff4444',7000);
    }

    // Zone boundary — push boss back inside zone
    const bz=BOSS_ZONES[b.zoneIdx];
    const dzx=b.x-bz.centerFx*MAP_W,dzy=b.y-bz.centerFy*MAP_H;
    const dzd=Math.hypot(dzx,dzy);
    if(dzd>bz.radius*0.9){const f=(dzd-bz.radius*0.9)/dzd;b.x-=dzx*f*0.08;b.y-=dzy*f*0.08;}

    // Calm boss after death-reset: idle until player re-enters arena or attacks
    const playerInside=_playerInArena(b.zoneIdx);
    if(b._calm&&playerInside)b._calm=false;
    // Notice-grace timer: short pause after entry so player gets a fair chance
    if(b._noticeT>0)b._noticeT=Math.max(0,b._noticeT-dt);
    // Auto-reset: if player leaves arena while boss is wounded, refill HP after 10s
    if(!playerInside&&b.hp<b.maxHp&&b._hpAnimT<=0){
      b._outsideT=(b._outsideT||0)+dt;
      if(b._outsideT>=10000){
        _resetZoneBoss(b,'left');
        const _el=document.getElementById('boss-reset-banner');
        if(_el){_el.classList.remove('show');void _el.offsetWidth;_el.classList.add('show');setTimeout(()=>_el.classList.remove('show'),2700);}
        b._outsideT=0;
      }
    } else {
      b._outsideT=0;
    }
    // HP refill animation tween — shows the boss healing back up after reset
    if(b._hpAnimT>0){b._hpAnimT-=dt;b._hpAnim=b._hpAnim+(b.hp-b._hpAnim)*Math.min(1,dt/220);if(b._hpAnimT<=0)b._hpAnim=b.hp;}

    const dx=PL.x-b.x,dy=PL.y-b.y,dist=Math.hypot(dx,dy);
    if(dist<closestDist){closestDist=dist;closestBoss=b;}

    // Phase-based speed
    const baseSpd=1.0+b.level*0.04;
    const phaseSpd=b.phase===3?baseSpd*1.8:b.phase===2?baseSpd*1.35:baseSpd*0.85;
    const aggroR=b.phase===3?360:b.phase===2?290:220;

    // Target selection: closest of player or any nearby player-pal (active, party, base)
    let tgtX=PL.x,tgtY=PL.y,tgtDist=PL.dead?Infinity:dist,tgtIsPal=false,tgtPal=null;
    const _candPals=[];
    if(activePal&&!activePal.fainted)_candPals.push(activePal);
    try{if(typeof basePals!=='undefined'){for(const bp of basePals){if(bp&&!bp.fainted&&bp.hp>0)_candPals.push(bp);}}}catch(e){}
    for(const cp of _candPals){
      const d2=Math.hypot(cp.x-b.x,cp.y-b.y);
      if(d2<tgtDist){tgtDist=d2;tgtX=cp.x;tgtY=cp.y;tgtIsPal=true;tgtPal=cp;}
    }
    const aggro=tgtDist<aggroR&&!b._calm&&!(b._noticeT>0);

    if(aggro){
      const tdx=tgtX-b.x,tdy=tgtY-b.y,tdL=tgtDist||1;
      moveWithColl(b,tdx/tdL*phaseSpd,tdy/tdL*phaseSpd,18,18);
    } else {
      b.wT=(b.wT||0)-dt;
      if(b.wT<=0){b.wT=1400+Math.random()*1000;b.vx=(Math.random()-.5)*0.6;b.vy=(Math.random()-.5)*0.6;}
      moveWithColl(b,b.vx,b.vy,18,18);
    }
    b.aT+=dt;if(b.aT>160){b.aF=(b.aF+1)%4;b.aT=0;}
    if(b.shakeT>0)b.shakeT=Math.max(0,b.shakeT-dt);
    tickPalFx(b,dt);

    // Basic ability — also fires when a player-pal is in range (no more pal-ignoring)
    b.abCD-=dt;
    const cdMult=b.phase===3?0.45:b.phase===2?0.65:1.0;
    const palDist=tgtIsPal?tgtDist:(activePal&&!activePal.fainted?Math.hypot(activePal.x-b.x,activePal.y-b.y):Infinity);
    if(b.abCD<=0&&!b._calm&&(((!PL.dead)&&dist<b.def.ability.range*1.2)||palDist<b.def.ability.range*1.2)){
      b.abCD=(b.def.ability.cd*cdMult)+(Math.random()*300-150);
      // Aim at the closer of player / pal
      const aimX=(palDist<dist&&tgtIsPal)?tgtX:PL.x;
      const aimY=(palDist<dist&&tgtIsPal)?tgtY:PL.y;
      b._atkT=200;b._atkDx=aimX-b.x;b._atkDy=aimY-b.y;
      const dmg=(b.def.baseDmg+(b.phase-1)*3)+Math.floor(Math.random()*3);
      // Arena gate: boss can only damage player while player is INSIDE the arena.
      if(!PL.dead&&dist<b.def.ability.range*1.4&&_playerInArena(b.zoneIdx))hurtPL(dmg);
      addPart(b.x,b.y,b.def.ability.color,b.def.ability.pc);
      // Hit any pal in range (active or base)
      const palDmg=Math.max(1,Math.floor(dmg*0.7));
      if(activePal&&!activePal.fainted&&Math.hypot(activePal.x-b.x,activePal.y-b.y)<b.def.ability.range*1.4)
        hurtActivePal(palDmg);
      try{if(typeof basePals!=='undefined'){for(const bp of basePals){if(bp&&!bp.fainted&&bp.hp>0&&Math.hypot(bp.x-b.x,bp.y-b.y)<b.def.ability.range*1.4){bp.hp=Math.max(0,bp.hp-Math.max(1,Math.floor(palDmg*0.7)));bp.shakeT=200;addPart(bp.x,bp.y,'#f44',3);}}}}catch(e){}
    }

    // Special attack (AoE, phase 2+) — hits player AND nearby pals
    b.spCD-=dt;
    if(b.spCD<=0&&!b._calm&&b.phase>=2&&(((!PL.dead)&&dist<b.def.special.range)||palDist<b.def.special.range)){
      b.spCD=b.def.special.cd*(b.phase===3?0.5:0.8)+(Math.random()*500);
      const sp=b.def.special;
      const spDmg=sp.dmg+(b.phase===3?4:2);
      // Arena gate: boss special damages player only when player is inside the arena.
      if(!PL.dead&&dist<sp.range&&_playerInArena(b.zoneIdx))hurtPL(spDmg);
      doShake(9);doHitStop(100);
      // AoE particles ring
      for(let pi=0;pi<8;pi++){
        const pa=pi/8*Math.PI*2,pr=40+Math.random()*50;
        addPart(b.x+Math.cos(pa)*pr,b.y+Math.sin(pa)*pr,sp.color,sp.pc);
      }
      addPart(b.x,b.y,sp.color,sp.pc*2);
      spawnPop('💥 '+sp.name+'! -'+spDmg+'HP','#ff4444');
      // Also damage active pal if in range
      if(activePal&&!activePal.fainted&&Math.hypot(activePal.x-b.x,activePal.y-b.y)<sp.range)
        hurtActivePal(Math.max(1,Math.floor(spDmg*0.6)));
    }

    // Projectile hits from player
    // (handled in updProjs — bossPals array is checked, but zoneBossState.boss is separate)
    // We check melee hits in doAttack; for zone bosses we check dist from PL
    const d2=Math.hypot(PL.x-b.x,PL.y-b.y);
    if(d2<b.def.size*1.5+30){
      // handled via doAttack patching below — zone bosses register in _allZoneBosses
    }
  }

  // Boss HP bar
  updBossHPBar(closestBoss,closestDist);
}

function _allZoneBosses(){return zoneBossState.map(zs=>zs.boss).filter(b=>b&&!b.dead);}

function updBossHPBar(b,dist){
  const el=document.getElementById('boss-hpbar');if(!el)return;
  if(!b||b.dead||dist>400){el.classList.remove('show');return;}
  el.classList.add('show');
  // During refill animation, render the tweened _hpAnim instead of full hp
  const showHp=(b._hpAnimT>0&&typeof b._hpAnim==='number')?b._hpAnim:b.hp;
  const pct=Math.max(0,Math.min(1,showHp/b.maxHp));
  document.getElementById('boss-hpbar-inner').style.width=(pct*100)+'%';
  el.classList.toggle('refilling',b._hpAnimT>0);
  const ph=getBossPhase(b);
  const phColors=['','#ff8844','#ff4400','#ff0000'];
  const phNames=['','Phase 1 — Calm','Phase 2 — Enraged','Phase 3 — Berserk!'];
  const nameEl=document.getElementById('boss-hpbar-name');
  nameEl.textContent='👑 '+b.def.name+' Lv'+b.level;
  nameEl.style.color=phColors[ph];
  const phEl=document.getElementById('boss-hpbar-phase');
  phEl.textContent=phNames[ph];phEl.style.color=phColors[ph];
  document.getElementById('boss-hpbar-outer').style.borderColor=phColors[ph];
  document.getElementById('boss-hpbar-inner').style.background=
    ph===3?'linear-gradient(90deg,#880000,#ff2200)':
    ph===2?'linear-gradient(90deg,#883300,#ff8800)':
    'linear-gradient(90deg,#aa0000,#ff4422)';
}

function drawZoneBoss(b){
  if(!b||!isFinite(b.x)||!isFinite(b.y))return;
  if(b.dead){
    const a=Math.max(0,1-(b._deadT||0)/1200);
    ctx.globalAlpha=a;drawPalBody(b.def,b.def.size*0.6,wx(b.x),wy(b.y)+10*ZOOM*a,ZOOM);ctx.globalAlpha=1;return;
  }
  if(!onScreen(b.x-b.def.size*4,b.y-b.def.size*4,b.def.size*8,b.def.size*8))return;
  const d=b.def,z=ZOOM,sz=d.size,sx=wx(b.x),sy=wy(b.y);
  const bob=Math.sin(Date.now()*.0025+b.id*44)*3*z;
  const t=Date.now()*.001;
  const ph=getBossPhase(b);
  const bz=BOSS_ZONES[b.zoneIdx];

  // Zone-colored glow — 5 entries: Rocky/Ice/Fire/Forest/Danger
  const glowColors=[
    'rgba(180,150,50,.40)',   // 0 Rocky  — earthy gold
    'rgba(60,160,255,.40)',   // 1 Ice    — frosty blue
    'rgba(255,80,0,.45)',     // 2 Fire   — orange-red
    'rgba(30,180,30,.42)',    // 3 Forest — nature green
    'rgba(180,0,0,.50)',      // 4 Danger — deep crimson
  ];
  const glowC=glowColors[b.zoneIdx]||'rgba(255,80,0,.40)';
  const glowR=(sz+14+Math.sin(t)*6)*z;
  const grad=ctx.createRadialGradient(sx,sy+bob,0,sx,sy+bob,glowR);
  grad.addColorStop(0,glowC);grad.addColorStop(1,'rgba(0,0,0,0)');
  ctx.fillStyle=grad;ctx.beginPath();ctx.arc(sx,sy+bob,glowR,0,Math.PI*2);ctx.fill();

  // Phase 3: extra rage aura ring
  if(ph===3){
    const rageR=(sz+20+Math.sin(t*2.5)*8)*z;
    ctx.strokeStyle='rgba(255,40,0,0.6)';ctx.lineWidth=3*z;
    ctx.beginPath();ctx.arc(sx,sy+bob,rageR,0,Math.PI*2);ctx.stroke();
    ctx.globalAlpha=0.25+0.15*Math.sin(t*3);
    ctx.fillStyle='rgba(255,40,0,0.3)';ctx.beginPath();ctx.arc(sx,sy+bob,rageR,0,Math.PI*2);ctx.fill();
    ctx.globalAlpha=1;
  }

  if(b.shakeT>0){const f=b.shakeT/220,sk=(Math.random()-.5)*7*f*z;ctx.save();ctx.translate(sk,0);}
  const _zbl=palLunge(b);
  drawPalBody(d,sz,sx+_zbl.lx*z,sy+bob+_zbl.ly*z,z);
  drawPalFx(b,sx+_zbl.lx*z,sy+bob+_zbl.ly*z,sz,z);
  // Crown + zone ring — 5 entries matching glowColors zones
  const ringColors=[
    'rgba(180,150,50,.80)',   // 0 Rocky
    'rgba(60,180,255,.80)',   // 1 Ice
    'rgba(255,80,0,.85)',     // 2 Fire
    'rgba(40,200,40,.80)',    // 3 Forest
    'rgba(220,20,20,.90)',    // 4 Danger
  ];
  ctx.strokeStyle=ringColors[b.zoneIdx]||'rgba(255,80,0,.8)';ctx.lineWidth=(ph===3?4:2.5)*z;
  ctx.beginPath();ctx.arc(sx,sy+bob,(sz+5)*z,0,Math.PI*2);ctx.stroke();
  const crownEmoji=ph===3?'💀':ph===2?'⚡':'👑';
  ctx.font=\`\${Math.round(20*z)}px serif\`;ctx.textAlign='center';ctx.fillText(crownEmoji,sx,sy+bob-(sz+12)*z);ctx.textAlign='left';
  if(b.shakeT>0)ctx.restore();

  // HP bar below name tag
  const hp=b.hp/b.maxHp;const bw=sz*4.5*z;
  ctx.fillStyle='#110000';ctx.fillRect(sx-bw/2,sy-(sz+18)*z,bw,8*z);
  ctx.fillStyle=ph===3?'#ff2200':ph===2?'#ff8800':hp>.5?'#f44':'#f80';
  ctx.fillRect(sx-bw/2,sy-(sz+18)*z,Math.round(bw*hp),8*z);
  ctx.strokeStyle=ph===3?'#ff0000':'#ff6644';ctx.lineWidth=z;ctx.strokeRect(sx-bw/2,sy-(sz+18)*z,bw,8*z);
  const tag='⚠ '+d.name+' Lv'+b.level+' (P'+ph+')';
  ctx.fillStyle='rgba(0,0,0,.8)';ctx.font=Math.round(7.5*z)+'px Courier New';const tw=ctx.measureText(tag).width;
  ctx.fillRect(sx-tw/2-3,sy+bob-(sz+30)*z,tw+6,11*z);
  ctx.fillStyle=ph===3?'#ff6666':ph===2?'#ffaa44':'#ff8866';
  ctx.fillText(tag,sx-tw/2,sy+bob-(sz+21)*z);
}

function updBoss(dt){
  bossSpawnTimer-=dt;
  if(bossSpawnTimer<=0){bossSpawnTimer=80000+Math.random()*60000;if(_bossUnlocked())spawnBoss();}
  for(let i=bossPals.length-1;i>=0;i--){
    const b=bossPals[i];
    if(b.dead){b._deadT=(b._deadT||0)+dt;if(b._deadT>900)bossPals.splice(i,1);continue;}
    const dx=PL.x-b.x,dy=PL.y-b.y,dist=Math.hypot(dx,dy);
    // Pick nearest base pal too (boss aggros base pals)
    let nearBP=null,nearBPd=Infinity;
    for(const bp of basePals){if(!bp||!bp.def)continue;const d2=Math.hypot(bp.x-b.x,bp.y-b.y);if(d2<nearBPd){nearBPd=d2;nearBP=bp;}}
    // Choose primary target: closest of (player, nearest base pal)
    let tgt=null,tdx=0,tdy=0,tdist=Infinity;
    if(!PL.dead&&dist<240){tgt='pl';tdx=dx;tdy=dy;tdist=dist;}
    if(nearBP&&nearBPd<260&&nearBPd<tdist){tgt='bp';tdx=nearBP.x-b.x;tdy=nearBP.y-b.y;tdist=nearBPd;}
    if(tgt){const spd=1.1+b.level*0.05;moveWithColl(b,tdx/tdist*spd,tdy/tdist*spd,16,16);}
    else{b.wT-=dt;if(b.wT<=0){b.wT=1600+Math.random()*1200;b.vx=(Math.random()-.5)*.5;b.vy=(Math.random()-.5)*.5;}moveWithColl(b,b.vx,b.vy,16,16);}
    b.aT+=dt;if(b.aT>180){b.aF=(b.aF+1)%4;b.aT=0;}
    if(b.shakeT>0)b.shakeT=Math.max(0,b.shakeT-dt);
    tickPalFx(b,dt);
    b.abCD-=dt;
    if(b.abCD<=0&&tgt&&tdist<b.def.ability.range){
      b.abCD=b.def.ability.cd+(Math.random()*300-150);
      b._atkT=200;b._atkDx=tdx;b._atkDy=tdy;
      const dmg=b.def.baseDmg+(b.level>4?2:1);
      addPart(b.x,b.y,b.def.ability.color,b.def.ability.pc);
      if(tgt==='pl'){hurtPL(dmg);if(activePal&&!activePal.fainted){const _bapd=Math.hypot(activePal.x-b.x,activePal.y-b.y);if(_bapd<b.def.ability.range*1.2)hurtActivePal(Math.max(1,Math.floor(b.def.baseDmg*0.65)));}}
      else if(tgt==='bp'&&nearBP){nearBP.hp=Math.max(0,(nearBP.hp||nearBP.maxHp||(nearBP.def.baseHp+(nearBP.level||1)*2))-dmg);if(typeof nearBP.maxHp!=='number')nearBP.maxHp=nearBP.def.baseHp+(nearBP.level||1)*2;nearBP.shakeT=250;if(nearBP.hp<=0){spawnPop('💀 Base pal fainted!','#f87171');addPart(nearBP.x,nearBP.y,'#f87171',10);nearBP.hp=Math.floor(nearBP.maxHp*0.4);}}
    }
  }
}

function drawBoss(b){
  if(!b||!isFinite(b.x)||!isFinite(b.y))return;
  if(b.dead){const a=Math.max(0,1-(b._deadT||0)/900);ctx.globalAlpha=a;drawPalBody(b.def,b.def.size*0.7,wx(b.x),wy(b.y)+8*ZOOM*a,ZOOM);ctx.globalAlpha=1;return;}
  const d=b.def,z=ZOOM,sz=d.size,sx=wx(b.x),sy=wy(b.y);
  if(!onScreen(b.x-sz*3,b.y-sz*3,sz*6,sz*6))return;
  const bob=Math.sin(Date.now()*.003+b.id*33)*2.5*z;
  const t=Date.now()*.0015;
  const glowR=(sz+10+Math.sin(t)*5)*z;
  const grad=ctx.createRadialGradient(sx,sy+bob,0,sx,sy+bob,glowR);
  grad.addColorStop(0,'rgba(255,60,60,.4)');grad.addColorStop(1,'rgba(200,0,0,0)');
  ctx.fillStyle=grad;ctx.beginPath();ctx.arc(sx,sy+bob,glowR,0,Math.PI*2);ctx.fill();
  if(b.shakeT>0){const f=b.shakeT/200,sk=(Math.random()-.5)*6*f*z;ctx.save();ctx.translate(sk,0);}
  const _bl=palLunge(b);
  drawPalBody(d,sz,sx+_bl.lx*z,sy+bob+_bl.ly*z,z);
  drawPalFx(b,sx+_bl.lx*z,sy+bob+_bl.ly*z,sz,z);
  ctx.strokeStyle='rgba(255,80,80,.7)';ctx.lineWidth=3*z;ctx.beginPath();ctx.arc(sx,sy+bob,(sz+4)*z,0,Math.PI*2);ctx.stroke();
  ctx.font=\`\${Math.round(18*z)}px serif\`;ctx.textAlign='center';ctx.fillText('👑',sx,sy+bob-(sz+10)*z);ctx.textAlign='left';
  if(b.shakeT>0)ctx.restore();
  const hp=b.hp/b.maxHp;const bw=sz*4*z;
  ctx.fillStyle='#220000';ctx.fillRect(sx-bw/2,sy-(sz+16)*z,bw,7*z);
  ctx.fillStyle=hp>.5?'#f44':hp>.25?'#f80':'#a00';ctx.fillRect(sx-bw/2,sy-(sz+16)*z,Math.round(bw*hp),7*z);
  ctx.strokeStyle='#ff4444';ctx.lineWidth=z;ctx.strokeRect(sx-bw/2,sy-(sz+16)*z,bw,7*z);
  const tag='⚠ '+d.name+' Lv'+b.level;
  ctx.fillStyle='rgba(0,0,0,.75)';ctx.font=Math.round(8*z)+'px Courier New';const tw=ctx.measureText(tag).width;
  ctx.fillRect(sx-tw/2-3,sy+bob-(sz+26)*z,tw+6,11*z);
  ctx.fillStyle='#ff6666';ctx.fillText(tag,sx-tw/2,sy+bob-(sz+17)*z);
}

// ═══════════════════════════════
// PLAYER SKILL TREE
// ═══════════════════════════════
const PlayerSkills={
  points:0,
  damage:{level:0,max:5,label:'⚔️ Attack Boost',desc:'+1 DMG per rank',color:'#f87171'},
  hp:{level:0,max:5,label:'❤️ Max HP Boost',desc:'+8 HP per rank',color:'#f43f5e'},
  atkSpd:{level:0,max:4,label:'⚡ Atk Speed',desc:'-60ms CD per rank',color:'#facc15'},
  moveSpd:{level:0,max:4,label:'🏃 Speed Boost',desc:'+0.12 SPd per rank',color:'#4aff78'},
  harvest:{level:0,max:5,label:'🪓 Harvest Boost',desc:'+1 resource per rank',color:'#fb923c'},
  hunger:{level:0,max:4,label:'🍗 Hunger Efficiency',desc:'-15% drain per rank',color:'#fbbf24'},
  capture:{level:0,max:4,label:'🎯 Capture Boost',desc:'+5% catch chance per rank',color:'#c084fc'},
  palDmg:{level:0,max:5,label:'🐾 Pal Strength',desc:'+1 pal DMG per rank',color:'#cc44ff'},
};
// ═══════════════════════════════
// PALDEX (Pal Collection Index) + TECH TREE (Level Unlocks)
// ═══════════════════════════════
const Paldex={seen:{},captured:{}};
const BIOME_NAMES=['Grassland','Rocky','Copper','Dense Forest','Danger Zone','Highland Plains','Ice','Fire'];
function _palBiomeStr(def){if(!def)return '?';if(def.boss)return BIOME_NAMES[def.biome]||'Boss Lair';const arr=(def.biomes||[]).map(b=>BIOME_NAMES[b]||'').filter(Boolean);return arr.length?arr.join(' / '):'Roaming';}
function _palRecLvl(def){const hp=def.baseHp||10;return Math.max(1,Math.round(hp/3));}
function _palDropEmoji(t){return ({wood:'🪵',stone:'🪨',copper:'🟠',coal:'⬛',iron:'🩶'})[t]||'🎁';}
// WORK label: per-pal flavored work role for the Paldex card.
const _PAL_WORK_OVERRIDES={
  Foxling:'Gathering · Logging',
  Mossy:'Farming · Logging',
  Pebble:'Mining',
  Blaze:'Smelting · Fire',
  Frostie:'Cooling · Ice',
  Stonehorn:'Mining · Hauling',
  Coprite:'Mining',
  Sylvan:'Planting · Medicine',
  DarkFang:'Combat · Hunting',
  Voidclaw:'Combat',
};
function _palWork(def){
  if(!def)return 'None';
  if(def.boss)return 'Combat (Boss)';
  if(_PAL_WORK_OVERRIDES[def.name])return _PAL_WORK_OVERRIDES[def.name];
  switch(def.helperType){
    case 'wood':return 'Logging';
    case 'stone':return 'Mining';
    case 'stone_copper':return 'Mining · Smelting';
    default:return 'None';
  }
}
function _palNote(def){
  if(def.boss)return '⚠ Boss — strong AoE';
  const ab=def.ability||{},sp=def.special||{};
  const tags=[];
  if(ab.type==='fire')tags.push('🔥 fire dmg');
  else if(ab.type==='ice')tags.push('❄️ ice dmg');
  else if(ab.type==='dark')tags.push('🌑 dark dmg');
  else if(ab.type==='nature')tags.push('🌿 nature');
  else if(ab.type==='earth')tags.push('🪨 earth');
  if(sp.effect==='stun')tags.push('stuns');
  else if(sp.effect==='slow')tags.push('slows');
  else if(sp.effect==='multi')tags.push('multi-hit');
  if(def.behavior==='timid')tags.push('flees');
  else if(def.behavior==='aggressive')tags.push('hostile');
  if(def.rare)tags.push('rare');
  return tags.join(' · ')||'common';
}
function markSeen(name){
  if(!name||Paldex.seen[name])return;
  Paldex.seen[name]=true;
  if(typeof spawnPop==='function')spawnPop('📘 New Pal Registered: '+name+'!','#c084fc');
  const b=document.getElementById('pdx-btn');if(b)b.classList.add('has-new');
  if(typeof saveGame==='function')try{saveGame();}catch(e){}
}
function markCaptured(name){
  if(!name)return;
  Paldex.seen[name]=true;
  if(!Paldex.captured[name]){Paldex.captured[name]=true;}
  if(typeof saveGame==='function')try{saveGame();}catch(e){}
}

// ── TECH TREE ──
// Default-unlocked starter recipes; everything else gated by player level + tech point.
const Tech={
  points:0,
  unlocked:{sphere:true,sw_wood:true,craftTable:true,chest:true,palbox:true},
};
const TECH_DEFS=[
  // tier 2
  {key:'ax_stone',lvl:2,cost:1,name:'🪓 Stone Axe',kind:'craft',cat:'TIER 2'},
  {key:'pk_stone',lvl:2,cost:1,name:'⛏ Stone Pickaxe',kind:'craft',cat:'TIER 2'},
  {key:'sw_stone',lvl:2,cost:1,name:'⚔️ Stone Sword',kind:'craft',cat:'TIER 2'},
  // tier 3
  {key:'campfire',lvl:3,cost:1,name:'🔥 Campfire',kind:'build',cat:'TIER 3'},
  {key:'ax_copper',lvl:3,cost:1,name:'🪓 Copper Axe',kind:'craft',cat:'TIER 3'},
  {key:'pk_copper',lvl:3,cost:1,name:'⛏ Copper Pickaxe',kind:'craft',cat:'TIER 3'},
  {key:'sw_copper',lvl:3,cost:1,name:'🔱 Copper Sword',kind:'craft',cat:'TIER 3'},
  // tier 4
  {key:'adv_sphere',lvl:4,cost:1,name:'💠 Advanced Sphere',kind:'craft',cat:'TIER 4'},
  {key:'ar_cloth',lvl:4,cost:1,name:'🥋 Cloth Armor',kind:'craft',cat:'TIER 4'},
  // tier 5
  {key:'repair_bench',lvl:5,cost:2,name:'🛠️ Repair Bench',kind:'build',cat:'TIER 5'},
  // tier 6
  {key:'ax_iron',lvl:6,cost:2,name:'🪓 Iron Axe',kind:'craft',cat:'TIER 6'},
  {key:'pk_iron',lvl:6,cost:2,name:'⛏ Iron Pickaxe',kind:'craft',cat:'TIER 6'},
  {key:'sw_iron',lvl:6,cost:2,name:'⚜️ Iron Sword',kind:'craft',cat:'TIER 6'},
  // tier 7
  {key:'ultra_sphere',lvl:7,cost:2,name:'🌀 Ultra Sphere',kind:'craft',cat:'TIER 7'},
  // tier 8
  {key:'ar_iron',lvl:8,cost:3,name:'🛡️ Iron Armor',kind:'craft',cat:'TIER 8'},
  // future placeholder slots
  {key:'_fut_weapon',lvl:99,cost:0,name:'⚔ Future Weapons',kind:'soon',cat:'COMING SOON'},
  {key:'_fut_build',lvl:99,cost:0,name:'🏛 Future Buildings',kind:'soon',cat:'COMING SOON'},
  {key:'_fut_saddle',lvl:99,cost:0,name:'🪢 Future Saddles',kind:'soon',cat:'COMING SOON'},
  {key:'_fut_legend',lvl:99,cost:0,name:'✨ Future Legendary Gear',kind:'soon',cat:'COMING SOON'},
];
function isUnlocked(key){return !!Tech.unlocked[key];}
function unlockTech(key){
  const def=TECH_DEFS.find(t=>t.key===key);if(!def)return;
  if(def.kind==='soon'){spawnPop('🔒 Coming soon!','#a87bd1');return;}
  if(Tech.unlocked[key]){spawnPop('Already unlocked','#888');return;}
  if(PL.level<def.lvl){spawnPop('🔒 Reach Lv.'+def.lvl+' first','#f87');return;}
  if(Tech.points<def.cost){spawnPop('Need '+def.cost+' Tech Pt','#f87');return;}
  Tech.points-=def.cost;Tech.unlocked[key]=true;
  spawnPop('🔬 Unlocked: '+def.name,'#60a5fa');
  if(typeof addPart==='function')addPart(PL.x,PL.y,'#60a5fa',8);
  if(typeof refreshCraftUI==='function')refreshCraftUI();
  renderTechTree();renderPaldex();
  try{saveGame();}catch(e){}
}

// ─── Premium icon swap ──────────────────────────────────────────────
// Returns HTML markup for a pal's UI icon. For pals that have a premium
// PNG (Foxling), uses an <span> with a background-image so the existing
// slot/grid sizing is preserved without layout shift. All other pals
// continue to use the emoji string they already used.
const PAL_PREMIUM_ICON={Foxling:'/sprites/foxling_icon.png',Blaze:'/sprites/blaze_icon.png',Frostie:'/sprites/frostie_icon.png',Voidclaw:'/sprites/voidclaw_icon.png'};
// Track which premium icon URLs are confirmed broken so we fall back once and never retry.
const _PAL_ICON_ERR={};
function palIconHTML(def){
  if(!def)return '';
  const src=PAL_PREMIUM_ICON[def.name];
  // Use CSS background-image icon; if the URL previously errored, fall back to emoji.
  if(src&&!_PAL_ICON_ERR[def.name]){
    // onerror in a CSS background can't fire — use an invisible Image() probe on first use
    // to detect failures, then replace the element's bg on next render.
    if(!_PAL_ICON_ERR._probed){
      _PAL_ICON_ERR._probed={};
    }
    if(!_PAL_ICON_ERR._probed[def.name]){
      _PAL_ICON_ERR._probed[def.name]=true;
      const _probe=new Image();
      _probe.onerror=function(){
        _PAL_ICON_ERR[def.name]=true;
        // Re-render any visible party slots so they flip to emoji immediately.
        try{if(typeof refreshPartyBar==='function')refreshPartyBar();}catch(_e){}
      };
      _probe.src=src;
    }
    return '<span class="pal-img-icon" style="background-image:url('+src+')" aria-label="'+def.name+'"></span>';
  }
  return def.emoji||'';
}
function renderPaldex(){
  const grid=document.getElementById('paldex-grid');if(!grid)return;
  const all=PAL_TYPES.concat((typeof BOSS_TYPES!=='undefined'?BOSS_TYPES:[])||[]);
  let seenN=0,capN=0;
  let html='';
  for(const def of all){
    const seen=!!Paldex.seen[def.name];
    const cap=!!Paldex.captured[def.name];
    if(seen)seenN++;if(cap)capN++;
    const beh=def.boss?'boss':(def.behavior||'passive');
    const tagCls=def.boss?'boss':beh==='aggressive'?'aggro':beh==='timid'?'timid':'passive';
    const status=cap?'<span class="pdx-status s-cap">✓ CAUGHT</span>':seen?'<span class="pdx-status s-seen">SEEN</span>':'<span class="pdx-status">—</span>';
    if(!seen){
      html+='<div class="pdx-card unseen"><div class="pdx-icon">❔</div><div class="pdx-name">???</div><div class="pdx-row"><span>Type</span><b>—</b></div><div class="pdx-row"><span>Biome</span><b>—</b></div><div class="pdx-row"><span>Lv.</span><b>?</b></div><div style="margin-top:3px;color:#666;font-size:8px;">Locked — defeat or capture to unlock</div>'+status+'</div>';
      continue;
    }
    const dropT=def.dropType||'?';
    const tags='<span class="pdx-tag '+tagCls+'">'+(def.boss?'BOSS':beh.toUpperCase())+'</span>'+(def.rare&&!def.boss?'<span class="pdx-tag rare">RARE</span>':'');
    html+='<div class="pdx-card '+(cap?'captured':'seen')+(def.boss?' boss':'')+'">'+
      '<div class="pdx-icon">'+palIconHTML(def)+'</div>'+
      '<div class="pdx-name">'+def.name+'</div>'+
      '<div style="text-align:center;margin:-2px 0 3px;">'+tags+'</div>'+
      '<div class="pdx-row"><span>Biome</span><b>'+_palBiomeStr(def)+'</b></div>'+
      '<div class="pdx-row"><span>Rec. Lv.</span><b>'+_palRecLvl(def)+'</b></div>'+
      '<div class="pdx-row"><span>Drops</span><b>'+_palDropEmoji(dropT)+' '+dropT+'</b></div>'+
      '<div class="pdx-row"><span>Work</span><b style="color:#ffd66e;">'+_palWork(def)+'</b></div>'+
      '<div style="margin-top:3px;color:#9ab;font-size:8.5px;font-style:italic;">'+_palNote(def)+'</div>'+
      status+'</div>';
  }
  grid.innerHTML=html;
  const c1=document.getElementById('pdx-count');if(c1)c1.textContent=seenN;
  const c2=document.getElementById('pdx-total');if(c2)c2.textContent=all.length;
  const c3=document.getElementById('pdx-cap-count');if(c3)c3.textContent=capN;
}

function renderTechTree(){
  const wrap=document.getElementById('tech-list');if(!wrap)return;
  const pts=document.getElementById('tech-pts');if(pts)pts.textContent=Tech.points;
  // Group by cat
  const groups={};const order=[];
  for(const t of TECH_DEFS){if(!groups[t.cat]){groups[t.cat]=[];order.push(t.cat);}groups[t.cat].push(t);}
  let html='';
  for(const cat of order){
    const tier=groups[cat];
    const tierLvl=tier[0].lvl;
    const reach=PL.level>=tierLvl;
    const isFut=tier[0].kind==='soon';
    const hCls=isFut?'future':(reach?'':'locked');
    const lvlStr=isFut?'∞':('Lv.'+tierLvl);
    html+='<div class="tech-tier"><div class="tech-tier-h '+hCls+'">'+cat+' · '+lvlStr+'</div><div class="tech-grid">';
    for(const t of tier){
      const unl=Tech.unlocked[t.key];
      const can=!unl&&!isFut&&PL.level>=t.lvl&&Tech.points>=t.cost;
      const cls='tech-cell '+(isFut?'future':unl?'unl':can?'canbuy':'locked');
      const act=isFut?'COMING SOON':unl?'✓ UNLOCKED':PL.level<t.lvl?('🔒 Lv.'+t.lvl):can?'TAP TO UNLOCK ('+t.cost+'pt)':('NEED '+t.cost+'pt');
      const cost=isFut?'—':(t.cost+' Tech Pt');
      html+='<div class="'+cls+'" data-key="'+t.key+'"><div class="tech-name">'+t.name+'</div><div class="tech-cost">'+cost+'</div><div class="tech-act">'+act+'</div></div>';
    }
    html+='</div></div>';
  }
  wrap.innerHTML=html;
  // Tap-vs-drag detection: cards must allow vertical scroll on touch.
  // Track touchstart Y; only fire unlock if finger barely moved (real tap).
  wrap.querySelectorAll('.tech-cell').forEach(el=>{
    const k=el.getAttribute('data-key');
    let _sy=0,_sx=0,_moved=false;
    el.addEventListener('touchstart',e=>{const t=e.changedTouches[0];_sy=t.clientY;_sx=t.clientX;_moved=false;},{passive:true});
    el.addEventListener('touchmove',e=>{const t=e.changedTouches[0];if(Math.abs(t.clientY-_sy)>8||Math.abs(t.clientX-_sx)>8)_moved=true;},{passive:true});
    el.addEventListener('touchend',e=>{if(!_moved){e.preventDefault();unlockTech(k);}},{passive:false});
    // Mouse path (desktop) — click still works normally
    el.addEventListener('click',e=>{if(e.detail===0)return;unlockTech(k);});
  });
}

function switchInvTab(t){
  document.querySelectorAll('.inv-tab').forEach(b=>b.classList.toggle('active',b.getAttribute('data-tab')===t));
  document.getElementById('pane-inv').classList.toggle('active',t==='inv');
  document.getElementById('pane-pdx').classList.toggle('active',t==='pdx');
  document.getElementById('pane-tch').classList.toggle('active',t==='tch');
  const ttl=document.getElementById('inv-panel-title');if(ttl)ttl.textContent=t==='pdx'?'📘 PAL INDEX':t==='tch'?'🔬 TECH TREE':'🎒 INVENTORY';
  if(t==='pdx')renderPaldex();
  else if(t==='tch')renderTechTree();
  if(t==='pdx'){const b=document.getElementById('pdx-btn');if(b)b.classList.remove('has-new');}
}

function getSkillDmgBonus(){return PlayerSkills.damage.level;}
function getSkillAtkCDReduction(){return PlayerSkills.atkSpd.level*60;}
function getSkillMoveSpd(){return (PL.speed+PlayerSkills.moveSpd.level*0.12)*(typeof wxMoveSpdMul==='function'?wxMoveSpdMul():1);}
function getSkillHarvestBonus(){return PlayerSkills.harvest.level;}
// Hunger drain multiplier: each level slows drain by 15% (cap at 60% reduction = 0.40 mul).
function getSkillHungerMul(){return Math.max(0.40,1-PlayerSkills.hunger.level*0.15);}
// Capture chance bonus (additive, applied in calcCaptureChance).
function getSkillCaptureBonus(){return PlayerSkills.capture.level*0.05;}
// Flat pal damage bonus, added inside palDmg().
function getSkillPalDmgBonus(){return PlayerSkills.palDmg.level;}
function upgradeSkill(key){
  const sk=PlayerSkills[key];if(!sk||sk.level>=sk.max)return;
  if(PlayerSkills.points<=0){spawnPop('No skill points!','#f87');return;}
  PlayerSkills.points--;sk.level++;
  if(key==='hp'){PL.maxHp+=8;PL.hp=Math.min(PL.hp+8,PL.maxHp);updHPBar();}
  spawnPop('⬆ '+sk.label+' Lv'+sk.level,(sk.color||'#facc15'));
  refreshSkillUI();saveGame();
}
function openSkillOverlay(){refreshSkillUI();document.getElementById('skill-overlay').classList.add('show');}
function closeSkillOverlay(){document.getElementById('skill-overlay').classList.remove('show');}
function refreshSkillUI(){
  const pts=PlayerSkills.points;
  document.getElementById('skill-pts').innerHTML='<span style="color:#facc15;font-size:13px;font-weight:bold">'+pts+'</span> <span style="color:#90ccff;letter-spacing:1px">SKILL POINT'+(pts!==1?'S':'')+'</span>';
  document.getElementById('skill-lvl-display').textContent='PLAYER  LV. '+PL.level;
  document.getElementById('skill-btn').classList.toggle('has-pts',pts>0);
  const rows=document.getElementById('skill-rows');rows.innerHTML='';
  for(const key of ['damage','hp','moveSpd','harvest','atkSpd','hunger','capture','palDmg']){
    const sk=PlayerSkills[key];const row=document.createElement('div');row.className='sk-row';
    const filled='★'.repeat(sk.level);const empty='☆'.repeat(sk.max-sk.level);
    const maxed=sk.level>=sk.max;
    const canUpgrade=!maxed&&pts>0;
    row.style.borderColor=maxed?(sk.color||'#facc15')+'55':'#2a3a0a';
    row.innerHTML=
      '<div class="sk-icon" style="color:'+(sk.color||'#facc15')+'">'+sk.label.split(' ')[0]+'</div>'+
      '<div class="sk-name"><span style="color:'+(sk.color||'#ddd')+'">'+sk.label.split(' ').slice(1).join(' ')+'</span><br><span class="sk-desc">'+sk.desc+'</span>'+
        '<div class="sk-stars" style="color:'+(sk.color||'#facc15')+'">'+filled+'<span style="color:#333">'+empty+'</span> <span style="color:#666;font-size:8px">'+sk.level+'/'+sk.max+'</span></div></div>';
    const btn=document.createElement('button');btn.className='sk-btn'+(maxed?' maxed':'');
    btn.textContent=maxed?'MAX':'UPGRADE';btn.disabled=!canUpgrade;
    if(canUpgrade)btn.style.borderColor=sk.color||'#facc15';
    btn.addEventListener('click',()=>upgradeSkill(key));
    row.appendChild(btn);rows.appendChild(row);
  }
  const stats=document.getElementById('skill-stats');
  const realSpd=getSkillMoveSpd().toFixed(2);
  const realAtk=Math.max(200,500-getSkillAtkCDReduction());
  stats.innerHTML=
    '<span style="color:#f87171">⚔ DMG Bonus: +'+getSkillDmgBonus()+'</span><br>'+
    '<span style="color:#f43f5e">❤ Max HP: '+PL.maxHp+'</span><br>'+
    '<span style="color:#4aff78">🏃 Move Speed: '+realSpd+'</span><br>'+
    '<span style="color:#fb923c">🪓 Harvest +'+getSkillHarvestBonus()+' per node</span><br>'+
    '<span style="color:#facc15">⚡ Atk CD: '+realAtk+'ms</span><br>'+
    '<span style="color:#fbbf24">🍗 Hunger Drain: x'+getSkillHungerMul().toFixed(2)+'</span><br>'+
    '<span style="color:#c084fc">🎯 Capture Bonus: +'+Math.round(getSkillCaptureBonus()*100)+'%</span><br>'+
    '<span style="color:#cc44ff">🐾 Pal DMG Bonus: +'+getSkillPalDmgBonus()+'</span>';
}
(function(){
  const btn=document.getElementById('skill-btn');
  function openSkill(e){if(e&&e.cancelable)e.preventDefault();openSkillOverlay();}
  btn.addEventListener('click',openSkill);btn.addEventListener('touchstart',openSkill,{passive:false});
  document.getElementById('skill-close').onclick=closeSkillOverlay;
})();
// ─── PAL SKILL BUTTON ───
(function(){
  const btn=document.getElementById('pal-skill-btn');
  function onPalSkill(e){if(e&&e.cancelable)e.preventDefault();firePalSpecial();}
  btn.addEventListener('click',onPalSkill);
  btn.addEventListener('touchstart',onPalSkill,{passive:false});
})();

// ─── SKILL LEVEL SYSTEM ───
function getSkillTier(p){const lv=p.level||1;return lv>=12?4:lv>=7?3:lv>=3?2:1;}
function getSkillSplash(p){return getSkillTier(p)>=3;}
function getSkillBigProj(p){return getSkillTier(p)>=4;}
function palDmg(p){const base=p.def.baseDmg||1;const tier=getSkillTier(p);const elem=p.def&&p.def.ability&&p.def.ability.type;const wm=(typeof wxPalDmgMul==='function')?wxPalDmgMul(elem):1;return Math.max(1,Math.round((base+1+Math.floor(tier/2)+getSkillPalDmgBonus())*wm));}
function palWorkSpd(p){const base=p.def.workSpd||4000;const tier=getSkillTier(p);return base*(1-0.1*(tier-1));}
function xpToNext(level){return Math.floor(40*Math.pow(1.45,level-1));}
function gainXP(p,amount){p.xp=(p.xp||0)+amount;const needed=p.xpNeeded||xpToNext(p.level||1);if(p.xp>=needed){p.xp-=needed;p.level=(p.level||1)+1;p.xpNeeded=xpToNext(p.level);return true;}return false;}

// ─── PAL BODY DRAWING ───
// ─── PAL SPRITE OVERRIDES (auto-trim + facing + ground placement) ───
const PAL_SPRITES={};       // name -> trimmed canvas (or raw img while loading)
const PAL_SPRITE_READY={};  // name -> true once trimmed
// width as a multiple of pal radius r — Mossy 2.8 = visual reference, others tuned to match
const PAL_SPRITE_SCALE={Mossy:2.8,Foxling:2.4,Pebble:2.5,DarkFang:2.7,Blaze:2.5,Stonehorn:2.9,Frostie:2.4,Coprite:2.4,Sylvan:2.6,Voidclaw:2.7};
// vertical offset of the sprite's FEET relative to shadow center (* r)
const PAL_SPRITE_FOOT={Pebble:0.95,Mossy:0.78,Foxling:0.92,DarkFang:0.95,Blaze:0.92,Stonehorn:0.96,Frostie:0.90,Coprite:0.92,Sylvan:0.85,Voidclaw:0.95};
// horizontal natural facing of source art (1 = source faces right, -1 = source faces left)
const PAL_SPRITE_NAT_FACING={Pebble:1,Mossy:-1,Foxling:1,DarkFang:1,Blaze:1,Stonehorn:1,Frostie:1,Coprite:1,Sylvan:1,Voidclaw:1};
// optional soft glow halo (color, alpha, radius multiplier of width)
const PAL_SPRITE_GLOW={
  Blaze:{color:'#ff6622',alpha:0.32,r:0.55},
  Frostie:{color:'#88ddff',alpha:0.30,r:0.60},
  Coprite:{color:'#ff9933',alpha:0.18,r:0.45},
  Sylvan:{color:'#88ff99',alpha:0.16,r:0.52},
  Voidclaw:{color:'#220033',alpha:0.30,r:0.58}
};
// vertical bob amplitude multiplier when moving (heavy pals stomp slower/bigger)
const PAL_SPRITE_BOB={Stonehorn:1.6,Pebble:1.3,Foxling:0.8,DarkFang:1.0,Blaze:1.0,Frostie:0.9,Mossy:1.0,Coprite:1.0,Sylvan:1.4,Voidclaw:0.7};
const PAL_SPRITE_BOB_SPD={Stonehorn:0.008,Pebble:0.009,Foxling:0.018,DarkFang:0.014,Blaze:0.014,Frostie:0.013,Mossy:0.015,Coprite:0.014,Sylvan:0.011,Voidclaw:0.010};
// pals that float (continuous idle bob even when standing still)
const PAL_SPRITE_FLOAT={Sylvan:1.6};

function _trimPalSprite(img,name){
  try{
    const w=img.naturalWidth,h=img.naturalHeight;
    if(!w||!h)return;
    const cv=document.createElement('canvas');cv.width=w;cv.height=h;
    const cx=cv.getContext('2d',{willReadFrequently:true});
    cx.imageSmoothingEnabled=false;cx.drawImage(img,0,0);
    const data=cx.getImageData(0,0,w,h).data;
    let minX=w,minY=h,maxX=-1,maxY=-1;
    for(let y=0;y<h;y++){
      for(let x=0;x<w;x++){
        if(data[(y*w+x)*4+3]>20){
          if(x<minX)minX=x;if(x>maxX)maxX=x;
          if(y<minY)minY=y;if(y>maxY)maxY=y;
        }
      }
    }
    if(maxX<0){PAL_SPRITES[name]=img;PAL_SPRITE_READY[name]=true;return;}
    const tw=maxX-minX+1,th=maxY-minY+1;
    const out=document.createElement('canvas');out.width=tw;out.height=th;
    const oc=out.getContext('2d');oc.imageSmoothingEnabled=false;
    oc.drawImage(img,minX,minY,tw,th,0,0,tw,th);
    PAL_SPRITES[name]=out;PAL_SPRITE_READY[name]=true;
  }catch(_e){PAL_SPRITES[name]=img;PAL_SPRITE_READY[name]=true;}
}
// ── Sprite loading is split into two tiers for mobile performance ──
// Tier 1 (immediate): sprites the player's active party is likely to need RIGHT NOW.
//   Loaded at script start so no pop-in on frame 1.
// Tier 2 (deferred 2 s): every other pal sprite.
//   The canvas renderer gracefully falls back to the old vector shape while
//   images are still loading, so a 2-second deferral is invisible in practice.
const _PAL_SPRITE_MAP={
  Pebble:'/sprites/pebble.png',
  Mossy:'/sprites/slime.png',
  Foxling:'/sprites/foxling_idle.png',
  DarkFang:'/sprites/darkfang.png',
  Blaze:'/sprites/blaze_idle.png',
  Stonehorn:'/sprites/stonehorn.png',
  Frostie:'/sprites/frostie_idle.png',
  Coprite:'/sprites/coprite.png',
  Sylvan:'/sprites/sylvan.png'
};
function _loadOnePalSprite(k){
  if(PAL_SPRITE_READY[k])return;
  const src=_PAL_SPRITE_MAP[k];if(!src)return;
  const im=new Image();
  im.onload=()=>_trimPalSprite(im,k);
  im.onerror=()=>{};
  im.src=src;
  PAL_SPRITES[k]=im;
}
function _loadPalSprites(keys){
  // keys=null → load all; keys=array → load only listed names
  const ks=keys||Object.keys(_PAL_SPRITE_MAP);
  for(const k of ks)_loadOnePalSprite(k);
  // Wild-horse (separate system — not in PAL_TYPES)
  if(!keys||keys.includes('__WildHorse')){
    if(!PAL_SPRITE_READY['__WildHorse']){
      const hi=new Image();
      hi.onload=()=>_trimPalSprite(hi,'__WildHorse');
      hi.onerror=()=>{};
      hi.src='/sprites/wildhorse.png';
      PAL_SPRITES['__WildHorse']=hi;
    }
  }
}
// Tier 1: load the three starter-pal sprites immediately so there is never
// a pop-in for the most commonly seen pals on frame 1.
_loadPalSprites(['Foxling','Blaze','Frostie']);
// Tier 2: defer everything else until the game loop is running and the
// loading screen has been dismissed. 2 000 ms gives the browser time to
// parse and execute the rest of the game script first.
setTimeout(()=>_loadPalSprites(null),2000);

// ─── BLAZE FRAME ANIMATION SYSTEM (lightweight) ──────────────────────────────
const _BLZ={idle:null,walk:[null,null]};
const _BLZ_R={idle:false,walk:[false,false]};
(function _loadBlazeAni(){
  function _li(key,idx,src){
    const im=new Image();
    if(idx==null){im.onload=function(){_BLZ[key]=im;_BLZ_R[key]=true;};_BLZ[key]=im;}
    else{const _i=idx;im.onload=function(){_BLZ[key][_i]=im;_BLZ_R[key][_i]=true;};_BLZ[key][idx]=im;}
    im.onerror=function(){};
    im.src=src;
  }
  _li('idle',null,'/sprites/blaze_idle.png');
  _li('walk',0,'/sprites/blaze_walk0.png');
  _li('walk',1,'/sprites/blaze_walk1.png');
})();
function drawBlazeSprite(d,sz,sx,sy,z,o){
  const _t=Date.now(),_oid=(o&&o.id)||0,r=sz*z;
  const moving=o&&(Math.abs(o.vx||0)+Math.abs(o.vy||0)>0.05);
  const isAtk=!!(o&&(o._atkT||0)>0),isHurt=!!(o&&(o.shakeT||0)>0);
  // Lightweight: idle or 2-frame walk cycle. No run/atk/hurt frames; lunge+flash instead.
  let frm=null;
  if(moving){const _wi=Math.floor((_t*0.008)%2);frm=_BLZ_R.walk[_wi]?_BLZ.walk[_wi]:(_BLZ_R.idle?_BLZ.idle:null);}
  else{frm=_BLZ_R.idle?_BLZ.idle:(_BLZ_R.walk[0]?_BLZ.walk[0]:null);}
  if(!frm)return;
  if(o){
    let _want=0;
    if(Math.abs(o.vx||0)>0.02)_want=(o.vx||0)<0?-1:1;
    if(typeof PL!=='undefined'&&typeof activePal!=='undefined'){
      const _pdx=PL.x-o.x;
      if(o===activePal){
        if(Math.abs(_pdx)>8)_want=_pdx<0?-1:1;
        else if(!_want){if(PL.facing==='left')_want=-1;else if(PL.facing==='right')_want=1;}
      } else if(Math.hypot(_pdx,PL.y-o.y)<220&&Math.abs(_pdx)>8){
        _want=_pdx<0?-1:1;
      }
    }
    if(!_want&&isAtk&&(o._atkDx!=null)&&Math.abs(o._atkDx)>0.3)_want=o._atkDx<0?-1:1;
    if(_want)o._facing=_want;
    if(o._facing==null)o._facing=1;
  }
  const _facing=(o&&o._facing)||1,_flip=_facing<0;
  const _fw=frm.naturalWidth||frm.width||90,_fh=frm.naturalHeight||frm.height||90;
  let _w=r*2.5;const _ringD=2*(sz+3)*z,_wCap=_ringD*(d.boss?1.1:0.92);if(_w>_wCap)_w=_wCap;
  let _h=_w*(_fh/_fw);const _hCap=_ringD*(d.boss?1.2:0.82)*1.6;if(_h>_hCap){_h=_hCap;_w=_h*(_fw/_fh);}
  const _groundY=sy+r*0.92;
  ctx.fillStyle='rgba(0,0,0,0.34)';ctx.beginPath();ctx.ellipse(sx,_groundY,_w*0.34,_w*0.10,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='rgba(0,0,0,0.19)';ctx.beginPath();ctx.ellipse(sx,_groundY,_w*0.46,_w*0.14,0,0,Math.PI*2);ctx.fill();
  const _pulse=0.85+Math.sin(_t*0.005+_oid*7)*0.15;
  const _gr=ctx.createRadialGradient(sx,sy,0,sx,sy,_w*0.55*_pulse);
  _gr.addColorStop(0,'#ff6622');_gr.addColorStop(1,'rgba(0,0,0,0)');
  ctx.globalAlpha=0.30*_pulse;ctx.fillStyle=_gr;ctx.beginPath();ctx.arc(sx,sy,_w*0.55*_pulse,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;
  const _breath=(!moving&&!isAtk)?(1+Math.sin(_t*0.0024+_oid*3.7)*0.022):1;
  const _legBob=moving?Math.sin(_t*0.014+_oid*9)*r*0.015:0;
  const _footY=sy+r*0.92;
  let _lungeX=0,_lungeY=0;
  if(isAtk){const _lk=Math.sin((1-(o._atkT||0)/180)*Math.PI)*7;const _adx=(o._atkDx||0),_ady=(o._atkDy||0),_ad=Math.hypot(_adx,_ady)||1;_lungeX=(_adx/_ad)*r*0.28*_lk;_lungeY=(_ady/_ad)*r*0.18*_lk;}
  const _bps=ctx.imageSmoothingEnabled;ctx.imageSmoothingEnabled=false;
  ctx.save();ctx.translate(sx+_lungeX,_footY+_lungeY);ctx.scale(_flip?-_breath:_breath,_breath);
  ctx.drawImage(frm,-_w/2,-_h+_legBob,_w,_h);
  ctx.restore();ctx.imageSmoothingEnabled=_bps;
  if(isHurt){const _ha=Math.min(0.55,(o.shakeT||0)/240*0.55);ctx.globalAlpha=_ha;ctx.fillStyle='#ffffff';ctx.beginPath();ctx.arc(sx,sy,sz*z*1.05,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;}
  if(d.rare){ctx.strokeStyle='rgba(255,230,80,.55)';ctx.lineWidth=1.5*z;ctx.beginPath();ctx.arc(sx,sy,r+2*z,0,Math.PI*2);ctx.stroke();}
}

// ─── FOXLING FRAME ANIMATION SYSTEM ──────────────────────────────────
const _FOX={idle:null,walk:[null,null]};
const _FOX_R={idle:false,walk:[false,false]};
(function _loadFoxAni(){
  function _fl(key,idx,src){
    const im=new Image();
    if(idx==null){im.onload=function(){_FOX[key]=im;_FOX_R[key]=true;};_FOX[key]=im;}
    else{const _i=idx;im.onload=function(){_FOX[key][_i]=im;_FOX_R[key][_i]=true;};_FOX[key][idx]=im;}
    im.onerror=function(){};im.src=src;
  }
  _fl('idle',null,'/sprites/foxling_idle.png');
  _fl('walk',0,'/sprites/foxling_walk0.png');
  _fl('walk',1,'/sprites/foxling_walk1.png');
})();

// ─── FROSTIE LIGHTWEIGHT SPRITE SYSTEM ──────────────────────────────────────
const _FRO={idle:null,walk:[null,null]};
const _FRO_R={idle:false,walk:[false,false]};
(function _loadFroAni(){
  function _fl(key,idx,src){
    const im=new Image();
    if(idx==null){im.onload=function(){_FRO[key]=im;_FRO_R[key]=true;};_FRO[key]=im;}
    else{const _i=idx;im.onload=function(){_FRO[key][_i]=im;_FRO_R[key][_i]=true;};_FRO[key][idx]=im;}
    im.onerror=function(){};im.src=src;
  }
  _fl('idle',null,'/sprites/frostie_idle.png');
  _fl('walk',0,'/sprites/frostie_walk0.png');
  _fl('walk',1,'/sprites/frostie_walk1.png');
})();
function drawFrostSprite(d,sz,sx,sy,z,o){
  const _t=Date.now(),_oid=(o&&o.id)||0,r=sz*z;
  const moving=o&&(Math.abs(o.vx||0)+Math.abs(o.vy||0)>0.05);
  const isAtk=!!(o&&(o._atkT||0)>0),isHurt=!!(o&&(o.shakeT||0)>0);
  // Frame: idle or 2-frame walk cycle — no run/atk/hurt frames; lunge+flash used instead
  let frm=null;
  if(moving){
    const _wi=Math.floor((_t*0.008)%2);
    frm=_FRO_R.walk[_wi]?_FRO.walk[_wi]:(_FRO_R.idle?_FRO.idle:null);
  } else {
    frm=_FRO_R.idle?_FRO.idle:(_FRO_R.walk[0]?_FRO.walk[0]:null);
  }
  if(!frm)return;
  // ── Facing: velocity first; player-position for ALL pals in range; attack dir fallback ──
  if(o){
    let _want=0;
    if(Math.abs(o.vx||0)>0.02)_want=(o.vx||0)<0?-1:1;
    if(typeof PL!=='undefined'&&typeof activePal!=='undefined'){
      const _pdx=PL.x-o.x;
      if(o===activePal){
        if(Math.abs(_pdx)>8)_want=_pdx<0?-1:1;
        else if(!_want){if(PL.facing==='left')_want=-1;else if(PL.facing==='right')_want=1;}
      } else if(Math.hypot(_pdx,PL.y-o.y)<220&&Math.abs(_pdx)>8){
        _want=_pdx<0?-1:1;
      }
    }
    if(!_want&&isAtk&&(o._atkDx!=null)&&Math.abs(o._atkDx)>0.3)_want=o._atkDx<0?-1:1;
    if(_want)o._facing=_want;
    if(o._facing==null)o._facing=1;
  }
  const _facing=(o&&o._facing)||1;
  const _flip=_facing<0;
  const _fw=frm.naturalWidth||frm.width||128,_fh=frm.naturalHeight||frm.height||128;
  let _w=r*2.4;const _ringD=2*(sz+3)*z,_wCap=_ringD*(d.boss?1.1:0.92);if(_w>_wCap)_w=_wCap;
  let _h=_w*(_fh/_fw);const _hCap=_ringD*(d.boss?1.2:0.82)*1.9;if(_h>_hCap){_h=_hCap;_w=_h*(_fw/_fh);}
  const _groundY=sy+r*0.90,_footY=sy+r*0.90;
  // Ice-tinted shadow
  ctx.fillStyle='rgba(100,200,255,0.16)';ctx.beginPath();ctx.ellipse(sx,_groundY,_w*0.35,_w*0.10,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='rgba(0,0,0,0.22)';ctx.beginPath();ctx.ellipse(sx,_groundY,_w*0.48,_w*0.13,0,0,Math.PI*2);ctx.fill();
  // Soft ice-blue aura glow
  const _glowA=(0.10+Math.sin(_t*0.0032+_oid*2.7)*0.04).toFixed(2);
  const _gr=ctx.createRadialGradient(sx,sy,0,sx,sy,_w*0.65);
  _gr.addColorStop(0,'rgba(120,220,255,'+_glowA+')');_gr.addColorStop(1,'rgba(50,150,255,0)');
  ctx.fillStyle=_gr;ctx.beginPath();ctx.ellipse(sx,sy,_w*0.65,_h*0.55,0,0,Math.PI*2);ctx.fill();
  // Idle breathing
  const _breath=(!moving&&!isAtk)?(1+Math.sin(_t*0.0028+_oid*4.1)*0.020):1;
  // Attack lunge + tiny upward hop
  let _lungeX=0,_lungeY=0;
  if(isAtk){
    const _lk=Math.sin((1-(o._atkT||0)/180)*Math.PI)*6;
    const _adx=(o._atkDx||0),_ady=(o._atkDy||0),_ad=Math.hypot(_adx,_ady)||1;
    _lungeX=(_adx/_ad)*r*0.26*_lk;
    _lungeY=(_ady/_ad)*r*0.14*_lk-r*0.10*Math.sin((1-(o._atkT||0)/180)*Math.PI);
  }
  const _fps=ctx.imageSmoothingEnabled;ctx.imageSmoothingEnabled=false;
  ctx.save();ctx.translate(sx+_lungeX,_footY+_lungeY);ctx.scale(_flip?-_breath:_breath,_breath);
  ctx.drawImage(frm,-_w/2,-_h,_w,_h);
  ctx.restore();ctx.imageSmoothingEnabled=_fps;
  // Ambient snow sparks
  if(!isAtk&&Math.random()<0.18){
    const _spx=sx+(Math.random()-.5)*_w*0.8,_spy=sy-Math.random()*_h*0.70;
    if(typeof addPart==='function')addPart(_spx,_spy,'#cceeff',1+Math.random()*1.5);
  }
  // Ice-blue hit flash (no hurt frame)
  if(isHurt){const _ha=Math.min(0.52,(o.shakeT||0)/240*0.52);ctx.globalAlpha=_ha;ctx.fillStyle='#88ddff';ctx.beginPath();ctx.arc(sx,sy,sz*z*1.05,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;}
  if(d.rare){ctx.strokeStyle='rgba(100,220,255,.65)';ctx.lineWidth=1.8*z;ctx.beginPath();ctx.arc(sx,sy,r+2*z,0,Math.PI*2);ctx.stroke();}
}

function drawFoxlingSprite(d,sz,sx,sy,z,o){
  const _t=Date.now(),_oid=(o&&o.id)||0,r=sz*z;
  const moving=o&&(Math.abs(o.vx||0)+Math.abs(o.vy||0)>0.05);
  const isAtk=!!(o&&(o._atkT||0)>0),isHurt=!!(o&&(o.shakeT||0)>0);
  // Frame selection: idle or 2-frame walk cycle. No run/atk/hurt frames.
  let frm=null;
  if(moving){
    const _wi=Math.floor((_t*0.008)%2);
    frm=_FOX_R.walk[_wi]?_FOX.walk[_wi]:(_FOX_R.idle?_FOX.idle:null);
  } else {
    frm=_FOX_R.idle?_FOX.idle:(_FOX_R.walk[0]?_FOX.walk[0]:null);
  }
  if(!frm)return;
  // ── Facing: priority order:
  //   1. Aggro target position (wild Foxling in combat → face whatever it's chasing)
  //   2. Velocity (fast lateral movement)
  //   3. Player proximity (activePal always faces player; others within 220u)
  //   4. Attack direction fallback
  if(o){
    let _want=0;
    // P1 — aggro/combat target position (updated every frame, never lags)
    if(o.aggroId&&typeof PL!=='undefined'){
      let _tgtX=PL.x;
      if(typeof activePal!=='undefined'&&activePal&&o.aggroId===activePal.id)_tgtX=activePal.x;
      const _tdx=_tgtX-o.x;
      if(Math.abs(_tdx)>4)_want=_tdx<0?-1:1;
    }
    // P2 — velocity (only if movement is clearly lateral)
    if(!_want&&Math.abs(o.vx||0)>0.06)_want=(o.vx||0)<0?-1:1;
    // P3 — player proximity (activePal always; others when near)
    if(typeof PL!=='undefined'&&typeof activePal!=='undefined'){
      const _pdx=PL.x-o.x;
      if(o===activePal){
        if(Math.abs(_pdx)>8)_want=_pdx<0?-1:1;
        else if(!_want){if(PL.facing==='left')_want=-1;else if(PL.facing==='right')_want=1;}
      } else if(!_want&&Math.hypot(_pdx,PL.y-o.y)<220&&Math.abs(_pdx)>8){
        _want=_pdx<0?-1:1;
      }
    }
    // P4 — attack direction (last resort)
    if(!_want&&isAtk&&(o._atkDx!=null)&&Math.abs(o._atkDx)>0.3)_want=o._atkDx<0?-1:1;
    if(_want)o._facing=_want;
    if(o._facing==null)o._facing=1;
  }
  const _facing=(o&&o._facing)||1;
  // Sprites face RIGHT naturally (natF=1); flip only when should face left
  const _natF=1;
  const _flip=_facing*_natF<0;
  const _fw=frm.naturalWidth||frm.width||127,_fh=frm.naturalHeight||frm.height||256;
  let _w=r*2.4;const _ringD=2*(sz+3)*z,_wCap=_ringD*(d.boss?1.1:0.92);if(_w>_wCap)_w=_wCap;
  let _h=_w*(_fh/_fw);const _hCap=_ringD*(d.boss?1.2:0.82)*1.9;if(_h>_hCap){_h=_hCap;_w=_h*(_fw/_fh);}
  const _groundY=sy+r*0.92;
  // Warm fire-tinted shadow
  ctx.fillStyle='rgba(180,60,0,0.18)';ctx.beginPath();ctx.ellipse(sx,_groundY,_w*0.34,_w*0.09,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='rgba(0,0,0,0.22)';ctx.beginPath();ctx.ellipse(sx,_groundY,_w*0.46,_w*0.13,0,0,Math.PI*2);ctx.fill();
  // Idle breathing scale
  const _breath=(!moving&&!isAtk)?(1+Math.sin(_t*0.0026+_oid*4.1)*0.020):1;
  const _footY=sy+r*0.92;
  // Attack: lunge toward target + tiny upward hop — no attack frame needed
  let _lungeX=0,_lungeY=0;
  if(isAtk){
    const _lk=Math.sin((1-(o._atkT||0)/180)*Math.PI)*6;
    const _adx=(o._atkDx||0),_ady=(o._atkDy||0),_ad=Math.hypot(_adx,_ady)||1;
    _lungeX=(_adx/_ad)*r*0.26*_lk;
    _lungeY=(_ady/_ad)*r*0.14*_lk-r*0.10*Math.sin((1-(o._atkT||0)/180)*Math.PI);
  }
  const _fps=ctx.imageSmoothingEnabled;ctx.imageSmoothingEnabled=false;
  ctx.save();ctx.translate(sx+_lungeX,_footY+_lungeY);ctx.scale(_flip?-_breath:_breath,_breath);
  ctx.drawImage(frm,-_w/2,-_h,_w,_h);
  ctx.restore();ctx.imageSmoothingEnabled=_fps;
  // Soft orange hit flash on hurt (no hurt frame)
  if(isHurt){
    const _ha=Math.min(0.50,(o.shakeT||0)/240*0.50);
    ctx.globalAlpha=_ha;ctx.fillStyle='#ff8822';
    ctx.beginPath();ctx.arc(sx,sy,sz*z*1.05,0,Math.PI*2);ctx.fill();
    ctx.globalAlpha=1;
  }
  if(d.rare){ctx.strokeStyle='rgba(255,180,40,.60)';ctx.lineWidth=1.5*z;ctx.beginPath();ctx.arc(sx,sy,r+2*z,0,Math.PI*2);ctx.stroke();}
}

// ─── VOIDCLAW FRAME ANIMATION SYSTEM (lightweight) ───────────────────────────
const _VC={idle:null,walk:[null,null]};
const _VC_R={idle:false,walk:[false,false]};
(function _loadVoidclawAni(){
  function _vl(key,idx,src){
    const im=new Image();
    if(idx==null){im.onload=function(){_VC[key]=im;_VC_R[key]=true;};_VC[key]=im;}
    else{const _i=idx;im.onload=function(){_VC[key][_i]=im;_VC_R[key][_i]=true;};_VC[key][idx]=im;}
    im.onerror=function(){};
    im.src=src;
  }
  _vl('idle',null,'/sprites/voidclaw_idle.png');
  _vl('walk',0,'/sprites/voidclaw_walk0.png');
  _vl('walk',1,'/sprites/voidclaw_walk1.png');
})();
function drawVoidclawSprite(d,sz,sx,sy,z,o){
  const _t=Date.now(),_oid=(o&&o.id)||0,r=sz*z;
  const moving=o&&(Math.abs(o.vx||0)+Math.abs(o.vy||0)>0.05);
  const isAtk=!!(o&&(o._atkT||0)>0),isHurt=!!(o&&(o.shakeT||0)>0);
  // Lightweight: idle or 2-frame walk cycle. No run/atk/hurt/faint frames — lunge+flash instead.
  let frm=null;
  if(moving){const _wi=Math.floor((_t*0.008)%2);frm=_VC_R.walk[_wi]?_VC.walk[_wi]:(_VC_R.idle?_VC.idle:null);}
  else{frm=_VC_R.idle?_VC.idle:(_VC_R.walk[0]?_VC.walk[0]:null);}
  if(!frm)return;
  // ── Facing: velocity first; player-position for ALL pals in range; attack dir fallback
  if(o){
    let _want=0;
    if(Math.abs(o.vx||0)>0.02)_want=(o.vx||0)<0?-1:1;
    if(typeof PL!=='undefined'&&typeof activePal!=='undefined'){
      const _pdx=PL.x-o.x;
      if(o===activePal){
        if(Math.abs(_pdx)>8)_want=_pdx<0?-1:1;
        else if(!_want){if(PL.facing==='left')_want=-1;else if(PL.facing==='right')_want=1;}
      } else if(Math.hypot(_pdx,PL.y-o.y)<220&&Math.abs(_pdx)>8){
        _want=_pdx<0?-1:1;
      }
    }
    if(!_want&&isAtk&&(o._atkDx!=null)&&Math.abs(o._atkDx)>0.3)_want=o._atkDx<0?-1:1;
    if(_want)o._facing=_want;
    if(o._facing==null)o._facing=1;
  }
  const _facing=(o&&o._facing)||1;
  const _flip=_facing<0;
  const _fw=frm.naturalWidth||frm.width||90,_fh=frm.naturalHeight||frm.height||90;
  let _w=r*2.7;
  const _ringD=2*(sz+3)*z,_wCap=_ringD*(d.boss?1.10:0.92);
  if(_w>_wCap)_w=_wCap;
  let _h=_w*(_fh/_fw);
  const _hCap=_ringD*(d.boss?1.20:0.82)*1.7;
  if(_h>_hCap){_h=_hCap;_w=_h*(_fw/_fh);}
  const _groundY=sy+r*0.95;
  // Void shadow
  ctx.fillStyle='rgba(34,0,51,0.45)';ctx.beginPath();ctx.ellipse(sx,_groundY,_w*0.36,_w*0.10,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='rgba(0,0,0,0.20)';ctx.beginPath();ctx.ellipse(sx,_groundY,_w*0.50,_w*0.14,0,0,Math.PI*2);ctx.fill();
  // Subtle void glow (no giant aura)
  const _pulse=0.85+Math.sin(_t*0.004+_oid*2.7)*0.15;
  const _gr=ctx.createRadialGradient(sx,sy,0,sx,sy,_w*0.40*_pulse);
  _gr.addColorStop(0,'rgba(80,0,120,0.22)');_gr.addColorStop(1,'rgba(0,0,0,0)');
  ctx.fillStyle=_gr;ctx.beginPath();ctx.arc(sx,sy,_w*0.40*_pulse,0,Math.PI*2);ctx.fill();
  // Idle breathing
  const _breath=(!moving&&!isAtk&&!isHurt)?(1+Math.sin(_t*0.0026+_oid*3.9)*0.022):1;
  // Attack lunge
  let _lungeX=0,_lungeY=0;
  if(isAtk){
    const _lk=Math.sin((1-Math.max(0,(o._atkT||0))/180)*Math.PI)*8;
    const _adx=(o._atkDx||0),_ady=(o._atkDy||0),_ad=Math.hypot(_adx,_ady)||1;
    _lungeX=(_adx/_ad)*r*0.30*_lk;_lungeY=(_ady/_ad)*r*0.18*_lk;
  }
  const _footY=sy+r*0.95;
  const _fps=ctx.imageSmoothingEnabled;ctx.imageSmoothingEnabled=false;
  ctx.save();
  ctx.translate(sx+_lungeX,_footY+_lungeY);
  ctx.scale((_flip?-1:1)*_breath,_breath);
  ctx.drawImage(frm,-_w/2,-_h,_w,_h);
  ctx.restore();
  ctx.imageSmoothingEnabled=_fps;
  // Hurt flash (dark purple tint)
  if(isHurt){
    const _ha=Math.min(0.55,(o.shakeT||0)/240*0.55);
    ctx.globalAlpha=_ha;ctx.fillStyle='#9900cc';
    ctx.beginPath();ctx.arc(sx,sy,sz*z*1.05,0,Math.PI*2);ctx.fill();
    ctx.globalAlpha=1;
  }
  if(d.rare){ctx.strokeStyle='rgba(180,60,255,.70)';ctx.lineWidth=1.8*z;ctx.beginPath();ctx.arc(sx,sy,r+2*z,0,Math.PI*2);ctx.stroke();}
}

function drawPalBody(d,sz,sx,sy,z,o){
  if(d.name==='Blaze'){drawBlazeSprite(d,sz,sx,sy,z,o);return;}
  if(d.name==='Foxling'){drawFoxlingSprite(d,sz,sx,sy,z,o);return;}
  if(d.name==='Frostie'){drawFrostSprite(d,sz,sx,sy,z,o);return;}
  if(d.name==='Voidclaw'){drawVoidclawSprite(d,sz,sx,sy,z,o);return;}
  const _idle=1+Math.sin(Date.now()*0.0028)*0.035;
  const r=sz*z*_idle;
  // ── Sprite override for redesigned pals (Fox, Slime, Pebble Golem) ──
  const _sp=PAL_SPRITES[d.name];
  const _ready=PAL_SPRITE_READY[d.name];
  if(_sp&&_ready){
    // Facing: velocity first; player-position for ALL pals in range; attack dir fallback
    if(o){
      let want=0;
      const vx=o.vx||0;
      if(Math.abs(vx)>0.02)want=vx<0?-1:1;
      if(typeof PL!=='undefined'&&typeof activePal!=='undefined'){
        const _pdx=PL.x-o.x;
        if(o===activePal){
          if(Math.abs(_pdx)>8)want=_pdx<0?-1:1;
          else if(!want){if(PL.facing==='left')want=-1;else if(PL.facing==='right')want=1;}
        } else if(Math.hypot(_pdx,PL.y-o.y)<220&&Math.abs(_pdx)>8){
          want=_pdx<0?-1:1;
        }
      }
      const aT=o._atkT||0;
      if(!want&&aT>0&&(o._atkDx!=null)&&Math.abs(o._atkDx)>0.3)want=o._atkDx<0?-1:1;
      if(want)o._facing=want;
      if(o._facing==null)o._facing=1;
    }
    const facing=(o&&o._facing)||1;
    const natF=PAL_SPRITE_NAT_FACING[d.name]||1;
    const flip=facing*natF<0;
    // Soft layered ground shadow (sits under the feet)
    const sw=_sp.width||_sp.naturalWidth||r*2;
    const sh=_sp.height||_sp.naturalHeight||r*2;
    let w=r*(PAL_SPRITE_SCALE[d.name]||2.5);
    // Hard cap WIDTH: never exceed ~92% of selection-ring diameter (110% for bosses).
    const ringD=2*(sz+3)*z;
    const wCap=ringD*(d.boss?1.10:0.92);
    if(w>wCap)w=wCap;
    let h=w*(sh/sw);
    // Hard cap HEIGHT for tall sprites (Sylvan etc) — max 82% of ring diameter, then re-derive width.
    const hCap=ringD*(d.boss?1.20:0.82)*1.6; // tall pals can be a bit taller than ring (1.31x)
    if(h>hCap){h=hCap;w=h*(sw/sh);}
    // Anchor: feet on ground for normal pals, body-centered on ring for floating pals (Sylvan).
    const isFloat=(PAL_SPRITE_FLOAT[d.name]||0)>0;
    const groundY=sy+r*0.92;                          // shadow always sits on the ground
    const footY=isFloat?(sy+h*0.5):(sy+r*0.92);       // body anchor (where bottom of sprite lands)
    // Heavier shadow for tank-class pals; lighter / smaller for floating pals
    const shScale=d.name==='Stonehorn'?1.25:d.name==='Pebble'?1.1:isFloat?0.75:1.0;
    const shAlpha=isFloat?0.22:0.34;
    ctx.fillStyle='rgba(0,0,0,'+shAlpha.toFixed(2)+')';ctx.beginPath();ctx.ellipse(sx,groundY,w*0.34*shScale,w*0.10*shScale,0,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='rgba(0,0,0,'+(shAlpha*0.55).toFixed(2)+')';ctx.beginPath();ctx.ellipse(sx,groundY,w*0.46*shScale,w*0.14*shScale,0,0,Math.PI*2);ctx.fill();
    // Optional soft glow halo (Blaze fire, Frostie sparkle) — drawn behind sprite
    const glow=PAL_SPRITE_GLOW[d.name];
    if(glow){
      const pulse=0.85+Math.sin(Date.now()*0.005+(o&&o.id||0)*7)*0.15;
      const gr=ctx.createRadialGradient(sx,sy,0,sx,sy,w*glow.r*pulse);
      gr.addColorStop(0,glow.color+'');
      gr.addColorStop(1,'rgba(0,0,0,0)');
      ctx.globalAlpha=glow.alpha*pulse;ctx.fillStyle=gr;
      ctx.beginPath();ctx.arc(sx,sy,w*glow.r*pulse,0,Math.PI*2);ctx.fill();
      ctx.globalAlpha=1;
    }
    // Tiny extra movement bob — per-pal amplitude/speed (heavy = slow stomp)
    const moving=o&&(Math.abs(o.vx||0)+Math.abs(o.vy||0)>0.05);
    const bobAmp=PAL_SPRITE_BOB[d.name]||1.0;
    const bobSpd=PAL_SPRITE_BOB_SPD[d.name]||0.012;
    const _t=Date.now(),_oid=(o&&o.id||0);
    const movBob=moving?Math.sin(_t*bobSpd+_oid*9)*r*0.06*bobAmp:0;
    // Floating idle (Sylvan) — gentle continuous up/down even when standing still
    const floatAmp=PAL_SPRITE_FLOAT[d.name]||0;
    const idleFloat=floatAmp?Math.sin(_t*0.0028+_oid*5)*r*0.10*floatAmp:0;
    // ── LIFE ANIMATIONS ──
    // 1) Idle breathing — gentle squash/stretch
    const breath=1+Math.sin(_t*0.0024+_oid*3.7)*0.022;
    // 2) Species pulse — predators do an aggressive crouch beat
    let crouchY=1,crouchX=1;
    if(d.name==='Voidclaw'||d.name==='DarkFang'){
      const cp=Math.sin(_t*0.0055+_oid*2.1);
      crouchY=1-Math.max(0,cp)*0.06;          // squash down on beat
      crouchX=1+Math.max(0,cp)*0.04;          // bulge sideways
    }
    // 3) Frostie chill wobble — tiny side sway
    const chillX=(d.name==='Frostie')?Math.sin(_t*0.0042+_oid*4)*r*0.05:0;
    // 4) Tail-swish for canines/horse — extra body sway when moving
    const tailSway=(moving&&(d.name==='Foxling'||d.name==='DarkFang'))?Math.sin(_t*0.018+_oid*7)*r*0.04:0;
    // 5) Movement tilt — gentle lean in direction of travel
    const _vx=(o&&o.vx)||0,_vy=(o&&o.vy)||0;
    const spd=Math.hypot(_vx,_vy);
    const tilt=moving?Math.max(-0.12,Math.min(0.12,_vx*0.025))*(1-Math.min(1,spd*0.3)*0)*facing:0;
    // 6) Combat: hit recoil — quick jitter using existing shakeT (220ms)
    const sT=(o&&o.shakeT)||0;
    const recoilK=sT>0?(sT/220):0;
    const recoilX=recoilK?Math.sin(_t*0.06)*r*0.20*recoilK:0;
    const recoilY=recoilK?Math.cos(_t*0.07)*r*0.10*recoilK:0;
    // 7) Combat: attack lunge — small forward thrust toward _atkDx/_atkDy
    const aT=(o&&o._atkT)||0;
    let lungeX=0,lungeY=0;
    if(aT>0){
      const lk=Math.sin((1-aT/180)*Math.PI);     // 0→1→0 over the 180ms
      const adx=(o&&o._atkDx)||0,ady=(o&&o._atkDy)||0;
      const ad=Math.hypot(adx,ady)||1;
      lungeX=(adx/ad)*r*0.28*lk;
      lungeY=(ady/ad)*r*0.18*lk;
    }
    const dy=footY-h+movBob+idleFloat+recoilY+lungeY;
    const dxOff=chillX+tailSway+recoilX+lungeX;
    // Frostie ice sparkle — 1 tiny twinkle, very cheap
    if(d.name==='Frostie'){
      const tt=(_t*0.001+_oid*3)%2;
      if(tt<0.4){
        const sa=Math.sin(tt/0.4*Math.PI);
        ctx.fillStyle='rgba(255,255,255,'+(0.7*sa).toFixed(2)+')';
        ctx.beginPath();ctx.arc(sx+r*0.6,sy-r*0.5,r*0.10*sa,0,Math.PI*2);ctx.fill();
      }
    }
    // Blaze flame flicker — extra hot ember pop on top of the glow halo
    if(d.name==='Blaze'){
      const flick=0.55+Math.sin(_t*0.024+_oid*5)*0.22+Math.sin(_t*0.041+_oid)*0.18;
      ctx.fillStyle='rgba(255,180,60,'+(0.18*Math.max(0,flick)).toFixed(2)+')';
      ctx.beginPath();ctx.arc(sx,sy-r*0.2,r*0.55,0,Math.PI*2);ctx.fill();
    }
    // Apply combined transform: tilt around feet + breathing + species squash + flip
    const _ps=ctx.imageSmoothingEnabled;ctx.imageSmoothingEnabled=false;
    const sx2=sx+dxOff;
    const cx=sx2,cy=footY;
    ctx.save();
    ctx.translate(cx,cy);
    if(tilt)ctx.rotate(tilt);
    const fScale=flip?-1:1;
    ctx.scale(fScale*breath*crouchX,breath*crouchY);
    ctx.drawImage(_sp,-w/2,dy-cy,w,h);
    ctx.restore();
    ctx.imageSmoothingEnabled=_ps;
    if(d.rare){ctx.strokeStyle='rgba(255,230,80,.55)';ctx.lineWidth=1.5*z;ctx.beginPath();ctx.arc(sx,sy,r+2*z,0,Math.PI*2);ctx.stroke();}
    return;
  }
  // Soft drop shadow (default fallback path)
  ctx.fillStyle='rgba(0,0,0,.3)';ctx.beginPath();ctx.ellipse(sx,sy+r*.95,r*.85,r*.28,0,0,Math.PI*2);ctx.fill();
  // Tail (back)
  ctx.fillStyle=d.tailCol||d.bodyCol;ctx.beginPath();ctx.ellipse(sx-r*.6,sy+r*.4,r*.5,r*.3,Math.PI*.35,0,Math.PI*2);ctx.fill();
  // Element-shaped body overlay (kept inside circle hitbox so collision unchanged)
  const el=(d.ability&&d.ability.type)||'';
  ctx.fillStyle=d.bodyCol;
  if(el==='fire'){
    // Flame teardrop body
    ctx.beginPath();ctx.moveTo(sx,sy-r*1.05);
    ctx.bezierCurveTo(sx+r*1.1,sy-r*.3, sx+r*.95,sy+r*.85, sx,sy+r*.95);
    ctx.bezierCurveTo(sx-r*.95,sy+r*.85, sx-r*1.1,sy-r*.3, sx,sy-r*1.05);
    ctx.closePath();ctx.fill();
    // inner flame
    ctx.fillStyle='rgba(255,220,80,.55)';ctx.beginPath();ctx.moveTo(sx,sy-r*.55);ctx.bezierCurveTo(sx+r*.55,sy-r*.05, sx+r*.4,sy+r*.55, sx,sy+r*.6);ctx.bezierCurveTo(sx-r*.4,sy+r*.55, sx-r*.55,sy-r*.05, sx,sy-r*.55);ctx.closePath();ctx.fill();
  } else if(el==='nature'){
    // Round body + leaf on top
    ctx.beginPath();ctx.arc(sx,sy,r,0,Math.PI*2);ctx.fill();
    ctx.save();ctx.translate(sx,sy-r*.85);ctx.rotate(-0.5);
    ctx.fillStyle='#3ea02a';ctx.beginPath();ctx.ellipse(0,0,r*.55,r*.28,0,0,Math.PI*2);ctx.fill();
    ctx.strokeStyle='#1f5a18';ctx.lineWidth=z;ctx.beginPath();ctx.moveTo(-r*.55,0);ctx.lineTo(r*.55,0);ctx.stroke();
    ctx.restore();
  } else if(el==='ice'){
    // Crystal-shape body (hexagonal-ish)
    ctx.beginPath();
    ctx.moveTo(sx,sy-r*1.05);
    ctx.lineTo(sx+r*.95,sy-r*.4);
    ctx.lineTo(sx+r*.85,sy+r*.7);
    ctx.lineTo(sx-r*.85,sy+r*.7);
    ctx.lineTo(sx-r*.95,sy-r*.4);
    ctx.closePath();ctx.fill();
    ctx.fillStyle='rgba(255,255,255,.45)';ctx.beginPath();ctx.moveTo(sx-r*.25,sy-r*.7);ctx.lineTo(sx+r*.05,sy-r*.5);ctx.lineTo(sx-r*.1,sy+r*.2);ctx.closePath();ctx.fill();
  } else if(el==='earth'){
    // Rough rock — body + 2 stone bumps
    ctx.beginPath();ctx.arc(sx,sy,r,0,Math.PI*2);ctx.fill();
    ctx.fillStyle=d.tailCol||'#7a6a5a';
    ctx.beginPath();ctx.arc(sx-r*.55,sy-r*.55,r*.32,0,Math.PI*2);ctx.fill();
    ctx.beginPath();ctx.arc(sx+r*.6,sy-r*.4,r*.28,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='rgba(0,0,0,.25)';ctx.fillRect(sx-r*.3,sy+r*.2,r*.6,r*.08);
  } else if(el==='dark'){
    // Spiky dark crown
    ctx.beginPath();ctx.arc(sx,sy,r,0,Math.PI*2);ctx.fill();
    ctx.fillStyle=d.eyeCol||'#ff2200';
    for(let i=0;i<5;i++){const ang=-Math.PI/2+(i-2)*0.5;const x1=sx+Math.cos(ang)*r*.85,y1=sy+Math.sin(ang)*r*.85;const x2=sx+Math.cos(ang)*r*1.25,y2=sy+Math.sin(ang)*r*1.25;ctx.beginPath();ctx.moveTo(x1-2*z,y1);ctx.lineTo(x1+2*z,y1);ctx.lineTo(x2,y2);ctx.closePath();ctx.fill();}
    ctx.fillStyle=d.bodyCol;
  } else {
    // Default: round body with little ears
    ctx.beginPath();ctx.arc(sx,sy,r,0,Math.PI*2);ctx.fill();
    ctx.fillStyle=d.tailCol||d.bodyCol;
    ctx.beginPath();ctx.moveTo(sx-r*.2,sy-r*.7);ctx.lineTo(sx+r*.2,sy-r*.7);ctx.lineTo(sx,sy-r*1.12);ctx.closePath();ctx.fill();
  }
  // Outline for readability
  ctx.strokeStyle='rgba(0,0,0,.55)';ctx.lineWidth=Math.max(1,z*1.1);ctx.beginPath();ctx.arc(sx,sy,r,0,Math.PI*2);ctx.stroke();
  // Eyes (white) + pupils
  ctx.fillStyle=d.eyeCol||'#fff';ctx.beginPath();ctx.arc(sx+r*.32,sy-r*.18,r*.22,0,Math.PI*2);ctx.fill();ctx.beginPath();ctx.arc(sx-r*.32,sy-r*.18,r*.22,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#111';ctx.beginPath();ctx.arc(sx+r*.34,sy-r*.18,r*.11,0,Math.PI*2);ctx.fill();ctx.beginPath();ctx.arc(sx-r*.34,sy-r*.18,r*.11,0,Math.PI*2);ctx.fill();
  // Tiny eye highlight
  ctx.fillStyle='rgba(255,255,255,.85)';ctx.beginPath();ctx.arc(sx+r*.37,sy-r*.22,r*.05,0,Math.PI*2);ctx.fill();ctx.beginPath();ctx.arc(sx-r*.31,sy-r*.22,r*.05,0,Math.PI*2);ctx.fill();
  // Tiny mouth — gives every pal a face
  ctx.fillStyle='rgba(0,0,0,.55)';
  ctx.fillRect(sx-r*.08,sy+r*.18,r*.16,r*.08);
  // Small ears for round-body variants that lack them (fire keeps teardrop, nature has leaf, dark has crown)
  if(el==='ice'||el==='earth'){
    ctx.fillStyle=d.tailCol||d.bodyCol;
    ctx.beginPath();ctx.moveTo(sx-r*.55,sy-r*.78);ctx.lineTo(sx-r*.30,sy-r*.50);ctx.lineTo(sx-r*.20,sy-r*.85);ctx.closePath();ctx.fill();
    ctx.beginPath();ctx.moveTo(sx+r*.55,sy-r*.78);ctx.lineTo(sx+r*.30,sy-r*.50);ctx.lineTo(sx+r*.20,sy-r*.85);ctx.closePath();ctx.fill();
  }
  if(d.rare){ctx.strokeStyle='rgba(255,230,80,.55)';ctx.lineWidth=1.5*z;ctx.beginPath();ctx.arc(sx,sy,r+2*z,0,Math.PI*2);ctx.stroke();}
}
function palLunge(o){
  if(!o||!o._atkT||o._atkT<=0)return{lx:0,ly:0};
  const dur=180,t=o._atkT/dur,f=Math.sin((1-t)*Math.PI)*7;
  const dn=Math.hypot(o._atkDx||0,o._atkDy||0)||1;
  return{lx:(o._atkDx||0)/dn*f,ly:(o._atkDy||0)/dn*f};
}
function drawPalFx(o,sx,sy,sz,z){
  if(!o)return;
  if(o.shakeT>0){
    const a=Math.min(0.55,o.shakeT/240*0.55);
    ctx.globalAlpha=a;ctx.fillStyle='#ffffff';
    ctx.beginPath();ctx.arc(sx,sy,sz*z*1.05,0,Math.PI*2);ctx.fill();
    ctx.globalAlpha=1;
  }
  if(o._skT>0){
    const dur=420,t=1-o._skT/dur;
    const r=sz*z*(1+t*1.5);
    ctx.globalAlpha=(1-t)*0.65;
    ctx.strokeStyle=o._skColor||'#cc44ff';ctx.lineWidth=2*z;
    ctx.beginPath();ctx.arc(sx,sy,r,0,Math.PI*2);ctx.stroke();
    ctx.globalAlpha=1;
  }
}
function tickPalFx(o,dt){
  if(!o)return;
  if(o._atkT>0)o._atkT=Math.max(0,o._atkT-dt);
  if(o._skT>0)o._skT=Math.max(0,o._skT-dt);
}
function drawSpk(p,sx,sy,sz,z){
  const t=Date.now()*.002+p.id*99;
  for(let i=0;i<6;i++){const a=t+i*Math.PI/3,r=(sz+5)*z;ctx.fillStyle=p.def.ability.color;ctx.globalAlpha=.45+Math.sin(t+i)*0.2;ctx.beginPath();ctx.arc(sx+Math.cos(a)*r,sy+Math.sin(a)*r,2.5*z,0,Math.PI*2);ctx.fill();}
  ctx.globalAlpha=1;
}

// ═══════════════════════════════
// WILD PALS
// ═══════════════════════════════
const wildPals=[];
const WILD_MAX=24;        // hard cap on active pals (perf safety)

// Biome-based pal spawning: weight map per biome (10 entries: 8 base + 2 danger pals)
const BIOME_PAL_WEIGHTS={
  0:[1.5,1.5,0.3,0.1,0.1,0.2,0.2,0.2,0.0,0.0],  // Grass: Foxling,Mossy dominant
  1:[0.2,0.1,1.5,0.1,1.2,1.5,0.3,0.1,0.0,0.0],  // Rocky: Pebble,Frostie,Stonehorn dominant
  2:[0.2,0.1,0.8,1.5,0.1,0.3,1.5,0.1,0.0,0.0],  // Copper: Blaze,Coprite dominant
  3:[0.8,1.5,0.2,0.1,0.1,0.1,0.1,1.5,0.0,0.0],  // Forest: Mossy,Sylvan dominant
  4:[0.1,0.1,0.3,1.0,0.8,0.2,0.4,0.4,2.2,2.4],  // Danger: DarkFang,Voidclaw dominant
  5:[0.3,0.4,0.2,0.1,1.5,0.2,0.3,0.4,0.0,0.0],  // Highland Plains: mix rocky+danger
  6:[0.1,0.3,0.1,0.1,1.5,0.3,0.1,0.2,0.2,0.1],  // Ice: Frostie dominant
  7:[0.1,0.1,0.5,1.5,0.2,0.1,1.5,0.1,0.3,0.3],  // Fire: Blaze+Coprite dominant
};

function pickPalForBiome(bId){
  const base=BIOME_PAL_WEIGHTS[bId]||BIOME_PAL_WEIGHTS[0];
  // Night bias: boost the two "danger" pals (indices 8,9) and the rare slots (3,4,7) everywhere.
  // Daytime keeps original biome weights untouched.
  const _night=typeof isNight==='function'&&isNight();
  let weights=base;
  if(_night&&bId!==4){
    weights=base.slice();
    weights[3]+=0.4; weights[4]+=0.3; weights[7]+=0.3;
    weights[8]+=0.6; weights[9]+=0.6;
  }
  // Fog: slightly boost rare pals (indices 3,4,7) — mysterious atmosphere
  if(WX.state==='Fog'&&WX.alpha>0.3){
    if(weights===base)weights=base.slice();
    weights[3]+=0.30; weights[4]+=0.30; weights[7]+=0.30;
  }
  // Storm: boost stronger/dangerous pals (indices 5=Stonehorn, 8=DarkFang, 9=Voidclaw)
  if(WX.state==='Storm'&&WX.alpha>0.4){
    if(weights===base)weights=base.slice();
    weights[5]+=0.40; weights[8]+=0.50; weights[9]+=0.50;
  }
  // Heat: boost fire-affinity pals (3=Blaze, 6=Coprite); reduce ice (4=Frostie)
  if(WX.state==='Heat'&&WX.alpha>0.4){
    if(weights===base)weights=base.slice();
    weights[3]+=0.50; weights[6]+=0.30;
    weights[4]=Math.max(0.05,(weights[4]||0)-0.30);
  }
  // Blood Moon: amplify dark/danger pals further at night
  if(WX.bloodMoon&&_night){
    if(weights===base)weights=base.slice();
    weights[8]+=0.70; weights[9]+=0.70; weights[7]+=0.30;
  }
  const total=weights.reduce((s,w)=>s+w,0);
  let r=Math.random()*total;
  for(let i=0;i<weights.length;i++){r-=weights[i];if(r<=0)return PAL_TYPES[i];}
  return PAL_TYPES[0];
}

// Population targets — keep world feeling alive without overcrowding.
const WILD_MIN=12;          // soft minimum across the whole map
const WILD_NEAR_MIN=2;      // minimum within NEAR_R of player (reduced — less base crowding)
const NEAR_R=380;           // "near player" radius in world units
let _wildTopUpT=0;
function _aliveWilds(){let n=0;for(let i=0;i<wildPals.length;i++)if(!wildPals[i].dead)n++;return n;}
function _aliveNearPlayer(){
  let n=0;const r2=NEAR_R*NEAR_R;
  for(let i=0;i<wildPals.length;i++){
    const w=wildPals[i];if(w.dead)continue;
    const dx=w.x-PL.x,dy=w.y-PL.y;
    if(dx*dx+dy*dy<=r2)n++;
  }
  return n;
}
function maintainWildPopulation(dt){
  _wildTopUpT-=dt;
  if(_wildTopUpT>0)return;
  // At night, spawn check fires more often (every ~2–3.5s vs 3–5s).
  const _night=typeof isNight==='function'&&isNight();
  _wildTopUpT=_night?(4000+Math.random()*2500):(6000+Math.random()*4000);
  const alive=_aliveWilds();
  if(alive>=WILD_MAX)return; // hard cap reached → do not spawn
  const near=_aliveNearPlayer();
  // Slightly higher minimums at night for the "danger" feel.
  const _wMin=_night?WILD_MIN+3:WILD_MIN;
  const _nMin=_night?WILD_NEAR_MIN+1:WILD_NEAR_MIN;
  let need=0;
  if(alive<_wMin)need=_wMin-alive;
  if(near<_nMin)need=Math.max(need,_nMin-near);
  if(need<=0)return;
  // Gradual: spawn 2–3 at a time (3–4 at night)
  const batch=_night?3+Math.floor(Math.random()*2):2+Math.floor(Math.random()*2);
  need=Math.min(need,batch,WILD_MAX-alive);
  if(need>0)spawnWild(need,'distributed');
}
// Avoid spawning on top of structures
function _structureOverlap(x,y,pad){
  if(!structures)return false;
  for(let i=0;i<structures.length;i++){
    const s=structures[i];
    if(Math.abs(s.x-x)<pad&&Math.abs(s.y-y)<pad)return true;
  }
  return false;
}
// Spawn distance bands (world units) — keep clear of player & within map.
const SPAWN_SAFE_MIN=288;   // never spawn closer than ~9 tiles to player
const SPAWN_NEAR_MAX=480;   // "near" band outer edge
const SPAWN_MID_MAX=880;    // "mid" band outer edge
function spawnWild(n,mode){
  // mode: 'near' | 'distributed' | undefined (legacy = distributed)
  for(let i=0;i<n;i++){
    if(wildPals.length>=WILD_MAX)break;
    // Pick a zone for this spawn: 40% near, 30% mid, 30% far
    let band;
    if(mode==='near')band='near';
    else{const rZ=Math.random();band=rZ<0.40?'near':rZ<0.70?'mid':'far';}
    let tries=0,ox=0,oy=0,bId=0,ok=false;
    while(tries<24&&!ok){
      tries++;
      if(band==='near'){
        const ang=Math.random()*Math.PI*2;
        const rad=SPAWN_SAFE_MIN+Math.random()*(SPAWN_NEAR_MAX-SPAWN_SAFE_MIN);
        ox=PL.x+Math.cos(ang)*rad;
        oy=PL.y+Math.sin(ang)*rad;
      }else if(band==='mid'){
        const ang=Math.random()*Math.PI*2;
        const rad=SPAWN_NEAR_MAX+Math.random()*(SPAWN_MID_MAX-SPAWN_NEAR_MAX);
        ox=PL.x+Math.cos(ang)*rad;
        oy=PL.y+Math.sin(ang)*rad;
      }else{
        // Far: random map cell, fall back to map ring if needed
        const col=Math.floor(Math.random()*(COLS-4))+2;
        const row=Math.floor(Math.random()*(ROWS-4))+2;
        ox=col*TILE+Math.random()*TILE*0.5;
        oy=row*TILE+Math.random()*TILE*0.5;
      }
      // Clamp to map
      ox=Math.max(TILE*2,Math.min(MAP_W-TILE*2,ox));
      oy=Math.max(TILE*2,Math.min(MAP_H-TILE*2,oy));
      const c=Math.floor(ox/TILE),r=Math.floor(oy/TILE);
      bId=biomeMap[r]?.[c]??0;
      // Conditions: respect safe radius from player + base + structures
      const dPlayer=Math.hypot(ox-PL.x,oy-PL.y);
      if(dPlayer<SPAWN_SAFE_MIN)continue;
      // Never spawn inside base/palbox defense radius
      const _spPB=getPB();
      if(_spPB&&Math.hypot(ox-_spPB.x,oy-_spPB.y)<BASE_RADIUS*0.90)continue;
      if(_structureOverlap(ox,oy,22))continue;
      ok=true;
    }
    if(!ok)continue;
    const def=pickPalForBiome(bId);
    // Zone-based level and rarity scaling
    const zone=getZoneType(ox,oy);
    const isDanger=bId===4||zone===2;
    const isMid=!isDanger&&zone===1;
    const lv=isDanger
      ?5+Math.floor(Math.random()*6)
      :isMid
        ?2+Math.floor(Math.random()*4)
        :bId===1?2+Math.floor(Math.random()*3):bId===2?3+Math.floor(Math.random()*4):bId===3?1+Math.floor(Math.random()*3):1+Math.floor(Math.random()*2);
    // Night gives a small rarity boost (more rares/epics, slight stat bump)
    const _isNightSpawn=(typeof isNight==='function')&&isNight();
    let rr=Math.random();
    if(_isNightSpawn)rr*=0.78; // bias toward rarer outcomes
    // Target overall ratios: Normal 70%, Rare 20%, Epic 8%, Legendary 2%
    // Slight zone weighting kept for danger/mid (more elites), but normals stay dominant.
    const rarity=isDanger
      ?(rr<0.04?'legendary':rr<0.14?'epic':rr<0.40?'rare':'common')
      :isMid
        ?(rr<0.025?'legendary':rr<0.10?'epic':rr<0.30?'rare':'common')
        :(rr<0.02?'legendary':rr<0.08?'epic':rr<0.20?'rare':'common');
    const _nMul=_isNightSpawn?1.10:1; // tiny HP/dmg bump at night for atmosphere
    const hpMult=(rarity==='legendary'?4.5:rarity==='epic'?2.5:rarity==='rare'?1.6:1)*_nMul;
    const dmgAdd=(rarity==='legendary'?6:rarity==='epic'?3:rarity==='rare'?1:0)+(_isNightSpawn?1:0);
    const sizAdd=rarity==='legendary'?8:rarity==='epic'?4:rarity==='rare'?2:0;
    const baseHp=Math.round((def.baseHp+lv)*hpMult);
    const skInitCD=def.special?(def.special.cd*0.6+Math.random()*2500):99999;
    wildPals.push({def,x:ox,y:oy,hp:baseHp,maxHp:baseHp,level:lv,xp:0,xpNeeded:xpToNext(lv),dead:false,id:Math.random(),aF:0,aT:0,shakeT:0,vx:(Math.random()-.5)*.4,vy:(Math.random()-.5)*.4,wT:2000+Math.random()*2000,abCD:def.ability.cd,skCD:skInitCD,rarity,dmgBonus:dmgAdd,sizeBonus:sizAdd});
    // Rare spawn announce (only nearby spawns, throttled — keeps it special, not spammy)
    if(rarity!=='common'){
      const _dPL=Math.hypot(ox-PL.x,oy-PL.y);
      if(_dPL<NEAR_R*1.6){
        const _ann=rarity==='legendary'?(Math.random()<0.95):rarity==='epic'?(Math.random()<0.65):(Math.random()<0.22);
        if(_ann){
          const _label=rarity==='legendary'?'🌟 LEGENDARY':rarity==='epic'?'💜 EPIC':'⭐ RARE';
          const _col=rarity==='legendary'?'#ffd700':rarity==='epic'?'#cc44ff':'#7dd3fc';
          spawnPop(_label+' '+def.name+' nearby!',_col);
        }
      }
    }
  }
}
function updWild(dt){
  maintainWildPopulation(dt);
  for(let i=wildPals.length-1;i>=0;i--){
    const p=wildPals[i];if(p.dead){p._deadT=(p._deadT||0)+dt;if(p._deadT>700)wildPals.splice(i,1);continue;}
    if(p.shakeT>0)p.shakeT=Math.max(0,p.shakeT-dt);

    // ── SMART TARGET: pick nearest of player / active pal ──
    const dxPL=PL.x-p.x,dyPL=PL.y-p.y,distPL=Math.hypot(dxPL,dyPL)||1;
    // PALDEX: register first sighting when pal is on-screen near player
    if(distPL<240&&p.def&&!Paldex.seen[p.def.name])markSeen(p.def.name);
    const palAlive=activePal&&!activePal.fainted&&!activePal.dead;
    let tgtX=PL.x,tgtY=PL.y,tgtIsPal=false,tgtDist=distPL;
    if(palAlive){
      const dxPal=activePal.x-p.x,dyPal=activePal.y-p.y,distPal=Math.hypot(dxPal,dyPal)||1;
      // Switch to pal if it has aggro on this enemy OR pal is closer
      if(p.aggroId===activePal.id||distPal<distPL){
        tgtX=activePal.x;tgtY=activePal.y;tgtIsPal=true;tgtDist=distPal;
      }
    }
    const dx=tgtX-p.x,dy=tgtY-p.y;
    // ── BEHAVIOR-AWARE AGGRO ──
    const _beh=(p.def&&p.def.behavior)||'aggressive';
    const _isHostile=!!p.hostile||p.aggroId==='PLAYER'||(p.aggroId&&palAlive&&p.aggroId===activePal.id);
    const _willFight=_beh==='aggressive'||_isHostile;
    // Timid pals only engage when cornered (very close) or already hostile
    const _timidCornered=_beh==='timid'&&distPL<48;
    const aggroR=(140+p.level*10)*(typeof wxAggroMul==='function'?wxAggroMul():1);
    const aggro=(_willFight||_timidCornered)&&(tgtDist<aggroR||p.aggroId==='PLAYER')&&(tgtIsPal?palAlive:!PL.dead);
    // Timid flee: when player approaches and pal isn't hostile yet, run away
    const _shouldFlee=_beh==='timid'&&!_isHostile&&!_timidCornered&&distPL<170;

    // Status effects: stun / slow from pal specials
    if((p._stunT||0)>0)p._stunT=Math.max(0,p._stunT-dt);
    if((p._slowT||0)>0)p._slowT=Math.max(0,p._slowT-dt);
    const _stunned=(p._stunT||0)>0;
    const _sMult=(p._slowT||0)>0?(p._slowMult||0.42):1;
    if(aggro&&!_stunned){const spd=(0.7+p.level*0.08)*_sMult;moveWithColl(p,dx/tgtDist*spd,dy/tgtDist*spd,10,10);}
    else if(_shouldFlee&&!_stunned){const fdx=p.x-PL.x,fdy=p.y-PL.y,fd=Math.hypot(fdx,fdy)||1;const spd=(0.85+p.level*0.05)*_sMult;moveWithColl(p,fdx/fd*spd,fdy/fd*spd,10,10);}
    else if(!_stunned){p.wT-=dt;if(p.wT<=0){p.wT=2200+Math.random()*2000;p.vx=(Math.random()-.5)*.5;p.vy=(Math.random()-.5)*.5;}moveWithColl(p,p.vx*_sMult,p.vy*_sMult,10,10);}
    p.aT+=dt;if(p.aT>200){p.aF=(p.aF+1)%4;p.aT=0;}
    tickPalFx(p,dt);

    // ── ABILITY ATTACK ──
    p.abCD-=dt;
    if(aggro&&p.abCD<=0&&tgtDist<p.def.ability.range){
      // Only fire if target is valid (not both dead)
      const canHitPl=!PL.dead&&!tgtIsPal;
      const canHitPal=tgtIsPal&&palAlive;
      if(canHitPl||canHitPal){
        p.abCD=p.def.ability.cd+(Math.random()*400-200);
        p._atkT=180;p._atkDx=tgtX-p.x;p._atkDy=tgtY-p.y;
        const bd=p.def.baseDmg+(p.dmgBonus||0)+(p.level>2?1:0);
        function _fireAtTarget(dmg){
          if(tgtIsPal){hurtActivePal(dmg);}
          else{
            if(p.rarity==='legendary'){if(PL.stunT<=0){PL.stunT=900;flashStun();}addPart(p.x,p.y,'#ffd700',12);spawnPop('⚡ STUNNED! '+p.def.name,'#ffd700');}
            else if(p.rarity==='epic'){doShake(5);addPart(p.x,p.y,'#cc44ff',8);spawnPop('💫 SLAM! -'+dmg,'#cc44ff');}
            else if(p.rarity==='rare'){const c=Math.random()<0.35;const fd=c?dmg*2:dmg;if(c){addPart(p.x,p.y,'#7dd3fc',6);spawnPop('💥 CRIT! -'+fd,'#7dd3fc');}hurtPL(fd);return;}
            hurtPL(dmg);
          }
        }
        const actualDmg=p.rarity==='epic'?bd+1:bd;
        _fireAtTarget(actualDmg);
        addPart(p.x,p.y,p.def.ability.color,p.def.ability.pc);
        // Splash: also hit other nearby target if close
        if(palAlive&&!tgtIsPal){const _apd2=Math.hypot(activePal.x-p.x,activePal.y-p.y);if(_apd2<p.def.ability.range*0.9)hurtActivePal(Math.max(1,Math.floor(bd*0.4)));}
        else if(!tgtIsPal&&!PL.dead){if(distPL<p.def.ability.range*0.9)hurtPL(Math.max(1,Math.floor(bd*0.4)));}
      }
    }

    // ── SPECIAL SKILL — only targets player (keeps existing behaviour) ──
    if(p.def.special&&!PL.dead&&_willFight){
      p.skCD=(p.skCD||9999)-dt;
      if(p.skCD<=0&&distPL<(p.def.special.range||70)&&Math.random()<0.26){
        p.skCD=p.def.special.cd+(Math.random()*1200-400);
        const sk=p.def.special;
        p._skT=420;p._skColor=sk.color;
        const sdmg=sk.dmg+(p.level>3?Math.floor(p.level/3):0)+(p.dmgBonus||0);
        hurtPL(sdmg);
        addPart(p.x,p.y,sk.color,sk.pc||8);
        for(let j=0;j<5;j++)addPart(p.x+(Math.random()-.5)*28,p.y+(Math.random()-.5)*28,sk.color,1);
        popAt((sk.emoji||'✨')+' '+sk.name+'!',sk.color,p.x,p.y-26);
        if(sk.effect==='shake'||sk.effect==='stun')doShake(sk.shake||5);
        if(sk.effect==='stun'&&PL.stunT<=0){PL.stunT=sk.stunTime||700;flashStun();}
        if(sk.effect==='slow'){PL._slowT=sk.slowTime||2500;PL._slowMult=sk.slowMult||0.45;}
        if(sk.effect==='multi'){const hits=sk.hits||3;for(let j=0;j<hits-1;j++){hurtPL(Math.max(1,Math.floor(sk.dmg*0.35)));addPart(p.x+(Math.random()-.5)*32,p.y+(Math.random()-.5)*32,sk.color,2);}}
      }
    }
  }
}
function killWild(p){
  if(p.dead)return;
  p.dead=true;p._deadT=0;playSnd('paldeath');addPart(p.x,p.y,'#ffcc44',8);addPart(p.x,p.y,'#ff4444',5);
  if(p.def.dropType){const qty=1+Math.floor(Math.random()*2);spawnDrop(p.def.dropType,qty,p.x,p.y);}
  // Raw meat drop — larger/rarer pals drop more often
  const meatChance=p.rarity==='epic'?.65:p.rarity==='rare'?.52:p.def.size>=14?.38:.25;
  if(Math.random()<meatChance){const qty=p.rarity==='epic'?2:1;spawnDrop('rawMeat',qty,p.x+(Math.random()-.5)*16,p.y+(Math.random()-.5)*16);}
  // ── ELITE / RARE PAL DROPS ──
  // Rare pals: small chance of crystal_shard, always some coins
  // Epic pals: guaranteed crystal_shard, often phoenix_feather
  // Legendary pals: guaranteed phoenix_feather + chance of dragon_horn + star dust
  if(p.rarity==='legendary'){
    spawnDrop('phoenix_feather',1+Math.floor(Math.random()*2),p.x-6,p.y);
    if(Math.random()<0.55)spawnDrop('dragon_horn',1,p.x+6,p.y);
    spawnDrop('star_dust',1+Math.floor(Math.random()*2),p.x,p.y-6);
    spawnDrop('coin',8+Math.floor(Math.random()*8),p.x,p.y+8);
    for(let _i=droppedItems.length-1;_i>=0&&_i>droppedItems.length-5;_i--){const _d=droppedItems[_i];if(_d&&['phoenix_feather','dragon_horn','star_dust'].includes(_d.type))_d.rare=true;}
    if(typeof showEventBanner==='function')showEventBanner('🌟 LEGENDARY '+p.def.name+' fell — rare drops!','#ffd700',3500);
  } else if(p.rarity==='epic'){
    spawnDrop('crystal_shard',1+Math.floor(Math.random()*2),p.x-6,p.y);
    if(Math.random()<0.45)spawnDrop('phoenix_feather',1,p.x+6,p.y);
    if(Math.random()<0.40)spawnDrop('star_dust',1,p.x,p.y-6);
    spawnDrop('coin',5+Math.floor(Math.random()*5),p.x,p.y+8);
    for(let _i=droppedItems.length-1;_i>=0&&_i>droppedItems.length-5;_i--){const _d=droppedItems[_i];if(_d&&['crystal_shard','phoenix_feather','star_dust'].includes(_d.type))_d.rare=true;}
  } else if(p.rarity==='rare'){
    if(Math.random()<0.45)spawnDrop('crystal_shard',1,p.x-6,p.y);
    if(Math.random()<0.30)spawnDrop('star_dust',1,p.x+6,p.y);
    spawnDrop('coin',2+Math.floor(Math.random()*4),p.x,p.y+8);
    for(let _i=droppedItems.length-1;_i>=0&&_i>droppedItems.length-3;_i--){const _d=droppedItems[_i];if(_d&&['crystal_shard','star_dust'].includes(_d.type))_d.rare=true;}
  } else if(Math.random()<0.45){
    // Even commons drop a coin or two sometimes
    spawnDrop('coin',1+Math.floor(Math.random()*2),p.x,p.y+8);
  }
  // Quest progression hook for "kill X rare pals" challenges
  if(typeof window!=='undefined'&&typeof window.__sideQuestKill==='function')window.__sideQuestKill(p);
  // Respawn timer: 20–35s — long enough to prevent respawn chains at the kill site
  const _respDelay=20000+Math.random()*15000;
  setTimeout(()=>{
    const aliveNow=wildPals.filter(w=>!w.dead).length;
    if(aliveNow<WILD_MAX&&aliveNow<WILD_MIN)spawnWild(1,'distributed');
  },_respDelay);
}
function drawWild(p){
  // FIX: skip NaN-position entities — canvas draws at NaN are silently dropped,
  // leaving the entity "invisible but still attacking" (the long-session ghost bug).
  if(!p||!isFinite(p.x)||!isFinite(p.y))return;
  if(p.dead){const a=Math.max(0,1-(p._deadT||0)/700);ctx.globalAlpha=a;const d=p.def,z=ZOOM,sz=d.size,sx2=wx(p.x),sy2=wy(p.y);drawPalBody(d,sz*0.8,sx2,sy2+8*z*a,z);ctx.globalAlpha=1;return;}
  const d=p.def,z=ZOOM,sz=d.size+(p.sizeBonus||0),sx2=wx(p.x),sy2=wy(p.y);
  if(!onScreen(p.x-sz*2,p.y-sz*2,sz*4,sz*4))return;
  const bob=Math.sin(Date.now()*.005+p.id*44)*1.2*z;
  // Rarity glow
  if(p.rarity==='legendary'){const t2=Date.now()*.0015;const gr=ctx.createRadialGradient(sx2,sy2+bob,0,sx2,sy2+bob,(sz+14)*z);gr.addColorStop(0,'rgba(255,215,0,.5)');gr.addColorStop(1,'rgba(255,170,0,0)');ctx.fillStyle=gr;ctx.beginPath();ctx.arc(sx2,sy2+bob,(sz+14)*z,0,Math.PI*2);ctx.fill();ctx.strokeStyle='rgba(255,215,0,.85)';ctx.lineWidth=2*z;ctx.beginPath();ctx.arc(sx2,sy2+bob,(sz+6)*z,0,Math.PI*2);ctx.stroke();for(let i=0;i<4;i++){const a=t2+i*Math.PI/2;ctx.fillStyle='rgba(255,215,0,.7)';ctx.beginPath();ctx.arc(sx2+Math.cos(a)*(sz+8)*z,sy2+bob+Math.sin(a)*(sz+8)*z,2*z,0,Math.PI*2);ctx.fill();}}
  else if(p.rarity==='epic'){const gr=ctx.createRadialGradient(sx2,sy2+bob,0,sx2,sy2+bob,(sz+8)*z);gr.addColorStop(0,'rgba(200,50,255,.35)');gr.addColorStop(1,'rgba(180,0,255,0)');ctx.fillStyle=gr;ctx.beginPath();ctx.arc(sx2,sy2+bob,(sz+8)*z,0,Math.PI*2);ctx.fill();}
  else if(p.rarity==='rare'){ctx.strokeStyle='rgba(100,180,255,.7)';ctx.lineWidth=2*z;ctx.beginPath();ctx.arc(sx2,sy2+bob,(sz+3)*z,0,Math.PI*2);ctx.stroke();}
  if(p.shakeT>0){const f=p.shakeT/200,sk=(Math.random()-.5)*4*f;ctx.save();ctx.translate(sk*z,0);}
  const _wl=palLunge(p);
  drawPalBody(d,sz,sx2+_wl.lx*z,sy2+bob+_wl.ly*z,z,p);
  drawPalFx(p,sx2+_wl.lx*z,sy2+bob+_wl.ly*z,sz,z);
  if(p.shakeT>0)ctx.restore();
  const hp=p.hp/p.maxHp;if(hp<1){ctx.fillStyle='#111';ctx.fillRect(sx2-sz*z,sy2-sz*z-8*z,sz*2*z,4*z);ctx.fillStyle=hp>.5?'#4aff60':hp>.25?'#fc0':'#f44';ctx.fillRect(sx2-sz*z,sy2-sz*z-8*z,Math.round(sz*2*z*hp),4*z);}
  const rarTag=p.rarity==='legendary'?'[LEGENDARY] ':p.rarity==='epic'?'[EPIC] ':p.rarity==='rare'?'[RARE] ':'';
  ctx.fillStyle='rgba(0,0,0,.6)';const tag=rarTag+d.name+' Lv'+p.level;ctx.font=Math.round(6.5*z)+'px Courier New';const tw=ctx.measureText(tag).width;ctx.fillRect(sx2-tw/2-2,sy2+bob-(sz+12)*z,tw+4,8*z);ctx.fillStyle=p.rarity==='legendary'?'#ffd700':p.rarity==='epic'?'#cc44ff':p.rarity==='rare'?'#7dd3fc':'#f87171';ctx.fillText(tag,sx2-tw/2,sy2+bob-(sz+5)*z);
}

// ═══════════════════════════════
// PROJECTILES
// ═══════════════════════════════
const projs=[];const MAX_PROJS=48;
function spawnProjFromPal(pal,target,dmg,splash,big){
  const dx=target.x-pal.x,dy=target.y-pal.y,dist=Math.hypot(dx,dy)||1;
  const spd=big?4.2:3.5;
  // src:'friendly_pal' → never hits player, only hits enemies (target-locked)
  projs.push({x:pal.x,y:pal.y,vx:dx/dist*spd,vy:dy/dist*spd,dmg,color:pal.def.ability.color,splash,big,src:'friendly_pal',target,targetId:target.id,life:2400,size:big?10:6});
}
function spawnSphere(x,y,tx,ty){
  const dx=tx-x,dy=ty-y,dist=Math.hypot(dx,dy)||1;
  projs.push({x,y,vx:dx/dist*5.5,vy:dy/dist*5.5,dmg:0,color:'#c084fc',splash:false,big:false,src:'player',life:1400,size:8,isSphere:true});
}
// Helper: apply pal-proj hit to a wild pal — returns true if hit registered
function _applyPalProjHit(p,wp){
  // Arena gate: pals can't damage a zone boss while player is outside its arena
  if(wp&&wp.isBoss&&typeof wp.zoneIdx==='number'&&typeof _canDamageBoss==='function'&&!_canDamageBoss(wp)){
    if(typeof _showArenaBlocked==='function')_showArenaBlocked();
    addPart(wp.x,wp.y,'#ff6644',2);
    return;
  }
  wp.hp=Math.max(0,wp.hp-p.dmg);wp.shakeT=200;addPart(wp.x,wp.y,p.color,p.big?7:3);
  if(wp.isBoss&&wp._calm)wp._calm=false;
  // Aggro switch: enemy now targets the pal that shot it
  if(activePal&&!activePal.fainted)wp.aggroId=activePal.id;
  _makeHostile(wp);
  // onHit status effects from pal special skills
  if(p.onHit==='stun'&&!(wp._stunT>0)){
    wp._stunT=p.stunTime||700;
    for(let _j=0;_j<7;_j++)addPart(wp.x+(Math.random()-.5)*20,wp.y+(Math.random()-.5)*20,'#88ddff',3);
    popAt('⚡ Stunned!','#88ddff',wp.x,wp.y-22);
  } else if(p.onHit==='slow'){
    wp._slowT=p.slowTime||2500;wp._slowMult=p.slowMult||0.42;
    addPart(wp.x,wp.y,'#aaddff',5);popAt('🌀 Slowed!','#aaddff',wp.x,wp.y-22);
  }
  if(p.splash){for(const wp2 of wildPals){if(wp2===wp||wp2.dead)continue;if(Math.hypot(wp2.x-wp.x,wp2.y-wp.y)<38){wp2.hp=Math.max(0,wp2.hp-Math.ceil(p.dmg/2));wp2.shakeT=120;if(activePal&&!activePal.fainted)wp2.aggroId=activePal.id;_makeHostile(wp2);}}}
  if(wp.hp<=0&&!wp.dead){const lv=wp.level;const ex=wp.x,ey=wp.y;killWild(wp);spawnPop('💨 Defeated!','#4aff78');questProg('kill');addStat('palsDefeated');const xpMult=wp.rarity==='legendary'?8:wp.rarity==='epic'?4:wp.rarity==='rare'?2:1;gainPlayerXP(lv*3*xpMult);popAt('+XP '+(lv*5*xpMult),(wp.rarity==='legendary'?'#ffd700':wp.rarity==='epic'?'#cc44ff':'#facc15'),ex,ey);const _ap=activePal;if(_ap){const _le=gainXP(_ap,lv*5+10);if(_le){spawnPop('⬆️ '+_ap.def.name+' Lv'+_ap.level+'!','#facc15');popAt('⬆ LEVEL UP!','#ffe066',_ap.x||ex,(_ap.y||ey)-20);addPart(_ap.x||ex,_ap.y||ey,'#ffe066',12);addPart(_ap.x||ex,_ap.y||ey,'#ffffff',6);if(typeof _ap.partyIdx==='number'&&partyPals[_ap.partyIdx]){partyPals[_ap.partyIdx].level=_ap.level;partyPals[_ap.partyIdx].xp=_ap.xp;partyPals[_ap.partyIdx].xpNeeded=_ap.xpNeeded;}playSnd('pop');}}}
  return true;
}
// ─── PAL SPECIAL SKILL (manual + auto) ───
function firePalSpecial(){
  if(!activePal||activePal.fainted||!activePal.def.special)return;
  if((activePal.skCD||0)>0)return;
  const p=activePal,sk=p.def.special;
  // Find nearest living enemy — unlimited range for manual trigger
  let tgt=null,bestD=Infinity;
  for(const e of _palAllEnemies()){if(e.dead)continue;const d=Math.hypot(p.x-e.x,p.y-e.y);if(d<bestD){bestD=d;tgt=e;}}
  if(!tgt){spawnPop('No target!','#aaa');return;}
  // Cooldown
  p.skCD=sk.cd+(Math.random()*600-300);
  p._skT=420;p._skColor=sk.color||p.def.ability.color;
  // Damage: base + level scaling + rarity bonus
  const pr=p.rarity||'common';
  const dmg=sk.dmg+Math.floor((p.level||1)/3)+(pr==='legendary'?5:pr==='epic'?3:pr==='rare'?1:0);
  // Particle burst at caster
  for(let j=0;j<12;j++)addPart(p.x+(Math.random()-.5)*26,p.y+(Math.random()-.5)*26,sk.color,3+Math.random()*4);
  popAt((sk.emoji||'✨')+' '+sk.name+'!',sk.color,p.x,p.y-26);
  playSnd('patatk');
  const dxT=tgt.x-p.x,dyT=tgt.y-p.y,dist=Math.hypot(dxT,dyT)||1;
  const vx=dxT/dist,vy=dyT/dist;
  if(sk.effect==='multi'){
    // Fan of projectiles
    const cnt=sk.hits||3,baseA=Math.atan2(dyT,dxT);
    for(let j=0;j<cnt;j++){
      const angle=baseA+(j-(cnt-1)/2)*0.30,spd=4.7;
      projs.push({x:p.x,y:p.y,vx:Math.cos(angle)*spd,vy:Math.sin(angle)*spd,dmg:Math.max(1,Math.ceil(dmg*0.72)),color:sk.color,splash:false,big:false,src:'friendly_pal',target:tgt,targetId:tgt.id,life:1900,size:8});
    }
  } else if(sk.effect==='shake'){
    // AoE explosion — damages all enemies in range + screen shake
    doShake(sk.shake||7);
    for(let j=0;j<18;j++)addPart(p.x+(Math.random()-.5)*54,p.y+(Math.random()-.5)*54,sk.color,4+Math.random()*5);
    for(const e of _palAllEnemies()){
      if(e.dead)continue;
      const d=Math.hypot(p.x-e.x,p.y-e.y);
      if(d<(sk.range||90)){
        e.hp=Math.max(0,e.hp-dmg);e.shakeT=350;e._stunT=Math.max(e._stunT||0,260);
        addPart(e.x,e.y,sk.color,7);
        if(e.hp<=0&&!e.dead&&wildPals.includes(e)){
          const lv=e.level,ex=e.x,ey=e.y;killWild(e);questProg('kill');addStat('palsDefeated');
          const xm=e.rarity==='legendary'?8:e.rarity==='epic'?4:e.rarity==='rare'?2:1;
          gainPlayerXP(lv*3*xm);popAt('+XP '+(lv*5*xm),(e.rarity==='legendary'?'#ffd700':e.rarity==='epic'?'#cc44ff':'#facc15'),ex,ey);
        }
      }
    }
  } else {
    // Single powerful bolt (stun / slow / default)
    const onHit=sk.effect==='stun'?'stun':sk.effect==='slow'?'slow':null;
    projs.push({x:p.x,y:p.y,vx:vx*5.3,vy:vy*5.3,dmg,color:sk.color,splash:sk.effect!=='stun',big:true,src:'friendly_pal',target:tgt,targetId:tgt.id,life:2500,size:14,onHit,stunTime:sk.stunTime||700,slowTime:sk.slowTime||2500,slowMult:sk.slowMult||0.42});
  }
}
// Update the pal skill button cooldown display
function _updPalSkBtn(){
  const btn=document.getElementById('pal-skill-btn');if(!btn)return;
  const cdEl=document.getElementById('pal-sk-cd'),lblEl=document.getElementById('pal-sk-label');
  const hasPal=!!(activePal&&!activePal.fainted&&activePal.def.special);
  btn.classList.toggle('no-pal',!hasPal);
  if(!hasPal){if(cdEl)cdEl.style.display='none';if(lblEl){lblEl.style.display='';lblEl.textContent='✨';}return;}
  const sk=activePal.def.special;
  if(lblEl)lblEl.textContent=sk.emoji||'✨';
  const skCD=activePal.skCD||0;
  if(skCD>0){
    if(cdEl){cdEl.textContent=Math.ceil(skCD/1000)+'s';cdEl.style.display='block';}
    if(lblEl)lblEl.style.display='none';
    btn.style.opacity='.52';btn.classList.remove('ready');btn.classList.add('on-cd');
  } else {
    if(cdEl)cdEl.style.display='none';
    if(lblEl)lblEl.style.display='block';
    btn.style.opacity='1';btn.classList.add('ready');btn.classList.remove('on-cd');
  }
}
function updProjs(dt){
  // Hard cap — evict oldest if bursts overflow MAX_PROJS
  if(projs.length>MAX_PROJS)projs.splice(0,projs.length-MAX_PROJS);
  for(let i=projs.length-1;i>=0;i--){
    const p=projs[i];p.x+=p.vx;p.y+=p.vy;p.life-=dt;
    if(p.life<=0){projs.splice(i,1);continue;}

    // ── ENEMY RANGED ATTACK (wild pal ranged, if ever added) ──
    if(p.src==='enemy'){
      if(!PL.dead&&Math.hypot(PL.x-p.x,PL.y-p.y)<14){hurtPL(p.dmg);addPart(PL.x,PL.y,p.color,p.big?6:3);projs.splice(i,1);}
      continue;
    }

    // ── CAPTURE SPHERE ──
    if(p.isSphere){
      let caught=false;
      for(const wp of wildPals){if(wp.dead)continue;if(Math.hypot(wp.x-p.x,wp.y-p.y)<wp.def.size*1.5){tryCatch(wp);projs.splice(i,1);caught=true;break;}}
      if(caught)continue;
      continue;
    }

    // ── FRIENDLY PAL PROJECTILE — never hits player ──
    if(p.src==='friendly_pal'){
      let hit=false;
      // 1) Check locked target first (most likely hit, cheapest check)
      const tgt=p.target;
      if(tgt&&!tgt.dead&&tgt.id===p.targetId){
        const hr=(tgt.def.size+(tgt.sizeBonus||0))*1.4+4;
        if(Math.hypot(tgt.x-p.x,tgt.y-p.y)<hr){
          // Boss pal targets
          if(bossPals.includes(tgt)){tgt.hp=Math.max(0,tgt.hp-p.dmg);tgt.shakeT=200;addPart(tgt.x,tgt.y,p.color,p.big?8:4);if(tgt.hp<=0&&!tgt.dead)killBoss(tgt);hit=true;}
          else{_applyPalProjHit(p,tgt);hit=true;}
        }
      }
      // 2) Broad sweep if target was already dead or out of range
      if(!hit){
        for(const wp of wildPals){if(wp.dead)continue;const hr=(wp.def.size+(wp.sizeBonus||0))*1.4+4;if(Math.hypot(wp.x-p.x,wp.y-p.y)<hr){_applyPalProjHit(p,wp);hit=true;break;}}
        if(!hit){for(const b of bossPals){if(b.dead)continue;if(Math.hypot(b.x-p.x,b.y-p.y)<b.def.size*1.8){b.hp=Math.max(0,b.hp-p.dmg);b.shakeT=200;addPart(b.x,b.y,p.color,p.big?8:4);if(b.hp<=0&&!b.dead)killBoss(b);hit=true;break;}}}
        if(!hit&&inDungeon){for(const e of dungeonEnemies){if(e.dead)continue;if(Math.hypot(e.x-p.x,e.y-p.y)<(e.def?.size||10)*1.4){e.hp=Math.max(0,e.hp-p.dmg);e.shakeT=160;addPart(e.x,e.y,p.color,4);hit=true;break;}}}
      }
      if(hit){projs.splice(i,1);}
      continue;
    }

    // ── PLAYER MELEE/RANGED (player-sourced non-sphere) — hits enemies only ──
    {
      let projHit=false;
      for(const wp of wildPals){if(wp.dead)continue;if(Math.hypot(wp.x-p.x,wp.y-p.y)<(wp.def.size+(wp.sizeBonus||0))*1.5){
        wp.hp=Math.max(0,wp.hp-p.dmg);wp.shakeT=200;addPart(wp.x,wp.y,p.color,p.big?7:3);
        if(wp.hp<=0&&!wp.dead){const lv=wp.level;const ex=wp.x,ey=wp.y;killWild(wp);spawnPop('💨 Defeated!','#4aff78');questProg('kill');addStat('palsDefeated');const xpMult=wp.rarity==='legendary'?8:wp.rarity==='epic'?4:wp.rarity==='rare'?2:1;gainPlayerXP(lv*3*xpMult);popAt('+XP '+(lv*5*xpMult),(wp.rarity==='legendary'?'#ffd700':wp.rarity==='epic'?'#cc44ff':'#facc15'),ex,ey);}
        projs.splice(i,1);projHit=true;break;
      }}
      if(!projHit){for(const b of bossPals){if(b.dead)continue;if(Math.hypot(b.x-p.x,b.y-p.y)<b.def.size*1.8){b.hp=Math.max(0,b.hp-p.dmg);b.shakeT=200;addPart(b.x,b.y,p.color,p.big?8:4);if(b.hp<=0&&!b.dead){killBoss(b);}projs.splice(i,1);projHit=true;break;}}}
      if(!projHit){for(const zb of _allZoneBosses()){if(Math.hypot(zb.x-p.x,zb.y-p.y)<zb.def.size*2.0){if(typeof _canDamageBoss==='function'&&!_canDamageBoss(zb)){if(typeof _showArenaBlocked==='function')_showArenaBlocked();projs.splice(i,1);projHit=true;break;}zb.hp=Math.max(0,zb.hp-p.dmg);zb.shakeT=200;addPart(zb.x,zb.y,p.color,p.big?10:5);if(zb._calm){zb._calm=false;}if(zb.hp<=0&&!zb.dead)killZoneBoss(zb);projs.splice(i,1);projHit=true;break;}}}
      void projHit;
    }
  }
}
function drawProjs(){
  for(const p of projs){
    if(!onScreen(p.x-12,p.y-12,24,24))continue;
    const z=ZOOM,r=(p.size||6)*z;
    ctx.fillStyle=p.color;ctx.globalAlpha=.85;ctx.beginPath();ctx.arc(wx(p.x),wy(p.y),r,0,Math.PI*2);ctx.fill();
    if(p.big){ctx.strokeStyle='#fff';ctx.lineWidth=1.5*z;ctx.beginPath();ctx.arc(wx(p.x),wy(p.y),r+1.5*z,0,Math.PI*2);ctx.stroke();}
    ctx.globalAlpha=1;
  }
}

// ═══════════════════════════════
// PLAYER
// ═══════════════════════════════
const PL={x:MAP_W/2,y:MAP_H/2,hp:20,maxHp:20,speed:1.9,dead:false,facing:'down',moving:false,aF:0,aT:0,invT:0,gatherCD:0,swT:0,level:1,xp:0,xpNeeded:60,stunT:0,hunger:100,maxHunger:100,_regenT:0,foodBuffT:0,foodBuffDmg:0};
function flashStun(){const el=document.getElementById('stun-flash');el.classList.add('show');setTimeout(()=>el.classList.remove('show'),900);}
let activeTool='axe';
const joy={ax:0,ay:0,active:false};

// Throttled biome check for "Enter Forest Zone" objective
let _forestCheckT=0;
function _checkForestObjective(dt){
  _forestCheckT-=dt;if(_forestCheckT>0)return;_forestCheckT=600;
  if(questIdx>=QUESTS.length||QUESTS[questIdx].key!=='enter_forest')return;
  const b=getBiomeAt(PL.x,PL.y);
  if(b===1)questProg('enter_forest');
}
function updPlayer(dt){
  _checkForestObjective(dt);
  // Tick arena warn timer + update arena edge glow visibility
  if(_arenaWarnT>0)_arenaWarnT=Math.max(0,_arenaWarnT-dt);
  _updArenaEdge();
  if(PL.dead)return;
  if(PL.invT>0)PL.invT=Math.max(0,PL.invT-dt);
  if(PL.gatherCD>0)PL.gatherCD=Math.max(0,PL.gatherCD-dt);
  if(PL.swT>0)PL.swT=Math.max(0,PL.swT-dt);
  if(PL.stunT>0){PL.stunT=Math.max(0,PL.stunT-dt);PL.moving=false;updateCamera(PL.x,PL.y);return;}
  if(PL._slowT>0){PL._slowT=Math.max(0,(PL._slowT||0)-dt);}
  const slowFactor=PL._slowT>0?(PL._slowMult||0.45):1;
  // ── HUNGER ──
  // Weather effect via helper: Rain slows drain, Storm/Heat speed it up; iron armor halves penalty
  const _wxCold=wxHungerMul();
  const _wxArmorSave=equipped.armor==='iron'?0.5:0;
  const _wxColdMul=_wxCold>1?(1+((_wxCold-1)*(1-_wxArmorSave))):_wxCold;
  PL.hunger=Math.max(0,PL.hunger-dt*0.00022*getSkillHungerMul()*_wxColdMul); // base ~75min full drain
  updHungerBar();
  // Food buff countdown
  if(PL.foodBuffT>0){PL.foodBuffT=Math.max(0,PL.foodBuffT-dt);document.getElementById('food-buff-label').classList.toggle('show',PL.foodBuffT>0);}
  // HP regen tick (every 6s at normal, 9s when hungry, 4s when full)
  const hungerRatio=PL.hunger/PL.maxHunger;
  const regenInterval=hungerRatio<0.25?9000:hungerRatio>0.75?4000:6000;
  if(PL.hp<PL.maxHp&&hungerRatio>0.1){
    PL._regenT=(PL._regenT||0)+dt;
    if(PL._regenT>=regenInterval){PL._regenT=0;PL.hp=Math.min(PL.maxHp,PL.hp+1);updHPBar();}
  }
  // ── STARVATION — slow HP drain, never below 1 ──
  if(PL.hunger<=0){
    PL._starvT=(PL._starvT||0)+dt;
    if(PL._starvT>=7000){PL._starvT=0;if(PL.hp>1){PL.hp=Math.max(1,PL.hp-1);updHPBar();spawnPop('😰 Starving! Eat food!','#f87171');}}
  }else{PL._starvT=0;}
  const spd=Math.min(getSkillMoveSpd(),3.8)*(joy.active?1:0)*slowFactor;
  if(spd>0){
    const rawX=joy.ax*spd,rawY=joy.ay*spd;
    const mag=Math.hypot(rawX,rawY);
    const dx=mag>spd?rawX/mag*spd:rawX,dy=mag>spd?rawY/mag*spd:rawY;
    moveWithColl(PL,dx,dy,14,12);
    if(Math.abs(dx)>.05||Math.abs(dy)>.05){
      PL.moving=true;PL.aT+=dt;if(PL.aT>150){PL.aF=(PL.aF+1)%4;PL.aT=0;}
      if(Math.abs(dx)>Math.abs(dy))PL.facing=dx>0?'right':'left';else PL.facing=dy>0?'down':'up';
    }else{PL.moving=false;}
  }else PL.moving=false;
  updateCamera(PL.x,PL.y);
  // Ruins loot
  if(_ruinLootCooldown>0)_ruinLootCooldown=Math.max(0,_ruinLootCooldown-dt);
  checkRuinLoot();
  // Update biome label
  const bId=getPlayerBiome();
  if(bId!==_lastBiomeId){
    const prev=_lastBiomeId;_lastBiomeId=bId;
    const bl=document.getElementById('biome-label');if(bl){bl.textContent=BIOMES[bId].name;const lc=bId===4||bId===7?'#ff4444':bId===6?'#88ccff':'#88ffcc';bl.style.color=lc;bl.style.textShadow=bId===4?'0 0 10px #ff0000':bId===7?'0 0 10px #ff4400':'none';}
    // Biome entry popup — only when actually entering a NEW region, with cooldown to stop border spam
    if(prev>=0&&bId!==_biomeNotifId&&_biomeNotifCD<=0){
      _biomeNotifId=bId;_biomeNotifCD=bId===4?18000:BIOME_NOTIF_CD;
      const msg=BIOME_ENTRY_MSGS[bId]||BIOMES[bId].name;
      const col=BIOME_ENTRY_COLORS[bId]||'#88ffcc';
      spawnPop(msg,col);
    }
  }
  if(_biomeNotifCD>0)_biomeNotifCD=Math.max(0,_biomeNotifCD-16);
  _curZone=getZoneType(PL.x,PL.y);
}

// ═══════════════════════════════
// COMBAT
// ═══════════════════════════════
// ── PAL REACTION HELPERS ──
// Broadcast a target enemy to nearby party/base pals so they assist.
function _palsAssistAttack(targetWp,fromX,fromY,radius){
  if(!targetWp||targetWp.dead)return;
  if(activePal&&!activePal.fainted){
    const d=Math.hypot(activePal.x-fromX,activePal.y-fromY);
    if(d<radius){activePal._lockEnemy=targetWp;activePal._lockT=4500;activePal.aggroId=targetWp.id||1;}
  }
  const pb=getPB();
  if(pb){
    const inBase=Math.hypot(targetWp.x-pb.x,targetWp.y-pb.y)<BASE_RADIUS;
    if(inBase){for(const bp of basePals){if(!bp||!bp.def)continue;bp._defTarget={x:targetWp.x,y:targetWp.y};bp._lockEnemy=targetWp;bp._lockT=4000;}}
  }
}
function doAttack(){
  if(PL.dead||PL.swT>0)return;
  PL.swT=Math.max(180,500-getSkillAtkCDReduction());
  playSnd('atk');
  const dmgBase=1+weaponDmgBonus()+getSkillDmgBonus()+(PL.foodBuffT>0?(PL.foodBuffDmg||0):0);
  let hitAny=false;
  for(const wp of wildPals){
    if(wp.dead)continue;
    const d=Math.hypot(wp.x-PL.x,wp.y-PL.y);
    if(d<52+(wp.def.size+(wp.sizeBonus||0))){
      const dmg=dmgBase+Math.floor(Math.random()*2);
      wp.hp=Math.max(0,wp.hp-dmg);wp.shakeT=280;addPart(wp.x,wp.y,'#f44',4);spawnPop('⚔ -'+dmg,'#f44');hitAny=true;
      wp.aggroId='PLAYER';_makeHostile(wp);
      _palsAssistAttack(wp,PL.x,PL.y,360);
      if(wp.hp<=0&&!wp.dead){const lv=wp.level;const ex=wp.x,ey=wp.y;killWild(wp);spawnPop('💨 Defeated!','#4aff78');questProg('kill');addStat('palsDefeated');const xpMult=wp.rarity==='legendary'?8:wp.rarity==='epic'?4:wp.rarity==='rare'?2:1;gainPlayerXP(lv*3*xpMult);popAt('+XP '+(lv*5*xpMult),(wp.rarity==='legendary'?'#ffd700':wp.rarity==='epic'?'#cc44ff':'#facc15'),ex,ey);}
    }
  }
  for(const b of bossPals){
    if(b.dead)continue;
    const d=Math.hypot(b.x-PL.x,b.y-PL.y);
    if(d<60+b.def.size){
      const dmg=dmgBase+Math.floor(Math.random()*2);
      b.hp=Math.max(0,b.hp-dmg);b.shakeT=280;addPart(b.x,b.y,'#f44',6);spawnPop('⚔ BOSS -'+dmg,'#ff6644');hitAny=true;
      if(b.hp<=0&&!b.dead){killBoss(b);}
    }
  }
  // Zone bosses — must be inside arena to deal damage (no outside-cheese)
  for(const zb of _allZoneBosses()){
    const d=Math.hypot(zb.x-PL.x,zb.y-PL.y);
    if(d<60+zb.def.size){
      if(!_canDamageBoss(zb)){_showArenaBlocked();continue;}
      const dmg=dmgBase+Math.floor(Math.random()*2);
      zb.hp=Math.max(0,zb.hp-dmg);zb.shakeT=280;addPart(zb.x,zb.y,'#f44',8);spawnPop('⚔ ZONE BOSS -'+dmg,'#ff6644');hitAny=true;
      // Hitting a calm boss wakes it up
      if(zb._calm){zb._calm=false;spawnPop('⚠ BOSS AWAKENED','#ff4444');}
      if(zb.hp<=0&&!zb.dead)killZoneBoss(zb);
    }
  }
  // Dungeon enemies
  if(inDungeon){
    for(const e of dungeonEnemies){
      if(e.dead)continue;
      const d=Math.hypot(e.x-PL.x,e.y-PL.y);
      if(d<52+e.def.size){const dmg=dmgBase+Math.floor(Math.random()*2);hurtDungeonEnemy(e,dmg);hitAny=true;}
    }
    if(dungeonBossObj&&!dungeonBossObj.dead){
      const d=Math.hypot(dungeonBossObj.x-PL.x,dungeonBossObj.y-PL.y);
      if(d<60+DUNGEON_BOSS_DEF.size){const dmg=dmgBase+Math.floor(Math.random()*2);hurtDungeonBoss(dmg);hitAny=true;}
    }
  }
  if(hitAny){lightShake(3);doHitStop(40);if(typeof wearWeapon==='function')wearWeapon();}
}
function doGather(){
  if(PL.dead||PL.gatherCD>0)return;
  const obj=nearestObj(PL.x,PL.y);
  if(!obj)return;
  const def=OBJ_DEF[obj.type];
  if(activeTool!==def.tool){spawnPop('Need '+def.tool,'#f87');return;}
  if(typeof toolBlocked==='function'&&toolBlocked(def.tool)){spawnPop('🛠️ '+def.tool[0].toUpperCase()+def.tool.slice(1)+' is broken! Repair it','#f87171');PL.gatherCD=300;return;}
  PL.gatherCD=getGatherCD();hitObject(obj);
  if(obj.type==='tree'){playSnd('wood');obj.hp--;if(typeof wearTool==='function')wearTool('axe');if(obj.hp<=0){const a=2+Math.floor(Math.random()*2)+getSkillHarvestBonus()+(typeof wxHarvestBonus==='function'?wxHarvestBonus('wood'):0);iAdd(playerInv,'wood',a);addPart(obj.x,obj.y,'#5c3d1e',6);objects.splice(objects.indexOf(obj),1);popAt('+'+a+'🪵','#5c3d1e',obj.x,obj.y);updResUI();questProg('wood',a);addStat('woodCollected',a);gainPlayerXP(2);}}
  else if(obj.type==='stone'){playSnd('stone');obj.hp--;if(typeof wearTool==='function')wearTool('pickaxe');if(obj.hp<=0){const a=1+Math.floor(Math.random()*2)+getSkillHarvestBonus()+(typeof wxHarvestBonus==='function'?wxHarvestBonus('stone'):0);iAdd(playerInv,'stone',a);addPart(obj.x,obj.y,'#9aa4b4',5);objects.splice(objects.indexOf(obj),1);popAt('+'+a+'🪨','#9aa4b4',obj.x,obj.y);updResUI();questProg('stone',a);addStat('stoneCollected',a);gainPlayerXP(2);}}
  else if(obj.type==='copper'){playSnd('copper');obj.hp--;if(typeof wearTool==='function')wearTool('pickaxe');if(obj.hp<=0){const a=1+getSkillHarvestBonus()+(typeof wxHarvestBonus==='function'?wxHarvestBonus('copper'):0);iAdd(playerInv,'copper',a);addPart(obj.x,obj.y,'#c87820',4);objects.splice(objects.indexOf(obj),1);popAt('+'+a+'🟠','#c87820',obj.x,obj.y);updResUI();addStat('copperCollected',a);gainPlayerXP(3);}}
  else if(obj.type==='coal'){playSnd('stone');obj.hp--;if(typeof wearTool==='function')wearTool('pickaxe');if(obj.hp<=0){const a=1+Math.floor(Math.random()*2)+Math.floor(getSkillHarvestBonus()/2)+(typeof wxHarvestBonus==='function'?wxHarvestBonus('coal'):0);iAdd(playerInv,'coal',a);addPart(obj.x,obj.y,'#444',5);objects.splice(objects.indexOf(obj),1);popAt('+'+a+'⬛','#888',obj.x,obj.y);updResUI();gainPlayerXP(3);}}
  // Assign active pal to finish this resource if it's still alive and pal has helperType
  if(activePal&&!activePal.fainted&&objects.includes(obj)){
    const ht=activePal.def.helperType;
    const matches=(ht==='wood'&&obj.type==='tree')||(ht==='stone'&&obj.type==='stone')||(ht==='stone_copper'&&(obj.type==='stone'||obj.type==='copper'));
    if(matches&&(!activePal.palTask||activePal.palTask.obj!==obj)){
      activePal.palTask={type:'resource',obj};activePal._switchT=300;
      spawnPop(activePal.def.emoji+' assigned to gather!','#4aff78');
    }
  }
  // Base pals near the resource also assist if it's inside base radius
  const _pb=getPB();
  if(_pb&&objects.includes(obj)&&Math.hypot(obj.x-_pb.x,obj.y-_pb.y)<BASE_RADIUS){
    for(const bp of basePals){if(!bp||!bp.def)continue;const ht=bp.def.helperType;const ok=(ht==='wood'&&obj.type==='tree')||(ht==='stone'&&obj.type==='stone')||(ht==='stone_copper'&&(obj.type==='stone'||obj.type==='copper'));if(!ok)continue;if(Math.hypot(bp.x-obj.x,bp.y-obj.y)<260){bp._resTarget=obj;bp._resT=4000;}}
  }
}

// Action button — interact with structure, attack if sword mode, else gather
function doActionBtn(){
  if(PL.dead)return;
  // Dungeon exit
  if(inDungeon&&dungeonPhase===3){exitDungeon();return;}
  // Dungeon gate entry
  if(!inDungeon){const g=nearestDungeonGate(PL.x,PL.y);if(g){enterDungeon(g);return;}}
  const st=nearestStruct(PL.x,PL.y);
  if(st){if(st.type==='craftTable'){openCraftOverlay();return;}if(st.type==='chest'){openChestOverlay(st);return;}if(st.type==='palbox'){openPBUI();return;}if(st.type==='campfire'){openCampfireOverlay();return;}if(st.type==='repair_bench'){openRepairOverlay();return;}}
  if(activeTool==='sword'){doAttack();}
  else if(activeTool==='axe'||activeTool==='pickaxe'){doGather();}
  else{doAttack();}
}
document.getElementById('action-btn').addEventListener('click',doActionBtn);
document.getElementById('action-btn').addEventListener('touchstart',e=>{e.preventDefault();doActionBtn();},{passive:false});

// Tool switch — cycle axe → pickaxe → sword (if equipped) → axe
let _lastSwitch=0;
function cycleTool(){
  const now=Date.now();if(now-_lastSwitch<200)return;_lastSwitch=now;
  const hasSword=!!equipped.weapon;
  if(activeTool==='axe')activeTool='pickaxe';
  else if(activeTool==='pickaxe')activeTool=hasSword?'sword':'axe';
  else activeTool='axe';
  const icon=activeTool==='axe'?'🪓':activeTool==='pickaxe'?'⛏':WEAPON_EMOJI[equipped.weapon]||'🗡️';
  document.getElementById('switch-btn').textContent=icon;
  const label=activeTool==='axe'?'🪓 Axe':activeTool==='pickaxe'?'⛏ Pickaxe':(WEAPON_EMOJI[equipped.weapon]||'🗡️')+' Sword';
  spawnPop(label,'#4aff78');
}
document.getElementById('switch-btn').addEventListener('click',cycleTool);
document.getElementById('switch-btn').addEventListener('touchstart',e=>{e.preventDefault();cycleTool();},{passive:false});

// Capture button
let _capCD=0;
function calcCaptureChance(wp,sphereBonus){
  const hp_pct=Math.max(0,wp.hp/wp.maxHp);
  // HP-based base chance
  let base;
  if(hp_pct>0.8)base=0.02;
  else if(hp_pct>0.6)base=0.05;
  else if(hp_pct>0.4)base=0.10;
  else if(hp_pct>0.2)base=0.20;
  else base=0.42;
  // Skill: Capture Boost adds flat bonus on top of base.
  base+=getSkillCaptureBonus();
  // Rarity multiplier
  const RARITY_MOD={legendary:0.25,epic:0.50,rare:0.70,common:1.0};
  const rMod=RARITY_MOD[wp.rarity||'common']||1.0;
  // Player level bonus (capped at +15%)
  const lvlBonus=Math.min(PL.level*0.01,0.15);
  // Final (clamped)
  return Math.min(0.95,Math.max(0.01,(base+lvlBonus+(sphereBonus||0))*rMod));
}
// ═══════════════════════════════
// SPHERE SWITCHER
// ═══════════════════════════════
const SPHERE_MODES=[
  {key:'auto',label:'AUTO'},
  {key:'sphere',label:'🔮 Basic',type:'sphere',bonus:0,emoji:'🔮'},
  {key:'adv_sphere',label:'💠 Adv',type:'adv_sphere',bonus:0.15,emoji:'💠'},
  {key:'ultra_sphere',label:'🌀 Ultra',type:'ultra_sphere',bonus:0.30,emoji:'🌀'},
];
let _sphereModeIdx=0;
// Friendly long labels for the new arrow row
const _SPHERE_LONG_LABELS={auto:'AUTO',sphere:'BASIC 🔮',adv_sphere:'ADV 💠',ultra_sphere:'ULTRA 🌀'};
function _updSphereLabel(){
  const m=SPHERE_MODES[_sphereModeIdx];
  const txt=_SPHERE_LONG_LABELS[m.key]||m.label;
  const lbl=document.getElementById('sphere-label');if(lbl)lbl.textContent=txt;
  const old=document.getElementById('sphere-switcher');if(old)old.textContent=m.label;
}
function cycleSphere(dir){
  const d=(typeof dir==='number')?dir:1;
  _sphereModeIdx=(_sphereModeIdx+d+SPHERE_MODES.length)%SPHERE_MODES.length;
  _updSphereLabel();
  spawnPop('Sphere: '+(_SPHERE_LONG_LABELS[SPHERE_MODES[_sphereModeIdx].key]||SPHERE_MODES[_sphereModeIdx].label),'#c084fc');
}
(function(){
  const prev=document.getElementById('sphere-prev'),next=document.getElementById('sphere-next');
  if(prev){prev.addEventListener('click',e=>{e.stopPropagation();cycleSphere(-1);});prev.addEventListener('touchstart',e=>{e.preventDefault();e.stopPropagation();cycleSphere(-1);},{passive:false});}
  if(next){next.addEventListener('click',e=>{e.stopPropagation();cycleSphere(1);});next.addEventListener('touchstart',e=>{e.preventDefault();e.stopPropagation();cycleSphere(1);},{passive:false});}
  const lbl=document.getElementById('sphere-label');
  if(lbl){lbl.addEventListener('click',e=>{e.stopPropagation();cycleSphere(1);});lbl.addEventListener('touchstart',e=>{e.preventDefault();e.stopPropagation();cycleSphere(1);},{passive:false});}
  // Legacy fallback if old element still exists
  const btn=document.getElementById('sphere-switcher');
  if(btn){btn.addEventListener('click',()=>cycleSphere(1));btn.addEventListener('touchstart',e=>{e.preventDefault();cycleSphere(1);},{passive:false});}
  _updSphereLabel();
})();
function getActiveSphere(inv){
  const m=SPHERE_MODES[_sphereModeIdx];
  if(m.key==='auto'){
    if(inv.ultraSpheres>0)return{type:'ultra_sphere',bonus:0.30,emoji:'🌀'};
    if(inv.advSpheres>0)return{type:'adv_sphere',bonus:0.15,emoji:'💠'};
    if(inv.spheres>0)return{type:'sphere',bonus:0,emoji:'🔮'};
    return null;
  }
  const qty=inv[m.type==='sphere'?'spheres':m.type==='adv_sphere'?'advSpheres':'ultraSpheres']||0;
  if(qty<=0){
    if(inv.ultraSpheres>0)return{type:'ultra_sphere',bonus:0.30,emoji:'🌀'};
    if(inv.advSpheres>0)return{type:'adv_sphere',bonus:0.15,emoji:'💠'};
    if(inv.spheres>0)return{type:'sphere',bonus:0,emoji:'🔮'};
    return null;
  }
  return{type:m.type,bonus:m.bonus,emoji:m.emoji};
}
// ═══════════════════════════════
// CAMPFIRE BATCH COOKING QUEUE
// ═══════════════════════════════
const _cfQ={queue:0,cooking:false,tickId:null,progress:0,cooked:0};
let _cfQty=1;

function _cfMaxQty(){
  const rawMeat=playerInv.find(i=>i&&i.type==='rawMeat');
  const coal=playerInv.find(i=>i&&i.type==='coal');
  return Math.min(rawMeat?rawMeat.qty:0,coal?coal.qty:0);
}
function _cfClampQty(){
  const mx=Math.max(1,_cfMaxQty());
  if(_cfQty<1)_cfQty=1;
  if(_cfQty>mx)_cfQty=mx;
}
function _cfUpdQtyUI(){
  const el=document.getElementById('cf-qty-val');
  if(el)el.textContent=String(_cfQty);
}
function refreshCampfireUI(){
  const rawM=iCount(playerInv,'rawMeat'),coal=iCount(playerInv,'coal');
  const cooked=iCount(playerInv,'cookedMeat'),mush=iCount(playerInv,'mushroom');
  const berr=iCount(playerInv,'berry'),soup=iCount(playerInv,'mushroomSoup');
  const strip=document.getElementById('cf-res-strip');
  if(strip)strip.innerHTML='<span>🥩 '+rawM+'</span><span>⬛ '+coal+'</span><span>🍖 '+cooked+'</span><span>🍄 '+mush+'</span><span>🍓 '+berr+'</span><span>🍲 '+soup+'</span>';
  _cfClampQty();_cfUpdQtyUI();
  const canAdd=_cfMaxQty()>=1;
  const cookBtn=document.getElementById('cf-cook-btn');
  if(cookBtn)cookBtn.disabled=!canAdd;
  const qEl=document.getElementById('cf-queue-display');
  if(qEl)qEl.textContent=_cfQ.queue>0?'⏳ Cooking: '+_cfQ.queue+' left':'';
  _cfRefreshSoupUI();
}

function _cfCookTick(){
  if(_cfQ.queue<=0){_cfQ.cooking=false;_cfQ.progress=0;_cfCookUI();return;}
  // Rain/storm slows campfire cooking (wet wood)
  const COOK_MS=(WX.state==='Storm'&&WX.alpha>0.3)?4500:(WX.state==='Rain'&&WX.alpha>0.3)?3000:2000;
  const step=100;
  _cfQ.progress+=step;
  _cfCookUI();
  if(_cfQ.progress>=COOK_MS){
    _cfQ.progress=0;
    _cfQ.queue--;
    _cfQ.cooked++;
    iAdd(playerInv,'cookedMeat',1);updResUI();
    if(_cfQ.queue>0){_cfQ.tickId=setTimeout(_cfCookTick,step);}
    else{
      _cfQ.cooking=false;
      spawnPop('🍖 Batch done! +'+_cfQ.cooked+' Cooked Meat','#4aff78');
      _cfQ.cooked=0;
    }
    _cfCookUI();refreshCampfireUI();
  }else{
    _cfQ.tickId=setTimeout(_cfCookTick,step);
  }
}
function _cfCookUI(){
  const COOK_MS=2000;
  const statusEl=document.getElementById('cook-status');
  const barEl=document.getElementById('cook-progress-bar');
  const qEl=document.getElementById('cf-queue-display');
  if(_cfQ.cooking&&_cfQ.queue>0){
    if(statusEl)statusEl.textContent='🔥 Cooking… ('+ _cfQ.queue+' left in queue)';
    if(barEl)barEl.style.width=((_cfQ.progress/COOK_MS)*100)+'%';
    if(qEl)qEl.textContent='⏳ Queue: '+_cfQ.queue+' — you can close this and explore!';
  }else{
    if(statusEl)statusEl.textContent=_cfQ.queue<=0?'✅ Queue empty — add more to cook':'';
    if(barEl)barEl.style.width='0%';
    if(qEl)qEl.textContent='';
  }
}

function _cfAddToQueue(){
  _cfClampQty();
  const n=_cfQty;
  const rawMeat=playerInv.find(i=>i&&i.type==='rawMeat');
  const coal=playerInv.find(i=>i&&i.type==='coal');
  const avail=Math.min(rawMeat?rawMeat.qty:0,coal?coal.qty:0);
  if(avail<1){spawnPop('Need 🥩 Raw Meat + ⬛ Coal','#f60');return;}
  const actual=Math.min(n,avail);
  iRemove(playerInv,'rawMeat',actual);iRemove(playerInv,'coal',actual);updResUI();
  _cfQ.queue+=actual;
  spawnPop('+'+actual+' items added to cooking queue 🔥','#fb923c');
  if(!_cfQ.cooking){_cfQ.cooking=true;_cfQ.progress=0;_cfQ.cooked=0;if(_cfQ.tickId)clearTimeout(_cfQ.tickId);_cfQ.tickId=setTimeout(_cfCookTick,100);}
  _cfQty=1;refreshCampfireUI();_cfCookUI();
}

function _cfBrewSoup(){
  const mush=iCount(playerInv,'mushroom'),berr=iCount(playerInv,'berry');
  if(mush<5||berr<10){spawnPop('Need 5🍄 + 10🍓 to brew!','#f87171');return;}
  iRemove(playerInv,'mushroom',5);iRemove(playerInv,'berry',10);
  iAdd(playerInv,'mushroomSoup',1);updResUI();
  spawnPop('🍲 Mushroom Soup brewed!','#86efac');
  addPart(PL.x,PL.y,'#86efac',5);
  refreshCampfireUI();
}
function _cfRefreshSoupUI(){
  const mush=iCount(playerInv,'mushroom'),berr=iCount(playerInv,'berry');
  const stockEl=document.getElementById('cf-soup-stock');
  if(stockEl)stockEl.textContent='🍄 '+mush+' · 🍓 '+berr;
  const btn=document.getElementById('cf-soup-btn');
  if(btn)btn.disabled=(mush<5||berr<10);
}
function openCampfireOverlay(){
  _cfQty=1;refreshCampfireUI();_cfCookUI();
  document.getElementById('campfire-overlay').classList.add('show');
  gamePaused=true;
}
function closeCampfireOverlay(){document.getElementById('campfire-overlay').classList.remove('show');gamePaused=false;}
document.getElementById('campfire-close').addEventListener('click',closeCampfireOverlay);
document.getElementById('cf-cook-btn').addEventListener('click',_cfAddToQueue);
document.getElementById('cf-qty-dn').addEventListener('click',()=>{_cfQty--;_cfClampQty();_cfUpdQtyUI();});
document.getElementById('cf-qty-up').addEventListener('click',()=>{_cfQty++;_cfClampQty();_cfUpdQtyUI();});
document.getElementById('cf-qty-max').addEventListener('click',()=>{_cfQty=Math.max(1,_cfMaxQty());_cfUpdQtyUI();});
// Soup button — static HTML, wire up once
(function(){const sb=document.getElementById('cf-soup-btn');if(!sb)return;sb.addEventListener('click',_cfBrewSoup);sb.addEventListener('touchstart',e=>{e.preventDefault();_cfBrewSoup();},{passive:false});})();
document.getElementById('capture-btn').addEventListener('click',()=>{
  if(PL.dead)return;
  if(Date.now()<_capCD){spawnPop('⏳ Reloading…','#888');return;}
  // Pick sphere using switcher
  const picked=getActiveSphere(inv);
  let sphereType,sphereBonus,sphereEmoji;
  if(!picked){spawnPop('No spheres! Craft 🔮 at craft table','#a855f7');return;}
  sphereType=picked.type;sphereBonus=picked.bonus;sphereEmoji=picked.emoji;
  // Find nearest wild pal
  let closest=null,cdist=Infinity;
  for(const wp of wildPals){if(wp.dead)continue;const d=Math.hypot(wp.x-PL.x,wp.y-PL.y);if(d<220&&d<cdist){cdist=d;closest=wp;}}
  if(!closest){spawnPop('No pal nearby','#888');return;}
  // Legendary hard block at high HP
  if((closest.rarity==='legendary')&&closest.hp/closest.maxHp>0.30){
    spawnPop('💀 '+closest.def.name+' is too powerful! Lower HP first (<30%)','#ffd700');return;}
  iRemove(playerInv,sphereType,1);updResUI();playSnd('throw');
  _capCD=Date.now()+800;
  // Show chance preview popup
  const pct=calcCaptureChance(closest,sphereBonus);
  const label=pct>=0.30?'🎯 HIGH Chance':pct>=0.12?'🎯 MED Chance':'🎯 LOW Chance';
  const col=pct>=0.30?'#4aff78':pct>=0.12?'#facc15':'#f87171';
  setTimeout(()=>spawnPop(sphereEmoji+' '+label+' ('+Math.round(pct*100)+'%)',col),110);
  closest._sphereBonus=sphereBonus;
  spawnSphere(PL.x,PL.y,closest.x,closest.y);
  document.getElementById('capture-btn').style.opacity=inv.anyBalls>0?'1':'.38';
});
document.getElementById('capture-btn').addEventListener('touchstart',e=>{e.preventDefault();document.getElementById('capture-btn').click();},{passive:false});

function tryCatch(wp){
  const sphereBonus=wp._sphereBonus||0;
  delete wp._sphereBonus;
  const chance=calcCaptureChance(wp,sphereBonus);
  addPart(wp.x,wp.y,'#c084fc',8);
  if(Math.random()<chance){
    // SUCCESS
    killWild(wp);
    const _palCaptMxHp=wp.def.baseHp+(wp.level||1)*2;const palObj={def:wp.def,level:wp.level||1,xp:wp.xp||0,xpNeeded:wp.xpNeeded||xpToNext(wp.level||1),rarity:wp.rarity||'common',maxHp:_palCaptMxHp,hp:_palCaptMxHp};
    const partySlot=partyPals.findIndex(p=>p===null);
    if(partySlot>=0){partyPals[partySlot]=palObj;spawnPop('✅ '+wp.def.name+' → Party!','#4aff78');}
    else{const fb=firstEmptyBox();while(boxPals.length<=fb)boxPals.push(null);boxPals[fb]=palObj;spawnPop('✅ '+wp.def.name+' → Pal Box!','#a855f7');}
    playSnd('pop');questProg('capture');addStat('palsCaptured');
    if(typeof markCaptured==='function')markCaptured(wp.def.name);
    gainPlayerXP((wp.level||1)*5);
    refreshPartyBar();refreshPBUI();saveGame();
  }else{
    // FAIL — pal shakes and escapes
    spawnPop('💨 '+wp.def.name+' Escaped!','#f87171');
    wp.shakeT=500;
    hurtWild(wp,Math.ceil(wp.maxHp*0.06));
  }
  document.getElementById('capture-btn').style.opacity=inv.anyBalls>0?'1':'.38';
}
function hurtWild(wp,d){wp.hp=Math.max(0,wp.hp-d);wp.shakeT=200;addPart(wp.x,wp.y,'#f44',3);}

// ═══════════════════════════════
// PLAYER DRAWING
// ═══════════════════════════════
function flashHitScreen(){const el=document.getElementById('hit-flash');el.classList.add('show');setTimeout(()=>el.classList.remove('show'),100);}
function hurtPL(d){if(PL.dead||PL.invT>0)return;PL.hp=Math.max(0,PL.hp-d);PL.invT=1200;playSnd('hit');doShake(4);flashHitScreen();updHPBar();spawnPop('💔 -'+d,'#f44');if(typeof wearArmor==='function')wearArmor();if(PL.hp<=0){killPL();return;}
  // PAL DEFENSE REACTION — find closest hostile near player and rally pals
  let atk=null,bd=Infinity;
  for(const wp of wildPals){if(!wp||wp.dead)continue;const dd=Math.hypot(wp.x-PL.x,wp.y-PL.y);if(dd<260&&dd<bd){bd=dd;atk=wp;}}
  if(atk)_palsAssistAttack(atk,PL.x,PL.y,420);
}
function updHPBar(){const p=PL.hp/PL.maxHp;document.getElementById('hp-bar-inner').style.width=(p*100)+'%';document.getElementById('hp-bar-inner').style.background=p>.5?'linear-gradient(90deg,#f44,#f86)':p>.25?'linear-gradient(90deg,#f80,#fa0)':'linear-gradient(90deg,#c00,#f44)';}
function updHungerBar(){const p=Math.max(0,PL.hunger)/PL.maxHunger;const el=document.getElementById('hunger-bar-inner');el.style.width=(p*100)+'%';el.style.background=p>.5?'linear-gradient(90deg,#f97316,#fbbf24)':p>.25?'linear-gradient(90deg,#ea580c,#f97316)':'linear-gradient(90deg,#c2410c,#ea580c)';}
function eatFood(type){
  if(type==='rawMeat'){spawnPop('🥩 Raw Meat is uncooked!','#f87171');return;}
  if(type==='berry'){
    if(!iRemove(playerInv,'berry',1)){spawnPop('No berries!','#888');return;}
    PL.hunger=Math.min(PL.maxHunger,PL.hunger+8);
    PL.hp=Math.min(PL.maxHp,PL.hp+2);
    updHPBar();updHungerBar();updResUI();
    spawnPop('🍓 +8 Hunger  +2 HP','#e85d8a');
    addPart(PL.x,PL.y,'#e85d8a',4);return;
  }
  if(type==='mushroom'){
    if(!iRemove(playerInv,'mushroom',1)){spawnPop('No mushrooms!','#888');return;}
    PL.hunger=Math.min(PL.maxHunger,PL.hunger+12);
    PL.hp=Math.min(PL.maxHp,PL.hp+4);
    updHPBar();updHungerBar();updResUI();
    spawnPop('🍄 +12 Hunger  +4 HP','#d8b4fe');
    addPart(PL.x,PL.y,'#d8b4fe',4);return;
  }
  if(type==='mushroomSoup'){
    if(!iRemove(playerInv,'mushroomSoup',1)){spawnPop('No soup!','#888');return;}
    PL.hunger=PL.maxHunger;
    PL.hp=Math.min(PL.maxHp,PL.hp+25);
    updHPBar();updHungerBar();updResUI();
    spawnPop('🍲 Mushroom Soup! Full Hunger + Strong Heal!','#86efac');
    addPart(PL.x,PL.y,'#86efac',6);
    // 30-second HP regen: +2 HP every 2s (up to +30 HP)
    if(PL._soupRegen)clearInterval(PL._soupRegen);
    let _regenTicks=15;
    PL._soupRegen=setInterval(()=>{
      if(_regenTicks<=0||PL.dead||PL.hp>=PL.maxHp){clearInterval(PL._soupRegen);PL._soupRegen=null;return;}
      PL.hp=Math.min(PL.maxHp,PL.hp+2);updHPBar();_regenTicks--;
    },2000);
    return;
  }
  if(type!=='cookedMeat')return;
  if(!iRemove(playerInv,type,1)){spawnPop('No food!','#888');return;}
  // Restore hunger and HP
  const hungerGain=35,hpGain=4;
  PL.hunger=Math.min(PL.maxHunger,PL.hunger+hungerGain);
  PL.hp=Math.min(PL.maxHp,PL.hp+hpGain);
  updHPBar();updHungerBar();updResUI();
  // Apply damage buff for 20 seconds
  PL.foodBuffT=20000;PL.foodBuffDmg=1;
  document.getElementById('food-buff-label').textContent='⚡+1 DMG ('+Math.ceil(PL.foodBuffT/1000)+'s)';
  document.getElementById('food-buff-label').classList.add('show');
  spawnPop('🍖 Ate! +'+hpGain+'HP +Hunger ⚡Buff!','#4ade80');
  addPart(PL.x,PL.y,'#4ade80',5);
}
function plXpToNext(level){return Math.floor(60*Math.pow(1.5,level-1));}
function updPlayerXPBar(){const pct=Math.min(1,PL.xp/PL.xpNeeded);document.getElementById('xp-bar-inner').style.width=(pct*100)+'%';document.getElementById('plvl-label').textContent='LV.'+PL.level;}
function gainPlayerXP(amount){if(!amount||amount<=0)return;PL.xp+=amount;if(PL.xp>=PL.xpNeeded){PL.xp-=PL.xpNeeded;PL.level++;PL.xpNeeded=plXpToNext(PL.level);PL.maxHp+=2;PL.hp=PL.maxHp;updHPBar();PlayerSkills.points++;if(typeof Tech!=='undefined'){Tech.points++;}document.getElementById('skill-btn').classList.add('has-pts');const _pdb=document.getElementById('pdx-btn');if(_pdb)_pdb.classList.add('has-new');spawnPop('⭐ LEVEL UP! Now Lv.'+PL.level,'#facc15');setTimeout(()=>spawnPop('+1 Skill Pt · +1 Tech Pt 🔬','#90ccff'),350);addPart(PL.x,PL.y,'#facc15',12);addPart(PL.x,PL.y,'#90ccff',10);addPart(PL.x,PL.y,'#60a5fa',8);if(document.getElementById('skill-overlay').classList.contains('show'))refreshSkillUI();if(typeof renderTechTree==='function')renderTechTree();saveGame();}updPlayerXPBar();}

function _isInBossFight(){
  if(inDungeon)return true;
  for(const b of bossPals)if(b&&!b.dead&&Math.hypot(b.x-PL.x,b.y-PL.y)<420)return true;
  try{for(const zb of _allZoneBosses())if(zb&&!zb.dead&&Math.hypot(zb.x-PL.x,zb.y-PL.y)<420)return true;}catch(e){}
  return false;
}
// ─── BOSS ARENA SYSTEM ──────────────────────────────────────────
// Player must be inside a zone-boss arena (the circular boss zone)
// to deal damage to that boss. Pals can damage too — but only while
// the player is inside (so player can't just camp outside and farm).
function _playerInArena(zoneIdx){
  if(zoneIdx==null||zoneIdx<0)return false;
  const bz=BOSS_ZONES[zoneIdx];if(!bz)return false;
  return Math.hypot(PL.x-bz.centerFx*MAP_W,PL.y-bz.centerFy*MAP_H)<bz.radius;
}
function _canDamageBoss(b){
  if(!b)return false;
  // Only zone bosses are arena-gated; nomadic bossPals can be hit anywhere.
  if(typeof b.zoneIdx!=='number')return true;
  return _playerInArena(b.zoneIdx);
}
let _arenaWarnT=0;
function _updArenaEdge(){
  // Show arena edge pulse when player is inside any boss arena with an alive boss
  const el=document.getElementById('arena-edge');if(!el)return;
  let inside=false;
  try{
    for(const zb of _allZoneBosses()){
      if(_playerInArena(zb.zoneIdx)){inside=true;break;}
    }
  }catch(e){}
  el.classList.toggle('show',inside);
}
function _showArenaBlocked(){
  if(_arenaWarnT>0)return;
  _arenaWarnT=1600;
  const w=document.getElementById('arena-warn');if(!w)return;
  w.classList.add('show');
  setTimeout(()=>w.classList.remove('show'),1400);
}
function _resetZoneBoss(b,reason){
  if(!b||typeof b.zoneIdx!=='number')return;
  const bz=BOSS_ZONES[b.zoneIdx];if(!bz)return;
  // HP refill animation: store target hp; gameLoop interpolates _hpAnim → hp
  b._hpAnim=b.hp;b.hp=b.maxHp;b._hpAnimT=900;
  // Return to spawn area
  const a=Math.random()*Math.PI*2,r2=80+Math.random()*120;
  b.x=bz.centerFx*MAP_W+Math.cos(a)*r2;
  b.y=bz.centerFy*MAP_H+Math.sin(a)*r2;
  b.vx=0;b.vy=0;b.wT=2000;b.shakeT=0;
  b.abCD=Math.max(b.abCD||0,2200);b.spCD=Math.max(b.spCD||0,4000);
  b.phase=1;b._calm=true;
  // Ring of yellow particles for refill
  for(let pi=0;pi<14;pi++){const pa=pi/14*Math.PI*2;addPart(b.x+Math.cos(pa)*30,b.y+Math.sin(pa)*30,'#ffd66e',6);}
}
function _resetEngagedBosses(){
  let any=false;
  try{
    for(const zb of _allZoneBosses()){
      // If player was inside this zone OR boss was actively chasing recently
      if(_playerInArena(zb.zoneIdx)||Math.hypot(zb.x-PL.x,zb.y-PL.y)<420){
        _resetZoneBoss(zb,'death');any=true;
      }
    }
  }catch(e){}
  if(any){
    const el=document.getElementById('boss-reset-banner');
    if(el){el.classList.remove('show');void el.offsetWidth;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),2700);}
  }
}
function _dropPlayerLoot(){
  const pb=getPB();
  const inBase=pb&&Math.hypot(PL.x-pb.x,PL.y-pb.y)<BASE_RADIUS;
  if(inBase)return;
  // PASS 1 — snapshot ALL items that will be dropped (full stack)
  const drops=[];
  for(let i=0;i<playerInv.length;i++){
    const it=playerInv[i];if(!it||!it.qty||it.qty<=0)continue;
    drops.push({idx:i,type:it.type,qty:it.qty});
  }
  if(!drops.length)return;
  // PASS 2 — remove full stacks from inventory, build loot list (no duplication)
  const items=[];
  for(const d of drops){
    const it=playerInv[d.idx];
    if(!it||it.type!==d.type)continue;
    const actualLose=it.qty;// drop entire stack
    items.push({type:it.type,qty:actualLose});
    playerInv[d.idx]=null;// clear slot immediately
  }
  if(!items.length)return;
  spawnLootBag(PL.x,PL.y,items);
  spawnPop('💀 All items dropped! Recover your loot bag.','#f87171');
  updResUI();
}
// Find a respawn point that's safely OUTSIDE every boss arena.
function _safeRespawn(rx,ry){
  for(const bz of BOSS_ZONES){
    const dx=rx-bz.centerFx*MAP_W,dy=ry-bz.centerFy*MAP_H,d=Math.hypot(dx,dy);
    if(d<bz.radius+40){
      // Push out along the vector from arena center
      const k=(bz.radius+80)/(d||1);rx=bz.centerFx*MAP_W+dx*k;ry=bz.centerFy*MAP_H+dy*k;
    }
  }
  rx=Math.max(40,Math.min(MAP_W-40,rx));
  ry=Math.max(40,Math.min(MAP_H-40,ry));
  return{x:rx,y:ry};
}
function killPL(){
  if(PL.dead)return;// re-entry guard — prevents double loot drop if two hits arrive same tick
  PL.dead=true;addStat('deathCount');
  // Auto-cancel dungeon on death — despawn all enemies and clear combat state
  if(inDungeon){
    dungeonEnemies.length=0;dungeonBossObj=null;
    inDungeon=false;dungeonPhase=0;dungeonKillCount=0;
    PL.stunT=0;PL.swT=0;
    for(const wp of wildPals){if(wp.aggroId==='PLAYER')wp.aggroId=null;}
    _showDungeonCancelBtn(false);
    PL.x=dungeonEntryX;PL.y=dungeonEntryY;
  }
  _dropPlayerLoot();
  // Reset any boss the player was engaged with (no suicide-cheese)
  _resetEngagedBosses();
  saveGame();
  const pb=getPB();
  if(pb){
    const sp=_safeRespawn(pb.x,pb.y+40);
    const ro=document.getElementById('respawn-overlay');ro.classList.add('show');setTimeout(()=>ro.classList.add('fade'),50);
    setTimeout(()=>{ro.classList.remove('fade');setTimeout(()=>{ro.classList.remove('show');doRespawn(sp.x,sp.y);},400);},1800);
  }
  else{document.getElementById('death-screen').classList.add('show');}
}
function doRespawn(rx,ry){
  const sp=_safeRespawn(rx,ry);
  PL.x=sp.x;PL.y=sp.y;PL.hp=PL.maxHp;PL.dead=false;PL.invT=2000;updHPBar();
  document.getElementById('death-screen').classList.remove('show');activePal=null;refreshPartyBar();
  const alive=wildPals.filter(w=>!w.dead).length;if(alive<WILD_NEAR_MIN)spawnWild(Math.min(WILD_NEAR_MIN-alive,WILD_MAX-wildPals.length),'near');
  spawnPop('🏠 Respawned at base!','#4aff78');
}
function respawn(){const pb=getPB();doRespawn(pb?pb.x:MAP_W/2,pb?pb.y+40:MAP_H/2);}

function drawPlayer(){
  if(PL.dead)return;
  const z=ZOOM,now=Date.now();
  // Idle breathing motion (subtle)
  const breath=PL.moving?0:Math.sin(now*0.0035)*0.55*z;
  const sx=wx(PL.x)-11*z,sy=wy(PL.y)-13*z+breath;
  const bob=PL.moving?Math.sin(PL.aF*Math.PI/2)*2*z:0;
  const sw=PL.swT>0;
  // Smooth attack swing easing (peaks mid-swing)
  const swP=sw?Math.sin(Math.max(0,Math.min(1,(500-PL.swT)/500))*Math.PI):0;
  if(PL.invT>0&&Math.floor(now/80)%2===0)ctx.globalAlpha=.4;
  // Layered ground shadow (soft outer + inner)
  ctx.fillStyle='rgba(0,0,0,.18)';ctx.beginPath();ctx.ellipse(wx(PL.x),wy(PL.y)+14*z,12*z,5*z,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='rgba(0,0,0,.36)';ctx.beginPath();ctx.ellipse(wx(PL.x),wy(PL.y)+13*z,9*z,3.5*z,0,0,Math.PI*2);ctx.fill();
  // Shirt (body) with top highlight + bottom shade
  ctx.fillStyle='#2060cc';ctx.fillRect(sx+3*z,sy+10*z+bob,16*z,14*z);
  ctx.fillStyle='#3a82e8';ctx.fillRect(sx+3*z,sy+10*z+bob,16*z,2*z);
  ctx.fillStyle='#163d8a';ctx.fillRect(sx+3*z,sy+22*z+bob,16*z,2*z);
  // Face + chin shadow
  ctx.fillStyle='#f5c89a';ctx.fillRect(sx+4*z,sy+bob,14*z,13*z);
  ctx.fillStyle='#e6b288';ctx.fillRect(sx+4*z,sy+11*z+bob,14*z,2*z);
  // Hair: base + highlight + shadow line
  ctx.fillStyle='#8B5E3C';ctx.fillRect(sx+4*z,sy+bob,14*z,4*z);
  ctx.fillStyle='#a87a52';ctx.fillRect(sx+4*z,sy+bob,14*z,1*z);
  ctx.fillStyle='#5a3a20';ctx.fillRect(sx+4*z,sy+3*z+bob,14*z,1*z);
  // Eyes / face per facing
  ctx.fillStyle='#1a1a1a';
  if(PL.facing==='down'){
    ctx.fillRect(sx+7*z,sy+5*z+bob,2*z,2*z);ctx.fillRect(sx+13*z,sy+5*z+bob,2*z,2*z);
    ctx.fillStyle='rgba(210,130,110,.55)';ctx.fillRect(sx+7*z,sy+9*z+bob,2*z,1*z);ctx.fillRect(sx+13*z,sy+9*z+bob,2*z,1*z);
  }
  if(PL.facing==='up'){ctx.fillStyle='#8B5E3C';ctx.fillRect(sx+4*z,sy+bob,14*z,6*z);ctx.fillStyle='#5a3a20';ctx.fillRect(sx+4*z,sy+5*z+bob,14*z,1*z);}
  if(PL.facing==='left')ctx.fillRect(sx+5*z,sy+5*z+bob,2*z,2*z);
  if(PL.facing==='right')ctx.fillRect(sx+15*z,sy+5*z+bob,2*z,2*z);
  // Arms with smooth swing
  ctx.fillStyle='#2060cc';
  const ab=PL.moving?Math.sin(PL.aF*Math.PI/2)*3*z:0,so=sw?-8*z*swP:0;
  ctx.fillRect(sx,sy+10*z+bob-ab+so,4*z,10*z);ctx.fillRect(sx+18*z,sy+10*z+bob+ab-so,4*z,10*z);
  const tx=PL.facing==='left'?sx-8*z:sx+18*z,ty=sy+16*z+bob+(sw?-8*z*swP:0);
  ctx.fillStyle='rgba(255,255,255,.72)';ctx.beginPath();ctx.ellipse(tx+5*z,ty-5*z,8*z,8*z,0,0,Math.PI*2);ctx.fill();
  // Empty hand mode: sword active but no weapon → no tool sprite, just the bare hand
  let toolEmoji=null;
  if(activeTool==='axe')toolEmoji='🪓';
  else if(activeTool==='pickaxe')toolEmoji='⛏';
  else if(activeTool==='sword'&&equipped.weapon)toolEmoji=WEAPON_EMOJI[equipped.weapon]||'🗡️';
  if(toolEmoji){ctx.font=\`\${Math.round(13*z)}px serif\`;ctx.fillText(toolEmoji,tx,ty);}
  else if(sw){
    // Bare-hand punch — small impact ring at fist on swing
    ctx.strokeStyle='rgba(255,220,160,'+(0.55*swP).toFixed(2)+')';ctx.lineWidth=2*z;
    ctx.beginPath();ctx.arc(tx+5*z,ty-5*z,(6+swP*4)*z,0,Math.PI*2);ctx.stroke();
  }
  // Pants with knee shading
  ctx.fillStyle='#1a2a6a';const ll=PL.moving?Math.sin(PL.aF*Math.PI/2)*3*z:0;
  ctx.fillRect(sx+4*z,sy+22*z+bob+ll,6*z,6*z);ctx.fillRect(sx+12*z,sy+22*z+bob-ll,6*z,6*z);
  ctx.fillStyle='#0f1e4a';
  ctx.fillRect(sx+4*z,sy+27*z+bob+ll,6*z,1*z);ctx.fillRect(sx+12*z,sy+27*z+bob-ll,6*z,1*z);
  ctx.strokeStyle='rgba(0,0,0,.45)';ctx.lineWidth=z;ctx.strokeRect(sx+3*z,sy+bob,16*z,26*z);
  ctx.globalAlpha=1;
}

// ═══════════════════════════════
// PARTICLES
// ═══════════════════════════════
const particles=[];const MAX_PARTICLES=200;
function addPart(x,y,color,n){
  if(particles.length>MAX_PARTICLES)particles.splice(0,particles.length-MAX_PARTICLES);
  for(let i=0;i<n;i++){const a=Math.random()*Math.PI*2,s=1+Math.random()*2;particles.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:1,color,size:(3+Math.random()*4)*ZOOM});}
}
function updPart(dt){for(let i=particles.length-1;i>=0;i--){const p=particles[i];p.x+=p.vx;p.y+=p.vy;p.vy+=.04;p.life-=dt/600;if(p.life<=0)particles.splice(i,1);}}
function drawPart(){for(const p of particles){ctx.globalAlpha=Math.max(0,p.life*.9);ctx.fillStyle=p.color;ctx.beginPath();ctx.arc(wx(p.x),wy(p.y),p.size*p.life,0,Math.PI*2);ctx.fill();}ctx.globalAlpha=1;}

// ═══════════════════════════════
// FOLLOWER PAL
// ═══════════════════════════════
const FOLLOW_D=48,FOLLOW_S=1.75,HELPER_CD=4000,HELPER_R=72,PAL_COMBAT_R=135;
let activePal=null;
function hurtActivePal(dmg){if(!activePal||activePal.fainted||!(activePal.maxHp>0))return;activePal.hp=Math.max(0,activePal.hp-dmg);activePal.shakeT=220;addPart(activePal.x,activePal.y,'#f44',3);}
function _palAllEnemies(){return[...wildPals,...bossPals,..._allZoneBosses(),...(inDungeon?dungeonEnemies:[])];}
function updActivePal(dt){
  if(!activePal||PL.dead)return;
  const p=activePal;
  // Faint check
  if(p.fainted||p.hp<=0){
    p.hp=0;p.fainted=true;
    if(typeof p.partyIdx==='number'&&partyPals[p.partyIdx]){partyPals[p.partyIdx].hp=0;partyPals[p.partyIdx].fainted=true;}
    spawnPop(p.def.emoji+' fainted!','#f87171');playSnd('paldeath');addPart(p.x,p.y,'#888',8);addPart(p.x,p.y,'#444',6);
    activePal=null;refreshPartyBar();return;
  }
  if(p.shakeT>0)p.shakeT=Math.max(0,p.shakeT-dt);
  tickPalFx(p,dt);
  // Tick special skill cooldown
  if((p.skCD||0)>0)p.skCD=Math.max(0,p.skCD-dt);
  // Auto-use special on a slow internal timer (won't conflict with manual trigger)
  p._autoSkT=(p._autoSkT||11000)-dt;
  if(p._autoSkT<=0){p._autoSkT=9000+Math.random()*6000;if((p.skCD||0)<=0&&p.def.special)firePalSpecial();}
  // Tick switch delay & target-lock timer
  if((p._switchT||0)>0)p._switchT=Math.max(0,p._switchT-dt);
  if((p._lockT||0)>0)p._lockT=Math.max(0,p._lockT-dt);
  // TARGET LOCK: keep current locked enemy if alive & within extended range
  const LOCK_R=PAL_COMBAT_R*1.6;
  if(p._lockEnemy){
    const le=p._lockEnemy;
    if(!le||le.dead||le.hp<=0||Math.hypot(p.x-le.x,p.y-le.y)>LOCK_R||(p._lockT||0)<=0){p._lockEnemy=null;}
  }
  // Find nearest enemy in combat radius (or use lock)
  // ── BEHAVIOR FILTER ── Only target wild pals that are hostile or aggressive-by-nature.
  // Bosses & dungeon enemies are always valid targets. Passive/timid wilds are off-limits
  // unless attacked — preventing pals from murdering peaceful Foxlings on sight.
  function _isValidPalTarget(e){
    if(!e||e.dead)return false;
    if(e.isBoss)return true;
    if(!e.def||!e.def.behavior)return true; // unknown shape (dungeon enemy etc.) → engage
    if(e.hostile)return true;
    if(e.aggroId==='PLAYER'||(activePal&&e.aggroId===activePal.id))return true;
    return e.def.behavior==='aggressive';
  }
  let nearEnemy=null,nearDist=Infinity;
  if(p._lockEnemy&&_isValidPalTarget(p._lockEnemy)){nearEnemy=p._lockEnemy;nearDist=Math.hypot(p.x-nearEnemy.x,p.y-nearEnemy.y);}
  else{
    if(p._lockEnemy)p._lockEnemy=null;
    for(const e of _palAllEnemies()){if(!_isValidPalTarget(e))continue;const d=Math.hypot(p.x-e.x,p.y-e.y);if(d<PAL_COMBAT_R&&d<nearDist){nearDist=d;nearEnemy=e;}}
    if(nearEnemy){p._lockEnemy=nearEnemy;p._lockT=3500;}
  }
  const dxPL=PL.x-p.x,dyPL=PL.y-p.y,distPL=Math.hypot(dxPL,dyPL)||1;
  // Validate active resource task (clear if object gone)
  if(p.palTask&&p.palTask.type==='resource'){
    const t=p.palTask.obj;if(!t||t.hp<=0||!objects.includes(t))p.palTask=null;
  }
  if(nearEnemy){
    // Priority 1: COMBAT — move toward enemy until in attack range
    const exd=nearEnemy.x-p.x,eyd=nearEnemy.y-p.y,ed=Math.hypot(exd,eyd)||1;
    if(ed>p.def.ability.range*0.65){const s=Math.min(FOLLOW_S+0.4,ed*0.055+0.38);moveWithColl(p,exd/ed*s,eyd/ed*s,12,12);}
    p.aT+=dt;if(p.aT>200){p.aF=(p.aF+1)%4;p.aT=0;}
  } else if(p.palTask&&p.palTask.type==='resource'){
    // Priority 2: RESOURCE TASK — move toward resource (ignore player distance)
    const t=p.palTask.obj;
    const dxT=t.x-p.x,dyT=t.y-p.y,dT=Math.hypot(dxT,dyT)||1;
    if(dT>22){const spd=Math.min(FOLLOW_S+0.3,dT*0.07+0.3);moveWithColl(p,dxT/dT*spd,dyT/dT*spd,12,12);p.aT+=dt;if(p.aT>200){p.aF=(p.aF+1)%4;p.aT=0;}}
    else{p.aF=1;p.aT=0;} // "working" animation frame
  } else if(distPL>FOLLOW_D){
    // Priority 3: FOLLOW player
    const s=Math.min(FOLLOW_S,(distPL-FOLLOW_D)*0.055+0.28);
    moveWithColl(p,dxPL/distPL*s,dyPL/distPL*s,12,12);
    p.aT+=dt;if(p.aT>200){p.aF=(p.aF+1)%4;p.aT=0;}
  } else {p.aF=0;p.aT=0;}
  // Attack — target any enemy in ability range
  p.abCD-=dt;
  if(p.abCD<=0){
    p.abCD=p.def.ability.cd*0.75+(Math.random()*300-150);
    let bw=null,bd=Infinity;
    for(const e of _palAllEnemies()){if(!_isValidPalTarget(e))continue;const d=Math.hypot(p.x-e.x,p.y-e.y);if(d<p.def.ability.range&&d<bd){bd=d;bw=e;}}
    if(bw&&!bw.dead){
      let dmg=palDmg(p);let splash=getSkillSplash(p);let big=getSkillBigProj(p);
      const pr=p.rarity||'common';let critLabel='';
      if(pr==='legendary'){dmg+=3;splash=true;big=true;critLabel=' ★';}
      else if(pr==='epic'){dmg+=1;splash=true;}
      else if(pr==='rare'&&Math.random()<0.30){dmg=Math.ceil(dmg*1.5);critLabel=' CRIT!';}
      const tier=getSkillTier(p);
      const skillName=(tier>=4?'★'+p.def.ability.name:tier>=3?p.def.ability.name+'+':tier>=2?p.def.ability.name+'✦':p.def.ability.name)+critLabel;
      popAt(skillName,pr==='legendary'?'#ffd700':pr==='epic'?'#cc44ff':p.def.ability.color,p.x,p.y-16);
      playSnd('patatk');spawnProjFromPal(p,bw,dmg,splash,big);
      p._atkT=180;p._atkDx=bw.x-p.x;p._atkDy=bw.y-p.y;
      addPart(p.x,p.y,pr==='legendary'?'#ffd700':p.def.ability.color,big?8:3);
    }
  }
  // ── RESOURCE TASK WORK (when in range of resource) ──
  if(!nearEnemy&&p.palTask&&p.palTask.type==='resource'){
    const t=p.palTask.obj;
    if(!t||t.hp<=0||!objects.includes(t)){p.palTask=null;}
    else{
      const dT=Math.hypot(t.x-p.x,t.y-p.y);
      if(dT<=24){
        // Within reach — tick work timer
        p.hT=(p.hT||HELPER_CD)-dt;
        if(p.hT<=0){
          p.hT=palWorkSpd(p)*0.65;
          t.hp--;addPart(t.x,t.y,p.def.ability.color,4);
          if(t.hp<=0){
            const idx2=objects.indexOf(t);if(idx2>=0)objects.splice(idx2,1);
            if(t.type==='tree'){const a=1+Math.floor(Math.random()*2)+Math.floor(getSkillHarvestBonus()/2);iAdd(playerInv,'wood',a);popAt('+'+a+'🪵',p.def.ability.color,t.x,t.y);questProg('wood',a);addStat('woodCollected',a);}
            else if(t.type==='stone'){const a=1+Math.floor(Math.random()*2)+Math.floor(getSkillHarvestBonus()/2);iAdd(playerInv,'stone',a);popAt('+'+a+'🪨',p.def.ability.color,t.x,t.y);questProg('stone',a);addStat('stoneCollected',a);}
            else if(t.type==='copper'){const a=1+Math.floor(getSkillHarvestBonus()/2);iAdd(playerInv,'copper',a);popAt('+'+a+'🟠',p.def.ability.color,t.x,t.y);addStat('copperCollected',a);}
            updResUI();gainXP(p,8);p.palTask=null;spawnPop(p.def.emoji+' done gathering!','#4aff78');
          }
        }
      }
    }
    return;
  }

  // Helper work only when not in combat and no assigned task
  if(!nearEnemy){p.hT=(p.hT||HELPER_CD)-dt;if(p.hT<=0){p.hT=palWorkSpd(p);doHelperWork(p);}}
}

function doHelperWork(p){
  const ht=p.def.helperType;let tgts=[];
  if(ht==='wood')tgts=objects.filter(o=>o.type==='tree'&&Math.hypot(o.x-p.x,o.y-p.y)<HELPER_R);
  else if(ht==='stone')tgts=objects.filter(o=>o.type==='stone'&&Math.hypot(o.x-p.x,o.y-p.y)<HELPER_R);
  else if(ht==='stone_copper')tgts=objects.filter(o=>(o.type==='stone'||o.type==='copper')&&Math.hypot(o.x-p.x,o.y-p.y)<HELPER_R);
  if(!tgts.length)return;const t=tgts[0];t.hp--;addPart(t.x,t.y,p.def.ability.color,3);
  if(t.hp<=0){objects.splice(objects.indexOf(t),1);
    if(t.type==='tree'){const a=1+Math.floor(Math.random()*2)+Math.floor(getSkillHarvestBonus()/2);iAdd(playerInv,'wood',a);popAt('+'+a+'🪵',p.def.ability.color,p.x,p.y);questProg('wood',a);addStat('woodCollected',a);}
    else if(t.type==='stone'){const a=1+Math.floor(Math.random()*2)+Math.floor(getSkillHarvestBonus()/2);iAdd(playerInv,'stone',a);popAt('+'+a+'🪨',p.def.ability.color,p.x,p.y);questProg('stone',a);addStat('stoneCollected',a);}
    else if(t.type==='copper'){const a=1+Math.floor(getSkillHarvestBonus()/2);iAdd(playerInv,'copper',a);popAt('+'+a+'🟠',p.def.ability.color,p.x,p.y);addStat('copperCollected',a);}
    updResUI();
    const leveled=gainXP(p,8);
    if(leveled){spawnPop('⬆️ '+p.def.name+' Lv'+p.level+'!','#facc15');popAt('⬆ LEVEL UP!','#ffe066',p.x,p.y-20);addPart(p.x,p.y,'#ffe066',12);addPart(p.x,p.y,'#ffffff',6);if(typeof p.partyIdx==='number'&&partyPals[p.partyIdx]){partyPals[p.partyIdx].level=p.level;partyPals[p.partyIdx].xp=p.xp;partyPals[p.partyIdx].xpNeeded=p.xpNeeded;}}
  }
}

function drawActivePal(){
  if(!activePal)return;
  const p=activePal,d=p.def,z=ZOOM,sz=d.size,sx=wx(p.x),sy=wy(p.y),bob=Math.sin(Date.now()*.004+p.id*77)*1.5*z;
  ctx.strokeStyle='rgba(74,255,120,.42)';ctx.lineWidth=1.5*z;ctx.setLineDash([3*z,3*z]);ctx.beginPath();ctx.arc(sx,sy+bob,(sz+3)*z,0,Math.PI*2);ctx.stroke();ctx.setLineDash([]);
  if(p.shakeT>0){const fsk=p.shakeT/220,sk=(Math.random()-.5)*3*fsk*z;ctx.save();ctx.translate(sk,0);}
  const _al=palLunge(p);
  drawPalBody(d,sz,sx+_al.lx*z,sy+bob+_al.ly*z,z,p);
  drawPalFx(p,sx+_al.lx*z,sy+bob+_al.ly*z,sz,z);
  if(p.shakeT>0)ctx.restore();
  if(d.rare)drawSpk(p,sx,sy+bob,sz,z);
  const abPct=Math.max(0,1-p.abCD/p.def.ability.cd);
  if(abPct<1){ctx.strokeStyle=d.ability.color;ctx.lineWidth=2*z;ctx.globalAlpha=.52;ctx.beginPath();ctx.arc(sx,sy+bob,(sz+2)*z,-Math.PI/2,-Math.PI/2+abPct*Math.PI*2);ctx.stroke();ctx.globalAlpha=1;}
  const tier=getSkillTier(p);
  if(tier>=2){ctx.fillStyle='rgba(0,0,0,.55)';ctx.font=Math.round(5.5*z)+'px Courier New';const tierStr='T'+tier;const tw2=ctx.measureText(tierStr).width;ctx.fillRect(sx+sz*z,sy+bob-(sz+5)*z-6*z,tw2+3,6.5*z);ctx.fillStyle=tier>=4?'#ff44ff':tier>=3?'#ffcc00':'#aaffaa';ctx.fillText(tierStr,sx+sz*z+1.5,sy+bob-(sz+5)*z);}
  // HP bar
  if(p.maxHp>0){const hpPct=Math.max(0,p.hp/p.maxHp);const bw=sz*2.8*z;ctx.fillStyle='rgba(0,0,0,.72)';ctx.fillRect(sx-bw/2,sy+bob-(sz+21)*z,bw,5*z);ctx.fillStyle=hpPct>.5?'#4aff60':hpPct>.25?'#fbbf24':'#f44';ctx.fillRect(sx-bw/2,sy+bob-(sz+21)*z,Math.round(bw*hpPct),5*z);ctx.strokeStyle='#000';ctx.lineWidth=0.5*z;ctx.strokeRect(sx-bw/2,sy+bob-(sz+21)*z,bw,5*z);}
  ctx.fillStyle='rgba(0,0,0,.54)';const tag=d.name+' Lv'+(activePal.level||1);ctx.font=Math.round(7*z)+'px Courier New';const tw=ctx.measureText(tag).width;ctx.fillRect(sx-tw/2-2,sy+bob-(sz+30)*z,tw+4,9*z);ctx.fillStyle=d.rare?'#facc15':'#4aff78';ctx.fillText(tag,sx-tw/2,sy+bob-(sz+22)*z);
}

// ═══════════════════════════════
// PARTY BAR
// ═══════════════════════════════
let boxCap=10;let baseWorkerLimit=2;const BASE_HARD_CAP=5;
// Pal Box Level → base worker capacity mapping
let palBoxLevel=1;const PB_LV_BASE=[2,3,4,5,5];
function _setPalBoxLevel(n){
  n=Math.max(1,Math.min(5,n|0));
  if(n<=palBoxLevel)return;
  const old=baseWorkerLimit;
  palBoxLevel=n;
  baseWorkerLimit=Math.min(BASE_HARD_CAP,PB_LV_BASE[n-1]);
  spawnPop('📦 Pal Box → LV.'+palBoxLevel,'#fb923c');
  if(baseWorkerLimit>old)setTimeout(()=>spawnPop('🆕 New Base Slot Unlocked!','#facc15'),650);
  try{playSnd('pop');}catch(e){}
  try{refreshPBUI&&refreshPBUI();}catch(e){}
}
const PARTY_MAX=4;const partyPals=Array(PARTY_MAX).fill(null);
const boxPals=[];const basePals=[];

function refreshPartyBar(){
  const usedCount=partyPals.filter(Boolean).length;document.getElementById('party-label').textContent='PARTY '+usedCount+'/4';
  for(let i=0;i<PARTY_MAX;i++){
    const slot=document.getElementById('ps-'+i),pal=partyPals[i];
    if(!slot)continue;
    // Null-guard: a corrupt save can leave slots as undefined — normalise to null
    if(partyPals[i]===undefined)partyPals[i]=null;
    if(pal&&pal.def){if(pal.fainted){slot.textContent='💀';}else{slot.innerHTML=palIconHTML(pal.def);}let cls='party-slot filled';const pr=pal.rarity||'common';if(pal.fainted)cls+=' fainted';else if(pr==='legendary')cls+=' legendary';else if(pr==='epic')cls+=' epic';else if(pal.def.rare||pr==='rare')cls+=' rare';if(activePal&&activePal.partyIdx===i)cls+=' active';if(sel&&sel.zone==='party'&&sel.idx===i)cls+=' selected';slot.className=cls;const hpStr=(pal.maxHp>0&&!pal.fainted)?(' HP:'+(pal.hp||0)+'/'+pal.maxHp):'';slot.title=pal.def.name+' Lv'+(pal.level||1)+' ['+pr.toUpperCase()+']'+(pal.fainted?' FAINTED':hpStr);}
    else{slot.textContent='';let cls='party-slot';if(sel&&sel.zone==='party'&&sel.idx===i)cls+=' selected';slot.className=cls;}
  }
}
for(let i=0;i<PARTY_MAX;i++){
  const idx=i;
  document.getElementById('ps-'+idx).addEventListener('click',()=>{
    if(document.getElementById('pb-overlay').classList.contains('show')){tapPalSelect('party',idx,partyPals[idx]?.def||null);refreshPBUI();return;}
    if(partyPals[idx]){
      if(activePal&&activePal.partyIdx===idx){if(partyPals[idx]&&activePal.maxHp>0){partyPals[idx].hp=activePal.hp;partyPals[idx].maxHp=activePal.maxHp;}activePal=null;refreshPartyBar();spawnPop(partyPals[idx].def.emoji+' recalled','#4aff78');}
      else{const _pd=partyPals[idx];if(_pd.fainted){spawnPop(_pd.def.emoji+' is Fainted — move to storage to recover','#f87171');return;}activePal={def:_pd.def,x:PL.x+32,y:PL.y+18,partyIdx:idx,id:Math.random(),aF:0,aT:0,abCD:_pd.def.ability.cd,hT:HELPER_CD,shakeT:0};activePal.level=_pd.level||1;activePal.xp=_pd.xp||0;activePal.xpNeeded=_pd.xpNeeded||xpToNext(activePal.level);activePal.rarity=_pd.rarity||'common';const _pmxhp=_pd.maxHp||(_pd.def.baseHp+(activePal.level)*2);activePal.maxHp=_pmxhp;activePal.hp=(_pd.hp!=null)?Math.min(_pd.hp,_pmxhp):_pmxhp;// Initialize skill cooldown — half cd so skill is ready quickly after deploy
activePal.skCD=_pd.def.special?Math.floor(_pd.def.special.cd*0.5):0;activePal._autoSkT=11000;refreshPartyBar();spawnPop(_pd.def.emoji+' deployed! ['+activePal.rarity.toUpperCase()+'] HP:'+activePal.hp+'/'+activePal.maxHp,'#4aff78');}
    }
  });
  document.getElementById('ps-'+idx).addEventListener('touchstart',e=>{e.preventDefault();document.getElementById('ps-'+idx).click();},{passive:false});
}

// ═══════════════════════════════
// PAL BOX FULL UI
// ═══════════════════════════════
function openPBUI(){refreshPBUI();document.getElementById('pb-overlay').classList.add('show');}
function closePBUI(){document.getElementById('pb-overlay').classList.remove('show');clearSel();}
document.getElementById('pb-hdr-close').onclick=closePBUI;
function refreshPBUI(){
  for(let i=0;i<PARTY_MAX;i++){
    const el=document.getElementById('pp-'+i);el.innerHTML='';
    const pal=partyPals[i];const isSel=sel&&sel.zone==='party'&&sel.idx===i;
    el.className='ppty-slot'+(pal?' filled':'')+(isSel?' sel-hi':'');
    if(pal){
      const lvPct=Math.min(100,((pal.xp||0)/(pal.xpNeeded||50))*100);
      const palHpStr=pal.fainted?'<span style="color:#f87171;font-size:8px">💀 Fainted'+(pal.recoverAt?' ('+Math.max(0,Math.ceil((pal.recoverAt-Date.now())/60000))+'min)':'')+' → move to storage</span>':((pal.maxHp>0)?('<span style="color:#4aff7888;font-size:8px">HP '+(pal.hp||0)+'/'+pal.maxHp+'</span>'):'');
      el.innerHTML='<span class="ppty-e">'+palIconHTML(pal.def)+'</span><span class="ppty-n">'+pal.def.name+'<br><span style="color:#4aff7888;font-size:8px">Lv'+(pal.level||1)+' · '+Math.floor(lvPct)+'%xp · T'+getSkillTier(pal)+'</span><br>'+palHpStr+'</span>'+(pal.def.rare?'<span class="ppty-r">★</span>':'');
      const rm=document.createElement('button');rm.className='ppty-rm';rm.textContent='−';rm.title='Return to storage';
      rm.addEventListener('click',e=>{e.stopPropagation();clearSel();movePal('party',i,'stor',firstEmptyBox());refreshPBUI();});
      rm.addEventListener('touchstart',e=>{e.stopPropagation();e.preventDefault();clearSel();movePal('party',i,'stor',firstEmptyBox());refreshPBUI();},{passive:false});
      el.appendChild(rm);el.setAttribute('draggable','true');
      el.addEventListener('dragstart',e=>{startMousePalDrag('party',i,pal.def,e);});
      el.addEventListener('touchstart',e=>{if(!e.target.classList.contains('ppty-rm')){e.stopPropagation();startTouchPalDrag('party',i,pal.def,e);}},{passive:true});
    }else{el.innerHTML='<span style="color:#223;font-size:9px">(empty)</span>';}
    el.setAttribute('draggable',pal?'true':'false');
    el.ondragover=e=>{e.preventDefault();el.classList.add('dov');};el.ondragleave=()=>el.classList.remove('dov');
    el.ondrop=e=>{e.preventDefault();el.classList.remove('dov');endMousePalDrop('party',i);};
    el.addEventListener('touchend',e=>{e.preventDefault();endTouchPalDrop('party',i);},{passive:false});
    el.addEventListener('click',e=>{if(e.target.classList.contains('ppty-rm'))return;tapPalSelect('party',i,pal?.def||null);refreshPBUI();});
  }
  document.getElementById('pb-cnt').textContent=boxPals.filter(Boolean).length;
  document.getElementById('pb-cap').textContent=boxCap;
  const sg=document.getElementById('pb-stor-grid');sg.innerHTML='';
  for(let i=0;i<boxCap;i++){
    const slot=document.createElement('div');const pal=boxPals[i]||null;const isSel=sel&&sel.zone==='stor'&&sel.idx===i;
    slot.className='pstor-slot'+(pal?(pal.def.rare?' rare-f':' filled'):'')+(isSel?' sel-hi':'');
    if(pal){const _recStr=pal.fainted?(pal.recoverAt?' ⏳'+Math.max(0,Math.ceil((pal.recoverAt-Date.now())/60000))+'m':' 💀'):'';slot.innerHTML='<span>'+palIconHTML(pal.def)+'</span><span class="ssn">'+pal.def.name+' Lv'+(pal.level||1)+_recStr+'</span>';slot.setAttribute('draggable','true');slot.addEventListener('dragstart',e=>{startMousePalDrag('stor',i,pal.def,e);});slot.addEventListener('touchstart',e=>{e.stopPropagation();startTouchPalDrag('stor',i,pal.def,e);},{passive:true});}
    slot.ondragover=onDragOverSlot;slot.ondragleave=()=>slot.classList.remove('dov');
    slot.ondrop=e=>{e.preventDefault();slot.classList.remove('dov');endMousePalDrop('stor',i);};
    slot.addEventListener('touchend',e=>{e.preventDefault();endTouchPalDrop('stor',i);},{passive:false});
    slot.addEventListener('click',()=>{tapPalSelect('stor',i,pal?.def||null);refreshPBUI();});
    sg.appendChild(slot);
  }
  const bw2=document.getElementById('pb-base-slots-wrap');bw2.innerHTML='';
  document.getElementById('pb-base-info').textContent=basePals.length+'/'+baseWorkerLimit+' • LV.'+palBoxLevel;
  for(let i=0;i<baseWorkerLimit;i++){
    const slot=document.createElement('div');const bp=basePals[i];const isSel=sel&&sel.zone==='base'&&sel.idx===i;
    slot.className='pbase-slot'+(bp?' filled':'')+(isSel?' dov':'');
    if(bp){slot.innerHTML=palIconHTML(bp.def);slot.title='Tap to return to storage';slot.addEventListener('click',()=>{clearSel();movePal('base',i,'stor',firstEmptyBox());refreshPBUI();});slot.addEventListener('touchstart',e=>{e.preventDefault();clearSel();movePal('base',i,'stor',firstEmptyBox());refreshPBUI();},{passive:false});}
    else{slot.textContent='';slot.ondragover=onDragOverSlot;slot.ondragleave=()=>slot.classList.remove('dov');slot.ondrop=e=>{e.preventDefault();slot.classList.remove('dov');endMousePalDrop('base',i);};slot.addEventListener('touchend',e=>{e.preventDefault();endTouchPalDrop('base',i);},{passive:false});slot.addEventListener('click',()=>{tapPalSelect('base',i,null);refreshPBUI();});}
    bw2.appendChild(slot);
  }
}
function firstEmptyBox(){for(let i=0;i<boxCap;i++)if(!boxPals[i])return i;return boxPals.length<boxCap?boxPals.length:boxCap-1;}

// ═══════════════════════════════
// BASE PALS
// ═══════════════════════════════
function updBasePals(dt){
  const pb=getPB();if(!pb)return;
  const snapshot=[...basePals];
  for(const bp of snapshot){
    if(!bp||!bp.def)continue;
    if(typeof bp.x!=='number'||isNaN(bp.x)){bp.x=pb.x+(Math.random()-.5)*80;}
    if(typeof bp.y!=='number'||isNaN(bp.y)){bp.y=pb.y+(Math.random()-.5)*80;}
    bp.hT=(bp.hT||4000)-dt;if(bp.hT<=0){bp.hT=palWorkSpd(bp);doHelperWork(bp);}
    bp.abCD=(bp.abCD||0)-dt;
    // Tick reaction timers
    if((bp._lockT||0)>0)bp._lockT=Math.max(0,bp._lockT-dt);
    if((bp._resT||0)>0)bp._resT=Math.max(0,bp._resT-dt);
    // Validate locked enemy: drop if dead or it left the base
    if(bp._lockEnemy){const le=bp._lockEnemy;if(!le||le.dead||le.hp<=0||Math.hypot(le.x-pb.x,le.y-pb.y)>BASE_RADIUS*1.15){bp._lockEnemy=null;bp._defTarget=null;}}
    if(bp.abCD<=0){
      bp.abCD=bp.def.ability.cd*0.75+(Math.random()*300-150);
      // Base defense — PRIORITY: 1) Boss, 2) any wild pal, 3) (fallthrough) resource work
      let bw=bp._lockEnemy||null,bd=bw?Math.hypot(bp.x-bw.x,bp.y-bw.y):Infinity;
      // (1) Boss has top priority — extended detection range so pals will engage even if boss is at the edge
      if((!bw||bw.isBoss!==true)){
        for(const bo of bossPals){if(!bo||bo.dead)continue;const dToBase=Math.hypot(pb.x-bo.x,pb.y-bo.y);if(dToBase>BASE_RADIUS*1.4)continue;const dd=Math.hypot(bp.x-bo.x,bp.y-bo.y);bw=bo;bd=dd;break;}
        if(bw&&bw.isBoss){bp._lockEnemy=bw;bp._lockT=6000;}
      }
      if(!bw){const wSnap=[...wildPals];
        for(const wp of wSnap){if(!wp||wp.dead)continue;const d=Math.hypot(bp.x-wp.x,bp.y-wp.y);const inBase=Math.hypot(pb.x-wp.x,pb.y-wp.y)<BASE_RADIUS;if(inBase&&d<bd){bd=d;bw=wp;}}
        if(bw){bp._lockEnemy=bw;bp._lockT=3500;}
      }
      if(bw&&!bw.dead){
        // Boss target: longer effective range + bypass base-clamp so pals can reach it
        const isBoss=bw.isBoss===true;
        const range=isBoss?bp.def.ability.range*1.4:bp.def.ability.range;
        if(bd<=range){
          const dmg=palDmg(bp);bw.hp=Math.max(0,bw.hp-dmg);bw.shakeT=250;
          addPart(bp.x,bp.y,bp.def.ability.color,bp.def.ability.pc);
          if(bw.hp<=0&&!bw.dead){
            if(isBoss){bw.dead=true;bw._deadT=0;spawnPop('💥 Base Pal felled the BOSS!','#facc15');questProg('boss');gainPlayerXP(40);bp._lockEnemy=null;}
            else{const lv=bw.level;const ex=bw.x,ey=bw.y;bw.hp=0;killWild(bw);spawnPop('💨 Defeated!','#4aff78');questProg('kill');addStat('palsDefeated');gainPlayerXP(lv*3);popAt('+XP '+(lv*5),'#facc15',ex,ey);const leveled=gainXP(bp,lv*5+10);if(leveled){spawnPop('⬆️ '+bp.def.name+' Lv'+bp.level+'!','#facc15');addPart(bp.x,bp.y,'#ffe066',12);addPart(bp.x,bp.y,'#ffffff',6);}bp._lockEnemy=null;}
          }
        }
        bp._defTarget={x:bw.x,y:bw.y,_isBoss:isBoss};
      } else {bp._defTarget=null;}
    }
    // Drop res-target if consumed
    if(bp._resTarget&&(!objects.includes(bp._resTarget)||bp._resTarget.hp<=0||(bp._resT||0)<=0))bp._resTarget=null;
    // Smooth wander-target + resource-seek (no random per-frame jitter)
    bp.wanderT=(bp.wanderT||0)-dt;
    let bpMx=0,bpMy=0;
    if(bp._defTarget){
      // Chase enemy — clamp inside base for normal enemies; bosses get extended chase radius
      let tx=bp._defTarget.x,ty=bp._defTarget.y;
      const chaseR=bp._defTarget._isBoss?BASE_RADIUS*1.35:BASE_RADIUS*0.95;
      const odx=tx-pb.x,ody=ty-pb.y,od=Math.hypot(odx,ody)||1;
      if(od>chaseR){tx=pb.x+odx/od*chaseR;ty=pb.y+ody/od*chaseR;}
      const ddx=tx-bp.x,ddy=ty-bp.y,dd=Math.hypot(ddx,ddy)||1;
      if(dd>14){const spd=Math.min(1.05,dd*0.06+0.3);bpMx=ddx/dd*spd;bpMy=ddy/dd*spd;}
    } else if(bp._resTarget){
      // Player rallied us to a resource inside base — go gather it
      const rt=bp._resTarget;const rdx=rt.x-bp.x,rdy=rt.y-bp.y,rd=Math.hypot(rdx,rdy)||1;
      if(rd>HELPER_R*0.5){const spd=Math.min(0.7,rd*0.045+0.18);bpMx=rdx/rd*spd;bpMy=rdy/rd*spd;}
    } else {
      const bpHt=bp.def.helperType;let bpRes=null,bpRd=Infinity;
      for(const o of objects){if(!((bpHt==='wood'&&o.type==='tree')||(bpHt==='stone'&&o.type==='stone')||(bpHt==='stone_copper'&&(o.type==='stone'||o.type==='copper'))))continue;if(Math.hypot(o.x-pb.x,o.y-pb.y)>BASE_RADIUS*0.88)continue;const dd2=Math.hypot(o.x-bp.x,o.y-bp.y);if(dd2<bpRd){bpRd=dd2;bpRes=o;}}
      if(bpRes&&bpRd>HELPER_R*0.55){const rdx=bpRes.x-bp.x,rdy=bpRes.y-bp.y,rd=Math.hypot(rdx,rdy)||1;const spd=Math.min(0.72,rd*0.045+0.18);bpMx=rdx/rd*spd;bpMy=rdy/rd*spd;}
      else{if(bp.wanderT<=0||!bp.tx||Math.hypot(bp.tx-bp.x,bp.ty-bp.y)<10){bp.wanderT=1800+Math.random()*1400;const a=Math.random()*Math.PI*2,r=40+Math.random()*(BASE_RADIUS*0.78-40);const nbx=pb.x+Math.cos(a)*r,nby=pb.y+Math.sin(a)*r;bp.tx=Math.max(20,Math.min(nbx,MAP_W-20));bp.ty=Math.max(20,Math.min(nby,MAP_H-20));}const tdx=bp.tx-bp.x,tdy=bp.ty-bp.y,td=Math.hypot(tdx,tdy)||1;if(td>8){const spd=Math.min(0.58,td*0.042+0.14);bpMx=tdx/td*spd;bpMy=tdy/td*spd;}}
    }
    if(bpMx||bpMy)moveWithColl(bp,bpMx,bpMy,12,12);
  }
}
function drawBasePals(){
  for(const bp of basePals){
    if(!bp||!bp.def||typeof bp.x!=='number'||isNaN(bp.x))continue;
    if(!onScreen(bp.x-bp.def.size*1.5,bp.y-bp.def.size*2,bp.def.size*3,bp.def.size*4))continue;
    const d=bp.def,z=ZOOM,sz=d.size,sx=wx(bp.x),sy=wy(bp.y),bob=Math.sin(Date.now()*.003+bp.id*66)*1.5*z;
    ctx.globalAlpha=0.82;drawPalBody(d,sz,sx,sy+bob,z);ctx.globalAlpha=1;
    const tag='Lv'+(bp.level||1);ctx.fillStyle='rgba(0,0,0,.5)';ctx.font=Math.round(6.5*z)+'px Courier New';const tw=ctx.measureText(tag).width;ctx.fillRect(sx-tw/2-2,sy+bob-(sz+12)*z,tw+4,8*z);ctx.fillStyle=d.rare?'#facc15':'#fb923c';ctx.fillText(tag,sx-tw/2,sy+bob-(sz+5)*z);
  }
}

// ═══════════════════════════════
// QUEST
// ═══════════════════════════════
// ── OBJECTIVE / STORY CHAIN ──
// Each objective: {key, target, label, hint, reward:{type,amt}}
// Event keys hooked elsewhere: wood, stone, kill, capture, build_table, assign_base, craft_sphere, enter_forest, boss
const QUESTS=[
  {key:'wood',target:20,label:'Collect 20 Wood',hint:'💡 Chop trees with the axe',reward:{type:'xp',amt:25}},
  {key:'build_table',target:1,label:'Build a Crafting Table',hint:'💡 Tap 🔨 BUILD',reward:{type:'xp',amt:30}},
  {key:'capture',target:1,label:'Capture 1 Pal',hint:'💡 Weaken pal, then throw 🔮 sphere',reward:{type:'sphere',amt:2}},
  {key:'assign_base',target:1,label:'Assign Pal to Base',hint:'💡 Open Pal Box → drag to Base slot',reward:{type:'xp',amt:35}},
  {key:'craft_sphere',target:1,label:'Craft a Pal Sphere',hint:'💡 Open Crafting Table',reward:{type:'sphere',amt:1}},
  {key:'kill',target:5,label:'Defeat 5 Wild Pals',hint:'💡 Equip sword and attack',reward:{type:'xp',amt:60}},
  {key:'enter_forest',target:1,label:'Enter the Forest Zone',hint:'💡 Travel to the green forest biome',reward:{type:'xp',amt:50}},
  {key:'boss',target:1,label:'Defeat the First Boss',hint:'💡 Boss now appears! Defeat it',reward:{type:'xp',amt:200}},
];
let questIdx=0;const qC={};
function _objHint(){const h=document.getElementById('quest-hint');if(!h)return;h.textContent=questIdx<QUESTS.length?(QUESTS[questIdx].hint||''):'';}
function _objLabel(){const q=QUESTS[questIdx];const el=document.getElementById('quest-label');if(!q){el.textContent='🏆 ALL OBJECTIVES DONE!';return;}const cur=Math.min(qC[q.key]||0,q.target);el.textContent='🎯 '+q.label+' '+cur+'/'+q.target;}
function _objBar(){const q=QUESTS[questIdx];const bar=document.getElementById('quest-bar-inner');if(!q){bar.style.width='100%';return;}const p=Math.min(1,(qC[q.key]||0)/q.target);bar.style.width=(p*100)+'%';}
function questProg(type,amt=1){
  if(questIdx>=QUESTS.length)return;
  const q=QUESTS[questIdx];if(q.key!==type)return;
  qC[type]=(qC[type]||0)+amt;
  _objBar();_objLabel();
  if((qC[type]||0)>=q.target)completeQuest();
}
function completeQuest(){
  const q=QUESTS[questIdx];if(!q)return;
  // Reward
  if(q.reward){
    if(q.reward.type==='xp'){gainPlayerXP(q.reward.amt);spawnPop('🏆 +'+q.reward.amt+' XP','#facc15');}
    else if(q.reward.type==='sphere'){iAdd(playerInv,'sphere',q.reward.amt);updResUI();spawnPop('🏆 +'+q.reward.amt+' 🔮','#c084fc');}
    else if(q.reward.type==='wood'){iAdd(playerInv,'wood',q.reward.amt);updResUI();spawnPop('🏆 +'+q.reward.amt+'🪵','#5c3d1e');}
  }
  spawnPop('✅ Objective Complete!','#4aff78');playSnd('pop');
  // Pal Box level rewards by objective key
  if(q.key==='build_table')_setPalBoxLevel(2);
  else if(q.key==='assign_base')_setPalBoxLevel(3);
  else if(q.key==='kill')_setPalBoxLevel(4);
  else if(q.key==='boss')_setPalBoxLevel(5);
  questIdx++;
  if(questIdx<QUESTS.length){spawnPop('🎯 New: '+QUESTS[questIdx].label,'#facc15');_objBar();_objLabel();_objHint();}
  else{document.getElementById('quest-label').textContent='🏆 ALL OBJECTIVES DONE!';document.getElementById('quest-bar-inner').style.width='100%';_objHint();}
  refreshPBUI();saveGame();
}
// Helper for boss-spawn gate
function _bossUnlocked(){return questIdx>=7;}

// ═══════════════════════════════
// BUILD MODE
// ═══════════════════════════════
let buildMode=false,buildType=null,buildPrev=null,removeMode=false;
function openBuildMenu(){
  if(removeMode)cancelRemove();
  // Show all structure options; locked ones get a "Unlock in Tech Tree" overlay
  const _BUILD_TECH={'bopt-table':'craftTable','bopt-chest':'chest','bopt-palbox':'palbox','bopt-campfire':'campfire','bopt-repair':'repair_bench'};
  for(const id in _BUILD_TECH){
    const el=document.getElementById(id);if(!el)continue;
    const k=_BUILD_TECH[id];
    const unl=(typeof Tech==='undefined')?true:!!Tech.unlocked[k];
    el.style.display='';
    el.classList.toggle('tech-locked',!unl);
    el.title=unl?'':'🔬 Unlock in Tech Tree';
    if(!unl){
      // Stash original label once so we can restore later
      if(!el.dataset.origHtml)el.dataset.origHtml=el.innerHTML;
      const origIcon=(el.querySelector('.bi')?.outerHTML)||'';
      el.innerHTML=origIcon+'<span style="opacity:.85;">🔬 Unlock in Tech Tree</span>';
    } else if(el.dataset.origHtml){
      el.innerHTML=el.dataset.origHtml;delete el.dataset.origHtml;
    }
  }
  // "Coming Soon" placeholder inside build menu
  let soon=document.getElementById('bopt-soon');
  if(!soon){
    soon=document.createElement('div');soon.id='bopt-soon';soon.className='bopt';
    soon.style.cssText='opacity:.55;cursor:default;font-style:italic;color:#a87bd1;';
    soon.innerHTML='<span class="bi">✨</span>Future Buildings (Coming Soon)';
    const cancel=document.getElementById('build-cancel-btn');
    if(cancel&&cancel.parentElement)cancel.parentElement.insertBefore(soon,cancel);
  }
  document.getElementById('build-menu').classList.toggle('show');
}
const BUILD_COSTS={craftTable:{wood:8,stone:5},chest:{wood:10},palbox:{wood:15,stone:10,copper:5},campfire:{wood:6,stone:4},repair_bench:{wood:20,stone:15,iron:5}};
function selBuild(type){
  // Tech gate first: ignore clicks on locked options + nudge user toward Tech Tree
  if(typeof Tech!=='undefined'&&!Tech.unlocked[type]){spawnPop('🔬 Unlock in Tech Tree first','#a87bd1');return;}
  const cost=BUILD_COSTS[type];if(!iHas(playerInv,cost)){spawnPop('Not enough resources','#f60');closeBuildMenu();return;}buildType=type;buildMode=true;document.getElementById('build-mode-label').classList.add('show');closeBuildMenu();
}
function closeBuildMenu(){document.getElementById('build-menu').classList.remove('show');}
function cancelBuild(){buildMode=false;buildType=null;buildPrev=null;document.getElementById('build-mode-label').classList.remove('show');}
function toggleRemoveMode(){if(buildMode)cancelBuild();removeMode=!removeMode;document.getElementById('remove-mode-label').classList.toggle('show',removeMode);if(removeMode)spawnPop('🗑️ Delete Mode ON — tap structure','#f87171');if(window._syncDelBtn)window._syncDelBtn();}
function cancelRemove(){removeMode=false;document.getElementById('remove-mode-label').classList.remove('show');if(window._syncDelBtn)window._syncDelBtn();}
function doRemoveStruct(wx2,wy2){let best=null,bd=Infinity;for(const s of structures){const d=Math.hypot(s.x-wx2,s.y-wy2);if(d<90&&d<bd){bd=d;best=s;}}if(!best){spawnPop('No structure nearby','#888');return;}const refund=STRUCT_REFUND[best.type]||{};for(const[res,amt]of Object.entries(refund)){iAdd(playerInv,res,amt);}updResUI();if(best.type==='palbox'){for(const bp of [...basePals]){const palObj={def:bp.def,level:bp.level||1,xp:bp.xp||0,xpNeeded:bp.xpNeeded||xpToNext(bp.level||1)};const fb=firstEmptyBox();while(boxPals.length<=fb)boxPals.push(null);boxPals[fb]=palObj;}basePals.length=0;}if(best.type==='chest'&&best.chestInv){for(const item of best.chestInv){if(item)spawnDrop(item.type,item.qty,best.x+Math.random()*20-10,best.y+Math.random()*20-10);}}addPart(best.x,best.y,'#f87171',12);structures.splice(structures.indexOf(best),1);const refundStr=Object.entries(refund).map(([r,a])=>'+'+a+(IEMOJI[r]||r)).join(' ');spawnPop('🗑️ Removed! '+refundStr,'#f87171');cancelRemove();saveGame();}
function confirmPlace(wx2,wy2){if(!buildMode||!buildType)return;if(!placementValid(buildType,wx2,wy2)){spawnPop('❌ Cannot place here','#f60');return;}const cost=BUILD_COSTS[buildType];for(const[res,amt]of Object.entries(cost))iRemove(playerInv,res,amt);placeStruct(buildType,wx2,wy2);updResUI();spawnPop('✅ '+STRUCT_DEF[buildType].label+' placed','#4aff78');if(buildType==='palbox')spawnPop('🏠 Respawn point set!','#a855f7');cancelBuild();saveGame();}
function drawBuildPrev(){if(!buildMode||!buildPrev)return;const valid=placementValid(buildType,buildPrev.x,buildPrev.y);const d=STRUCT_DEF[buildType],z=ZOOM;ctx.globalAlpha=.52;ctx.fillStyle=valid?'#4aff78':'#f44';ctx.fillRect(wx(buildPrev.x)-d.w/2*z,wy(buildPrev.y)-d.h*z,d.w*z,d.h*z);ctx.strokeStyle=valid?'#4aff78':'#f44';ctx.lineWidth=2*z;ctx.strokeRect(wx(buildPrev.x)-d.w/2*z,wy(buildPrev.y)-d.h*z,d.w*z,d.h*z);ctx.font=\`\${Math.round(14*z)}px serif\`;ctx.fillText(STRUCT_DEF[buildType].emoji,wx(buildPrev.x)-6*z,wy(buildPrev.y)-d.h/2*z+4*z);ctx.globalAlpha=1;}
canvas.addEventListener('click',e=>{const r=canvas.getBoundingClientRect();const wx2=(e.clientX-r.left)/r.width*VW/ZOOM+cam.x;const wy2=(e.clientY-r.top)/r.height*VH/ZOOM+cam.y;if(removeMode){doRemoveStruct(wx2,wy2);return;}if(buildMode){confirmPlace(wx2,wy2);}});
canvas.addEventListener('mousemove',e=>{if(!buildMode)return;const r=canvas.getBoundingClientRect();buildPrev={x:(e.clientX-r.left)/r.width*VW/ZOOM+cam.x,y:(e.clientY-r.top)/r.height*VH/ZOOM+cam.y};});
canvas.addEventListener('touchmove',e=>{if(!buildMode)return;e.preventDefault();const r=canvas.getBoundingClientRect(),t=e.changedTouches[0];buildPrev={x:(t.clientX-r.left)/r.width*VW/ZOOM+cam.x,y:(t.clientY-r.top)/r.height*VH/ZOOM+cam.y};},{passive:false});
canvas.addEventListener('touchend',e=>{const r=canvas.getBoundingClientRect(),t=e.changedTouches[0];const wx2=(t.clientX-r.left)/r.width*VW/ZOOM+cam.x;const wy2=(t.clientY-r.top)/r.height*VH/ZOOM+cam.y;if(removeMode){e.preventDefault();doRemoveStruct(wx2,wy2);return;}if(buildMode){e.preventDefault();confirmPlace(wx2,wy2);}},{passive:false});
document.getElementById('build-btn').addEventListener('click',openBuildMenu);
document.getElementById('build-btn').addEventListener('touchstart',e=>{e.preventDefault();openBuildMenu();},{passive:false});
document.getElementById('bopt-table').addEventListener('click',()=>selBuild('craftTable'));
document.getElementById('bopt-chest').addEventListener('click',()=>selBuild('chest'));
document.getElementById('bopt-palbox').addEventListener('click',()=>selBuild('palbox'));
document.getElementById('bopt-campfire').addEventListener('click',()=>selBuild('campfire'));
document.getElementById('bopt-repair').addEventListener('click',()=>selBuild('repair_bench'));
// Cancel button: close menu instantly + cancel any in-progress placement (mobile-safe)
(function(){
  const cb=document.getElementById('build-cancel-btn');if(!cb)return;
  function _cancelAll(e){if(e){e.preventDefault();e.stopPropagation();}cancelBuild();closeBuildMenu();}
  cb.addEventListener('click',_cancelAll);
  cb.addEventListener('touchstart',_cancelAll,{passive:false});
})();
// Outside-tap closes build menu (mobile + mouse). Use capture so it fires before bopt clicks bubble.
(function(){
  const menu=document.getElementById('build-menu');
  const btn=document.getElementById('build-btn');
  if(!menu||!btn)return;
  function _outside(e){
    if(!menu.classList.contains('show'))return;
    const t=e.target;
    if(menu.contains(t)||btn.contains(t))return;
    closeBuildMenu();
  }
  document.addEventListener('pointerdown',_outside,true);
})();
// Delete Mode — now lives inside build menu
(function(){
  const dBtn=document.getElementById('bopt-delete');
  function _togDel(e){if(e&&e.cancelable)e.preventDefault();closeBuildMenu();toggleRemoveMode();}
  dBtn.addEventListener('click',_togDel);
  dBtn.addEventListener('touchstart',_togDel,{passive:false});
  // Keep delete button visually in sync with remove mode
  const _origToggle=toggleRemoveMode;
  window._syncDelBtn=function(){dBtn.style.background=removeMode?'rgba(248,113,113,.22)':'';dBtn.style.borderColor=removeMode?'#f87171':'';};
})();

// ═══════════════════════════════
// CRAFTING
// ═══════════════════════════════
function refreshCraftUI(){
  const wt=equipped.weapon?tierVal(equipped.weapon.replace('sword_','')):-1;
  // Map craft buttons → tech key. If locked, hide entire row.
  const _CRAFT_TECH={
    'cr-sphere':'sphere','cr-adv-sphere':'adv_sphere','cr-ultra-sphere':'ultra_sphere',
    'cr-sw-wood':'sw_wood','cr-sw-stone':'sw_stone','cr-sw-copper':'sw_copper','cr-sw-iron':'sw_iron',
    'cr-ax-stone':'ax_stone','cr-ax-copper':'ax_copper','cr-ax-iron':'ax_iron',
    'cr-pk-stone':'pk_stone','cr-pk-copper':'pk_copper','cr-pk-iron':'pk_iron',
    'cr-ar-cloth':'ar_cloth','cr-ar-iron':'ar_iron'
  };
  for(const id in _CRAFT_TECH){
    const btn=document.getElementById(id);if(!btn)continue;
    const row=btn.closest('.cr-row');if(!row)continue;
    const k=_CRAFT_TECH[id];
    const unl=(typeof Tech==='undefined')?true:!!Tech.unlocked[k];
    row.style.display='';
    row.classList.toggle('tech-locked',!unl);
    const costEl=row.querySelector('.cr-cost');
    if(!unl){
      if(costEl){if(!costEl.dataset.origText)costEl.dataset.origText=costEl.textContent||'';costEl.textContent='🔬 Unlock in Tech Tree';}
      btn.textContent='LOCKED';btn.disabled=true;btn.title='🔬 Unlock in Tech Tree';
    } else {
      if(costEl&&costEl.dataset.origText){costEl.textContent=costEl.dataset.origText;delete costEl.dataset.origText;}
      if(btn.textContent==='LOCKED')btn.textContent='CRAFT';
      btn.title='';
    }
  }
  // Resource gating (skip locked rows — they keep their LOCKED state)
  const _set=(id,have)=>{const e=document.getElementById(id);if(!e)return;const row=e.closest('.cr-row');if(row&&row.classList.contains('tech-locked'))return;e.disabled=!have;};
  _set('cr-sphere',iHas(playerInv,{wood:5,stone:3,copper:2}));
  _set('cr-adv-sphere',iHas(playerInv,{sphere:5,copper:3}));
  _set('cr-ultra-sphere',iHas(playerInv,{adv_sphere:3,copper:5}));
  _set('cr-sw-wood',iHas(playerInv,{wood:6}));
  _set('cr-sw-stone',iHas(playerInv,{wood:5,stone:5}));
  _set('cr-sw-copper',iHas(playerInv,{wood:12,stone:12,copper:20}));
  _set('cr-sw-iron',iHas(playerInv,{wood:8,iron:18}));
  _set('cr-ax-stone',iHas(playerInv,{wood:3,stone:3}));
  _set('cr-ax-copper',iHas(playerInv,{wood:3,copper:3}));
  _set('cr-ax-iron',iHas(playerInv,{wood:5,iron:12}));
  _set('cr-pk-stone',iHas(playerInv,{wood:3,stone:3}));
  _set('cr-pk-copper',iHas(playerInv,{wood:3,copper:3}));
  _set('cr-pk-iron',iHas(playerInv,{wood:5,iron:12}));
  _set('cr-ar-cloth',iHas(playerInv,{wood:8,stone:4}));
  _set('cr-ar-iron',iHas(playerInv,{wood:10,copper:5,iron:20}));
  const capBtn=document.getElementById('capture-btn');capBtn.style.opacity=inv.anyBalls>0?'1':'.38';
}
let _openChest=null;
function openCraftOverlay(){refreshCraftUI();document.getElementById('craft-overlay').classList.add('show');}
function closeCraftOverlay(){document.getElementById('craft-overlay').classList.remove('show');}
document.getElementById('craft-close').onclick=closeCraftOverlay;
function doCraft(type){
  // Tech gate
  if(typeof Tech!=='undefined'&&!Tech.unlocked[type]){spawnPop('🔬 Unlock in Tech Tree first','#a87bd1');return;}
  const recipes={sphere:{wood:5,stone:3,copper:2},adv_sphere:{sphere:5,copper:3},ultra_sphere:{adv_sphere:3,copper:5},sw_wood:{wood:6},sw_stone:{wood:5,stone:5},sw_copper:{wood:12,stone:12,copper:20},sw_iron:{wood:8,iron:18},ax_stone:{wood:3,stone:3},ax_copper:{wood:3,copper:3},ax_iron:{wood:5,iron:12},pk_stone:{wood:3,stone:3},pk_copper:{wood:3,copper:3},pk_iron:{wood:5,iron:12},ar_cloth:{wood:8,stone:4},ar_iron:{wood:10,copper:5,iron:20}};
  if(!recipes[type]||!iHas(playerInv,recipes[type])){spawnPop('Not enough resources','#f60');return;}
  for(const[r,q]of Object.entries(recipes[type]))iRemove(playerInv,r,q);
  if(type==='sphere'){iAdd(playerInv,'sphere',1);spawnPop('+1🔮 Pal Sphere','#c084fc');questProg('craft_sphere');}
  else if(type==='adv_sphere'){iAdd(playerInv,'adv_sphere',1);spawnPop('+1💠 Advanced Sphere (+15% cap)','#60a5fa');}
  else if(type==='ultra_sphere'){iAdd(playerInv,'ultra_sphere',1);spawnPop('+1🌀 Ultra Sphere (+30% cap)','#a855f7');}
  else if(type.startsWith('sw_')||type.startsWith('ax_')||type.startsWith('pk_')||type.startsWith('ar_')){gearAddCrafted(type);}
  // Crafting XP — small reward to feed progression
  const _cxp=type.endsWith('_iron')?12:type.endsWith('_copper')||type==='ultra_sphere'?8:type.endsWith('_stone')||type==='adv_sphere'?5:3;
  gainPlayerXP(_cxp);
  updResUI();updEquipPanel();refreshCraftUI();saveGame();
}
document.getElementById('cr-adv-sphere').onclick=()=>doCraft('adv_sphere');
document.getElementById('cr-ultra-sphere').onclick=()=>doCraft('ultra_sphere');
document.getElementById('cr-sphere').onclick=()=>doCraft('sphere');
document.getElementById('cr-sw-wood').onclick=()=>doCraft('sw_wood');
document.getElementById('cr-sw-stone').onclick=()=>doCraft('sw_stone');
document.getElementById('cr-sw-copper').onclick=()=>doCraft('sw_copper');
document.getElementById('cr-ax-stone').onclick=()=>doCraft('ax_stone');
document.getElementById('cr-ax-copper').onclick=()=>doCraft('ax_copper');
document.getElementById('cr-pk-stone').onclick=()=>doCraft('pk_stone');
document.getElementById('cr-pk-copper').onclick=()=>doCraft('pk_copper');
document.getElementById('cr-ar-cloth').onclick=()=>doCraft('ar_cloth');
document.getElementById('cr-ar-iron').onclick=()=>doCraft('ar_iron');
const _bSwIron=document.getElementById('cr-sw-iron');if(_bSwIron)_bSwIron.onclick=()=>doCraft('sw_iron');
const _bAxIron=document.getElementById('cr-ax-iron');if(_bAxIron)_bAxIron.onclick=()=>doCraft('ax_iron');
const _bPkIron=document.getElementById('cr-pk-iron');if(_bPkIron)_bPkIron.onclick=()=>doCraft('pk_iron');
// Equipped slot wiring — tap to unequip, hold-then-drag for touch, HTML5 drag for mouse
(function(){
  const SLOT_MAP={'eq-weapon':'weapon','eq-armor':'armor','eq-axe':'axe','eq-pick':'pickaxe'};
  function _slotGear(slot){const id=equippedId&&equippedId[slot];return id?_gearById(id):null;}
  function _wireEqSlot(id,slot){
    const el=document.getElementById(id);if(!el)return;
    // ── Mouse / desktop drag
    el.addEventListener('mousedown',function(){const g=_slotGear(slot);el.draggable=!!(g&&!g.broken);});
    el.addEventListener('dragstart',function(e){
      const g=_slotGear(slot);if(!g||g.broken){e.preventDefault();return;}
      _dragState.dragging=true;_dragState.gid=g.id;
      el.classList.add('dragging');
      try{e.dataTransfer.setData('text/plain',String(g.id));e.dataTransfer.effectAllowed='move';}catch(_){}
    });
    el.addEventListener('dragend',function(){
      el.classList.remove('dragging');
      setTimeout(function(){_dragState.dragging=false;_dragState.gid=null;},80);
      document.querySelectorAll('.eq-slot').forEach(function(e2){e2.classList.remove('drag-target');});
    });
    el.addEventListener('click',function(e){
      // Tap-to-unequip (desktop). Skip if a drag was just in progress.
      if(_dragState.dragging)return;
      e.stopPropagation();
      _unequipFromSlot(slot);
    });
    // ── Touch: hold-then-drag, quick-tap unequip
    let sx=0,sy=0,started=false,dragging=false,holdT=null,gearRef=null;
    function clearHold(){if(holdT){clearTimeout(holdT);holdT=null;}}
    el.addEventListener('touchstart',function(e){
      if(e.touches.length!==1)return;
      gearRef=_slotGear(slot);
      if(!gearRef||gearRef.broken){
        // Allow tap-to-unequip even on broken (cleans the slot)
        if(gearRef&&gearRef.broken){
          // Do nothing on hold — only on tap end
        } else if(!gearRef){return;}
      }
      started=true;dragging=false;
      sx=e.touches[0].clientX;sy=e.touches[0].clientY;
      el.classList.add('dragging');
      if(gearRef&&!gearRef.broken){
        holdT=setTimeout(function(){
          if(!started||dragging)return;
          dragging=true;
          _dragState.dragging=true;_dragState.gid=gearRef.id;
          _makeGhost({key:gearRef.key});
          _moveGhost(sx,sy);
        },220);
      }
    },{passive:true});
    el.addEventListener('touchmove',function(e){
      if(!started)return;
      const t=e.touches[0];
      if(!dragging){
        if(Math.hypot(t.clientX-sx,t.clientY-sy)>10){
          clearHold();
          if(gearRef&&!gearRef.broken){
            dragging=true;
            _dragState.dragging=true;_dragState.gid=gearRef.id;
            _makeGhost({key:gearRef.key});
          } else {
            // moved without ability to drag → cancel
            started=false;el.classList.remove('dragging');
          }
        }
      }
      if(dragging&&_ghost){_moveGhost(t.clientX,t.clientY);if(e.cancelable)e.preventDefault();}
    },{passive:false});
    el.addEventListener('touchend',function(e){
      if(!started)return;
      started=false;clearHold();el.classList.remove('dragging');
      if(dragging){
        const tt=e.changedTouches[0];
        const tgt=document.elementFromPoint(tt.clientX,tt.clientY);
        // Eq → eq-slot of same type → no-op (already equipped). Eq → inv-cell → unequip.
        const dropEq=tgt&&tgt.closest?tgt.closest('.eq-slot'):null;
        const dropInv=tgt&&tgt.closest?tgt.closest('#inv-grid, .inv-cell'):null;
        if(dropEq){
          const did=dropEq.id;const want=SLOT_MAP[did];
          if(want===slot){/* same slot, no-op */}
          else spawnPop('Wrong slot for this item','#f60');
        } else if(dropInv){
          _unequipFromSlot(slot);
        }
        _killGhost();
        setTimeout(function(){_dragState.dragging=false;_dragState.gid=null;},80);
      } else {
        // Quick tap → unequip
        _unequipFromSlot(slot);
      }
      gearRef=null;
    },{passive:true});
    el.addEventListener('touchcancel',function(){started=false;dragging=false;clearHold();el.classList.remove('dragging');_killGhost();_dragState.dragging=false;_dragState.gid=null;gearRef=null;},{passive:true});
  }
  Object.keys(SLOT_MAP).forEach(function(id){_wireEqSlot(id,SLOT_MAP[id]);});
})();

// ═══════════════════════════════
// CHEST UI
// ═══════════════════════════════
function openChestOverlay(chest){_openChest=chest;renderChestUI();document.getElementById('chest-overlay').classList.add('show');}
function closeChestOverlay(){document.getElementById('chest-overlay').classList.remove('show');_openChest=null;}
document.getElementById('chest-close').onclick=closeChestOverlay;
function renderChestUI(){
  const pg=document.getElementById('ch-player');pg.innerHTML='';
  const slice=playerInv.slice(0,8);
  for(let i=0;i<8;i++){const c=document.createElement('div'),item=slice[i];c.className='c-cell'+(item?' has-item':'');if(item){c.textContent=item.emoji;const q=document.createElement('span');q.className='cq';q.textContent=item.qty;c.appendChild(q);}c.addEventListener('click',()=>{if(!_openChest||!item)return;iRemove(playerInv,item.type,item.qty);iAdd(_openChest.chestInv,item.type,item.qty);updResUI();renderChestUI();});pg.appendChild(c);}
  const cg=document.getElementById('ch-chest');cg.innerHTML='';
  if(!_openChest)return;
  for(let i=0;i<8;i++){const c=document.createElement('div'),item=_openChest.chestInv[i];c.className='c-cell'+(item?' has-item':'');if(item){c.textContent=item.emoji;const q=document.createElement('span');q.className='cq';q.textContent=item.qty;c.appendChild(q);}c.addEventListener('click',()=>{if(!_openChest||!item)return;iRemove(_openChest.chestInv,item.type,item.qty);iAdd(playerInv,item.type,item.qty);updResUI();renderChestUI();});cg.appendChild(c);}
}

// ═══════════════════════════════
// PAL DRAG / SELECT
// ═══════════════════════════════
let sel=null;
let _drag=null,_touchDrag=null;
function clearSel(){sel=null;document.getElementById('sel-info').classList.remove('show');}
function tapPalSelect(zone,idx,def){
  if(!def){if(sel){movePal(sel.zone,sel.idx,zone,idx);clearSel();refreshPBUI();refreshPartyBar();}return;}
  if(sel){if(sel.zone===zone&&sel.idx===idx){clearSel();return;}movePal(sel.zone,sel.idx,zone,idx);clearSel();refreshPBUI();refreshPartyBar();return;}
  sel={zone,idx,def};const si=document.getElementById('sel-info');si.textContent=def.emoji+' '+def.name+' — tap slot to move';si.classList.add('show');setTimeout(()=>{if(sel&&sel.zone===zone&&sel.idx===idx)clearSel();},3000);
}
function movePal(fromZone,fromIdx,toZone,toIdx){
  function getArr(z){return z==='party'?partyPals:z==='stor'?boxPals:basePals;}
  const fa=getArr(fromZone),ta=getArr(toZone);
  while(ta.length<=toIdx)ta.push(null);
  while(fa.length<=fromIdx)fa.push(null);
  const tmp=ta[toIdx];ta[toIdx]=fa[fromIdx];fa[fromIdx]=tmp||null;
  if(activePal&&activePal.partyIdx===fromIdx&&fromZone==='party'){activePal=null;}
  // When a fainted pal moves to storage, start 5-min recovery timer
  if(toZone==='stor'&&ta[toIdx]&&ta[toIdx].fainted&&!ta[toIdx].recoverAt){ta[toIdx].recoverAt=Date.now()+300000;spawnPop(ta[toIdx].def.emoji+' '+ta[toIdx].def.name+' recovering in 5 min…','#fb923c');}
  // Initialize position/physics for base pals placed during gameplay
  if(toZone==='base'&&ta[toIdx]){
    const pb=getPB();
    // Spread evenly around the palbox so pals don't overlap
    let spX=MAP_W/2,spY=MAP_H/2;
    if(pb){
      let bestX=pb.x,bestY=pb.y,bestMin=-1;
      for(let tries=0;tries<8;tries++){
        const ang=(toIdx*0.9+tries*0.78+Math.random()*0.4)*Math.PI;
        const rad=70+tries*8+Math.random()*15;
        const cx=pb.x+Math.cos(ang)*rad,cy=pb.y+Math.sin(ang)*rad;
        let minD=Infinity;
        for(const ob of basePals){if(!ob||ob===ta[toIdx])continue;const d=Math.hypot(ob.x-cx,ob.y-cy);if(d<minD)minD=d;}
        if(minD>bestMin){bestMin=minD;bestX=cx;bestY=cy;if(minD>50)break;}
      }
      spX=Math.max(20,Math.min(bestX,MAP_W-20));spY=Math.max(20,Math.min(bestY,MAP_H-20));
    }
    ta[toIdx].x=spX;ta[toIdx].y=spY;
    ta[toIdx].vx=0;ta[toIdx].vy=0;
    ta[toIdx].hT=4000;ta[toIdx].abCD=ta[toIdx].def?.ability?.cd||3000;
    ta[toIdx].id=ta[toIdx].id||Math.random();
  }
  if(toZone==='base'&&ta[toIdx])questProg('assign_base');
  refreshPartyBar();saveGame();
}
function onDragOverSlot(e){e.preventDefault();e.currentTarget.classList.add('dov');}
function startMousePalDrag(zone,idx,def,e){_drag={zone,idx,def};e.dataTransfer.effectAllowed='move';}
function endMousePalDrop(zone,idx){if(!_drag)return;movePal(_drag.zone,_drag.idx,zone,idx);_drag=null;refreshPBUI();refreshPartyBar();}
function startTouchPalDrag(zone,idx,def,e){_touchDrag={zone,idx,def};}
function endTouchPalDrop(zone,idx){if(!_touchDrag)return;movePal(_touchDrag.zone,_touchDrag.idx,zone,idx);_touchDrag=null;refreshPBUI();refreshPartyBar();}

// ═══════════════════════════════
// MINIMAP (biome colors)
// ═══════════════════════════════
const mm=document.getElementById('minimap'),mctx=mm.getContext('2d');
const MM_W=84,MM_H=84;
let _mmFrame=0;
function drawMinimap(){
  _mmFrame++;if(_mmFrame%4!==0)return; // Only update every 4 frames
  mctx.clearRect(0,0,MM_W,MM_H);
  const scaleX=MM_W/MAP_W,scaleY=MM_H/MAP_H;
  // Draw biome terrain (sample every 8 tiles for performance)
  const step=8;
  for(let r=0;r<ROWS;r+=step){
    for(let c=0;c<COLS;c+=step){
      const bId=biomeMap[r]?.[c]??0;
      mctx.fillStyle=BIOMES[bId].mmColor;
      mctx.fillRect(c*TILE*scaleX,r*TILE*scaleY,step*TILE*scaleX+1,step*TILE*scaleY+1);
    }
  }
  // Compass labels — N/S/E/W only, matches reference minimap
  const cx2=MM_W/2,cy2=MM_H/2;
  mctx.font='5px monospace';mctx.textAlign='center';mctx.fillStyle='rgba(255,255,255,0.60)';
  mctx.fillText('N',cx2,6);mctx.fillText('S',cx2,MM_H-1);
  mctx.textAlign='left';mctx.fillText('W',2,cy2+2);
  mctx.textAlign='right';mctx.fillText('E',MM_W-2,cy2+2);
  mctx.textAlign='left';
  // Draw structures
  // Draw boss zones on minimap
  for(let zi=0;zi<BOSS_ZONES.length;zi++){
    const bz=BOSS_ZONES[zi];
    const zx=bz.centerFx*MAP_W*scaleX,zy=bz.centerFy*MAP_H*scaleY,zr=bz.radius*Math.min(scaleX,scaleY);
    mctx.globalAlpha=0.20;mctx.fillStyle=bz.mmColor;mctx.beginPath();mctx.arc(zx,zy,zr,0,Math.PI*2);mctx.fill();
    mctx.globalAlpha=0.55;mctx.strokeStyle=bz.mmColor;mctx.lineWidth=1;mctx.beginPath();mctx.arc(zx,zy,zr,0,Math.PI*2);mctx.stroke();
    mctx.globalAlpha=1;
    const zs=zoneBossState[zi];
    if(zs.boss&&!zs.boss.dead){mctx.fillStyle=Math.floor(Date.now()/350)%2===0?'#ff4400':'#ffaa00';mctx.fillRect(zs.boss.x*scaleX-3,zs.boss.y*scaleY-3,6,6);}
  }
  // Pal Box only (no campfire/chest clutter)
  for(const s of structures){
    if(s.type==='palbox'){
      mctx.fillStyle='#a855f7';mctx.fillRect(s.x*scaleX-3,s.y*scaleY-3,6,6);
      mctx.strokeStyle='#c084fc';mctx.lineWidth=1;mctx.strokeRect(s.x*scaleX-3,s.y*scaleY-3,6,6);
    }
  }
  // Boss zone bosses (blinking red ◆)
  for(const b of bossPals){if(!b||b.dead)continue;mctx.fillStyle=Math.floor(Date.now()/400)%2===0?'#ff2200':'#ff8800';mctx.fillRect(b.x*scaleX-3,b.y*scaleY-3,6,6);}
  // ── NEARBY WILD PALS (simple colored dots, radius-filtered) ──
  // Rebuild candidate list every ~8 minimap updates to keep it cheap.
  if(!drawMinimap._mmEnemyCache||(_mmFrame%16===0)){
    // Show ALL nearby pals within radius, regardless of whether they are on-screen.
    const MM_RANGE=900; // world-units around player to show on minimap
    const RANGE2=MM_RANGE*MM_RANGE;
    const cand=[];
    for(let i=0;i<wildPals.length;i++){
      const w=wildPals[i];if(!w||w.dead)continue;
      const dx=w.x-PL.x,dy=w.y-PL.y;
      if(dx*dx+dy*dy>RANGE2)continue;
      cand.push(w);
    }
    drawMinimap._mmEnemyCache=cand;
  }
  const _eList=drawMinimap._mmEnemyCache;
  for(let i=0;i<_eList.length;i++){
    const w=_eList[i];if(!w||w.dead)continue;
    const r=w.rarity||'common';
    let col='#ffffff',sz=1.3;
    if(r==='legendary'){col='#ffd700';sz=2.0;}
    else if(r==='epic'){col='#cc44ff';sz=1.8;}
    else if(r==='rare'){col='#7dd3fc';sz=1.6;}
    mctx.fillStyle=col;
    mctx.beginPath();mctx.arc(w.x*scaleX,w.y*scaleY,sz,0,Math.PI*2);mctx.fill();
  }
  // Loot bags — pulsing yellow ✕ marker
  for(const b of lootBags){const blink=Math.floor(Date.now()/350)%2===0;mctx.fillStyle=blink?'#facc15':'#fde68a';mctx.fillRect(b.x*scaleX-2.5,b.y*scaleY-2.5,5,5);mctx.strokeStyle='#000';mctx.lineWidth=0.6;mctx.strokeRect(b.x*scaleX-2.5,b.y*scaleY-2.5,5,5);}
  // Party pals (green dots)
  for(let pi=0;pi<partyPals.length;pi++){const pp=partyPals[pi];if(!pp)continue;mctx.fillStyle='#4aff78';mctx.beginPath();mctx.arc(PL.x*scaleX+(pi-1)*3,PL.y*scaleY+5,1.5,0,Math.PI*2);mctx.fill();}
  // Active pal following player
  if(activePal&&!activePal.dead){mctx.fillStyle='#86efac';mctx.beginPath();mctx.arc(activePal.x*scaleX,activePal.y*scaleY,2,0,Math.PI*2);mctx.fill();}
  // Player — directional arrow
  const px=PL.x*scaleX,py=PL.y*scaleY;
  const facDir={right:0,down:Math.PI/2,left:Math.PI,up:-Math.PI/2}[PL.facing]||0;
  mctx.save();mctx.translate(px,py);mctx.rotate(facDir);
  mctx.fillStyle='#ffffff';mctx.beginPath();mctx.moveTo(4,0);mctx.lineTo(-2.5,2.5);mctx.lineTo(-1.5,0);mctx.lineTo(-2.5,-2.5);mctx.closePath();mctx.fill();
  mctx.restore();
  // Camera rect
  mctx.strokeStyle='rgba(255,255,255,.18)';mctx.lineWidth=0.8;mctx.strokeRect(cam.x*scaleX,cam.y*scaleY,visW()*scaleX,visH()*scaleY);
}

// ═══════════════════════════════
// POPUPS
// ═══════════════════════════════
const MAX_POPUPS=12;
function spawnPop(text,color){const _ex=document.querySelectorAll('.popup');if(_ex.length>=MAX_POPUPS)try{_ex[0].remove();}catch(_){}const p=document.createElement('div');p.className='popup';p.style.cssText='left:50%;top:38%;color:'+color+';transform:translateX(-50%)';p.textContent=text;document.body.appendChild(p);setTimeout(()=>p.remove(),920);}
function popAt(text,color,wx2,wy2){if(document.querySelectorAll('.popup').length>=MAX_POPUPS)return;const sx=wx(wx2),sy=wy(wy2);const p=document.createElement('div');p.className='popup';p.style.cssText='left:'+sx+'px;top:'+sy+'px;color:'+color;p.textContent=text;document.body.appendChild(p);setTimeout(()=>p.remove(),920);}

// ═══════════════════════════════
// JOYSTICK
// ═══════════════════════════════
(function(){
  const zone=document.getElementById('joy-zone'),stick=document.getElementById('joy-stick');
  const R=52,cr=zone.getBoundingClientRect;
  let _tid=null;
  function getCenter(){const b=zone.getBoundingClientRect();return{cx:b.left+b.width/2,cy:b.top+b.height/2};}
  function setStick(dx,dy){const d=Math.min(Math.hypot(dx,dy),R);const a=Math.atan2(dy,dx);stick.style.transform='translate(calc(-50% + '+(Math.cos(a)*d)+'px), calc(-50% + '+(Math.sin(a)*d)+'px))';}
  function resetStick(){stick.style.transform='translate(-50%,-50%)';joy.ax=0;joy.ay=0;joy.active=false;}
  zone.addEventListener('touchstart',e=>{e.preventDefault();const t=e.changedTouches[0];_tid=t.identifier;const{cx,cy}=getCenter();const dx=t.clientX-cx,dy=t.clientY-cy;setStick(dx,dy);const d=Math.min(Math.hypot(dx,dy),R)||1;joy.ax=dx/d;joy.ay=dy/d;joy.active=true;},{passive:false});
  zone.addEventListener('touchmove',e=>{e.preventDefault();for(const t of e.changedTouches){if(t.identifier!==_tid)continue;const{cx,cy}=getCenter();const dx=t.clientX-cx,dy=t.clientY-cy;setStick(dx,dy);const d=Math.min(Math.hypot(dx,dy),R)||1;joy.ax=dx/d;joy.ay=dy/d;joy.active=true;}},{passive:false});
  zone.addEventListener('touchend',e=>{for(const t of e.changedTouches)if(t.identifier===_tid){resetStick();break;}},{passive:false});
  // Keyboard
  const keys={};document.addEventListener('keydown',e=>{keys[e.key]=true;updateJoyFromKeys();});
  document.addEventListener('keyup',e=>{delete keys[e.key];updateJoyFromKeys();});
  function updateJoyFromKeys(){
    let ax=0,ay=0;
    if(keys['ArrowLeft']||keys['a']||keys['A'])ax-=1;
    if(keys['ArrowRight']||keys['d']||keys['D'])ax+=1;
    if(keys['ArrowUp']||keys['w']||keys['W'])ay-=1;
    if(keys['ArrowDown']||keys['s']||keys['S'])ay+=1;
    if(keys[' ']){doAttack();}
    if(ax||ay){const l=Math.hypot(ax,ay)||1;joy.ax=ax/l;joy.ay=ay/l;joy.active=true;setStick(ax*R,ay*R);}
    else{resetStick();}
  }
})();

// ═══════════════════════════════
// SAVE / LOAD
// ═══════════════════════════════
// === Multi-world save system ===
const WORLDS_IDX_KEY='palworld_worlds_idx';
const ACTIVE_WORLD_KEY='palworld_active_world';
const LEGACY_SAVE_KEY='palworld_save';
const SAVE_VERSION=3;
let activeWorldId=null;
let _playStartT=Date.now();
let _saving=false;
function _saveKey(id){return 'palworld_save_'+id;}
function _readWorldsIdx(){try{const r=localStorage.getItem(WORLDS_IDX_KEY);if(!r)return [];const a=JSON.parse(r);return Array.isArray(a)?a:[];}catch(e){return [];}}
function _writeWorldsIdx(arr){try{localStorage.setItem(WORLDS_IDX_KEY,JSON.stringify(arr));}catch(e){}}
function listWorlds(){return _readWorldsIdx();}
function createWorld(name){
  const idx=_readWorldsIdx();
  const id='w'+Date.now()+'_'+Math.floor(Math.random()*1e6);
  let nm=(name||'').trim();
  if(!nm){let n=1;const used=new Set(idx.map(w=>w.name));while(used.has('World '+n))n++;nm='World '+n;}
  nm=nm.slice(0,24);
  idx.push({id,name:nm,createdAt:Date.now(),lastPlayed:Date.now(),level:1,playMs:0});
  _writeWorldsIdx(idx);
  return id;
}
function deleteWorldById(id){
  const idx=_readWorldsIdx().filter(w=>w.id!==id);
  _writeWorldsIdx(idx);
  try{localStorage.removeItem(_saveKey(id));}catch(e){}
}
function _updateWorldMeta(id,patch){
  const idx=_readWorldsIdx();
  const w=idx.find(x=>x.id===id);
  if(w){Object.assign(w,patch);_writeWorldsIdx(idx);}
}
function setActiveWorld(id){activeWorldId=id;try{localStorage.setItem(ACTIVE_WORLD_KEY,id);}catch(e){}}
function clearActiveWorld(){activeWorldId=null;try{localStorage.removeItem(ACTIVE_WORLD_KEY);}catch(e){}}
function _migrateLegacySave(){
  try{
    const idx=_readWorldsIdx();
    const legacy=localStorage.getItem(LEGACY_SAVE_KEY);
    if(legacy&&idx.length===0){
      const id=createWorld('World 1');
      localStorage.setItem(_saveKey(id),legacy);
      localStorage.removeItem(LEGACY_SAVE_KEY);
    }
  }catch(e){}
}
function showSaveIndicator(msg){
  try{const si=document.getElementById('save-indicator');si.textContent=msg||'💾 SAVED';si.classList.add('show');setTimeout(()=>si.classList.remove('show'),1400);}catch(e){}
}
function saveGame(){
  if(!activeWorldId)return;
  if(_saving)return; // mutex — only one save at a time
  _saving=true;
  try{
    // Validate player position — guard against NaN/Infinity corrupting the save
    const _px=typeof PL.x==='number'&&isFinite(PL.x)?PL.x:MAP_W/2;
    const _py=typeof PL.y==='number'&&isFinite(PL.y)?PL.y:MAP_H/2;
    // Serialize a pal as lightweight data (def name only, not full def object)
    function _sPal(p){
      if(!p||!p.def||!p.def.name)return null;
      const lv=Math.max(1,p.level||1);
      const mh=typeof p.maxHp==='number'&&p.maxHp>0?p.maxHp:p.def.baseHp+lv*2;
      const h=typeof p.hp==='number'&&isFinite(p.hp)?Math.max(0,Math.min(mh,p.hp)):mh;
      return{defName:p.def.name,level:lv,xp:p.xp||0,xpNeeded:p.xpNeeded||xpToNext(lv),hp:h,maxHp:mh};
    }
    const data={
      version:SAVE_VERSION,
      player:{x:_px,y:_py,hp:PL.hp,maxHp:PL.maxHp,level:PL.level,xp:PL.xp,xpNeeded:PL.xpNeeded,speed:PL.speed,hunger:PL.hunger,maxHunger:PL.maxHunger},
      inv:playerInv,
      equipped:{weapon:equipped.weapon||null,armor:equipped.armor||null,axe:equipped.axe||'wood',pickaxe:equipped.pickaxe||'wood'},
      partyPals:partyPals.map(_sPal),
      boxPals:boxPals.map(_sPal),
      basePals:basePals.filter(p=>p&&p.def&&p.def.name&&typeof p.x==='number'&&isFinite(p.x)).map(p=>{const lv=Math.max(1,p.level||1);return{defName:p.def.name,level:lv,xp:p.xp||0,xpNeeded:p.xpNeeded||xpToNext(lv),x:p.x,y:p.y};}),
      structures:structures.map(s=>({type:s.type,x:s.x,y:s.y,chestInv:s.chestInv})),
      questIdx,qC,boxCap,baseWorkerLimit,palBoxLevel,
      skills:{points:PlayerSkills.points,damage:PlayerSkills.damage.level,hp:PlayerSkills.hp.level,atkSpd:PlayerSkills.atkSpd.level,moveSpd:PlayerSkills.moveSpd.level,harvest:PlayerSkills.harvest.level,hunger:PlayerSkills.hunger.level,capture:PlayerSkills.capture.level,palDmg:PlayerSkills.palDmg.level},
      paldex:{seen:Paldex.seen,captured:Paldex.captured},
      tech:{points:Tech.points,unlocked:Tech.unlocked},
      Stats,
      zoneBosses:zoneBossState.map(zs=>({respawnTimer:zs.respawnTimer||0})),
      lootBags:lootBags.map(b=>({x:b.x,y:b.y,items:b.items})),
      // NPC + Mount state written here — eliminates the double read-parse-write hooks
      coins:typeof PL.coins==='number'?PL.coins:0,
      npc:typeof NpcState!=='undefined'?{done:NpcState.done||0,task:NpcState.task||null,progress:NpcState.progress||0}:undefined,
      mount:typeof Mount!=='undefined'?{saddle:!!Mount.saddle,bossDefeated:!!Mount.bossDefeated,capturedCount:(Mount.capturedCount)|0}:undefined,
      // Gear system
      gearBag:typeof gearBag!=='undefined'?gearBag:undefined,
      equippedId:typeof equippedId!=='undefined'?{weapon:equippedId.weapon||null,axe:equippedId.axe||null,pickaxe:equippedId.pickaxe||null,armor:equippedId.armor||null}:undefined,
      _gearGid:typeof _gearGid!=='undefined'?_gearGid:undefined,
      // Audio / world state
      sndEnabled:typeof sndEnabled!=='undefined'?!!sndEnabled:undefined,
      time:typeof TimeSys!=='undefined'?{t:TimeSys.t,phase:TimeSys.phase}:undefined,
      weather:typeof WX!=='undefined'?{state:WX.state,t:WX.t,dur:WX.dur,alpha:WX.alpha,bloodMoon:!!WX.bloodMoon}:undefined,
    };
    localStorage.setItem(_saveKey(activeWorldId),JSON.stringify(data));
    const cur=_readWorldsIdx().find(w=>w.id===activeWorldId);
    const prevPlay=(cur&&cur.playMs)||0;
    _updateWorldMeta(activeWorldId,{lastPlayed:Date.now(),level:PL.level||1,playMs:prevPlay+(Date.now()-_playStartT)});
    _playStartT=Date.now();
    showSaveIndicator('💾 SAVED');
  }catch(e){}
  finally{_saving=false;}
}
function loadGame(){
  if(!activeWorldId)return false;
  // Reconstruct a pal from saved lightweight data. Handles both new format (defName
  // string) and old format (def as full object). Returns null if pal is unrecoverable.
  function _lPal(p){
    if(!p)return null;
    const nm=typeof p.defName==='string'?p.defName:(p.def&&typeof p.def.name==='string'?p.def.name:null);
    if(!nm)return null;
    const def=PAL_TYPES.find(t=>t.name===nm);
    if(!def)return null;
    const lv=Math.max(1,p.level||1);
    const mh=typeof p.maxHp==='number'&&p.maxHp>0?p.maxHp:def.baseHp+lv*2;
    const h=Math.max(1,Math.min(mh,typeof p.hp==='number'&&isFinite(p.hp)?p.hp:mh));
    return{def,level:lv,xp:p.xp||0,xpNeeded:p.xpNeeded||xpToNext(lv),hp:h,maxHp:mh};
  }
  let raw=null;
  try{raw=localStorage.getItem(_saveKey(activeWorldId));}catch(e){return false;}
  if(!raw)return false;
  let d=null;
  try{d=JSON.parse(raw);}catch(e){
    // JSON is malformed — do NOT delete, just skip loading so player gets safe spawn
    return false;
  }
  if(!d||typeof d!=='object')return false;
  // Each block is wrapped independently — one bad field never kills the whole load
  try{if(d.inv&&Array.isArray(d.inv))for(let i=0;i<d.inv.length;i++)playerInv[i]=d.inv[i]||null;}catch(e){}
  try{if(d.partyPals&&Array.isArray(d.partyPals))for(let i=0;i<PARTY_MAX;i++)partyPals[i]=_lPal(d.partyPals[i]);}catch(e){}
  try{if(d.boxPals&&Array.isArray(d.boxPals)){boxPals.length=0;d.boxPals.forEach(p=>boxPals.push(_lPal(p)));}}catch(e){}
  try{if(d.basePals&&Array.isArray(d.basePals)){
    basePals.length=0;
    d.basePals.forEach(p=>{
      if(!p)return;
      const nm=typeof p.defName==='string'?p.defName:(p.def&&typeof p.def.name==='string'?p.def.name:null);
      if(!nm)return;
      const def=PAL_TYPES.find(t=>t.name===nm);
      if(!def)return;
      const bx=typeof p.x==='number'&&isFinite(p.x)?p.x:MAP_W/2;
      const by=typeof p.y==='number'&&isFinite(p.y)?p.y:MAP_H/2;
      const lv=Math.max(1,p.level||1);
      const mh=typeof p.maxHp==='number'&&p.maxHp>0?p.maxHp:def.baseHp+lv*2;
      const h=Math.max(1,Math.min(mh,typeof p.hp==='number'&&isFinite(p.hp)?p.hp:mh));
      basePals.push({def,level:lv,xp:p.xp||0,xpNeeded:p.xpNeeded||xpToNext(lv),hp:h,maxHp:mh,x:bx,y:by,vx:0,vy:0,id:Math.random(),hT:4000,abCD:def.ability?.cd||3000});
    });
  }}catch(e){}
  try{if(d.equipped){equipped.weapon=d.equipped.weapon||null;equipped.armor=d.equipped.armor||null;equipped.axe=d.equipped.axe||'wood';equipped.pickaxe=d.equipped.pickaxe||'wood';}}catch(e){}
  try{if(typeof d.questIdx==='number')questIdx=d.questIdx;}catch(e){}
  try{if(d.qC&&typeof d.qC==='object')Object.assign(qC,d.qC);}catch(e){}
  try{if(typeof d.boxCap==='number')boxCap=d.boxCap;}catch(e){}
  try{if(typeof d.baseWorkerLimit==='number')baseWorkerLimit=Math.min(BASE_HARD_CAP,d.baseWorkerLimit);}catch(e){}
  try{if(typeof d.palBoxLevel==='number'){palBoxLevel=Math.max(1,Math.min(5,d.palBoxLevel|0));baseWorkerLimit=Math.min(BASE_HARD_CAP,Math.max(baseWorkerLimit,PB_LV_BASE[palBoxLevel-1]));}}catch(e){}
  try{if(d.lootBags&&Array.isArray(d.lootBags)){lootBags.length=0;d.lootBags.forEach(b=>{if(b&&Array.isArray(b.items))lootBags.push({x:b.x,y:b.y,items:b.items,id:Math.random(),bobT:Math.random()*Math.PI*2,life:LOOT_BAG_LIFE});});}}catch(e){}
  try{if(d.structures&&Array.isArray(d.structures))for(const s of d.structures){const sd=STRUCT_DEF[s.type];if(sd)structures.push({type:s.type,x:s.x,y:s.y,hw:sd.hw,hh:sd.hh,chestInv:s.chestInv||createInv(8)});}}catch(e){}
  try{if(d.Stats&&typeof d.Stats==='object')Object.assign(Stats,d.Stats);}catch(e){}
  try{if(d.zoneBosses&&Array.isArray(d.zoneBosses)){d.zoneBosses.forEach((zb,i)=>{if(zoneBossState[i]&&typeof zb.respawnTimer==='number')zoneBossState[i].respawnTimer=zb.respawnTimer;});}}catch(e){}
  // Support both new format (player) and old format (PL). Validate coords against NaN.
  const pl=d.player||d.PL;
  try{if(pl&&typeof pl==='object'){
    const _nx=typeof pl.x==='number'&&isFinite(pl.x)&&pl.x>0&&pl.x<MAP_W?pl.x:MAP_W/2;
    const _ny=typeof pl.y==='number'&&isFinite(pl.y)&&pl.y>0&&pl.y<MAP_H?pl.y:MAP_H/2;
    PL.x=_nx;PL.y=_ny;
    if(typeof pl.hp==='number'&&pl.hp>0)PL.hp=pl.hp;
    if(typeof pl.maxHp==='number'&&pl.maxHp>0)PL.maxHp=pl.maxHp;
    if(typeof pl.level==='number'&&pl.level>0)PL.level=pl.level;
    if(typeof pl.xp==='number')PL.xp=pl.xp;
    if(typeof pl.xpNeeded==='number'&&pl.xpNeeded>0)PL.xpNeeded=pl.xpNeeded;
    if(typeof pl.speed==='number'&&pl.speed>0)PL.speed=pl.speed;
    if(typeof pl.hunger==='number')PL.hunger=Math.max(0,pl.hunger);
    if(typeof pl.maxHunger==='number'&&pl.maxHunger>0)PL.maxHunger=pl.maxHunger;
  }}catch(e){}
  try{if(d.skills&&typeof d.skills==='object'){PlayerSkills.points=d.skills.points||0;PlayerSkills.damage.level=d.skills.damage||0;PlayerSkills.hp.level=d.skills.hp||0;PlayerSkills.atkSpd.level=d.skills.atkSpd||0;PlayerSkills.moveSpd.level=d.skills.moveSpd||0;PlayerSkills.harvest.level=d.skills.harvest||0;PlayerSkills.hunger.level=d.skills.hunger||0;PlayerSkills.capture.level=d.skills.capture||0;PlayerSkills.palDmg.level=d.skills.palDmg||0;}}catch(e){}
  try{if(d.paldex&&typeof d.paldex==='object'){if(d.paldex.seen&&typeof d.paldex.seen==='object')Object.assign(Paldex.seen,d.paldex.seen);if(d.paldex.captured&&typeof d.paldex.captured==='object')Object.assign(Paldex.captured,d.paldex.captured);}}catch(e){}
  try{if(d.tech&&typeof d.tech==='object'){if(typeof d.tech.points==='number')Tech.points=d.tech.points;if(d.tech.unlocked&&typeof d.tech.unlocked==='object')Object.assign(Tech.unlocked,d.tech.unlocked);}}catch(e){}
  // Coins, NPC, Mount — loaded here in base so hooks are not needed for reads either
  try{if(typeof d.coins==='number')PL.coins=d.coins;}catch(e){}
  try{if(d.npc&&typeof NpcState!=='undefined'){NpcState.done=d.npc.done||0;NpcState.task=d.npc.task||null;NpcState.progress=d.npc.progress||0;}}catch(e){}
  try{if(d.mount&&typeof Mount!=='undefined'){Mount.saddle=!!d.mount.saddle;Mount.bossDefeated=!!d.mount.bossDefeated;Mount.capturedCount=d.mount.capturedCount|0;}}catch(e){}
  // Gear bag — also applied here when the overrides have not yet been wired (boot-time call).
  // The gear override at the bottom repeats this load for explicit loadGame() calls made later;
  // having it here too means the very first boot call always gets fresh gear data.
  try{
    if(d.gearBag&&Array.isArray(d.gearBag)&&typeof gearBag!=='undefined'){
      gearBag=d.gearBag;
      if(d.equippedId&&typeof equippedId!=='undefined'){
        equippedId.weapon=d.equippedId.weapon||null;
        equippedId.axe=d.equippedId.axe||null;
        equippedId.pickaxe=d.equippedId.pickaxe||null;
        equippedId.armor=d.equippedId.armor||null;
      }
      if(typeof d._gearGid==='number'&&d._gearGid>0&&typeof _gearGid!=='undefined')_gearGid=d._gearGid;
    }
  }catch(_ge){}
  // Minimap cache — force rebuild so the next draw reflects freshly-loaded entity arrays
  try{if(typeof drawMinimap==='function')drawMinimap._mmEnemyCache=null;}catch(_e){}
  return true;
}

// ═══════════════════════════════
// DUNGEON SYSTEM
// ═══════════════════════════════
let inDungeon=false,dungeonPhase=0,dungeonKillCount=0;
let dungeonEntryX=MAP_W/2,dungeonEntryY=MAP_H/2;
const dungeonGates=[];
const dungeonEnemies=[];
let dungeonBossObj=null;
const DUNGEON_ENEMY_DEFS=[
  {name:'Cave Stalker',emoji:'🐾',bodyCol:'#2a1a3a',eyeCol:'#ff2200',tailCol:'#1a0a2a',size:14,baseHp:22,baseDmg:4,
   ability:{name:'Claw Slash',type:'dark',color:'#cc22ff',dmg:4,range:55,cd:1700,pc:7},
   special:{name:'Dark Rush',emoji:'⚡',color:'#8800ff',dmg:7,range:65,cd:5500,effect:'shake',pc:10,shake:7}},
  {name:'Stone Wraith',emoji:'👻',bodyCol:'#3a3a4a',eyeCol:'#aaaaff',tailCol:'#2a2a3a',size:13,baseHp:18,baseDmg:3,
   ability:{name:'Haunt',type:'dark',color:'#6666ff',dmg:3,range:60,cd:1900,pc:6},
   special:{name:'Phantom Strike',emoji:'💀',color:'#4444ff',dmg:6,range:70,cd:5000,effect:'stun',pc:9,stunTime:800}},
];
const DUNGEON_BOSS_DEF={name:'Dungeon Lord',emoji:'👹',bodyCol:'#3a0010',eyeCol:'#ff4400',tailCol:'#500020',size:26,baseHp:120,baseDmg:8,
  ability:{name:'Crush',type:'dark',color:'#ff0000',dmg:8,range:80,cd:1600,pc:16},isBoss:true,rare:true};

(function initDungeonGates(){
  const mid=0.36;
  dungeonGates.push({x:MAP_W*(0.5+mid),y:MAP_H*(0.5-mid*0.6),active:true,anim:0});
  dungeonGates.push({x:MAP_W*(0.5-mid*0.8),y:MAP_H*(0.5+mid),active:true,anim:0});
})();

function nearestDungeonGate(px,py){
  if(inDungeon)return null;
  let best=null,bd=Infinity;
  for(const g of dungeonGates){if(!g.active)continue;const d=Math.hypot(px-g.x,py-g.y);if(d<80&&d<bd){bd=d;best=g;}}
  return best;
}

function _showDungeonCancelBtn(show){const el=document.getElementById('dungeon-cancel-btn');if(el)el.classList.toggle('show',show);}

function enterDungeon(gate){
  if(inDungeon||dungeonPhase!==0)return;
  console.log('[WORLD] Entering dungeon — PL pos',(PL.x|0)+','+(PL.y|0));
  dungeonEntryX=PL.x;dungeonEntryY=PL.y;
  inDungeon=true;dungeonPhase=1;dungeonKillCount=0;
  dungeonEnemies.length=0;dungeonBossObj=null;
  _showDungeonCancelBtn(true);
  spawnPop('⚔️ ENTERING DUNGEON…','#cc44ff');
  // Spawn wave 1: 5 dungeon enemies around player
  for(let i=0;i<5;i++){
    const a=i/5*Math.PI*2,r=140+Math.random()*60;
    const def=DUNGEON_ENEMY_DEFS[i%DUNGEON_ENEMY_DEFS.length];
    const lv=Math.max(PL.level,4)+Math.floor(Math.random()*3);
    const hp=def.baseHp+lv*5;
    dungeonEnemies.push({def,x:PL.x+Math.cos(a)*r,y:PL.y+Math.sin(a)*r,hp,maxHp:hp,level:lv,dead:false,id:Math.random(),aF:0,aT:0,shakeT:0,vx:0,vy:0,wT:1000,abCD:def.ability.cd,skCD:def.special.cd*0.5,_deadT:0});
  }
  setTimeout(()=>spawnPop('⚠️ Defeat all enemies! ('+dungeonEnemies.length+' remain)','#ff8866'),600);
}

function exitDungeon(){
  console.log('[WORLD] Exiting dungeon — returning to',(dungeonEntryX|0)+','+(dungeonEntryY|0));
  inDungeon=false;dungeonPhase=0;
  PL.x=dungeonEntryX;PL.y=dungeonEntryY;
  // FIX: ensure player is not stuck dead after dungeon exit
  if(PL.dead&&PL.hp>0){PL.dead=false;PL.invT=1500;console.log('[WORLD] Cleared stuck PL.dead on dungeon exit');}
  dungeonEnemies.length=0;dungeonBossObj=null;
  _showDungeonCancelBtn(false);
  cam.x=Math.max(0,Math.min(PL.x-visW()/2,MAP_W-visW()));
  cam.y=Math.max(0,Math.min(PL.y-visH()/2,MAP_H-visH()));
  // FIX: force context reset on world re-entry to clear any dungeon alpha state
  try{ctx.globalAlpha=1;ctx.setTransform(1,0,0,1,0,0);}catch(_e){}
  spawnPop('🏠 Returned from dungeon!','#4aff78');
}

function cancelDungeon(){
  if(!inDungeon)return;
  // Despawn all dungeon enemies immediately
  dungeonEnemies.length=0;
  dungeonBossObj=null;
  // Clear dungeon state
  inDungeon=false;dungeonPhase=0;dungeonKillCount=0;
  // Return player to where they entered
  PL.x=dungeonEntryX;PL.y=dungeonEntryY;
  // Clear combat/stun lock
  PL.stunT=0;PL.invT=600;PL.swT=0;
  // Reset all wild pal aggro on player (so they don't immediately chase)
  for(const wp of wildPals){if(wp.aggroId==='PLAYER')wp.aggroId=null;}
  _showDungeonCancelBtn(false);
  cam.x=Math.max(0,Math.min(PL.x-visW()/2,MAP_W-visW()));
  cam.y=Math.max(0,Math.min(PL.y-visH()/2,MAP_H-visH()));
  spawnPop('🚫 Dungeon cancelled — returned safely','#f87171');
}

function dungeonRewards(){
  spawnPop('🎉 DUNGEON CLEARED! Claiming rewards…','#ffd700');
  iAdd(playerInv,'copper',8+Math.floor(Math.random()*8));
  iAdd(playerInv,'stone',10+Math.floor(Math.random()*10));
  iAdd(playerInv,'wood',8+Math.floor(Math.random()*6));
  iAdd(playerInv,'sphere',2+Math.floor(Math.random()*3));
  gainPlayerXP(80+PL.level*12);
  updResUI();
  // Rare pal drop chance
  if(Math.random()<0.55){
    const rare=PAL_TYPES.filter(p=>p.rare);
    const rd=rare[Math.floor(Math.random()*rare.length)];
    const lv=Math.max(4,PL.level)+1;const hp=rd.baseHp+lv*2;
    wildPals.push({def:rd,x:PL.x+Math.cos(Math.random()*Math.PI*2)*80,y:PL.y+Math.sin(Math.random()*Math.PI*2)*80,hp,maxHp:hp,level:lv,xp:0,xpNeeded:xpToNext(lv),dead:false,id:Math.random(),aF:0,aT:0,shakeT:0,vx:0,vy:0,wT:1500,abCD:rd.ability.cd,skCD:rd.special?.cd||9999,rarity:'rare',dmgBonus:1,sizeBonus:2});
    spawnPop('⭐ Rare Pal appeared!','#facc15');
  }
  setTimeout(()=>spawnPop('Tap ⚔️ to EXIT DUNGEON','#88ffcc'),1400);
  setTimeout(()=>saveGame(),500);
}

function updDungeon(dt){
  if(!inDungeon)return;
  // Update dungeon gate animation
  for(const g of dungeonGates)g.anim=(g.anim||0)+dt;
  // Update dungeon enemies
  for(let i=dungeonEnemies.length-1;i>=0;i--){
    const e=dungeonEnemies[i];
    if(e.dead){e._deadT=(e._deadT||0)+dt;if(e._deadT>700)dungeonEnemies.splice(i,1);continue;}
    const dx=PL.x-e.x,dy=PL.y-e.y,dist=Math.hypot(dx,dy);
    if(!PL.dead){const spd=0.9+e.level*0.06;moveWithColl(e,dx/dist*spd,dy/dist*spd,10,10);}
    e.aT+=dt;if(e.aT>200){e.aF=(e.aF+1)%4;e.aT=0;}
    if(e.shakeT>0)e.shakeT=Math.max(0,e.shakeT-dt);
    e.abCD-=dt;
    if(e.abCD<=0&&dist<e.def.ability.range&&!PL.dead){
      e.abCD=e.def.ability.cd+(Math.random()*300-150);
      hurtPL(e.def.baseDmg+Math.floor(e.level/3));
      addPart(e.x,e.y,e.def.ability.color,e.def.ability.pc);
    }
    if(e.def.special){
      e.skCD=(e.skCD||9999)-dt;
      if(e.skCD<=0&&dist<(e.def.special.range||70)&&Math.random()<0.28&&!PL.dead){
        e.skCD=e.def.special.cd+(Math.random()*1000);
        const sk=e.def.special;
        hurtPL(sk.dmg+Math.floor(e.level/2));
        addPart(e.x,e.y,sk.color,sk.pc||8);
        for(let j=0;j<4;j++)addPart(e.x+(Math.random()-.5)*26,e.y+(Math.random()-.5)*26,sk.color,1);
        popAt((sk.emoji||'✨')+' '+sk.name+'!',sk.color,e.x,e.y-26);
        if(sk.effect==='stun'&&PL.stunT<=0){PL.stunT=sk.stunTime||700;flashStun();}
        if(sk.effect==='shake')doShake(sk.shake||6);
      }
    }
  }
  // Update dungeon boss
  if(dungeonBossObj&&!dungeonBossObj.dead){
    const b=dungeonBossObj;
    const dx=PL.x-b.x,dy=PL.y-b.y,dist=Math.hypot(dx,dy);
    if(!PL.dead){const spd=0.7+b.level*0.05;moveWithColl(b,dx/dist*spd,dy/dist*spd,16,16);}
    b.aT+=dt;if(b.aT>180){b.aF=(b.aF+1)%4;b.aT=0;}
    if(b.shakeT>0)b.shakeT=Math.max(0,b.shakeT-dt);
    b.abCD-=dt;
    if(b.abCD<=0&&dist<DUNGEON_BOSS_DEF.ability.range&&!PL.dead){
      b.abCD=DUNGEON_BOSS_DEF.ability.cd+(Math.random()*400-200);
      hurtPL(DUNGEON_BOSS_DEF.baseDmg+Math.floor(b.level/2));
      addPart(b.x,b.y,DUNGEON_BOSS_DEF.ability.color,DUNGEON_BOSS_DEF.ability.pc);
      doShake(6);
    }
  }
  if(dungeonBossObj&&dungeonBossObj.dead){
    dungeonBossObj._deadT=(dungeonBossObj._deadT||0)+dt;
    if(dungeonBossObj._deadT>900&&dungeonPhase===2){dungeonPhase=3;dungeonRewards();}
  }
  // Phase transitions
  if(dungeonPhase===1){
    const alive=dungeonEnemies.filter(e=>!e.dead).length;
    if(alive===0&&dungeonEnemies.length>0&&!dungeonBossObj){
      dungeonPhase=2;
      // Spawn mini boss
      const bLv=Math.max(PL.level+2,6);const bHp=DUNGEON_BOSS_DEF.baseHp+bLv*6;
      dungeonBossObj={x:PL.x+Math.cos(Math.random()*Math.PI*2)*160,y:PL.y+Math.sin(Math.random()*Math.PI*2)*160,hp:bHp,maxHp:bHp,level:bLv,dead:false,_deadT:0,id:Math.random(),aF:0,aT:0,shakeT:0,abCD:DUNGEON_BOSS_DEF.ability.cd*0.5};
      spawnPop('👹 DUNGEON LORD APPEARS!','#ff4444');doShake(10);
    }
  }
}

function drawDungeonGates(dt){
  for(const g of dungeonGates){
    if(!onScreen(g.x-30,g.y-50,60,60))continue;
    const z=ZOOM,sx=wx(g.x),sy=wy(g.y);
    const t=(g.anim||0)*0.002;
    // Portal glow
    const glowR=(24+Math.sin(t)*4)*z;
    const grad=ctx.createRadialGradient(sx,sy,0,sx,sy,glowR);
    grad.addColorStop(0,'rgba(160,60,255,.55)');grad.addColorStop(1,'rgba(100,0,200,0)');
    ctx.fillStyle=grad;ctx.beginPath();ctx.arc(sx,sy,glowR,0,Math.PI*2);ctx.fill();
    // Portal ring
    ctx.strokeStyle='#cc44ff';ctx.lineWidth=3*z;
    ctx.beginPath();ctx.arc(sx,sy,16*z,0,Math.PI*2);ctx.stroke();
    ctx.strokeStyle='rgba(200,100,255,.4)';ctx.lineWidth=1.5*z;
    ctx.beginPath();ctx.arc(sx,sy,(16+Math.sin(t*1.5)*3)*z,0,Math.PI*2);ctx.stroke();
    // Portal emoji
    ctx.font=\`\${Math.round(18*z)}px serif\`;ctx.textAlign='center';ctx.fillText('🌀',sx,sy+6*z);ctx.textAlign='left';
    // Label
    if(Math.hypot(PL.x-g.x,PL.y-g.y)<120){
      ctx.fillStyle='#cc44ff';ctx.font=Math.round(7*z)+'px Courier New';ctx.textAlign='center';
      ctx.fillText('DUNGEON GATE',sx,sy-20*z);ctx.textAlign='left';
    }
  }
  void dt;
}

function drawDungeonEnemy(e){
  if(e.dead){const a=Math.max(0,1-(e._deadT||0)/700);ctx.globalAlpha=a;drawPalBody(e.def,e.def.size*0.7,wx(e.x),wy(e.y)+8*ZOOM*a,ZOOM);ctx.globalAlpha=1;return;}
  if(!onScreen(e.x-e.def.size*2,e.y-e.def.size*3,e.def.size*4,e.def.size*5))return;
  const z=ZOOM,sz=e.def.size,sx=wx(e.x),sy=wy(e.y);
  const bob=Math.sin(Date.now()*.003+e.id*22)*1.5*z;
  if(e.shakeT>0){const sk=(Math.random()-.5)*4*(e.shakeT/200)*z;ctx.save();ctx.translate(sk,0);}
  drawPalBody(e.def,sz,sx,sy+bob,z);
  ctx.strokeStyle='rgba(200,100,255,.6)';ctx.lineWidth=2*z;ctx.beginPath();ctx.arc(sx,sy+bob,(sz+3)*z,0,Math.PI*2);ctx.stroke();
  const tag=e.def.name+' Lv'+e.level;const tw=ctx.measureText(tag).width;
  ctx.font=Math.round(6.5*z)+'px Courier New';
  ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillRect(sx-tw/2-2,sy+bob-(sz+14)*z,tw+4,9*z);
  ctx.fillStyle='#ff88cc';ctx.fillText(tag,sx-tw/2,sy+bob-(sz+7)*z);
  const hp=e.hp/e.maxHp;const bw=sz*3*z;
  ctx.fillStyle='#330';ctx.fillRect(sx-bw/2,sy+bob-(sz+22)*z,bw,5*z);
  ctx.fillStyle=hp>.5?'#f44':hp>.25?'#f80':'#a00';ctx.fillRect(sx-bw/2,sy+bob-(sz+22)*z,Math.round(bw*hp),5*z);
  if(e.shakeT>0)ctx.restore();
}

function drawDungeonBoss(){
  const b=dungeonBossObj;if(!b)return;
  if(b.dead){const a=Math.max(0,1-(b._deadT||0)/900);ctx.globalAlpha=a;drawPalBody(DUNGEON_BOSS_DEF,DUNGEON_BOSS_DEF.size*0.7,wx(b.x),wy(b.y),ZOOM);ctx.globalAlpha=1;return;}
  if(!onScreen(b.x-40,b.y-50,80,80))return;
  const d=DUNGEON_BOSS_DEF,z=ZOOM,sz=d.size,sx=wx(b.x),sy=wy(b.y);
  const bob=Math.sin(Date.now()*.0025+b.id*55)*3*z;
  const glowR=(sz+14+Math.sin(Date.now()*.002)*6)*z;
  const grad=ctx.createRadialGradient(sx,sy+bob,0,sx,sy+bob,glowR);
  grad.addColorStop(0,'rgba(255,0,60,.5)');grad.addColorStop(1,'rgba(180,0,0,0)');
  ctx.fillStyle=grad;ctx.beginPath();ctx.arc(sx,sy+bob,glowR,0,Math.PI*2);ctx.fill();
  if(b.shakeT>0){const sk=(Math.random()-.5)*7*(b.shakeT/200)*z;ctx.save();ctx.translate(sk,0);}
  drawPalBody(d,sz,sx,sy+bob,z);
  ctx.strokeStyle='rgba(255,60,60,.8)';ctx.lineWidth=3*z;ctx.beginPath();ctx.arc(sx,sy+bob,(sz+5)*z,0,Math.PI*2);ctx.stroke();
  ctx.font=\`\${Math.round(20*z)}px serif\`;ctx.textAlign='center';ctx.fillText('👑',sx,sy+bob-(sz+12)*z);ctx.textAlign='left';
  const hp=b.hp/b.maxHp;const bw=sz*5*z;
  ctx.fillStyle='#220000';ctx.fillRect(sx-bw/2,sy-(sz+18)*z,bw,8*z);
  ctx.fillStyle=hp>.5?'#f44':hp>.25?'#f80':'#a00';ctx.fillRect(sx-bw/2,sy-(sz+18)*z,Math.round(bw*hp),8*z);
  ctx.strokeStyle='#ff4444';ctx.lineWidth=z;ctx.strokeRect(sx-bw/2,sy-(sz+18)*z,bw,8*z);
  const tag='👹 DUNGEON LORD Lv'+b.level;const tw=ctx.measureText(tag).width;
  ctx.fillStyle='rgba(0,0,0,.8)';ctx.font=Math.round(8*z)+'px Courier New';ctx.fillRect(sx-tw/2-3,sy-(sz+28)*z,tw+6,11*z);
  ctx.fillStyle='#ff6666';ctx.fillText(tag,sx-tw/2,sy-(sz+18)*z);
  if(b.shakeT>0)ctx.restore();
}

function hurtDungeonEnemy(target,dmg){
  if(!target||target.dead)return;
  target.hp=Math.max(0,target.hp-dmg);target.shakeT=220;
  addPart(target.x,target.y,'#ff4444',4);
  if(target.hp<=0&&!target.dead){
    target.dead=true;target._deadT=0;
    playSnd('paldeath');addPart(target.x,target.y,'#ffcc44',8);
    const xp=target.level*5+20;gainPlayerXP(xp);popAt('+XP '+xp,'#facc15',target.x,target.y);
    dungeonKillCount++;
    const alive=dungeonEnemies.filter(e=>!e.dead).length;
    if(dungeonPhase===1&&alive>0)spawnPop((alive)+' enemies remain','#ff8866');
  }
}

function hurtDungeonBoss(dmg){
  const b=dungeonBossObj;if(!b||b.dead)return;
  b.hp=Math.max(0,b.hp-dmg);b.shakeT=250;
  addPart(b.x,b.y,'#ff4444',6);doShake(4);
  if(b.hp<=0&&!b.dead){
    b.dead=true;b._deadT=0;b.hp=0;
    playSnd('paldeath');doShake(12);
    for(let i=0;i<6;i++)addPart(b.x+(Math.random()-.5)*50,b.y+(Math.random()-.5)*50,'#ffd700',10);
    spawnPop('💥 DUNGEON LORD DEFEATED!','#ff4444');
  }
}

// ═══════════════════════════════
// EVENT SYSTEM
// ═══════════════════════════════
let _eventTimer=180000+Math.random()*60000;
let _resourceBoostT=0;

function showEventBanner(msg,color,duration){
  const el=document.getElementById('event-banner');
  if(!el)return;
  el.textContent=msg;el.style.color=color;el.style.borderColor=color;
  el.classList.add('show');
  setTimeout(()=>el.classList.remove('show'),duration||8000);
}

function triggerEvent(){
  if(PL.dead)return;
  _eventTimer=240000+Math.random()*120000;
  const type=Math.floor(Math.random()*5);
  if(type===0){
    // Rare pal appearance
    const palsDefs=PAL_TYPES.filter(p=>p.rare);
    for(let i=0;i<3;i++){
      const def=palsDefs[Math.floor(Math.random()*palsDefs.length)];
      const a=Math.random()*Math.PI*2,r=200+Math.random()*150;
      const ex=PL.x+Math.cos(a)*r,ey=PL.y+Math.sin(a)*r;
      const lv=PL.level+1+Math.floor(Math.random()*3);const hp=def.baseHp+lv*2;
      wildPals.push({def,x:ex,y:ey,hp,maxHp:hp,level:lv,xp:0,xpNeeded:xpToNext(lv),dead:false,id:Math.random(),aF:0,aT:0,shakeT:0,vx:0,vy:0,wT:2000,abCD:def.ability.cd,skCD:def.special?.cd||9999,rarity:'rare',dmgBonus:1,sizeBonus:2});
    }
    showEventBanner('⭐ EVENT: Rare Pals Appeared nearby!','#ffd700',12000);
  }else if(type===1){
    // Resource boost
    _resourceBoostT=35000;
    showEventBanner('✨ EVENT: Resource Boost! Double drops for 35s!','#4aff78',10000);
  }else if(type===2){
    // Danger wave
    spawnWild(10);
    const recent=wildPals.slice(-10);
    for(const p of recent){if(Math.random()<0.5)p.rarity='rare';p.level=Math.max(p.level,PL.level+1);}
    showEventBanner('☠️ EVENT: Danger Wave! Pals swarming!','#f87171',10000);
  }else if(type===3){
    // Resource cache — scatter loot drops near player
    const resTypes=['wood','stone','copper','coal'];
    for(let i=0;i<5;i++){
      const a=Math.random()*Math.PI*2,r=80+Math.random()*140;
      const t=resTypes[Math.floor(Math.random()*resTypes.length)];
      spawnDrop(t,2+Math.floor(Math.random()*3),PL.x+Math.cos(a)*r,PL.y+Math.sin(a)*r);
    }
    showEventBanner('💎 EVENT: Resource Cache! Loot scattered nearby!','#fb923c',10000);
  }else{
    // Legendary pal appearance
    const palsDefs=PAL_TYPES.filter(p=>p.rare);
    const def=palsDefs[Math.floor(Math.random()*palsDefs.length)];
    const a=Math.random()*Math.PI*2,r=160+Math.random()*100;
    const ex=PL.x+Math.cos(a)*r,ey=PL.y+Math.sin(a)*r;
    const lv=PL.level+3+Math.floor(Math.random()*3);const hp=def.baseHp+lv*3;
    wildPals.push({def,x:ex,y:ey,hp,maxHp:hp,level:lv,xp:0,xpNeeded:xpToNext(lv),dead:false,id:Math.random(),aF:0,aT:0,shakeT:0,vx:0,vy:0,wT:2000,abCD:def.ability.cd,skCD:def.special?.cd||9999,rarity:'legendary',dmgBonus:3,sizeBonus:6});
    showEventBanner('🌟 EVENT: LEGENDARY PAL appeared nearby!','#ffd700',14000);
    doShake(5);
  }
}

function updEvents(dt){
  if(inDungeon)return;
  _eventTimer-=dt;
  if(_eventTimer<=0)triggerEvent();
  if(_resourceBoostT>0)_resourceBoostT=Math.max(0,_resourceBoostT-dt);
}

// ═══════════════════════════════
// PAL RECOVERY
// ═══════════════════════════════
function updPalRecovery(){
  const now=Date.now();
  const allSlots=[...boxPals,...partyPals];
  let anyChanged=false;
  for(const p of allSlots){
    if(!p)continue;
    const mxhp=p.maxHp||(p.def.baseHp+(p.level||1)*2);
    if(p.fainted&&p.recoverAt){
      if(now>=p.recoverAt){p.hp=mxhp;p.maxHp=mxhp;p.fainted=false;delete p.recoverAt;spawnPop(p.def.emoji+' '+p.def.name+' fully recovered!','#4aff78');anyChanged=true;}
    } else if(!p.fainted&&p.hp<mxhp){
      // Slow passive heal for pals in box/party at rest
      const healAmt=Math.ceil(mxhp*0.04);
      p.hp=Math.min(mxhp,p.hp+healAmt);
      if(p.hp>=mxhp){p.hp=mxhp;anyChanged=true;}
    }
  }
  if(anyChanged){refreshPartyBar();refreshPBUI();}
}

// ═══════════════════════════════
// NEAR LABEL
// ═══════════════════════════════
let _nearLabelT=0;
function updNearLabel(){
  _nearLabelT+=16;if(_nearLabelT<120)return;_nearLabelT=0;
  const obj=nearestObj(PL.x,PL.y);
  const st=nearestStruct(PL.x,PL.y);
  const gate=nearestDungeonGate(PL.x,PL.y);
  let txt='';
  if(inDungeon&&dungeonPhase===3)txt='[🚪 TAP ⚔️ TO EXIT DUNGEON]';
  else if(gate)txt='[🌀 DUNGEON GATE — tap ⚔️]';
  else if(st)txt='{'+STRUCT_DEF[st.type].label+(st.type==='campfire'?' — tap ⚔️ to cook':'')+'}'; 
  else if(obj)txt='['+obj.type+' — tap ⚔️]';
  document.getElementById('near-label').textContent=txt;
}

// ═══════════════════════════════
// GAME LOOP
// ═══════════════════════════════
let lastT=0;
// Visual fallback: paints a green ground + blue player marker so the screen is never just black
function _drawFallback(){
  try{
    ctx.setTransform(1,0,0,1,0,0);ctx.globalAlpha=1;
    ctx.fillStyle='#1a3320';ctx.fillRect(0,0,VW||300,VH||300);
    ctx.fillStyle='#3aff66';for(let i=0;i<60;i++){ctx.fillRect((i*53)%VW,((i*97)%VH),2,2);}
    ctx.fillStyle='#60a5fa';ctx.fillRect((VW||300)/2-10,(VH||300)/2-10,20,20);
    ctx.fillStyle='#fff';ctx.font='10px Courier New';ctx.textAlign='center';
    ctx.fillText('SAFE-MODE RENDER',(VW||300)/2,(VH||300)/2+28);ctx.textAlign='left';
  }catch(_e){}
}
function gameLoop(ts){
  requestAnimationFrame(gameLoop);
  let dt=Math.min(ts-lastT,50);lastT=ts;
  // Hit-stop is just a brief frame freeze — still skip update+draw for that
  if(_hitStopT>0){_hitStopT=Math.max(0,_hitStopT-dt);return;}
  // Pause skips updates only. We MUST keep drawing so the world stays visible
  // behind menus/dialogs (settings, NPC, campfire, save/load) instead of going black.
  const _paused=!!gamePaused;
  if(!_paused){
    updShake(dt);
    updTime(dt);
    updWeather(dt);
    updPlayer(dt);
    updWild(dt);
    updBoss(dt);
    if(!inDungeon)updZoneBosses(dt);
    updActivePal(dt);
    _updPalSkBtn();
    updBasePals(dt);
    updProjs(dt);
    updDrops(dt);updLootBags(dt);
    updPart(dt);
    updObjectShake(dt);
    updDungeon(dt);
    updEvents(dt);
    updNearLabel();
  }
  // ── DRAW (always) ──
  // Force-safe canvas state so a stray ctx.globalAlpha/transform from elsewhere can't blank the screen
  try{ctx.setTransform(1,0,0,1,0,0);}catch(_e){}
  ctx.globalAlpha=1;
  if(!isFinite(cam.x))cam.x=PL.x||0;
  if(!isFinite(cam.y))cam.y=PL.y||0;
  if(!isFinite(VW)||VW<=0||!isFinite(VH)||VH<=0){try{resizeCanvas();}catch(_e){}}
  // If canvas just became valid after a deferred resize, snap camera now
  if(cam._needSnap&&VW>0&&VH>0){cam._needSnap=false;cam.x=Math.max(0,Math.min(PL.x-visW()/2,MAP_W-visW()));cam.y=Math.max(0,Math.min(PL.y-visH()/2,MAP_H-visH()));}
  ctx.clearRect(0,0,VW,VH);
  try{drawWorld();}catch(_e){console.error('drawWorld failed',_e);_drawFallback();return;}
  if(!inDungeon)drawRuins();
  for(const o of objects)renderObj(o,false);
  for(const s of structures)drawStruct(s,nearestStruct(PL.x,PL.y)===s);
  drawDrops();drawLootBags();
  if(!inDungeon)drawDungeonGates(dt);
  drawBasePals();
  drawActivePal();
  const sortedWild=[...wildPals].sort((a,b)=>a.y-b.y);
  for(const wp of sortedWild)drawWild(wp);
  for(const b of bossPals)drawBoss(b);
  if(!inDungeon){for(const zb of _allZoneBosses())drawZoneBoss(zb);}
  drawPlayer();
  drawProjs();
  if(!inDungeon)drawDayNightOverlay();
  drawWeatherEffects();
  if(!inDungeon)drawAtmosphere();
  // Dungeon elements drawn on top
  if(inDungeon){
    // Dark overlay for dungeon feel
    ctx.fillStyle='rgba(0,0,0,0.32)';ctx.fillRect(0,0,VW,VH);
    for(const e of dungeonEnemies)drawDungeonEnemy(e);
    if(dungeonBossObj)drawDungeonBoss();
  }
  drawPart();
  // Zone vignette overlays
  if(!inDungeon){
    const z=_curZone;
    if(z===2){
      const grad=ctx.createRadialGradient(VW/2,VH/2,VW*0.18,VW/2,VH/2,VW*0.82);
      grad.addColorStop(0,'rgba(0,0,0,0)');grad.addColorStop(1,'rgba(160,8,8,0.38)');
      ctx.fillStyle=grad;ctx.fillRect(0,0,VW,VH);
      // Pulsing "DANGER ZONE" text in corners
      const pulse=0.65+0.35*Math.sin(Date.now()/520);
      ctx.globalAlpha=pulse*0.55;ctx.fillStyle='#ff3a3a';ctx.font='bold 11px Courier New';
      ctx.textAlign='right';ctx.fillText('☠ DANGER ZONE',VW-8,VH-10);ctx.textAlign='left';
      ctx.globalAlpha=1;
    }else if(z===1){
      const grad=ctx.createRadialGradient(VW/2,VH/2,VW*0.20,VW/2,VH/2,VW*0.85);
      grad.addColorStop(0,'rgba(0,0,0,0)');grad.addColorStop(1,'rgba(120,80,0,0.18)');
      ctx.fillStyle=grad;ctx.fillRect(0,0,VW,VH);
    }
    // Boss zone vignettes
    const bzIdx=getPlayerBossZone();
    if(bzIdx>=0){
      const bz=BOSS_ZONES[bzIdx];
      const tc=Date.now();
      const bPulse=0.55+0.38*Math.sin(tc*0.0022);
      const grad2=ctx.createRadialGradient(VW/2,VH/2,VW*0.12,VW/2,VH/2,VW*0.9);
      grad2.addColorStop(0,'rgba(0,0,0,0)');grad2.addColorStop(1,bz.vigColor||'rgba(200,40,40,0.28)');
      ctx.fillStyle=grad2;ctx.globalAlpha=bPulse;ctx.fillRect(0,0,VW,VH);ctx.globalAlpha=1;
      // Zone label
      const labelPulse=0.7+0.3*Math.sin(tc*0.0018);
      ctx.globalAlpha=labelPulse*0.75;ctx.fillStyle=bz.mmColor;ctx.font='bold 10px Courier New';
      ctx.textAlign='right';ctx.fillText(bz.name.toUpperCase()+' ZONE',VW-8,22);ctx.textAlign='left';ctx.globalAlpha=1;
    }
  }
  drawBuildPrev();
  try{drawMinimap();}catch(_e){console.error('drawMinimap failed',_e);}
  // Auto-save every 30s
  if(!_saving&&Math.floor(ts/30000)!==Math.floor((ts-dt)/30000))saveGame();
  // Recovery check every 8s
  if(Math.floor(ts/8000)!==Math.floor((ts-dt)/8000)){
    updPalRecovery();
    // FIX: in-loop entity health sweep — runs every 8s to catch long-session drift
    // without the overhead of a full array scan every frame.
    try{
      // 1. Unstick PL.dead if player has HP (dungeon respawn race condition)
      if(typeof PL!=='undefined'&&PL&&PL.dead&&PL.hp>0){
        console.log('[LOOP-RECOVERY] Unsticking PL.dead (hp='+PL.hp+')');
        PL.dead=false;PL.invT=1500;
      }
      // 2. Purge wildPals with NaN coordinates (ghost entities that still attack)
      if(typeof wildPals!=='undefined'&&Array.isArray(wildPals)){
        for(let _i=wildPals.length-1;_i>=0;_i--){
          const _wp=wildPals[_i];
          if(!_wp||!isFinite(_wp.x)||!isFinite(_wp.y))wildPals.splice(_i,1);
        }
      }
      // 3. Purge bossPals with NaN coordinates
      if(typeof bossPals!=='undefined'&&Array.isArray(bossPals)){
        for(let _i=bossPals.length-1;_i>=0;_i--){
          const _bp=bossPals[_i];
          if(!_bp||!isFinite(_bp.x)||!isFinite(_bp.y))bossPals.splice(_i,1);
        }
      }
      // 4. Guard canvas context state — reset alpha/transform each sweep
      ctx.globalAlpha=1;
      try{ctx.setTransform(1,0,0,1,0,0);}catch(_e){}
    }catch(_re){}
  }
}

// ═══════════════════════════════
// NPC SYSTEM (Trader + Helper)
// ═══════════════════════════════
if(typeof PL.coins!=='number')PL.coins=0;

const NPCS=[
  {id:'trader',type:'trader',name:'Trader',emoji:'💰',shirt:'#facc15',hat:'#7a5a10',pants:'#3a2a1a',x:MAP_W/2+150,y:MAP_H/2+50,bobT:0},
  {id:'helper',type:'helper',name:'Helper',emoji:'📋',shirt:'#22d3ee',hat:'#0e6a7a',pants:'#1a2a3a',x:MAP_W/2-150,y:MAP_H/2+50,bobT:0}
];
const NPC_R=46;

const TRADE_BUY=[
  {key:'sphere',label:'🔮 Pal Sphere',price:8},
  {key:'adv_sphere',label:'💠 Adv Sphere',price:18},
  {key:'cookedMeat',label:'🍖 Cooked Meat',price:6},
  {key:'wood',label:'🪵 Wood x5',price:5,qty:5},
  {key:'stone',label:'🪨 Stone x5',price:6,qty:5}
];
const TRADE_SELL=[
  {key:'wood',label:'🪵 Wood',price:1},
  {key:'stone',label:'🪨 Stone',price:2},
  {key:'copper',label:'🟠 Copper',price:3},
  {key:'coal',label:'⬛ Coal',price:2},
  {key:'rawMeat',label:'🥩 Raw Meat',price:2}
];

const HELPER_TASKS=[
  {kind:'wood',need:10,label:'Collect 10 Wood',reward:25},
  {kind:'stone',need:8,label:'Collect 8 Stone',reward:25},
  {kind:'kill',need:3,label:'Defeat 3 Pals',reward:35},
  {kind:'copper',need:5,label:'Collect 5 Copper',reward:30}
];

const NpcState={task:null,progress:0,done:0};

// Coin display in HUD
(function(){const _hud=document.getElementById('hud');if(_hud&&!document.getElementById('coin-label')){const _c=document.createElement('div');_c.id='coin-label';_c.style.cssText='color:#facc15;font-size:10px;letter-spacing:1px;margin-top:1px;';_c.textContent='💰 0';_hud.appendChild(_c);}})();
function updCoinUI(){const el=document.getElementById('coin-label');if(el)el.textContent='💰 '+PL.coins;}

// Overlay styles
(function(){const s=document.createElement('style');s.textContent='#npc-overlay .panel{border:2px solid #facc15;width:min(360px,92vw);max-height:78vh;overflow-y:auto;}#npc-overlay h2{color:#facc15;}.npc-tabs{display:flex;gap:6px;margin-bottom:8px;}.npc-tab{flex:1;background:rgba(255,255,255,.06);border:1px solid #444;color:#ccc;border-radius:6px;padding:6px;font-size:10px;cursor:pointer;letter-spacing:1px;touch-action:manipulation;}.npc-tab.on{background:rgba(250,204,21,.18);border-color:#facc15;color:#facc15;}.tr-row{display:flex;align-items:center;justify-content:space-between;gap:6px;padding:6px 8px;border:1px solid #333;border-radius:6px;margin-bottom:4px;background:rgba(255,255,255,.03);}.tr-row .tr-name{font-size:10px;color:#eee;flex:1;}.tr-row .tr-cost{font-size:9px;color:#facc15;min-width:46px;text-align:right;}.tr-btn{background:rgba(74,255,120,.16);border:1px solid #4aff78;color:#4aff78;border-radius:5px;padding:4px 9px;font-size:9px;cursor:pointer;letter-spacing:1px;touch-action:manipulation;}.tr-btn.sell{background:rgba(255,180,40,.14);border-color:#ff9922;color:#ffb84d;}.tr-btn:disabled{opacity:.35;cursor:not-allowed;}.helper-task{background:rgba(34,211,238,.08);border:1px solid #22d3ee;border-radius:8px;padding:10px;margin-bottom:8px;}.helper-task .ht-title{font-size:11px;color:#22d3ee;margin-bottom:5px;}.helper-task .ht-prog{font-size:9px;color:#aaa;margin-bottom:6px;}.helper-task .ht-bar-out{height:6px;background:#222;border:1px solid #333;border-radius:3px;overflow:hidden;}.helper-task .ht-bar-in{height:100%;background:linear-gradient(90deg,#22d3ee,#4aff78);transition:width .25s;}';document.head.appendChild(s);})();

// Overlay element
(function(){if(document.getElementById('npc-overlay'))return;const o=document.createElement('div');o.className='overlay';o.id='npc-overlay';o.innerHTML='<div class="panel"><h2 id="npc-title">NPC</h2><button class="panel-close" id="npc-close">✕</button><div class="npc-tabs" id="npc-tabs"></div><div id="npc-body"></div></div>';document.body.appendChild(o);})();

let _curNpc=null,_npcTab='trade';
function openNpc(npc){
  _curNpc=npc;_npcTab=npc.type==='trader'?'trade':'task';
  document.getElementById('npc-title').textContent=npc.emoji+' '+npc.name;
  const tabs=document.getElementById('npc-tabs');
  if(npc.type==='trader')tabs.innerHTML='<button class="npc-tab on" data-t="trade">TRADE</button><button class="npc-tab" data-t="talk">TALK</button><button class="npc-tab" data-t="close" style="flex:0 0 60px;">CLOSE</button>';
  else tabs.innerHTML='<button class="npc-tab on" data-t="task">TASK</button><button class="npc-tab" data-t="talk">TALK</button><button class="npc-tab" data-t="close" style="flex:0 0 60px;">CLOSE</button>';
  tabs.querySelectorAll('.npc-tab').forEach(b=>b.addEventListener('click',()=>{if(b.dataset.t==='close'){closeNpc();return;}_npcTab=b.dataset.t;tabs.querySelectorAll('.npc-tab').forEach(x=>x.classList.toggle('on',x===b));renderNpcBody();}));
  renderNpcBody();
  gamePaused=true;
  document.getElementById('npc-overlay').classList.add('show');
}
function closeNpc(){gamePaused=false;document.getElementById('npc-overlay').classList.remove('show');_curNpc=null;}
document.getElementById('npc-close').addEventListener('click',closeNpc);

function renderNpcBody(){
  const body=document.getElementById('npc-body');
  if(!body||!_curNpc)return;
  if(_curNpc.type==='trader'&&_npcTab==='trade'){
    let h='<div style="font-size:9px;color:#facc15;margin:2px 0 6px;text-align:right;">💰 Coins: '+PL.coins+'</div>';
    h+='<div style="font-size:10px;color:#4aff78;margin:6px 0 4px;letter-spacing:1px;">🛒 BUY</div>';
    for(const r of TRADE_BUY){const can=PL.coins>=r.price;h+='<div class="tr-row"><span class="tr-name">'+r.label+'</span><span class="tr-cost">'+r.price+'💰</span><button class="tr-btn" data-buy="'+r.key+'" '+(can?'':'disabled')+'>BUY</button></div>';}
    h+='<div style="font-size:10px;color:#ffb84d;margin:8px 0 4px;letter-spacing:1px;">💼 SELL</div>';
    for(const r of TRADE_SELL){const have=iCount(playerInv,r.key);const can=have>=1;h+='<div class="tr-row"><span class="tr-name">'+r.label+' <span style="color:#888;">('+have+')</span></span><span class="tr-cost">+'+r.price+'💰</span><button class="tr-btn sell" data-sell="'+r.key+'" '+(can?'':'disabled')+'>SELL</button></div>';}
    body.innerHTML=h;
    body.querySelectorAll('[data-buy]').forEach(b=>b.addEventListener('click',()=>doBuy(b.dataset.buy)));
    body.querySelectorAll('[data-sell]').forEach(b=>b.addEventListener('click',()=>doSell(b.dataset.sell)));
  } else if(_curNpc.type==='trader'&&_npcTab==='talk'){
    body.innerHTML='<div style="font-size:10px;color:#ccc;line-height:1.7;padding:8px;">"Welcome, traveler! Bring me extra resources and I will pay you in coins. Need spheres or food? I have those too."</div>';
  } else if(_curNpc.type==='helper'&&_npcTab==='task'){
    let h='<div style="font-size:9px;color:#888;margin-bottom:6px;">Tasks completed: '+NpcState.done+'  •  💰 '+PL.coins+'</div>';
    if(!NpcState.task){
      h+='<div style="font-size:10px;color:#ccc;line-height:1.6;padding:6px 4px 10px;">"Need a hand earning coins? I have odd jobs around the area."</div>';
      h+='<button class="tr-btn" id="ht-get" style="width:100%;padding:9px;font-size:10px;">📋 GET A TASK</button>';
    } else {
      const t=NpcState.task;const pct=Math.min(100,Math.floor(NpcState.progress/t.need*100));const done=NpcState.progress>=t.need;
      h+='<div class="helper-task"><div class="ht-title">📋 '+t.label+'</div><div class="ht-prog">Progress: '+Math.min(NpcState.progress,t.need)+' / '+t.need+'   •   Reward: '+t.reward+'💰</div><div class="ht-bar-out"><div class="ht-bar-in" style="width:'+pct+'%"></div></div></div>';
      if(done)h+='<button class="tr-btn" id="ht-claim" style="width:100%;padding:9px;font-size:10px;">🎉 CLAIM REWARD</button>';
      else h+='<button class="tr-btn sell" id="ht-cancel" style="width:100%;padding:6px;font-size:9px;">CANCEL TASK</button>';
    }
    body.innerHTML=h;
    const g=document.getElementById('ht-get');if(g)g.addEventListener('click',giveTask);
    const c=document.getElementById('ht-claim');if(c)c.addEventListener('click',claimTask);
    const x=document.getElementById('ht-cancel');if(x)x.addEventListener('click',()=>{NpcState.task=null;NpcState.progress=0;renderNpcBody();saveGame();});
  } else if(_curNpc.type==='helper'&&_npcTab==='talk'){
    body.innerHTML='<div style="font-size:10px;color:#ccc;line-height:1.7;padding:8px;">"Out here you survive by working. Take a task, finish it, get paid. Simple."</div>';
  }
}

function doBuy(key){
  const r=TRADE_BUY.find(x=>x.key===key);if(!r)return;
  if(PL.coins<r.price){spawnPop('Not enough coins!','#f87171');return;}
  PL.coins-=r.price;_npcSilent=true;iAdd(playerInv,r.key,r.qty||1);_npcSilent=false;updResUI();updCoinUI();
  spawnPop('+'+(r.qty||1)+(IEMOJI[r.key]||''),'#4aff78');
  renderNpcBody();saveGame();
}
function doSell(key){
  const r=TRADE_SELL.find(x=>x.key===key);if(!r)return;
  if(iCount(playerInv,key)<1){spawnPop('Nothing to sell!','#f87171');return;}
  iRemove(playerInv,key,1);PL.coins+=r.price;updResUI();updCoinUI();
  spawnPop('+'+r.price+'💰','#facc15');
  renderNpcBody();saveGame();
}
function giveTask(){
  const t=HELPER_TASKS[Math.floor(Math.random()*HELPER_TASKS.length)];
  NpcState.task={kind:t.kind,need:t.need,label:t.label,reward:t.reward};NpcState.progress=0;
  renderNpcBody();saveGame();
  spawnPop('📋 New task: '+t.label,'#22d3ee');
}
function claimTask(){
  if(!NpcState.task||NpcState.progress<NpcState.task.need)return;
  const rw=NpcState.task.reward;
  PL.coins+=rw;NpcState.done++;NpcState.task=null;NpcState.progress=0;
  updCoinUI();renderNpcBody();saveGame();
  spawnPop('🎉 Task done! +'+rw+'💰','#facc15');
}

function nearestNpc(px,py){let best=null,bd=Infinity;for(const n of NPCS){const d=Math.hypot(px-n.x,py-n.y);if(d<NPC_R&&d<bd){bd=d;best=n;}}return best;}

function updNPCs(dt){for(const n of NPCS)n.bobT=(n.bobT||0)+dt*0.004;}
function drawNPCs(){
  for(const n of NPCS){
    if(!onScreen(n.x-14,n.y-26,28,40))continue;
    const z=ZOOM,bob=Math.sin(n.bobT)*1.4;
    ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();ctx.ellipse(wx(n.x),wy(n.y+12),9*z,3*z,0,0,Math.PI*2);ctx.fill();
    ctx.fillStyle=n.pants;ctx.fillRect(wx(n.x-5),wy(n.y+5+bob),4*z,6*z);ctx.fillRect(wx(n.x+1),wy(n.y+5+bob),4*z,6*z);
    ctx.fillStyle=n.shirt;ctx.fillRect(wx(n.x-6),wy(n.y-6+bob),12*z,12*z);
    ctx.fillStyle='rgba(0,0,0,.18)';ctx.fillRect(wx(n.x-6),wy(n.y+2+bob),12*z,2*z);
    ctx.fillStyle='#f1c27d';ctx.beginPath();ctx.arc(wx(n.x),wy(n.y-11+bob),5*z,0,Math.PI*2);ctx.fill();
    ctx.fillStyle=n.hat;ctx.fillRect(wx(n.x-7),wy(n.y-16+bob),14*z,2.5*z);ctx.fillRect(wx(n.x-4),wy(n.y-19+bob),8*z,3*z);
    ctx.fillStyle='#000';ctx.fillRect(wx(n.x-2.2),wy(n.y-11+bob),1.3*z,1.3*z);ctx.fillRect(wx(n.x+1),wy(n.y-11+bob),1.3*z,1.3*z);
    ctx.font='bold '+Math.round(11*z)+'px sans-serif';ctx.textAlign='center';ctx.fillStyle='#fff';ctx.strokeStyle='rgba(0,0,0,.7)';ctx.lineWidth=2;ctx.strokeText(n.emoji,wx(n.x),wy(n.y-22+bob));ctx.fillText(n.emoji,wx(n.x),wy(n.y-22+bob));ctx.textAlign='left';
    const near=Math.hypot(PL.x-n.x,PL.y-n.y)<NPC_R;
    if(near){ctx.strokeStyle='#facc15';ctx.lineWidth=1.5;ctx.setLineDash([4,3]);ctx.beginPath();ctx.arc(wx(n.x),wy(n.y),NPC_R*z*0.55,0,Math.PI*2);ctx.stroke();ctx.setLineDash([]);}
  }
}

// ── Hooks: kills give coins + advance helper kill task ──
const _npcOrigKillWild=killWild;
killWild=function(p){
  _npcOrigKillWild(p);
  const reward=1+Math.floor(Math.random()*3);
  PL.coins+=reward;updCoinUI();
  if(NpcState.task&&NpcState.task.kind==='kill'){NpcState.progress++;if(_curNpc&&_curNpc.type==='helper')renderNpcBody();}
};

// ── Hook: collecting items advances helper resource tasks (skip when buying) ──
let _npcSilent=false;
const _npcOrigIAdd=iAdd;
iAdd=function(arr,type,qty){
  _npcOrigIAdd(arr,type,qty);
  if(_npcSilent)return;
  if(arr===playerInv&&NpcState.task&&NpcState.task.kind===type){NpcState.progress+=qty;if(_curNpc&&_curNpc.type==='helper')renderNpcBody();}
};

// ── Hook: action button intercepts NPC interaction (capture phase) ──
(function(){const ab=document.getElementById('action-btn');if(!ab)return;const handler=function(e){if(PL.dead||inDungeon)return;const n=nearestNpc(PL.x,PL.y);if(n){e.stopImmediatePropagation();e.preventDefault&&e.preventDefault();openNpc(n);}};ab.addEventListener('click',handler,true);ab.addEventListener('touchstart',handler,{capture:true,passive:false});})();

// ── Hook: near-label shows NPC interaction prompt ──
const _npcOrigNearLabel=updNearLabel;
updNearLabel=function(){
  _npcOrigNearLabel();
  const n=nearestNpc(PL.x,PL.y);
  if(n){const el=document.getElementById('near-label');if(el)el.textContent='['+n.emoji+' '+n.name+' — tap ⚔️ to interact]';}
};

// ── Hook: persist coins + NPC state ──
const _npcOrigSave=saveGame;
// NPC state (coins + npc) is now written in base saveGame — eliminate double read-parse-write.
saveGame=_npcOrigSave;
const _npcOrigLoad=loadGame;
loadGame=function(){
  const r=_npcOrigLoad();
  try{if(!activeWorldId)return r;const raw=localStorage.getItem(_saveKey(activeWorldId));if(raw){const d=JSON.parse(raw);if(typeof d.coins==='number')PL.coins=d.coins;if(d.npc){NpcState.done=d.npc.done||0;NpcState.task=d.npc.task||null;NpcState.progress=d.npc.progress||0;}}}catch(e){}
  updCoinUI();
  return r;
};

// ── Hook: draw + animate NPCs each frame ──
const _npcOrigLoop=gameLoop;
let _npcLastT=0;
gameLoop=function(ts){
  _npcOrigLoop(ts);
  const dt=Math.min(ts-_npcLastT,50);_npcLastT=ts;
  if(!gamePaused)updNPCs(dt);
  drawNPCs();
};

// ═══════════════════════════════
// IRON ORE RENDERING + MINING
// ═══════════════════════════════
function drawIron(o,hi){
  const{sx:sh,sy:sv}=shakeOff(o);const x=o.x+sh,y=o.y+sv,z=ZOOM;
  ctx.fillStyle='rgba(0,0,0,.32)';ctx.beginPath();ctx.ellipse(wx(o.x+13),wy(o.y+22),13*z,5*z,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle=hi?'#dde2ec':'#a8b0bc';ctx.beginPath();
  [[x+5,y+20],[x+2,y+11],[x+7,y+2],[x+18,y+2],[x+23,y+10],[x+22,y+18],[x+15,y+22]].forEach(([px,py],i)=>{i===0?ctx.moveTo(wx(px),wy(py)):ctx.lineTo(wx(px),wy(py));});
  ctx.closePath();ctx.fill();
  ctx.fillStyle=hi?'#f0f4fa':'#c8d0dc';ctx.beginPath();
  [[x+8,y+4],[x+17,y+3],[x+19,y+9],[x+12,y+8]].forEach(([px,py],i)=>{i===0?ctx.moveTo(wx(px),wy(py)):ctx.lineTo(wx(px),wy(py));});
  ctx.closePath();ctx.fill();
  ctx.strokeStyle='#5a4030';ctx.lineWidth=z;ctx.beginPath();
  ctx.moveTo(wx(x+10),wy(y+5));ctx.lineTo(wx(x+8),wy(y+12));ctx.lineTo(wx(x+13),wy(y+16));
  ctx.moveTo(wx(x+16),wy(y+8));ctx.lineTo(wx(x+19),wy(y+14));
  ctx.stroke();
  if(hi){ctx.fillStyle='#fff';ctx.fillRect(wx(x+15),wy(y+5),2*z,2*z);}
}

const _ironOrigRender=renderObj;
renderObj=function(o,hi){
  if(o.type==='iron'){if(!onScreen(o.x,o.y,OBJ_DEF.iron.w,OBJ_DEF.iron.h))return;drawIron(o,hi);drawObjHP(o);return;}
  _ironOrigRender(o,hi);
};

const _ironOrigGather=doGather;
doGather=function(){
  if(PL.dead||PL.gatherCD>0)return;
  const obj=nearestObj(PL.x,PL.y);
  if(!obj||obj.type!=='iron'){_ironOrigGather();return;}
  if(typeof Mount!=='undefined'&&Mount.active){spawnPop('Cannot gather while riding','#f87171');return;}
  const def=OBJ_DEF.iron;
  if(activeTool!==def.tool){spawnPop('Need '+def.tool,'#f87');return;}
  if(tierVal(equipped.pickaxe)<2){spawnPop('🩶 Iron needs Copper Pickaxe!','#f87171');return;}
  if(typeof toolBlocked==='function'&&toolBlocked('pickaxe')){spawnPop('🛠️ Pickaxe is broken! Repair it','#f87171');PL.gatherCD=300;return;}
  PL.gatherCD=getGatherCD();hitObject(obj);playSnd('copper');
  if(typeof wearTool==='function')wearTool('pickaxe');
  obj.hp--;
  if(obj.hp<=0){
    const a=1+Math.floor(getSkillHarvestBonus()/2);
    iAdd(playerInv,'iron',a);addPart(obj.x,obj.y,'#a8b0bc',5);
    objects.splice(objects.indexOf(obj),1);
    popAt('+'+a+'🩶','#a8b0bc',obj.x,obj.y);
    updResUI();gainPlayerXP(4);
  }
};

// ═══════════════════════════════
// BERRY BUSH SYSTEM — Dense Forest resource gathering
// ═══════════════════════════════
const BERRY_RESPAWN_MS=45000;

function drawBerryBush(o,hi){
  if(!onScreen(o.x,o.y,24,20))return;
  const{sx:sh,sy:sv}=shakeOff(o);
  const x=o.x+sh,y=o.y+sv,z=ZOOM;
  const sc=o.sizeVar||1.0;
  const hvst=o.harvested||false;
  // Ground shadow
  ctx.fillStyle='rgba(0,0,0,.13)';ctx.beginPath();ctx.ellipse(wx(o.x+12),wy(o.y+20),11*z*sc,4*z*sc,0,0,Math.PI*2);ctx.fill();
  // Stems
  ctx.strokeStyle='#4a2c12';ctx.lineWidth=1*z;
  ctx.beginPath();ctx.moveTo(wx(x+12),wy(y+19));ctx.lineTo(wx(x+12),wy(y+15));ctx.stroke();
  ctx.beginPath();ctx.moveTo(wx(x+7),wy(y+19));ctx.lineTo(wx(x+8),wy(y+16));ctx.stroke();
  ctx.beginPath();ctx.moveTo(wx(x+17),wy(y+19));ctx.lineTo(wx(x+16),wy(y+16));ctx.stroke();
  // Bush body — darker when harvested
  const g1=hvst?'#263a14':'#326018';
  const g2=hvst?'#1c2e0e':'#3e7820';
  const g3=hvst?'#304416':'#4a9428';
  ctx.fillStyle=g1;
  ctx.beginPath();ctx.arc(wx(x+8),wy(y+15),6*z*sc,0,Math.PI*2);ctx.fill();
  ctx.beginPath();ctx.arc(wx(x+16),wy(y+15),6*z*sc,0,Math.PI*2);ctx.fill();
  ctx.beginPath();ctx.arc(wx(x+12),wy(y+12),6.5*z*sc,0,Math.PI*2);ctx.fill();
  ctx.fillStyle=g2;
  ctx.beginPath();ctx.arc(wx(x+9),wy(y+13),3.5*z*sc,0,Math.PI*2);ctx.fill();
  ctx.beginPath();ctx.arc(wx(x+15),wy(y+13),3.5*z*sc,0,Math.PI*2);ctx.fill();
  ctx.fillStyle=g3;
  ctx.beginPath();ctx.arc(wx(x+12),wy(y+10),3*z*sc,0,Math.PI*2);ctx.fill();
  // Leaf highlight
  ctx.fillStyle='rgba(110,200,70,.28)';ctx.beginPath();ctx.arc(wx(x+10),wy(y+9),2*z*sc,0,Math.PI*2);ctx.fill();
  if(!hvst){
    // Red/purple berry clusters
    const bpts=[[x+7,y+13],[x+15,y+14],[x+11,y+10],[x+13,y+14],[x+9,y+12],[x+16,y+12]];
    for(const[bx,by] of bpts){
      const bc=((Math.floor(bx)*3+Math.floor(by)*7)%3===0)?'#8b0000':((Math.floor(bx)+Math.floor(by))%2===0?'#7b21a8':'#be123c');
      ctx.fillStyle=bc;ctx.beginPath();ctx.arc(wx(bx),wy(by),2*z*sc,0,Math.PI*2);ctx.fill();
      ctx.fillStyle='rgba(255,150,150,.48)';ctx.beginPath();ctx.arc(wx(bx-.5),wy(by-.5),.8*z*sc,0,Math.PI*2);ctx.fill();
    }
  } else {
    // Harvested: fade and show tiny regrowth dot once 50% done
    const now2=Date.now();const timeLeft=Math.max(0,(o.respawnT||0)-now2);const prog=1-timeLeft/BERRY_RESPAWN_MS;
    if(prog>0.5){
      ctx.globalAlpha=0.5*(prog-0.5)*2;
      ctx.fillStyle='#be123c';ctx.beginPath();ctx.arc(wx(x+12),wy(y+11),1.5*z,0,Math.PI*2);ctx.fill();
      ctx.globalAlpha=1;
    }
  }
  // Nearby highlight ring
  if(hi&&!hvst){ctx.strokeStyle='rgba(255,220,100,.55)';ctx.lineWidth=1.5*z;ctx.beginPath();ctx.arc(wx(x+12),wy(y+12),9*z*sc,0,Math.PI*2);ctx.stroke();}
}

// Chain renderObj
const _bbOrigRender=renderObj;
renderObj=function(o,hi){
  if(o.type==='berryBush'){drawBerryBush(o,hi);return;}
  _bbOrigRender(o,hi);
};

// Chain doGather — berry bush needs no tool, hand-gather only
const _bbOrigGather=doGather;
doGather=function(){
  if(PL.dead||PL.gatherCD>0)return;
  const obj=nearestObj(PL.x,PL.y);
  if(!obj||obj.type!=='berryBush'){_bbOrigGather();return;}
  if(typeof Mount!=='undefined'&&Mount.active){spawnPop('Cannot gather while riding','#f87171');return;}
  if(obj.harvested){
    const tl=Math.max(0,Math.ceil(((obj.respawnT||0)-Date.now())/1000));
    spawnPop('🌿 Regrowing... ('+tl+'s)','#888');PL.gatherCD=600;return;
  }
  PL.gatherCD=Math.floor(getGatherCD()*0.6);
  hitObject(obj);
  const bonus=(typeof getSkillHarvestBonus==='function')?Math.floor(getSkillHarvestBonus()/2):0;
  const qty=2+bonus+Math.floor(Math.random()*2);
  iAdd(playerInv,'berry',qty);
  obj.harvested=true;obj.hp=1;obj.maxHp=1;
  obj.respawnT=Date.now()+BERRY_RESPAWN_MS;
  popAt('+'+qty+'🍓','#e85d8a',obj.x,obj.y-10);
  spawnPop('🍓 +'+qty+' Berries!','#e85d8a');
  addPart(obj.x,obj.y,'#e85d8a',5);
  updResUI();gainPlayerXP(2);
};

// Chain updNearLabel for berry bush prompt
const _bbOrigNearLabel=updNearLabel;
updNearLabel=function(){
  _bbOrigNearLabel();
  if(typeof nearestNpc==='function'&&nearestNpc(PL.x,PL.y))return;
  const obj=nearestObj(PL.x,PL.y);
  if(obj&&obj.type==='berryBush'){
    const el=document.getElementById('near-label');
    if(el){
      if(obj.harvested){const tl=Math.max(0,Math.ceil(((obj.respawnT||0)-Date.now())/1000));el.textContent='[🌿 Berry Bush — regrowing ('+tl+'s)]';}
      else el.textContent='[🍓 Berry Bush — tap ⚔️ to gather]';
    }
  }
};

// Chain gameLoop — berry bush respawn tick
const _bbOrigLoop=gameLoop;
let _bbLastT=0;
gameLoop=function(ts){
  _bbOrigLoop(ts);
  const dtb=Math.min(ts-_bbLastT,200);_bbLastT=ts;
  if(!gamePaused&&dtb>0){
    const now2=Date.now();
    for(const o of objects){
      if(o.type==='berryBush'&&o.harvested&&now2>=o.respawnT){
        o.harvested=false;o.hp=1;
        addPart(o.x+12,o.y+10,'#4aff78',2);
      }
    }
  }
};

// ═══════════════════════════════
// MUSHROOM SYSTEM — Rocky biome gatherable resource
// ═══════════════════════════════
const MUSHROOM_RESPAWN_MS=90000;

function drawMushroom(o,hi){
  if(!onScreen(o.x,o.y,16,18))return;
  const{sx:msh,sy:msv}=shakeOff(o);
  const x=o.x+msh,y=o.y+msv,z=ZOOM;
  const sc=o.sizeVar||1.0;
  const hvst=o.harvested||false;
  // Ground shadow
  ctx.fillStyle='rgba(0,0,0,.18)';ctx.beginPath();ctx.ellipse(wx(o.x+8),wy(o.y+18),7*z*sc,2.5*z*sc,0,0,Math.PI*2);ctx.fill();
  if(hvst){
    // Harvested: just a small stump
    ctx.fillStyle='#6b5b3a';ctx.fillRect(wx(x+6),wy(y+14),(3)*z*sc,(4)*z*sc);
    ctx.fillStyle='#8a7348';ctx.fillRect(wx(x+6),wy(y+14),(3)*z*sc,(1)*z*sc);
    // Regrowth indicator
    const now3=Date.now();const timeLeft3=Math.max(0,(o.respawnT||0)-now3);const prog3=1-timeLeft3/MUSHROOM_RESPAWN_MS;
    if(prog3>0.4){
      ctx.globalAlpha=0.6*(prog3-0.4)/0.6;
      ctx.fillStyle='#e06030';ctx.beginPath();ctx.arc(wx(x+7.5),wy(y+11),2*z*sc,0,Math.PI*2);ctx.fill();
      ctx.globalAlpha=1;
    }
    return;
  }
  // Stem
  ctx.fillStyle='#e8d9b5';ctx.fillRect(wx(x+5.5),wy(y+10),(5)*z*sc,(8)*z*sc);
  // Stem shading
  ctx.fillStyle='rgba(0,0,0,.12)';ctx.fillRect(wx(x+9),wy(y+11),(1.5)*z*sc,(7)*z*sc);
  ctx.fillStyle='rgba(255,255,255,.18)';ctx.fillRect(wx(x+5.5),wy(y+11),(1.5)*z*sc,(7)*z*sc);
  // Cap — rich orange-red gradient mushroom cap
  const capCx=wx(x+8),capCy=wy(y+9);
  const capR=6*z*sc;
  const capGr=ctx.createRadialGradient(capCx-capR*0.3,capCy-capR*0.3,0,capCx,capCy,capR);
  capGr.addColorStop(0,'#ff9955');capGr.addColorStop(0.5,'#d94a10');capGr.addColorStop(1,'#8b2200');
  ctx.fillStyle=capGr;
  ctx.beginPath();ctx.ellipse(capCx,capCy,capR,capR*0.65,0,Math.PI,0);ctx.fill();
  // Cap rim
  ctx.fillStyle='#b83800';
  ctx.beginPath();ctx.ellipse(capCx,capCy,capR,2.5*z*sc,0,0,Math.PI*2);ctx.fill();
  // White spots on cap
  const spots=[[x+5.5,y+7],[x+10.5,y+7.5],[x+8,y+5.5],[x+12,y+9.5]];
  for(const[sx2,sy2] of spots){
    ctx.fillStyle='rgba(255,255,255,0.82)';ctx.beginPath();ctx.arc(wx(sx2),wy(sy2),1.3*z*sc,0,Math.PI*2);ctx.fill();
  }
  // Subtle glow when highlighted
  if(hi){
    ctx.globalAlpha=0.28;
    const glow=ctx.createRadialGradient(capCx,capCy,0,capCx,capCy,8*z*sc);
    glow.addColorStop(0,'#ffa060');glow.addColorStop(1,'rgba(255,100,0,0)');
    ctx.fillStyle=glow;ctx.beginPath();ctx.arc(capCx,capCy,8*z*sc,0,Math.PI*2);ctx.fill();
    ctx.globalAlpha=1;
    ctx.strokeStyle='rgba(255,200,80,.6)';ctx.lineWidth=1.2*z;ctx.beginPath();ctx.arc(capCx,capCy,7*z*sc,0,Math.PI*2);ctx.stroke();
  }
}

// Chain renderObj for mushroom
const _msOrigRender=renderObj;
renderObj=function(o,hi){
  if(o.type==='mushroom'){drawMushroom(o,hi);return;}
  _msOrigRender(o,hi);
};

// Chain doGather — mushroom needs no tool, hand-gather
const _msOrigGather=doGather;
doGather=function(){
  if(PL.dead||PL.gatherCD>0)return;
  const obj=nearestObj(PL.x,PL.y);
  if(!obj||obj.type!=='mushroom'){_msOrigGather();return;}
  if(typeof Mount!=='undefined'&&Mount.active){spawnPop('Cannot gather while riding','#f87171');return;}
  if(obj.harvested){
    const tl=Math.max(0,Math.ceil(((obj.respawnT||0)-Date.now())/1000));
    spawnPop('🍄 Regrowing... ('+tl+'s)','#888');PL.gatherCD=600;return;
  }
  PL.gatherCD=Math.floor(getGatherCD()*0.7);
  hitObject(obj);
  const bonus=(typeof getSkillHarvestBonus==='function')?Math.floor(getSkillHarvestBonus()/3):0;
  const qty=1+bonus+Math.floor(Math.random()*2);
  iAdd(playerInv,'mushroom',qty);
  obj.harvested=true;obj.hp=1;obj.maxHp=1;
  obj.respawnT=Date.now()+MUSHROOM_RESPAWN_MS;
  popAt('+'+qty+'🍄','#d8b4fe',obj.x,obj.y-10);
  spawnPop('🍄 +'+qty+' Mushroom!','#d8b4fe');
  addPart(obj.x,obj.y,'#d8b4fe',4);
  updResUI();gainPlayerXP(3);
};

// Chain updNearLabel for mushroom prompt
const _msOrigNearLabel=updNearLabel;
updNearLabel=function(){
  _msOrigNearLabel();
  if(typeof nearestNpc==='function'&&nearestNpc(PL.x,PL.y))return;
  const obj=nearestObj(PL.x,PL.y);
  if(obj&&obj.type==='mushroom'){
    const el=document.getElementById('near-label');
    if(el){
      if(obj.harvested){const tl=Math.max(0,Math.ceil(((obj.respawnT||0)-Date.now())/1000));el.textContent='[🍄 Mushroom — regrowing ('+tl+'s)]';}
      else el.textContent='[🍄 Mushroom — tap ⚔️ to gather]';
    }
  }
};

// Chain gameLoop — mushroom respawn tick
const _msOrigLoop=gameLoop;
let _msLastT=0;
gameLoop=function(ts){
  _msOrigLoop(ts);
  const dtm=Math.min(ts-_msLastT,200);_msLastT=ts;
  if(!gamePaused&&dtm>0){
    const now3=Date.now();
    for(const o of objects){
      if(o.type==='mushroom'&&o.harvested&&now3>=o.respawnT){
        o.harvested=false;o.hp=1;
        addPart(o.x+8,o.y+10,'#d8b4fe',2);
      }
    }
  }
};

// ═══════════════════════════════
// HORSE SYSTEM — Rare wild horses + Boss Horse endgame (Plains biome)
// ═══════════════════════════════
const Mount={saddle:false,active:false,horse:null,bossDefeated:false,capturedCount:0};
const HORSE_R=50,HORSE_SPEED_MULT=1.95;
const NORMAL_HORSE_CAP=3;        // 2–3 normal horses world-wide
const NORMAL_HORSE_RESPAWN_MS=6*60*1000;  // 6 min after death/capture
const BOSS_HORSE_RESPAWN_MS=12*60*1000;   // 12 min between boss spawns
const HORSE_HP_BASE=80;          // strong vs ~20–30 HP regular pals (+~50%+)
const HORSE_DMG_BASE=7;
const BOSS_HORSE_HP=420;
const BOSS_HORSE_DMG=14;
// Territorial AI tunables — keeps the boss fair and contained to its zone
const BOSS_AGGRO_RADIUS=11*TILE;     // ~11 tiles = 352px (player must be near to provoke)
const BOSS_LEASH_RADIUS=22*TILE;     // ~22 tiles = 704px from home anchor — past this, give up
const BOSS_CHASE_TIMEOUT=10000;      // 10s without contact → return home
const BOSS_HEAL_PER_SEC=8;           // heals while returning to spawn
const BOSS_AI_SLEEP_DIST=1700;       // skip heavy AI when very far from player (off-screen)
const BOSS_TERRITORY_CD=18000;       // throttle territory warning re-show

// Plains pal weights — quiet biome, mostly normals (horses handled separately, not in PAL_TYPES)
BIOME_PAL_WEIGHTS[5]=[0.7,0.7,0.10,0.05,0.05,0.10,0.05,0.05,0,0];

const HORSE_PALETTE=[
  {body:'#5a3a1e',mane:'#2a1a0e',hoof:'#1a0e08'},
  {body:'#a89070',mane:'#3a2a1a',hoof:'#1a1208'},
  {body:'#3a2814',mane:'#1a0e06',hoof:'#0e0604'},
  {body:'#d8c8a8',mane:'#a08c5a',hoof:'#3a2a14'},
  {body:'#262626',mane:'#0c0c0c',hoof:'#000'},
  {body:'#7c5a36',mane:'#1a0e06',hoof:'#0e0604'}
];
const BOSS_PALETTE={body:'#1a0a0a',mane:'#660011',hoof:'#000'};

const horses=[];
let _horseRespawnTimers=[];        // timestamps when next normal horse may spawn
let _bossRespawnAt=Date.now()+45000; // first boss eligible 45s after world start
let _hAnimT=0;

function _findPlainsSpawn(){
  for(let tries=0;tries<400;tries++){
    const col=4+Math.floor(Math.random()*(COLS-8));
    const row=4+Math.floor(Math.random()*(ROWS-8));
    if(biomeMap[row]?.[col]!==5)continue;
    const x=col*TILE+Math.random()*TILE,y=row*TILE+Math.random()*TILE;
    if(horses.some(h=>Math.hypot(h.x-x,h.y-y)<200))continue;
    if(objects.some(o=>Math.hypot(o.x-x,o.y-y)<46))continue;
    if(Math.hypot(PL.x-x,PL.y-y)<280)continue; // never spawn on top of player
    return{x,y};
  }
  return null;
}

function _makeNormalHorse(){
  const p=_findPlainsSpawn();if(!p)return null;
  const c=HORSE_PALETTE[Math.floor(Math.random()*HORSE_PALETTE.length)];
  return{kind:'normal',x:p.x,y:p.y,vx:0,vy:0,homeX:p.x,homeY:p.y,
    bobT:Math.random()*Math.PI*2,wT:1000+Math.random()*2500,
    facing:Math.random()<0.5?'left':'right',
    body:c.body,mane:c.mane,hoof:c.hoof,
    hp:HORSE_HP_BASE,maxHp:HORSE_HP_BASE,dmg:HORSE_DMG_BASE,
    state:'idle',stateT:0,atkCD:0,aggro:0,shakeT:0,
    captureShakeT:0,_lastTargetX:0,_lastTargetY:0};
}

function _makeBossHorse(){
  const p=_findPlainsSpawn();if(!p)return null;
  return{kind:'boss',name:'STORM STALLION',x:p.x,y:p.y,vx:0,vy:0,
    homeX:p.x,homeY:p.y,           // Territory anchor — boss patrols/returns here
    bobT:Math.random()*Math.PI*2,facing:'left',
    body:BOSS_PALETTE.body,mane:BOSS_PALETTE.mane,hoof:BOSS_PALETTE.hoof,
    hp:BOSS_HORSE_HP,maxHp:BOSS_HORSE_HP,dmg:BOSS_HORSE_DMG,
    state:'idle',stateT:0,atkCD:1500,aggro:0,shakeT:0,
    phase:1,_phaseAnnounced:1,
    abCD:{dash:1500,stomp:5000,kick:2500,jump:8000,burst:7000},
    rageT:0,
    mode:'patrol',                 // 'patrol' | 'aggro' | 'returning'
    chaseT:0,                      // ms remaining in current chase
    patrolT:0,                     // ms until next patrol move
    patrolTargetX:p.x,patrolTargetY:p.y,
    _territoryShown:false,         // throttle territory warning
    _territoryCD:0};
}

(function _spawnInitialHorses(){
  for(let i=0;i<2;i++){const h=_makeNormalHorse();if(h)horses.push(h);}
  // Top up to NORMAL_HORSE_CAP gradually via respawn timers
  for(let i=horses.length;i<NORMAL_HORSE_CAP;i++)_horseRespawnTimers.push(Date.now()+30000+i*45000);
})();

function _aliveNormalHorses(){let n=0;for(const h of horses)if(h.kind==='normal')n++;return n;}
function _aliveBossHorse(){for(const h of horses)if(h.kind==='boss')return h;return null;}

function nearestHorse(px,py){
  let best=null,bd=Infinity;
  for(const h of horses){
    if(Mount.active&&h===Mount.horse)continue;
    const d=Math.hypot(px-h.x,py-h.y);
    if(d<HORSE_R+(h.kind==='boss'?22:0)&&d<bd){bd=d;best=h;}
  }
  return best;
}

function _horseFaceTowards(h,tx,ty){h.facing=tx<h.x?'left':'right';}

function _horseTryMove(h,nx,ny,allowAnyBiome){
  const c=Math.floor(nx/TILE),r=Math.floor(ny/TILE);
  const bId=biomeMap[r]?.[c];
  // Boss + aggroed normals can leave plains while charging player
  if(bId===5||allowAnyBiome){h.x=nx;h.y=ny;return true;}
  return false;
}

function _hurtPlayerByHorse(h,dmgScale,knockMult){
  if(PL.dead||PL.invT>0)return;
  const dmg=Math.max(1,Math.round(h.dmg*(dmgScale||1)));
  hurtPL(dmg);
  // Knockback feel via small camera shake (uses existing doShake)
  doShake(4+(knockMult||0)*3);
  addPart(PL.x,PL.y,'#ff6644',6);
}

function _bossSetPhase(b){
  const pct=b.hp/b.maxHp;
  const p=pct>0.70?1:pct>0.35?2:3;
  if(p!==b.phase){b.phase=p;}
  if(b.phase!==b._phaseAnnounced){
    b._phaseAnnounced=b.phase;
    if(b.phase===2){popAt('💢 PHASE 2 — Enraged!','#ff8844',b.x,b.y-40);showEventBanner('⚡ STORM STALLION enters PHASE 2!','#ff8844',5000);}
    else if(b.phase===3){popAt('🔥 PHASE 3 — RAGING!','#ff2222',b.x,b.y-40);showEventBanner('🔥 STORM STALLION is ENRAGED!','#ff2222',5000);b.rageT=999999;}
    doShake(7);
  }
}

function _normalHorseAI(h,dt){
  // Decay timers
  h.stateT-=dt;h.atkCD-=dt;h.aggro-=dt;h.shakeT-=dt;h.captureShakeT-=dt;
  // Aggro check: react to nearby player damage (shakeT spike means recently hit)
  const distPL=Math.hypot(PL.x-h.x,PL.y-h.y);
  if(h.aggro>0||(distPL<160&&!PL.dead)){
    if(h.aggro<=0)h.aggro=8000;
    // Combat states
    if(h.state==='idle'||h.state==='wander')h.state=h.atkCD<=0?(Math.random()<0.6?'charge':'kick'):'reposition';
    if(h.stateT<=0){
      if(h.state==='charge'){
        // Aim a charge: store target, dash toward it for 700ms
        h._lastTargetX=PL.x;h._lastTargetY=PL.y;h.stateT=700;
        const ang=Math.atan2(PL.y-h.y,PL.x-h.x);h.vx=Math.cos(ang)*3.0;h.vy=Math.sin(ang)*3.0;
        _horseFaceTowards(h,PL.x,PL.y);
      } else if(h.state==='kick'){
        // Quick kick if very close, else reposition
        if(distPL<58){_hurtPlayerByHorse(h,1.0,1);popAt('🐴 KICK!','#ff8844',h.x,h.y-26);h.atkCD=2500;h.stateT=300;h.vx=-Math.cos(Math.atan2(PL.y-h.y,PL.x-h.x))*1.4;h.vy=-Math.sin(Math.atan2(PL.y-h.y,PL.x-h.x))*1.4;h.state='retreat';}
        else{h.state='reposition';h.stateT=200;}
      } else if(h.state==='retreat'){
        // Briefly back off then re-engage
        h.stateT=600;h.atkCD=1100;h.state='reposition';
      } else if(h.state==='reposition'){
        // Side-step / dodge then re-attack
        const ang=Math.atan2(PL.y-h.y,PL.x-h.x)+(Math.random()<0.5?-1:1)*(Math.PI/2);
        h.vx=Math.cos(ang)*1.6;h.vy=Math.sin(ang)*1.6;h.stateT=400+Math.random()*300;
        if(h.atkCD<=0)h.state=Math.random()<0.7?'charge':'kick';
      }
    }
    // Apply movement
    const nx=h.x+h.vx*dt*0.06,ny=h.y+h.vy*dt*0.06;
    _horseTryMove(h,nx,ny,true);
    // Charge collision damage
    if(h.state==='charge'&&distPL<48){_hurtPlayerByHorse(h,1.15,1);popAt('🐴 CHARGE!','#ff6644',h.x,h.y-26);h.atkCD=2200;h.stateT=300;h.state='retreat';h.vx*=-0.6;h.vy*=-0.6;}
  } else {
    // Peaceful wander within plains
    if(h.wT===undefined)h.wT=2200;
    h.wT-=dt;
    if(h.wT<=0){h.wT=2200+Math.random()*3500;const ang=Math.random()*Math.PI*2;h.vx=Math.cos(ang)*0.55;h.vy=Math.sin(ang)*0.55;h.facing=h.vx>0?'right':'left';}
    const nx=h.x+h.vx*dt*0.06,ny=h.y+h.vy*dt*0.06;
    if(!_horseTryMove(h,nx,ny,false)){h.vx=-h.vx;h.vy=-h.vy;h.wT=400;h.facing=h.vx>0?'right':'left';}
    h.state='wander';
  }
  // Continuous facing update — always tracks actual velocity so sprite never slides sideways
  if(Math.abs(h.vx||0)>0.05)h.facing=h.vx>0?'right':'left';
  h.x=Math.max(TILE*2,Math.min(MAP_W-TILE*2,h.x));
  h.y=Math.max(TILE*2,Math.min(MAP_H-TILE*2,h.y));
}

// ── BOSS HORSE AI — territorial: patrol → aggro (with leash + chase timeout) → returning ──
function _bossPatrol(b,dt){
  // Roam slowly inside territory; occasional showy idle actions (stomp / short charge)
  b.patrolT-=dt;
  if(b.patrolT<=0){
    const roll=Math.random();
    if(roll<0.18){
      // Idle stomp animation (no damage — just presence)
      b.state='idle_stomp';b.stateT=600;b.vx=0;b.vy=0;
      addPart(b.x,b.y+10,'#cc8844',8);doShake(3);
      popAt('💢','#cc8844',b.x,b.y-30);
      b.patrolT=4500+Math.random()*3000;
    } else if(roll<0.40){
      // Short flex charge toward a random in-zone point
      const ang=Math.random()*Math.PI*2;
      const px=b.homeX+Math.cos(ang)*90,py=b.homeY+Math.sin(ang)*90;
      b.patrolTargetX=px;b.patrolTargetY=py;
      const ang2=Math.atan2(py-b.y,px-b.x);
      b.vx=Math.cos(ang2)*1.8;b.vy=Math.sin(ang2)*1.8;
      b.state='patrol_move';b.stateT=900;
      b.patrolT=3500+Math.random()*2500;
    } else {
      // Pick a new patrol point inside ~7-tile radius around home
      const r=80+Math.random()*150;const ang=Math.random()*Math.PI*2;
      b.patrolTargetX=b.homeX+Math.cos(ang)*r;
      b.patrolTargetY=b.homeY+Math.sin(ang)*r;
      const ang2=Math.atan2(b.patrolTargetY-b.y,b.patrolTargetX-b.x);
      b.vx=Math.cos(ang2)*0.7;b.vy=Math.sin(ang2)*0.7;
      b.state='patrol_move';b.stateT=2500+Math.random()*1500;
      b.patrolT=4000+Math.random()*3000;
    }
  }
  // Apply patrol movement (kept in zone)
  if(b.state==='patrol_move'){
    const nx=b.x+b.vx*dt*0.06,ny=b.y+b.vy*dt*0.06;_horseTryMove(b,nx,ny,true);
    _horseFaceTowards(b,b.x+b.vx,b.y+b.vy);
    if(b.stateT<=0){b.state='idle';b.vx=0;b.vy=0;}
    // Snap back if drifted too far from home
    const dh=Math.hypot(b.x-b.homeX,b.y-b.homeY);
    if(dh>BOSS_AGGRO_RADIUS*0.85){const a=Math.atan2(b.homeY-b.y,b.homeX-b.x);b.vx=Math.cos(a)*0.9;b.vy=Math.sin(a)*0.9;}
  } else if(b.state==='idle_stomp'){
    if(b.stateT<=0){b.state='idle';}
  }
}

function _bossReturning(b,dt){
  // Walk back home, slowly heal, ignore player
  const dh=Math.hypot(b.x-b.homeX,b.y-b.homeY);
  if(dh<40){
    // Arrived
    b.mode='patrol';b.state='idle';b.vx=0;b.vy=0;b.patrolT=800;
    b._territoryShown=false; // allow warning to show again next time
    return;
  }
  const ang=Math.atan2(b.homeY-b.y,b.homeX-b.x);
  b.vx=Math.cos(ang)*1.5;b.vy=Math.sin(ang)*1.5;
  _horseFaceTowards(b,b.homeX,b.homeY);
  const nx=b.x+b.vx*dt*0.06,ny=b.y+b.vy*dt*0.06;_horseTryMove(b,nx,ny,true);
  // Heal slowly while returning
  if(b.hp<b.maxHp){b.hp=Math.min(b.maxHp,b.hp+BOSS_HEAL_PER_SEC*dt/1000);}
  // Soft sparkle so player sees boss is "resetting"
  if(Math.random()<0.05)addPart(b.x+(Math.random()-0.5)*30,b.y-10+(Math.random()-0.5)*20,'#88ccff',2);
}

function _bossAggro(b,dt){
  // Active combat — premium boss is faster than wild horses across all phases
  const distPL=Math.hypot(PL.x-b.x,PL.y-b.y);
  const phaseSpdMul=b.phase===3?1.75:b.phase===2?1.40:1.15;
  const cdMul=b.phase===3?0.50:b.phase===2?0.74:0.95;
  // Pick next ability
  if(b.state==='idle'&&b.atkCD<=0&&distPL<420){
    const opts=[];
    if(b.abCD.dash<=0)opts.push('dash');
    if(b.abCD.kick<=0&&distPL<70)opts.push('kick');
    if(b.abCD.stomp<=0&&distPL<140&&b.phase>=2)opts.push('stomp');
    if(b.abCD.jump<=0&&b.phase>=2)opts.push('jump');
    if(b.abCD.burst<=0&&b.phase>=2)opts.push('burst');
    if(opts.length===0)opts.push('reposition');
    const pick=opts[Math.floor(Math.random()*opts.length)];
    b.state=pick;b.stateT=180;
    _horseFaceTowards(b,PL.x,PL.y);
    if(pick==='dash'){const ang=Math.atan2(PL.y-b.y,PL.x-b.x);b.vx=Math.cos(ang)*4.2*phaseSpdMul;b.vy=Math.sin(ang)*4.2*phaseSpdMul;b.stateT=b.phase>=2?900:700;b.abCD.dash=2200*cdMul;popAt('⚡ DASH!','#ffaa44',b.x,b.y-40);}
    else if(pick==='kick'){_hurtPlayerByHorse(b,1.0,2);popAt('🦵 BACK-KICK!','#ff8844',b.x,b.y-40);b.abCD.kick=2400*cdMul;b.atkCD=900*cdMul;b.state='idle';doShake(8);b.chaseT=BOSS_CHASE_TIMEOUT;}
    else if(pick==='stomp'){popAt('💥 HOOF STOMP!','#cc8844',b.x,b.y-40);b.stateT=500;b.abCD.stomp=6000*cdMul;b.vx=0;b.vy=0;}
    else if(pick==='jump'){popAt('🦘 JUMP SLAM!','#ffcc44',b.x,b.y-40);b.stateT=900;b.abCD.jump=10000*cdMul;b.vx=0;b.vy=0;}
    else if(pick==='burst'){popAt('🌪 WIND BURST!','#aaeeff',b.x,b.y-40);b.stateT=600;b.abCD.burst=9000*cdMul;b.vx=0;b.vy=0;}
    else if(pick==='reposition'){const ang=Math.atan2(PL.y-b.y,PL.x-b.x)+(Math.random()<0.5?-1:1)*0.9;b.vx=Math.cos(ang)*2.0;b.vy=Math.sin(ang)*2.0;b.stateT=600;b.atkCD=400;}
  }
  // Resolve active state hits
  if(b.state==='dash'){
    const nx=b.x+b.vx*dt*0.06,ny=b.y+b.vy*dt*0.06;_horseTryMove(b,nx,ny,true);
    if(distPL<60){_hurtPlayerByHorse(b,1.4,2);popAt('💥 IMPACT!','#ff4422',b.x,b.y-40);b.atkCD=1400*cdMul;b.state='idle';b.stateT=200;b.vx*=-0.4;b.vy*=-0.4;b.chaseT=BOSS_CHASE_TIMEOUT;}
    if(b.stateT<=0){b.state='idle';b.atkCD=900*cdMul;}
    if(b.stateT<=0&&b.phase>=2&&Math.random()<0.55&&b.abCD.dash<800){const ang=Math.atan2(PL.y-b.y,PL.x-b.x);b.vx=Math.cos(ang)*4.4*phaseSpdMul;b.vy=Math.sin(ang)*4.4*phaseSpdMul;b.state='dash';b.stateT=700;popAt('⚡⚡ COMBO!','#ff6644',b.x,b.y-40);}
  } else if(b.state==='stomp'){
    if(b.stateT<=300&&!b._stompFired){b._stompFired=true;
      const radius=120;if(distPL<radius){_hurtPlayerByHorse(b,1.2,2);b.chaseT=BOSS_CHASE_TIMEOUT;}
      addPart(b.x,b.y,'#cc8844',24);doShake(10);
    }
    if(b.stateT<=0){b._stompFired=false;b.state='idle';b.atkCD=600*cdMul;}
  } else if(b.state==='jump'){
    if(b.stateT>500){b.vx=0;b.vy=0;}
    else if(!b._jumped){
      // Cap teleport distance — can't teleport past the leash
      const dh=Math.hypot(PL.x-b.homeX,PL.y-b.homeY);
      if(dh<BOSS_LEASH_RADIUS*0.9){b._jumped=true;b.x=PL.x+(Math.random()-0.5)*30;b.y=PL.y+(Math.random()-0.5)*30;}
      else{b._jumped=true;} // skip teleport, slam in place
    }
    if(b.stateT<=200&&!b._jumpFired){b._jumpFired=true;
      const radius=140;if(Math.hypot(PL.x-b.x,PL.y-b.y)<radius){_hurtPlayerByHorse(b,1.5,2);b.chaseT=BOSS_CHASE_TIMEOUT;}
      addPart(b.x,b.y,'#ffcc44',32);doShake(14);popAt('💥 SLAM!','#ffcc44',b.x,b.y-40);
    }
    if(b.stateT<=0){b._jumped=false;b._jumpFired=false;b.state='idle';b.atkCD=900*cdMul;}
  } else if(b.state==='burst'){
    if(b.stateT<=300&&!b._burstFired){b._burstFired=true;
      const radius=170;if(distPL<radius){_hurtPlayerByHorse(b,0.9,1);b.chaseT=BOSS_CHASE_TIMEOUT;
        const ang=Math.atan2(PL.y-b.y,PL.x-b.x);PL.x+=Math.cos(ang)*22;PL.y+=Math.sin(ang)*22;
      }
      for(let i=0;i<24;i++){const ang=(i/24)*Math.PI*2;addPart(b.x+Math.cos(ang)*40,b.y+Math.sin(ang)*40,'#aaeeff',2);}
      doShake(8);
    }
    if(b.stateT<=0){b._burstFired=false;b.state='idle';b.atkCD=600*cdMul;}
  } else if(b.state==='reposition'){
    const nx=b.x+b.vx*dt*0.06,ny=b.y+b.vy*dt*0.06;_horseTryMove(b,nx,ny,true);
    if(b.stateT<=0){b.state='idle';}
  } else {
    // Idle: drift toward player slowly (only if within aggro radius)
    if(distPL>120&&distPL<BOSS_AGGRO_RADIUS*1.2){
      const ang=Math.atan2(PL.y-b.y,PL.x-b.x);b.vx=Math.cos(ang)*1.2*phaseSpdMul;b.vy=Math.sin(ang)*1.2*phaseSpdMul;
      const nx=b.x+b.vx*dt*0.06,ny=b.y+b.vy*dt*0.06;_horseTryMove(b,nx,ny,true);_horseFaceTowards(b,PL.x,PL.y);
    } else {b.vx*=0.85;b.vy*=0.85;}
  }
}

function _bossHorseAI(b,dt){
  _bossSetPhase(b);
  b.stateT-=dt;b.atkCD-=dt;b.shakeT-=dt;
  for(const k in b.abCD)b.abCD[k]-=dt;
  if(b.rageT>0)b.rageT-=dt;
  if(b._territoryCD>0)b._territoryCD-=dt;
  // Hoof spark particles when running (lightweight — throttled, only on screen)
  const _moving=Math.abs(b.vx||0)+Math.abs(b.vy||0)>1.4;
  if(_moving){
    b._hoofT=(b._hoofT||0)-dt;
    if(b._hoofT<=0){
      b._hoofT=b.mode==='aggro'?70:140;
      // Camera-cull: only spawn if visible
      if(typeof onScreen!=='function'||onScreen(b.x-30,b.y-30,60,60)){
        const col=b.phase===3?'#ffee44':b.phase===2?'#ffaa55':'#88c0ff';
        addPart(b.x+(Math.random()-0.5)*10,b.y+10+(Math.random()-0.5)*4,col,2);
      }
    }
  }
  const distPL=Math.hypot(PL.x-b.x,PL.y-b.y);
  const distHome=Math.hypot(b.x-b.homeX,b.y-b.homeY);

  // ── PERFORMANCE: deep sleep when very far from player AND not in aggro ──
  if(b.mode!=='aggro'&&distPL>BOSS_AI_SLEEP_DIST){
    // Snap back home cheaply — no per-frame work
    if(distHome>40){const ang=Math.atan2(b.homeY-b.y,b.homeX-b.x);b.x+=Math.cos(ang)*0.6*dt*0.06;b.y+=Math.sin(ang)*0.6*dt*0.06;}
    if(b.hp<b.maxHp)b.hp=Math.min(b.maxHp,b.hp+BOSS_HEAL_PER_SEC*dt/1000);
    return;
  }

  // ── Mode transitions ──
  // Pause aggro entirely while player is in dungeon (separate map)
  const playerInOtherSpace=(typeof inDungeon!=='undefined'&&inDungeon)||PL.dead;
  if(b.mode==='aggro'){
    b.chaseT-=dt;
    // Leash break: too far from home OR chase timed out without hitting player
    if(distHome>BOSS_LEASH_RADIUS||b.chaseT<=0||playerInOtherSpace){
      b.mode='returning';b.state='idle';b.vx=0;b.vy=0;
      popAt('💨 Stalls...','#888',b.x,b.y-30);
    }
  } else if(b.mode==='patrol'){
    // Aggro only when player enters territory AND boss not busy returning
    if(!playerInOtherSpace&&distPL<BOSS_AGGRO_RADIUS&&distHome<BOSS_LEASH_RADIUS*0.85){
      b.mode='aggro';b.chaseT=BOSS_CHASE_TIMEOUT;b.state='idle';b.atkCD=400;
      // Territory warning — fade banner, throttled
      if(!b._territoryShown||b._territoryCD<=0){
        b._territoryShown=true;b._territoryCD=BOSS_TERRITORY_CD;
        showEventBanner('⚠️ STORM STALLION TERRITORY','#ff6644',3500);
        popAt('💢 Get out!','#ff6644',b.x,b.y-40);
        doShake(5);
      }
    }
  } else if(b.mode==='returning'){
    // Only re-aggro if player attacks me (shakeT spike) inside aggro range
    if(!playerInOtherSpace&&b.shakeT>0&&distPL<BOSS_AGGRO_RADIUS&&distHome<BOSS_LEASH_RADIUS*0.85){
      b.mode='aggro';b.chaseT=BOSS_CHASE_TIMEOUT;b.state='idle';b.atkCD=400;
    }
  }

  // ── Run mode-appropriate AI ──
  if(b.mode==='aggro')_bossAggro(b,dt);
  else if(b.mode==='returning')_bossReturning(b,dt);
  else _bossPatrol(b,dt);

  // Continuous facing — always matches actual velocity so sprite never slides sideways
  if(Math.abs(b.vx||0)>0.05)b.facing=b.vx>0?'right':'left';
  b.x=Math.max(TILE*2,Math.min(MAP_W-TILE*2,b.x));
  b.y=Math.max(TILE*2,Math.min(MAP_H-TILE*2,b.y));
}

function updHorses(dt){
  _hAnimT+=dt;
  for(const h of horses){
    if(Mount.active&&h===Mount.horse)continue;
    h.bobT+=dt*0.005;
    // PERFORMANCE: skip full AI for normal horses when far off-screen
    if(h.kind==='normal'){
      const d=Math.hypot(PL.x-h.x,PL.y-h.y);
      if(d>BOSS_AI_SLEEP_DIST){
        // Cheap timer decay only — no movement / no aggro
        if(h.aggro>0)h.aggro-=dt;if(h.shakeT>0)h.shakeT-=dt;if(h.captureShakeT>0)h.captureShakeT-=dt;
        continue;
      }
      _normalHorseAI(h,dt);
    } else _bossHorseAI(h,dt);
  }
  // Maintain normal horse population via respawn timers
  if(_aliveNormalHorses()<NORMAL_HORSE_CAP){
    const now=Date.now();
    for(let i=_horseRespawnTimers.length-1;i>=0;i--){
      if(now>=_horseRespawnTimers[i]){
        const nh=_makeNormalHorse();
        if(nh){horses.push(nh);_horseRespawnTimers.splice(i,1);}
      }
    }
    while(_aliveNormalHorses()+_horseRespawnTimers.length<NORMAL_HORSE_CAP)_horseRespawnTimers.push(Date.now()+NORMAL_HORSE_RESPAWN_MS);
  }
  // Boss spawn (only one alive at a time, plains only)
  if(!_aliveBossHorse()&&Date.now()>=_bossRespawnAt){
    const bh=_makeBossHorse();
    if(bh){
      horses.push(bh);
      _stormFlash();
      doShake(14);
      showEventBanner('⚡ STORM STALLION ROAMS THE PLAINS!','#88c0ff',9000);
      _bossRespawnAt=Date.now()+BOSS_HORSE_RESPAWN_MS;
    } else _bossRespawnAt=Date.now()+30000;
  }
}
// Premium screen flash for legendary boss spawn (lightning)
function _stormFlash(){
  const el=document.getElementById('storm-flash');if(!el)return;
  _WXSnd.thunder();
  el.classList.remove('fade');el.classList.add('show');
  setTimeout(function(){el.classList.remove('show');el.classList.add('fade');},90);
  // Quick second flicker for thunder feel
  setTimeout(function(){el.classList.remove('fade');el.classList.add('show');},220);
  setTimeout(function(){el.classList.remove('show');el.classList.add('fade');},310);
  setTimeout(function(){el.classList.remove('fade');},900);
}

function _drawHorseBody(h,size,ridden){
  const z=ZOOM,bob=Math.sin(h.bobT)*1.4*size;
  const fx=h.facing==='left'?-1:1;
  const sxOff=(h.shakeT>0||h.captureShakeT>0)?(Math.sin(_hAnimT*0.05)*2):0;
  const sx=wx(h.x)+sxOff,sy0=wy(h.y);
  // Shadow (always)
  ctx.fillStyle='rgba(0,0,0,.42)';ctx.beginPath();ctx.ellipse(sx,wy(h.y+13*size),18*size*z,5.5*size*z,0,0,Math.PI*2);ctx.fill();
  // ── PNG sprite override for normal wild horses (boss keeps geometric red look) ──
  const _hsp=PAL_SPRITES['__WildHorse'];
  const _hready=PAL_SPRITE_READY['__WildHorse'];
  if(_hsp&&_hready&&h.kind!=='boss'){
    const sw=_hsp.width||_hsp.naturalWidth||64;
    const sh=_hsp.height||_hsp.naturalHeight||64;
    // Fit width first (horse is wider than tall). Cap at 80% of capture-ring diameter.
    const ringD=2*HORSE_R*z*size*0.55*2; // ~ visual ring used in drawHorse
    let w=44*size*z;
    if(w>ringD*0.80)w=ringD*0.80;
    const hh=w*(sh/sw);
    const footY=wy(h.y+11*size);
    const _ht=Date.now(),_hid=(h.id||0);
    // Idle breathing
    const breath=1+Math.sin(_ht*0.0026+_hid*3.1)*0.020;
    // Tail-swish body sway when running
    const moving=Math.abs(h.vx||0)+Math.abs(h.vy||0)>0.05;
    const tailSway=moving?Math.sin(_ht*0.020+_hid*5)*size*z*0.5:0;
    // Movement tilt
    const tilt=moving?Math.max(-0.10,Math.min(0.10,(h.vx||0)*0.020))*fx:0;
    // Hit recoil
    const sT=h.shakeT||0;
    const recK=sT>0?(sT/220):0;
    const recX=recK?Math.sin(_ht*0.06)*size*z*1.5*recK:0;
    const dy=footY-hh+bob*z;
    const dxOff=tailSway+recX;
    const _ps=ctx.imageSmoothingEnabled;ctx.imageSmoothingEnabled=false;
    ctx.save();
    ctx.translate(sx+dxOff,footY);
    if(tilt)ctx.rotate(tilt);
    ctx.scale((fx<0?-1:1)*breath,breath);
    ctx.drawImage(_hsp,-w/2,dy-footY,w,hh);
    ctx.restore();
    ctx.imageSmoothingEnabled=_ps;
    // Saddle visual on top when player owns one
    if(Mount.saddle&&!ridden){
      ctx.fillStyle='#7a4a20';ctx.fillRect(sx-5*z,sy0+(-7+bob)*z,10*z,4*z);
      ctx.fillStyle='#5a3818';ctx.fillRect(sx-5*z,sy0+(-7+bob)*z,10*z,1*z);
    }
    return;
  }
  // Hooves
  ctx.fillStyle=h.hoof;
  ctx.fillRect(sx-10*size*z,sy0+(4+bob)*z,3*size*z,9*size*z);
  ctx.fillRect(sx-4*size*z,sy0+(4+bob)*z,3*size*z,9*size*z);
  ctx.fillRect(sx+3*size*z,sy0+(4+bob)*z,3*size*z,9*size*z);
  ctx.fillRect(sx+9*size*z,sy0+(4+bob)*z,3*size*z,9*size*z);
  // Body
  ctx.fillStyle=h.body;
  ctx.fillRect(sx-12*size*z,sy0+(-4+bob)*z,24*size*z,10*size*z);
  // Tail
  ctx.fillStyle=h.mane;
  ctx.fillRect(sx-13*size*fx*z-(fx>0?0:3*size*z),sy0+(-3+bob)*z,3*size*z,9*size*z);
  // Neck + head
  ctx.fillStyle=h.body;
  const neckCx=sx+9*size*fx*z;
  ctx.fillRect(neckCx-3*size*z,sy0+(-11+bob)*z,6*size*z,9*size*z);
  ctx.fillRect(neckCx+(fx>0?-1:-7)*size*z,sy0+(-15+bob)*z,8*size*z,6*size*z);
  ctx.fillStyle=h.mane;
  ctx.fillRect(neckCx-3*size*fx*z-(fx<0?2*size*z:0),sy0+(-13+bob)*z,3*size*z,7*size*z);
  ctx.fillStyle=h.kind==='boss'?(h.phase===3?'#ffee44':'#ff4400'):'#000';
  ctx.fillRect(neckCx+(fx>0?2*size*z:-4*size*z),sy0+(-12+bob)*z,1.5*size*z,1.5*size*z);
  // Saddle visual when player owns one
  if(Mount.saddle&&!ridden&&h.kind==='normal'){
    ctx.fillStyle='#7a4a20';ctx.fillRect(sx-5*z,sy0+(-7+bob)*z,10*z,4*z);
    ctx.fillStyle='#5a3818';ctx.fillRect(sx-5*z,sy0+(-7+bob)*z,10*z,1*z);
  }
}

function drawHorse(h,ridden){
  const isBoss=h.kind==='boss';
  const size=isBoss?1.55:1.0;
  const z=ZOOM;
  // Boss rage glow halo (phase 3)
  if(isBoss&&h.phase===3){
    const r=70*size*z*(0.95+Math.sin(_hAnimT*0.012)*0.08);
    const grd=ctx.createRadialGradient(wx(h.x),wy(h.y),r*0.2,wx(h.x),wy(h.y),r);
    grd.addColorStop(0,'rgba(255,68,32,0.35)');grd.addColorStop(1,'rgba(255,68,32,0)');
    ctx.fillStyle=grd;ctx.beginPath();ctx.arc(wx(h.x),wy(h.y),r,0,Math.PI*2);ctx.fill();
  } else if(isBoss&&h.phase===2){
    const r=58*size*z;
    const grd=ctx.createRadialGradient(wx(h.x),wy(h.y),r*0.2,wx(h.x),wy(h.y),r);
    grd.addColorStop(0,'rgba(255,140,40,0.20)');grd.addColorStop(1,'rgba(255,140,40,0)');
    ctx.fillStyle=grd;ctx.beginPath();ctx.arc(wx(h.x),wy(h.y),r,0,Math.PI*2);ctx.fill();
  }
  _drawHorseBody(h,size,ridden);
  // Boss name + premium HP bar above (lightning frame, gradient, pulse)
  if(isBoss){
    const labelY=wy(h.y-32*size);
    const cx=wx(h.x);
    const pulse=0.85+Math.sin(_hAnimT*0.012)*0.15;
    // Lightning aura behind label
    ctx.save();
    ctx.shadowColor=h.phase===3?'rgba(255,68,32,'+(0.85*pulse).toFixed(2)+')':h.phase===2?'rgba(255,140,40,'+(0.7*pulse).toFixed(2)+')':'rgba(140,200,255,'+(0.6*pulse).toFixed(2)+')';
    ctx.shadowBlur=8;
    ctx.font='bold '+Math.round(11*z)+'px sans-serif';ctx.textAlign='center';
    ctx.fillStyle='#fff';ctx.strokeStyle='rgba(0,0,0,.95)';ctx.lineWidth=3.5;
    const _crown=h.phase===3?'💀':h.phase===2?'⚡':'👑';
    ctx.strokeText(_crown+' '+h.name+' '+_crown,cx,labelY);
    ctx.fillText(_crown+' '+h.name+' '+_crown,cx,labelY);
    ctx.restore();
    // Phase pip row
    ctx.font='bold '+Math.round(7*z)+'px sans-serif';
    ctx.fillStyle='rgba(255,220,140,.92)';
    ctx.fillText('PHASE '+h.phase+'/3',cx,labelY+10);
    // Premium HP bar — gradient + double frame + tick marks
    const bw=104*z,bh=8*z,bx=cx-bw/2,by=labelY+14;
    // Outer black frame
    ctx.fillStyle='rgba(0,0,0,.92)';ctx.fillRect(bx-2,by-2,bw+4,bh+4);
    // Inner background
    ctx.fillStyle='rgba(20,8,8,.95)';ctx.fillRect(bx,by,bw,bh);
    // Gradient fill based on phase
    const hpPct=Math.max(0,h.hp/h.maxHp);
    const grd=ctx.createLinearGradient(bx,by,bx+bw,by);
    if(h.phase===3){grd.addColorStop(0,'#ff2222');grd.addColorStop(0.5,'#ff5544');grd.addColorStop(1,'#ffaa44');}
    else if(h.phase===2){grd.addColorStop(0,'#ff7722');grd.addColorStop(0.5,'#ffaa44');grd.addColorStop(1,'#ffdd66');}
    else {grd.addColorStop(0,'#88aaff');grd.addColorStop(0.5,'#aaccff');grd.addColorStop(1,'#cce4ff');}
    ctx.fillStyle=grd;ctx.fillRect(bx,by,bw*hpPct,bh);
    // Inner shine
    ctx.fillStyle='rgba(255,255,255,.22)';ctx.fillRect(bx,by,bw*hpPct,bh*0.32);
    // Tick marks (3 phase splits)
    ctx.fillStyle='rgba(0,0,0,.6)';
    ctx.fillRect(bx+bw*0.35,by,1,bh);
    ctx.fillRect(bx+bw*0.70,by,1,bh);
    // Outer gold border with phase tint
    ctx.strokeStyle=h.phase===3?'#ff5544':h.phase===2?'#ffbb55':'#aacfff';
    ctx.lineWidth=1.2;ctx.strokeRect(bx,by,bw,bh);
    // HP number overlay
    ctx.font='bold '+Math.round(7*z)+'px sans-serif';
    ctx.fillStyle='#fff';ctx.strokeStyle='rgba(0,0,0,.85)';ctx.lineWidth=2;
    const _hpTxt=Math.ceil(h.hp)+' / '+h.maxHp;
    ctx.strokeText(_hpTxt,cx,by+bh-1);
    ctx.fillText(_hpTxt,cx,by+bh-1);
    ctx.textAlign='left';
  } else {
    // Normal horse small HP bar when injured
    if(h.hp<h.maxHp){
      const bw=36*z,bh=3*z;
      ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillRect(wx(h.x)-bw/2,wy(h.y-22),bw,bh);
      ctx.fillStyle='#ff7766';ctx.fillRect(wx(h.x)-bw/2,wy(h.y-22),bw*(h.hp/h.maxHp),bh);
    }
  }
  // Interaction prompt for nearest horse (mount or capture hint)
  if(!Mount.active){
    const near=Math.hypot(PL.x-h.x,PL.y-h.y)<HORSE_R+(isBoss?22:0);
    if(near){
      const col=isBoss?'#ff4422':(Mount.saddle?'#4aff78':'#facc15');
      ctx.strokeStyle=col;ctx.lineWidth=1.5;ctx.setLineDash([4,3]);
      ctx.beginPath();ctx.arc(wx(h.x),wy(h.y+2),HORSE_R*z*0.55*size,0,Math.PI*2);ctx.stroke();
      ctx.setLineDash([]);
      if(!isBoss){
        ctx.font='bold '+Math.round(9*z)+'px sans-serif';ctx.textAlign='center';
        ctx.fillStyle='#fff';ctx.strokeStyle='rgba(0,0,0,.85)';ctx.lineWidth=2.5;
        const lbl=Mount.saddle?'🐎 RIDE':'🐎 (Saddle from Boss)';
        ctx.strokeText(lbl,wx(h.x),wy(h.y-30));
        ctx.fillText(lbl,wx(h.x),wy(h.y-30));
        ctx.textAlign='left';
      }
    }
  }
}

function drawHorses(){
  for(const h of horses){
    if(Mount.active&&h===Mount.horse)continue;
    const sz=h.kind==='boss'?44:22;
    if(!onScreen(h.x-sz,h.y-sz,sz*2,sz*2))continue;
    drawHorse(h,false);
  }
  if(Mount.active&&Mount.horse){
    Mount.horse.x=PL.x;Mount.horse.y=PL.y+5;
    Mount.horse.facing=PL.facing==='left'?'left':'right';
    drawHorse(Mount.horse,true);
  }
}

function _killHorse(h,reason){
  const idx=horses.indexOf(h);if(idx<0)return;
  if(h.kind==='boss'){
    // BOSS REWARD — premium drop tier
    Mount.saddle=true;Mount.bossDefeated=true;
    const ironGain=10+Math.floor(Math.random()*5);
    const copperGain=6+Math.floor(Math.random()*5);
    const coinGain=45+Math.floor(Math.random()*25);
    const meatGain=2+Math.floor(Math.random()*2);
    iAdd(playerInv,'iron',ironGain);
    iAdd(playerInv,'copper',copperGain);
    iAdd(playerInv,'rawMeat',meatGain);
    if(Math.random()<0.6)iAdd(playerInv,'cookedMeat',1+Math.floor(Math.random()*2));
    if(Math.random()<0.35)iAdd(playerInv,'ultra_sphere',1);
    PL.coins=(PL.coins||0)+coinGain;
    updResUI();if(typeof updCoinUI==='function')updCoinUI();
    gainPlayerXP(180);
    addStat('palsDefeated');questProg('boss');
    // Lightning farewell + heavy shake
    _stormFlash();
    addPart(h.x,h.y,'#ffee44',32);
    addPart(h.x,h.y,'#ff4422',40);
    addPart(h.x,h.y,'#88c0ff',24);
    doShake(22);
    showEventBanner('👑 STORM STALLION SLAIN — 🪢 SADDLE & RICHES!','#ffd700',12000);
    popAt('🪢 SADDLE!','#ffd700',h.x,h.y-60);
    popAt('+🩶 '+ironGain+' Iron','#a8b0bc',h.x-30,h.y-38);
    popAt('+🟫 '+copperGain+' Copper','#e09030',h.x+30,h.y-38);
    popAt('+💰 '+coinGain+' Coins','#facc15',h.x,h.y-22);
    popAt('+XP 180','#90ccff',h.x,h.y-6);
    horses.splice(idx,1);
    _bossRespawnAt=Date.now()+BOSS_HORSE_RESPAWN_MS;
    saveGame();
  } else {
    addPart(h.x,h.y,'#ff6644',12);
    if(reason==='capture'){
      Mount.capturedCount++;addStat('palsCaptured');questProg('capture');
      gainPlayerXP(35);
      // Chance to drop a horse-y resource (rawMeat)
      if(Math.random()<0.6)iAdd(playerInv,'rawMeat',1+Math.floor(Math.random()*2));
      popAt('✅ HORSE TAMED!','#a855f7',h.x,h.y-30);
    } else {
      gainPlayerXP(20);
      if(Math.random()<0.45)iAdd(playerInv,'rawMeat',1);
      popAt('💨 Horse Defeated','#888',h.x,h.y-26);
    }
    horses.splice(idx,1);
    _horseRespawnTimers.push(Date.now()+NORMAL_HORSE_RESPAWN_MS);
    saveGame();
  }
}

function damageHorse(h,dmg){
  if(!h)return false;
  h.hp=Math.max(0,h.hp-dmg);h.shakeT=260;
  if(h.kind==='normal')h.aggro=8000;
  if(h.kind==='boss'){
    // Hit always re-engages: switch from patrol/returning to aggro and refresh chase timer
    h.mode='aggro';h.chaseT=BOSS_CHASE_TIMEOUT;
    if(h.state==='idle_stomp'||h.state==='patrol_move')h.state='idle';
  }
  addPart(h.x,h.y,'#f44',h.kind==='boss'?6:4);
  if(h.kind==='boss')spawnPop('⚔ BOSS HORSE -'+dmg,'#ff4422');
  else spawnPop('⚔ HORSE -'+dmg,'#ff8844');
  if(h.hp<=0){_killHorse(h,'kill');return true;}
  return false;
}

function _tryCaptureHorse(h){
  if(h.kind==='boss'){spawnPop('👑 Boss is uncatchable — defeat it!','#ff4422');return;}
  // Only Ultra Sphere works; consume one
  const ultra=iCount(playerInv,'ultra_sphere');
  if(ultra<=0){spawnPop('🌀 Need Ultra Sphere to capture horse!','#a855f7');return;}
  if(Date.now()<_capCD){spawnPop('⏳ Reloading…','#888');return;}
  iRemove(playerInv,'ultra_sphere',1);updResUI();playSnd('throw');
  _capCD=Date.now()+900;
  // Capture chance based on HP — best at critical, low at full
  const pct=h.hp/h.maxHp;
  let chance;
  if(pct>0.85)chance=0.04;
  else if(pct>0.55)chance=0.18;
  else if(pct>0.30)chance=0.42;
  else chance=0.72;
  // Slight resistance: 25% break-free chance even on success roll if HP > 30%
  const label=chance>=0.45?'🎯 HIGH':chance>=0.18?'🎯 MED':'🎯 LOW';
  const col=chance>=0.45?'#4aff78':chance>=0.18?'#facc15':'#f87171';
  setTimeout(()=>spawnPop('🌀 '+label+' ('+Math.round(chance*100)+'%)',col),100);
  addPart(h.x,h.y,'#a855f7',10);h.captureShakeT=900;
  setTimeout(()=>{
    const roll=Math.random();
    if(roll<chance){
      if(pct>0.30&&Math.random()<0.25){
        // Resistance break-free
        spawnPop('💨 Horse broke free and ran!','#f87171');
        h.aggro=0;h.wT=300;
        const ang=Math.atan2(h.y-PL.y,h.x-PL.x);h.vx=Math.cos(ang)*1.8;h.vy=Math.sin(ang)*1.8;
        return;
      }
      _killHorse(h,'capture');
    } else {
      spawnPop('💨 '+(h.kind==='boss'?'Boss Horse':'Horse')+' Escaped!','#f87171');
      // small dmg-on-fail to add progression
      damageHorse(h,Math.ceil(h.maxHp*0.04));
    }
    document.getElementById('capture-btn').style.opacity=inv.anyBalls>0?'1':'.38';
  },650);
}

function mountHorse(h){
  if(h.kind==='boss'){spawnPop('👑 Cannot ride the Boss!','#f87171');return;}
  if(!Mount.saddle){spawnPop('🪢 Need Saddle (defeat the Boss Horse!)','#f87171');return;}
  if(Mount.active)return;
  Mount.active=true;Mount.horse=h;h.aggro=0;
  spawnPop('🐎 Mounted! +Speed','#4aff78');
  updMountUI();saveGame();
}
function dismountHorse(){
  if(!Mount.active)return;
  if(Mount.horse){
    Mount.horse.x=PL.x+(PL.facing==='left'?26:-26);
    Mount.horse.y=PL.y;Mount.horse.vx=0;Mount.horse.vy=0;Mount.horse.wT=1500;Mount.horse.state='idle';Mount.horse.aggro=0;
  }
  Mount.active=false;Mount.horse=null;
  spawnPop('🚪 Dismounted','#facc15');
  updMountUI();saveGame();
}

// Dismount button — only visible when riding
(function(){
  if(document.getElementById('mount-btn'))return;
  const b=document.createElement('button');
  b.id='mount-btn';b.textContent='🚪 DISMOUNT';
  b.style.cssText='position:fixed;right:8px;top:48px;z-index:30;background:rgba(250,204,21,.20);border:1.5px solid #facc15;color:#facc15;border-radius:6px;padding:6px 11px;font-size:10px;letter-spacing:1px;cursor:pointer;display:none;touch-action:manipulation;font-family:monospace;font-weight:bold;';
  b.addEventListener('click',dismountHorse);
  b.addEventListener('touchstart',e=>{e.preventDefault();dismountHorse();},{passive:false});
  document.body.appendChild(b);
})();
function updMountUI(){const b=document.getElementById('mount-btn');if(b)b.style.display=Mount.active?'block':'none';}

// ── Hooks ──
const _mntOrigSpd=getSkillMoveSpd;
getSkillMoveSpd=function(){return _mntOrigSpd()*(Mount.active?HORSE_SPEED_MULT:1);};

const _mntOrigAttack=doAttack;
doAttack=function(){
  if(Mount.active){spawnPop('Cannot attack while riding!','#f87171');return;}
  _mntOrigAttack();
  // After regular attack, also damage any horse in melee range
  const dmgBase=1+weaponDmgBonus()+getSkillDmgBonus()+(PL.foodBuffT>0?(PL.foodBuffDmg||0):0);
  for(const h of horses){
    if(Mount.active&&h===Mount.horse)continue;
    const reach=h.kind==='boss'?70:55;
    const d=Math.hypot(h.x-PL.x,h.y-PL.y);
    if(d<reach){
      const dmg=dmgBase+Math.floor(Math.random()*2);
      if(damageHorse(h,dmg))break;
    }
  }
};

// Action button → mount nearest horse (normal only)
(function(){
  const ab=document.getElementById('action-btn');if(!ab)return;
  const handler=function(e){
    if(PL.dead||inDungeon||Mount.active)return;
    const h=nearestHorse(PL.x,PL.y);
    if(h&&h.kind==='normal'){e.stopImmediatePropagation();e.preventDefault&&e.preventDefault();mountHorse(h);}
  };
  ab.addEventListener('click',handler,true);
  ab.addEventListener('touchstart',handler,{capture:true,passive:false});
})();

// Capture button → if a horse is the closest valid target, route to horse capture (Ultra Sphere only)
(function(){
  const cb=document.getElementById('capture-btn');if(!cb)return;
  const handler=function(e){
    if(PL.dead||Mount.active)return;
    const h=nearestHorse(PL.x,PL.y);
    if(!h)return;
    // Find nearest wild pal for comparison
    let cdist=Infinity;
    for(const wp of wildPals){if(wp.dead)continue;const d=Math.hypot(wp.x-PL.x,wp.y-PL.y);if(d<220&&d<cdist)cdist=d;}
    const hd=Math.hypot(h.x-PL.x,h.y-PL.y);
    if(hd<=cdist&&hd<HORSE_R+(h.kind==='boss'?22:0)){
      e.stopImmediatePropagation();e.preventDefault&&e.preventDefault();
      _tryCaptureHorse(h);
    }
  };
  cb.addEventListener('click',handler,true);
  cb.addEventListener('touchstart',handler,{capture:true,passive:false});
})();

const _mntOrigNearLabel=updNearLabel;
updNearLabel=function(){
  _mntOrigNearLabel();
  if(Mount.active)return;
  const h=nearestHorse(PL.x,PL.y);
  if(h){
    const el=document.getElementById('near-label');
    if(el){
      if(h.kind==='boss')el.textContent='[👑 STORM STALLION — attack with ⚔️ / capture with 🌀]';
      else el.textContent='[🐎 Horse '+(Mount.saddle?'— ⚔️ to RIDE / 🌀 to capture':'— 🌀 to capture')+']';
    }
  }
};

const _mntOrigSave=saveGame;
// Mount state is now written in base saveGame — eliminate double read-parse-write.
saveGame=_mntOrigSave;
const _mntOrigLoad=loadGame;
loadGame=function(){
  const r=_mntOrigLoad();
  try{
    if(!activeWorldId)return r;
    const raw=localStorage.getItem(_saveKey(activeWorldId));
    if(raw){
      const d=JSON.parse(raw);
      if(d.mount){
        Mount.saddle=!!d.mount.saddle;
        Mount.bossDefeated=!!d.mount.bossDefeated;
        Mount.capturedCount=d.mount.capturedCount|0;
      }
    }
  }catch(e){}
  Mount.active=false;Mount.horse=null;updMountUI();
  return r;
};

const _mntOrigLoop=gameLoop;
let _mntLastT=0;
gameLoop=function(ts){
  _mntOrigLoop(ts);
  const dt=Math.min(ts-_mntLastT,50);_mntLastT=ts;
  if(!gamePaused)updHorses(dt);
  drawHorses();
};

const _mntOrigMM=drawMinimap;
drawMinimap=function(){
  _mntOrigMM();
  if(_mmFrame%4!==0)return;
  const scaleX=MM_W/MAP_W,scaleY=MM_H/MAP_H;
  for(const h of horses){
    if(Mount.active&&h===Mount.horse)continue;
    if(h.kind==='boss'){
      mctx.fillStyle='#ff2222';mctx.fillRect(h.x*scaleX-3,h.y*scaleY-3,6,6);
      mctx.strokeStyle='#660000';mctx.lineWidth=0.8;mctx.strokeRect(h.x*scaleX-3,h.y*scaleY-3,6,6);
    } else {
      mctx.fillStyle='#d8c8a8';mctx.fillRect(h.x*scaleX-2,h.y*scaleY-2,4,4);
      mctx.strokeStyle='#5a3a1e';mctx.lineWidth=0.6;mctx.strokeRect(h.x*scaleX-2,h.y*scaleY-2,4,4);
    }
  }
  if(Mount.active){
    mctx.fillStyle='#4aff78';
    mctx.fillRect(PL.x*scaleX-3,PL.y*scaleY-3,6,6);
    mctx.strokeStyle='#000';mctx.lineWidth=0.8;
    mctx.strokeRect(PL.x*scaleX-3,PL.y*scaleY-3,6,6);
  }
};

// ═══════════════════════════════
// INIT
// ─── Gear-bag state declared EARLY so updEquipPanel() (called below) can
// safely read equippedId without hitting a TDZ ReferenceError. The full
// DURABILITY/GEAR BAG block further down only re-uses these bindings.
let gearBag=[];
let _gearGid=1;
function _gearNewId(){return _gearGid++;}
const equippedId={weapon:null,axe:null,pickaxe:null,armor:null};
// ═══════════════════════════════
// Multi-world startup: migrate legacy save, then either auto-resume the active
// world OR show the start menu. We must determine the world BEFORE loadGame()
// so the loaded data lands in the in-memory state correctly.
_migrateLegacySave();
const _aw=(localStorage.getItem(ACTIVE_WORLD_KEY)||'').trim();
const _awExists=_aw&&listWorlds().some(w=>w.id===_aw);
if(_aw&&_awExists){
  activeWorldId=_aw;
  const _loadOk=loadGame();
  _playStartT=Date.now();
  gamePaused=false;
  // If save data was missing or corrupted, recover player to a safe spawn point
  if(!_loadOk){PL.x=MAP_W/2;PL.y=MAP_H/2;PL.hp=PL.maxHp;try{spawnPop('⚠️ Save recovered','#facc15');}catch(_e){}}
  // Belt-and-braces: clamp player into valid world bounds regardless of load outcome.
  // Prevents camera-behind-map and invisible-player bugs on partial/corrupt saves.
  try{
    PL.x=Math.max(40,Math.min(isFinite(PL.x)?PL.x:MAP_W/2,MAP_W-40));
    PL.y=Math.max(40,Math.min(isFinite(PL.y)?PL.y:MAP_H/2,MAP_H-40));
    if(!isFinite(PL.hp)||PL.hp<=0)PL.hp=Math.max(1,PL.maxHp||20);
    if(!isFinite(PL.maxHp)||PL.maxHp<=0)PL.maxHp=20;
    if(!PL.facing)PL.facing='down';
  }catch(_pe){}
}else{
  clearActiveWorld();
  gamePaused=true;
}
applyUpgrades();
if(PlayerSkills.points>0)document.getElementById('skill-btn').classList.add('has-pts');
// Force canvas resize so VW/VH are valid before the camera snap.
// srcdoc iframes may have 0-size viewport on first script tick, so we check and
// fall back to a deferred snap if the canvas is still unsized at this point.
try{resizeCanvas();}catch(_e){}
if(VW>0&&VH>0){
  cam.x=Math.max(0,Math.min(PL.x-visW()/2,MAP_W-visW()));
  cam.y=Math.max(0,Math.min(PL.y-visH()/2,MAP_H-visH()));
}else{
  // Canvas not yet sized — park cam near player; the deferred snap below will correct it.
  cam._needSnap=true;
  cam.x=Math.max(0,Math.min(PL.x,MAP_W));
  cam.y=Math.max(0,Math.min(PL.y,MAP_H));
}
// Deferred cam snap: re-snap at 200 ms, 800 ms, and 1800 ms so any srcdoc layout
// delay or orientation-change resize is caught and corrected before the player notices.
(function(){
  [200,800,1800].forEach(function(ms){
    setTimeout(function(){
      try{resizeCanvas();}catch(_e){}
      if(VW>0&&VH>0){
        cam._needSnap=false;
        cam.x=Math.max(0,Math.min(PL.x-visW()/2,MAP_W-visW()));
        cam.y=Math.max(0,Math.min(PL.y-visH()/2,MAP_H-visH()));
      }
    },ms);
  });
})();
// Spawn wild pals deferred to next animation frame so the canvas is sized and
// PL position is fully resolved (all additive patches not yet wired here, but
// position is correct). maintainWildPopulation fills remaining slots gradually.
requestAnimationFrame(function(){
  try{spawnWild(4+Math.floor(Math.random()*3),'near');}catch(_e){}
});
updHPBar();
updHungerBar();
updPlayerXPBar();
// Defensive: never let a UI render throw and abort the rest of init / break the world
try{if(typeof renderTechTree==='function')renderTechTree();}catch(_e){console.error('renderTechTree init failed',_e);}
try{if(typeof renderPaldex==='function')renderPaldex();}catch(_e){console.error('renderPaldex init failed',_e);}
// Force-close any overlays so the world is never hidden on first frame
try{['inv-overlay','build-menu','pb-overlay','death-screen','respawn-overlay'].forEach(id=>{const el=document.getElementById(id);if(el)el.classList.remove('show');});}catch(_e){}
updResUI();
updEquipPanel();
refreshPartyBar();
_objLabel();_objBar();_objHint();
// One-time intro popup per session
setTimeout(()=>{if(questIdx===0){spawnPop('📖 You are a Pal Trainer.','#facc15');setTimeout(()=>spawnPop('Build your base, capture pals, defeat bosses!','#90ccff'),1400);}},800);
if(gamePaused){
  _refreshContinueBtn();
  document.getElementById('start-menu').classList.add('show');
}
// Wire Enter key on world-name-input to confirm
try{
  const _wInp=document.getElementById('world-name-input');
  if(_wInp)_wInp.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();confirmCreateWorld();}});
}catch(e){}
// ═══════════════════════════════
// DURABILITY + GEAR BAG + REPAIR (additive)
// ═══════════════════════════════
const DURA_MAX={
  sword_wood:25, sword_stone:55, sword_copper:90, sword_iron:160,
  axe_stone:50, axe_copper:80, axe_iron:140,
  pickaxe_stone:50, pickaxe_copper:80, pickaxe_iron:140,
  ar_cloth:60, ar_iron:200,
};
const GEAR_EMOJI={
  sword_wood:'🗡️',sword_stone:'⚔️',sword_copper:'🔱',sword_iron:'⚜️',
  axe_stone:'🪓',axe_copper:'🪓',axe_iron:'🪓',
  pickaxe_stone:'⛏',pickaxe_copper:'⛏',pickaxe_iron:'⛏',
  ar_cloth:'🥋',ar_iron:'🛡️',
};
const GEAR_LABEL={
  sword_wood:'Wood Sword',sword_stone:'Stone Sword',sword_copper:'Copper Sword',sword_iron:'Iron Sword',
  axe_stone:'Stone Axe',axe_copper:'Copper Axe',axe_iron:'Iron Axe',
  pickaxe_stone:'Stone Pickaxe',pickaxe_copper:'Copper Pickaxe',pickaxe_iron:'Iron Pickaxe',
  ar_cloth:'Cloth Armor',ar_iron:'Iron Armor',
};
const REPAIR_PER_UNIT={
  sword_stone:{wood:1,stone:1}, sword_copper:{wood:1,copper:1}, sword_iron:{wood:1,iron:1},
  axe_stone:{wood:1,stone:1}, axe_copper:{wood:1,copper:1}, axe_iron:{wood:1,iron:1},
  pickaxe_stone:{wood:1,stone:1}, pickaxe_copper:{wood:1,copper:1}, pickaxe_iron:{wood:1,iron:1},
  ar_cloth:{wood:1,stone:1}, ar_iron:{wood:1,iron:1},
};
// gearBag, _gearGid, _gearNewId, equippedId moved earlier (declared before
// INIT) so updEquipPanel() can read equippedId without a TDZ ReferenceError.
function gearSlotOf(key){if(!key)return null;if(key.indexOf('sword_')===0)return 'weapon';if(key.indexOf('axe_')===0)return 'axe';if(key.indexOf('pickaxe_')===0)return 'pickaxe';if(key.indexOf('ar_')===0)return 'armor';return null;}
function gearItemKeyFromCraft(type){
  if(type.indexOf('sw_')===0)return 'sword_'+type.slice(3);
  if(type.indexOf('ax_')===0)return 'axe_'+type.slice(3);
  if(type.indexOf('pk_')===0)return 'pickaxe_'+type.slice(3);
  return type;
}
function _equipGear(item){
  const slot=gearSlotOf(item.key);if(!slot)return;
  // If a different item is currently equipped in this slot, push it back to inventory as a voucher
  const prevId=equippedId[slot];
  if(prevId&&prevId!==item.id){
    const prev=_gearById(prevId);
    if(prev&&!prev.broken)_addGearVoucher(prev);
  }
  equippedId[slot]=item.id;
  if(slot==='weapon'){equipped.weapon=item.key;}
  else if(slot==='axe'){equipped.axe=item.key.replace('axe_','');}
  else if(slot==='pickaxe'){equipped.pickaxe=item.key.replace('pickaxe_','');}
  else if(slot==='armor'){setArmor(item.key.replace('ar_',''));}
}
function _unequipSlot(slot){
  equippedId[slot]=null;
  if(slot==='weapon'){equipped.weapon=null;}
  else if(slot==='axe'){equipped.axe='wood';}
  else if(slot==='pickaxe'){equipped.pickaxe='wood';}
  else if(slot==='armor'){setArmor(null);}
}
// Gear voucher — represents a crafted gear instance inside playerInv (unique per id, no stacking)
function _gearVoucherType(id){return 'g_'+id;}
function _addGearVoucher(item){
  if(!item)return;
  const type=_gearVoucherType(item.id);
  const v={type:type,emoji:GEAR_EMOJI[item.key]||'?',qty:1,gearId:item.id,gearKey:item.key,isGear:true,name:GEAR_LABEL[item.key]||item.key};
  for(let i=0;i<playerInv.length;i++){if(!playerInv[i]){playerInv[i]=v;if(typeof updResUI==='function')updResUI();return;}}
  playerInv.push(v);
  if(typeof updResUI==='function')updResUI();
}
function _removeGearVoucher(gearId){
  const t=_gearVoucherType(gearId);
  for(let i=0;i<playerInv.length;i++){if(playerInv[i]&&playerInv[i].type===t){playerInv[i]=null;return true;}}
  return false;
}
function gearAddCrafted(type){
  const key=gearItemKeyFromCraft(type);
  const max=DURA_MAX[key]||50;
  const item={id:_gearNewId(),key:key,dur:max,max:max,broken:false};
  gearBag.push(item);
  const slot=gearSlotOf(key);
  if(slot&&!equippedId[slot]){
    // Slot is free → auto-equip new craft
    _equipGear(item);
    spawnPop('✨ Auto-equipped '+(GEAR_EMOJI[key]||'?')+' '+(GEAR_LABEL[key]||key),'#4aff78');
    addPart(PL.x,PL.y,'#4aff78',6);
  }else{
    // Slot already occupied → put new gear into normal inventory as a voucher
    _addGearVoucher(item);
    spawnPop('🎒 +'+(GEAR_EMOJI[key]||'?')+' '+(GEAR_LABEL[key]||key)+' → bag (tap to equip)','#facc15');
  }
  if(typeof renderGearBag==='function')renderGearBag();
  if(typeof updEquipPanel==='function')updEquipPanel();
  if(typeof updResUI==='function')updResUI();
}
function _gearById(id){for(const g of gearBag){if(g.id===id)return g;}return null;}
function _equippedGear(slot){const id=equippedId[slot];return id?_gearById(id):null;}
function toolBlocked(tool){const g=_equippedGear(tool);if(!g)return false;return !!g.broken;}
function _wearItem(g,amt){
  if(!g||g.broken)return;
  g.dur=Math.max(0,g.dur-(amt||1));
  if(g.dur===0){
    g.broken=true;
    spawnPop('💥 '+(GEAR_EMOJI[g.key]||'?')+' '+(GEAR_LABEL[g.key]||g.key)+' broken!','#f87171');
    const slot=gearSlotOf(g.key);if(slot)_unequipSlot(slot);
    if(typeof updEquipPanel==='function')updEquipPanel();
  }
  if(typeof renderGearBag==='function')renderGearBag();
}
function wearWeapon(){const g=_equippedGear('weapon');if(g)_wearItem(g,1);}
function wearTool(slot){const g=_equippedGear(slot);if(g)_wearItem(g,1);}
let _armorWearTick=0;
function wearArmor(){_armorWearTick++;if(_armorWearTick%2!==0)return;const g=_equippedGear('armor');if(g)_wearItem(g,1);}
// Override weaponDmgBonus to return 0 when broken
const _origWeaponDmgBonus=weaponDmgBonus;
weaponDmgBonus=function(){const g=_equippedGear('weapon');if(g&&g.broken)return 0;return _origWeaponDmgBonus();};

// ─── Repair Overlay (injected) ───
(function(){
  const html='<div class="overlay" id="repair-overlay"><div class="panel" style="width:min(360px,94vw);background:#0a1420;border:2px solid #dde2ec;"><h2 style="color:#dde2ec;">🛠️ REPAIR BENCH</h2><button class="panel-close" id="repair-close">✕</button><div id="repair-list" style="display:flex;flex-direction:column;gap:6px;max-height:60dvh;overflow:auto;padding:4px;"></div><div style="font-size:9px;color:#888;margin-top:6px;text-align:center;">Stone: 🪵+🪨 · Copper: 🪵+🟠 · Iron: 🪵+🩶</div></div></div>';
  document.body.insertAdjacentHTML('beforeend',html);
  document.getElementById('repair-close').onclick=closeRepairOverlay;
})();
function openRepairOverlay(){renderRepairList();document.getElementById('repair-overlay').classList.add('show');}
function closeRepairOverlay(){document.getElementById('repair-overlay').classList.remove('show');}
function _repairCostFor(g,need){
  const tier=g.key.replace(/^(sword_|axe_|pickaxe_|ar_)/,'');
  if(tier==='wood'||tier==='cloth'){return {wood:Math.max(1,Math.ceil(need/3))};}
  const per=REPAIR_PER_UNIT[g.key]||{wood:1};
  const cost={};
  for(const r in per){if(per.hasOwnProperty(r))cost[r]=Math.max(1,Math.ceil(need*per[r]/4));}
  return cost;
}
function renderRepairList(){
  const list=document.getElementById('repair-list');list.innerHTML='';
  if(gearBag.length===0){list.innerHTML='<div style="color:#888;text-align:center;padding:20px;font-size:10px;">Gear bag is empty.<br>Craft tools/armor first.</div>';return;}
  for(const g of gearBag){
    const need=g.max-g.dur;
    const cost=_repairCostFor(g,Math.max(need,1));
    const canRepair=need>0&&iHas(playerInv,cost);
    const costParts=[];for(const r in cost){if(cost.hasOwnProperty(r))costParts.push(cost[r]+(IEMOJI[r]||r));}
    const costStr=costParts.join(' ');
    const pct=Math.round(g.dur/g.max*100);
    const barCol=pct>60?'#4aff78':pct>30?'#facc15':'#f87171';
    const row=document.createElement('div');
    row.style.cssText='display:flex;align-items:center;gap:7px;padding:6px;background:rgba(255,255,255,.03);border:1px solid #333;border-radius:6px;';
    row.innerHTML='<span style="font-size:18px;">'+(GEAR_EMOJI[g.key]||'?')+'</span><div style="flex:1;min-width:0;"><div style="font-size:10px;color:#fff;">'+(GEAR_LABEL[g.key]||g.key)+(g.broken?' <span style="color:#f87171;">(BROKEN)</span>':'')+'</div><div style="height:5px;background:#222;border-radius:3px;overflow:hidden;margin-top:3px;"><div style="height:100%;width:'+pct+'%;background:'+barCol+';"></div></div><div style="font-size:8px;color:#aaa;margin-top:2px;">'+g.dur+'/'+g.max+' · '+(costStr||'—')+'</div></div><button class="cr-btn" '+(canRepair?'':'disabled')+' style="font-size:9px;padding:5px 8px;">REPAIR</button>';
    const btn=row.querySelector('button');
    btn.onclick=function(){
      const need2=g.max-g.dur;if(need2<=0)return;
      const c2=_repairCostFor(g,need2);
      if(!iHas(playerInv,c2)){spawnPop('Not enough resources','#f60');return;}
      for(const r in c2){if(c2.hasOwnProperty(r))iRemove(playerInv,r,c2[r]);}
      g.dur=g.max;g.broken=false;
      spawnPop('🛠️ '+(GEAR_LABEL[g.key]||g.key)+' fully repaired!','#4aff78');
      updResUI();renderRepairList();renderGearBag();updEquipPanel();saveGame();
    };
    list.appendChild(row);
  }
}

// Gear bag UI removed — crafted gear now lives in normal inventory (auto-equip if slot empty,
// otherwise placed as a tappable voucher in playerInv). The internal gearBag array still
// tracks per-instance durability for save-compat and the repair bench.
const _dragState={dragging:false,gid:null};
let _ghost=null;
function _makeGhost(g){
  if(_ghost)_ghost.remove();
  _ghost=document.createElement('div');
  _ghost.style.cssText='position:fixed;width:38px;height:38px;border-radius:6px;background:rgba(96,165,250,.85);border:2px solid #fff;display:flex;align-items:center;justify-content:center;font-size:20px;pointer-events:none;z-index:9999;';
  _ghost.textContent=GEAR_EMOJI[g.key]||'?';
  document.body.appendChild(_ghost);
}
function _moveGhost(x,y){if(_ghost){_ghost.style.left=(x-19)+'px';_ghost.style.top=(y-19)+'px';}}
function _killGhost(){if(_ghost){_ghost.remove();_ghost=null;}}
function _handleDrop(target,gid){
  const g=_gearById(gid);if(!g)return;
  if(g.broken){spawnPop('Item broken — repair at bench','#f87171');return;}
  const slot=gearSlotOf(g.key);if(!slot)return;
  const slotEl=target&&target.closest?target.closest('.eq-slot'):null;
  const invEl=target&&target.closest?target.closest('#inv-grid, .inv-cell'):null;
  if(slotEl){
    const sid=slotEl.id;
    const want=sid==='eq-weapon'?'weapon':sid==='eq-armor'?'armor':sid==='eq-axe'?'axe':sid==='eq-pick'?'pickaxe':null;
    if(want&&want===slot){
      // Equip with auto-swap (current item → bag) — works for inv-voucher drop AND eq-to-eq same-slot (no-op)
      const sameAsEquipped=equippedId[slot]===g.id;
      _removeGearVoucher(g.id); // safe even if not in inv
      _equipGear(g);
      if(!sameAsEquipped)spawnPop('✨ Equipped '+(GEAR_EMOJI[g.key]||'')+' '+(GEAR_LABEL[g.key]||g.key),'#4aff78');
      updEquipPanel();
      if(typeof renderGearBag==='function')renderGearBag();
      const ov=document.getElementById('inv-overlay');
      if(ov&&ov.classList.contains('show'))renderInvOverlay();
      if(typeof updResUI==='function')updResUI();
      saveGame();return;
    }
    if(want&&want!==slot){spawnPop('Wrong slot for this item','#f60');return;}
  } else if(invEl){
    // Dropping equipped gear onto inventory → unequip
    for(const k of ['weapon','axe','pickaxe','armor']){
      if(equippedId[k]===g.id){_unequipFromSlot(k);return;}
    }
  }
}
function _unequipFromSlot(slot){
  const gid=equippedId&&equippedId[slot];
  const g=gid?_gearById(gid):null;
  if(!g){
    // No real gear (e.g. wood baseline axe/pick) — nothing to unequip
    if(slot==='axe'||slot==='pickaxe')spawnPop(slot+' is the basic tool — craft an upgrade!','#888');
    else spawnPop('Slot is already empty','#888');
    return;
  }
  if(slot==='armor'){
    setArmor(null);equippedId.armor=null;
    if(!g.broken)_addGearVoucher(g);
  } else {
    _unequipSlot(slot);
    if(!g.broken)_addGearVoucher(g);
  }
  spawnPop('🎒 '+(GEAR_LABEL[g.key]||g.key)+(g.broken?' removed (broken)':' → bag'),'#aaa');
  updEquipPanel();
  if(typeof renderGearBag==='function')renderGearBag();
  const ov=document.getElementById('inv-overlay');
  if(ov&&ov.classList.contains('show'))renderInvOverlay();
  if(typeof updResUI==='function')updResUI();
  if(typeof refreshCraftUI==='function')refreshCraftUI();
  saveGame();
}
function _touchDragStart(e,g){
  if(!e.cancelable)return;e.preventDefault();
  if(g.broken){spawnPop('Item broken — repair at bench','#f87171');return;}
  _dragState.dragging=true;_dragState.gid=g.id;
  _makeGhost(g);
  const t=e.touches[0];_moveGhost(t.clientX,t.clientY);
  function move(ev){const tt=ev.touches[0];_moveGhost(tt.clientX,tt.clientY);ev.preventDefault();}
  function end(ev){
    document.removeEventListener('touchmove',move);
    document.removeEventListener('touchend',end);
    document.removeEventListener('touchcancel',end);
    const tt=(ev.changedTouches&&ev.changedTouches[0])||{clientX:0,clientY:0};
    const target=document.elementFromPoint(tt.clientX,tt.clientY);
    _handleDrop(target,g.id);
    _killGhost();
    setTimeout(function(){_dragState.dragging=false;_dragState.gid=null;},80);
  }
  document.addEventListener('touchmove',move,{passive:false});
  document.addEventListener('touchend',end);
  document.addEventListener('touchcancel',end);
}
function renderGearBag(){
  const list=document.getElementById('gear-bag-list');if(!list)return;
  list.innerHTML='';
  if(gearBag.length===0){list.innerHTML='<div style="color:#666;font-size:9px;padding:6px;width:100%;text-align:center;">Empty — craft tools/armor</div>';return;}
  for(const g of gearBag){
    const isEq=g.id===equippedId.weapon||g.id===equippedId.axe||g.id===equippedId.pickaxe||g.id===equippedId.armor;
    const pct=g.max>0?g.dur/g.max:0;
    const barCol=pct>0.6?'#4aff78':pct>0.3?'#facc15':'#f87171';
    const cell=document.createElement('div');
    cell.className='gear-cell';
    cell.draggable=true;
    cell.dataset.gid=g.id;
    cell.style.cssText='width:42px;height:48px;border-radius:6px;background:rgba(96,165,250,.08);border:1.5px solid '+(isEq?'#4aff78':(g.broken?'#f87171':'#60a5fa55'))+';display:flex;flex-direction:column;align-items:center;justify-content:flex-start;padding:2px;position:relative;cursor:grab;font-size:18px;-webkit-tap-highlight-color:transparent;touch-action:none;'+(g.broken?'opacity:0.55;':'');
    cell.innerHTML='<span>'+(GEAR_EMOJI[g.key]||'?')+'</span><div style="width:90%;height:3px;background:#222;border-radius:2px;margin-top:auto;overflow:hidden;"><div style="height:100%;width:'+Math.round(pct*100)+'%;background:'+barCol+';"></div></div><div style="font-size:6px;color:#aaa;line-height:1;">'+g.dur+'/'+g.max+'</div>'+(isEq?'<div style="position:absolute;top:-2px;right:-2px;font-size:7px;color:#4aff78;">●</div>':'')+(g.broken?'<div style="position:absolute;top:1px;left:2px;font-size:6px;color:#f87171;font-weight:bold;">✕</div>':'');
    cell.title=(GEAR_LABEL[g.key]||g.key)+(isEq?' (EQUIPPED — tap to unequip)':' — tap to equip');
    cell.addEventListener('click',function(e){
      e.stopPropagation();
      if(_dragState.dragging)return;
      if(g.broken){spawnPop('Item broken — repair at bench','#f87171');return;}
      const slot=gearSlotOf(g.key);if(!slot)return;
      if(equippedId[slot]===g.id){_unequipSlot(slot);spawnPop('Unequipped '+(GEAR_LABEL[g.key]||g.key),'#aaa');}
      else{_equipGear(g);spawnPop('Equipped '+(GEAR_LABEL[g.key]||g.key),'#4aff78');}
      updEquipPanel();renderGearBag();saveGame();
    });
    cell.addEventListener('dragstart',function(e){
      _dragState.dragging=true;_dragState.gid=g.id;
      try{e.dataTransfer.setData('text/plain',String(g.id));e.dataTransfer.effectAllowed='move';}catch(_){}
    });
    cell.addEventListener('dragend',function(){setTimeout(function(){_dragState.dragging=false;_dragState.gid=null;},80);});
    cell.addEventListener('touchstart',function(e){_touchDragStart(e,g);},{passive:false});
    list.appendChild(cell);
  }
}
// HTML5 drop on eq-slots
['eq-weapon','eq-armor','eq-axe','eq-pick'].forEach(function(id){
  const el=document.getElementById(id);if(!el)return;
  el.addEventListener('dragover',function(e){e.preventDefault();try{e.dataTransfer.dropEffect='move';}catch(_){}el.style.outline='2px solid #4aff78';});
  el.addEventListener('dragleave',function(){el.style.outline='';});
  el.addEventListener('drop',function(e){e.preventDefault();el.style.outline='';let gid=null;try{gid=parseInt(e.dataTransfer.getData('text/plain'),10);}catch(_){gid=_dragState.gid;}_handleDrop(el,gid);});
});
// Refresh gear bag whenever inventory opens
(function(){
  const ov=document.getElementById('inv-overlay');if(!ov)return;
  const obs=new MutationObserver(function(){if(ov.classList.contains('show'))renderGearBag();});
  obs.observe(ov,{attributes:true,attributeFilter:['class']});
})();
// Save/load extension
const _origSaveGame=saveGame;
// Gear state (gearBag, equippedId, _gearGid) is now written in base saveGame — no double-write.
saveGame=_origSaveGame;
const _origLoadGame=loadGame;
loadGame=function(){
  const r=_origLoadGame.apply(this,arguments);
  try{
    const raw=localStorage.getItem(_saveKey(activeWorldId));
    if(raw){
      const d=JSON.parse(raw);
      gearBag=Array.isArray(d.gearBag)?d.gearBag:[];
      if(d.equippedId){equippedId.weapon=d.equippedId.weapon||null;equippedId.axe=d.equippedId.axe||null;equippedId.pickaxe=d.equippedId.pickaxe||null;equippedId.armor=d.equippedId.armor||null;}
      else{equippedId.weapon=null;equippedId.axe=null;equippedId.pickaxe=null;equippedId.armor=null;}
      _gearGid=(typeof d._gearGid==='number'&&d._gearGid>0)?d._gearGid:1;
      // Reconcile legacy: if equipped.X is set but no gear item, create one (full dur)
      function _legacy(slot,key){if(!key||equippedId[slot])return;const max=DURA_MAX[key]||50;const it={id:_gearNewId(),key:key,dur:max,max:max,broken:false};gearBag.push(it);equippedId[slot]=it.id;}
      if(equipped.weapon)_legacy('weapon',equipped.weapon);
      if(equipped.axe&&equipped.axe!=='wood')_legacy('axe','axe_'+equipped.axe);
      if(equipped.pickaxe&&equipped.pickaxe!=='wood')_legacy('pickaxe','pickaxe_'+equipped.pickaxe);
      if(equipped.armor)_legacy('armor','ar_'+equipped.armor);
    }
  }catch(e){}
  if(typeof renderGearBag==='function')renderGearBag();
  return r;
};
// Initial sync for already-loaded world (fresh starts have no equipment)
(function(){
  function _legacy(slot,key){if(!key||equippedId[slot])return;const max=DURA_MAX[key]||50;const it={id:_gearNewId(),key:key,dur:max,max:max,broken:false};gearBag.push(it);equippedId[slot]=it.id;}
  if(equipped.weapon)_legacy('weapon',equipped.weapon);
  if(equipped.axe&&equipped.axe!=='wood')_legacy('axe','axe_'+equipped.axe);
  if(equipped.pickaxe&&equipped.pickaxe!=='wood')_legacy('pickaxe','pickaxe_'+equipped.pickaxe);
  if(equipped.armor)_legacy('armor','ar_'+equipped.armor);
  renderGearBag();
})();

// ═══════════════════════════════════════════════════════════════════════════
// EXTRA PERSISTED STATE — sound, time-of-day, weather (additive override).
// Kept after gearBag overrides so the chain stays intact. Each field is
// defensively read so older saves without these keys still load fine.
// ═══════════════════════════════════════════════════════════════════════════
(function(){
  const _origS=saveGame, _origL=loadGame;
  // Sound/time/weather state is now written in base saveGame — no double-write.
  saveGame=_origS;
  loadGame=function(){
    const r=_origL.apply(this,arguments);
    try{
      if(!activeWorldId)return r;
      const raw=localStorage.getItem(_saveKey(activeWorldId));
      if(!raw)return r;
      const d=JSON.parse(raw);
      if(typeof d.sndEnabled==='boolean'){sndEnabled=d.sndEnabled;try{_syncSndToggle&&_syncSndToggle();}catch(_e){}}
      if(d.time&&typeof TimeSys!=='undefined'){
        if(typeof d.time.t==='number')TimeSys.t=d.time.t;
        if(typeof d.time.phase==='string')TimeSys.phase=d.time.phase;
      }
      if(d.weather&&typeof WX!=='undefined'){
        if(typeof d.weather.state==='string')WX.state=d.weather.state;
        if(typeof d.weather.t==='number')WX.t=d.weather.t;
        if(typeof d.weather.dur==='number')WX.dur=d.weather.dur;
        if(typeof d.weather.alpha==='number')WX.alpha=d.weather.alpha;
        WX.bloodMoon=!!d.weather.bloodMoon;
      }
    }catch(e){}
    return r;
  };
  // Apply now for the world that was already loaded during boot
  try{
    if(activeWorldId){
      const raw=localStorage.getItem(_saveKey(activeWorldId));
      if(raw){
        const d=JSON.parse(raw);
        if(typeof d.sndEnabled==='boolean'){sndEnabled=d.sndEnabled;try{_syncSndToggle&&_syncSndToggle();}catch(_e){}}
        if(d.time&&typeof TimeSys!=='undefined'){
          if(typeof d.time.t==='number')TimeSys.t=d.time.t;
          if(typeof d.time.phase==='string')TimeSys.phase=d.time.phase;
        }
        if(d.weather&&typeof WX!=='undefined'){
          if(typeof d.weather.state==='string')WX.state=d.weather.state;
          if(typeof d.weather.t==='number')WX.t=d.weather.t;
          if(typeof d.weather.dur==='number')WX.dur=d.weather.dur;
          if(typeof d.weather.alpha==='number')WX.alpha=d.weather.alpha;
          WX.bloodMoon=!!d.weather.bloodMoon;
        }
      }
    }
  }catch(_e){}
})();

// ═══════════════════════════════════════════════════════════════════════════
// REWARD PROGRESSION • WORLD EVENTS • QUEST EXPANSION
// One contained module. All hooks/patches/UI are defined here.
// ═══════════════════════════════════════════════════════════════════════════
(function(){
  const PROG_KEY='palworld_prog_v1';

  // ── INJECT CSS for new UI ──
  const _css=document.createElement('style');
  _css.textContent=
    "#prog-tracker{position:static;display:flex;flex-direction:column;gap:5px;pointer-events:auto;font-family:'Courier New',monospace;width:100%;max-width:none;}"+
    "#prog-tracker::-webkit-scrollbar{display:none;}"+
    ".pq-card{background:rgba(8,12,20,.84);border:1.5px solid #facc1577;border-radius:6px;padding:3px 6px;color:#fff;font-size:8px;line-height:1.3;text-shadow:0 1px 2px #000;box-shadow:0 2px 6px rgba(0,0,0,.5);overflow:hidden;}"+
    ".pq-card.daily{border-color:#7dd3fc88;}"+
    ".pq-card.chal{border-color:#fb923c88;}"+
    ".pq-title{display:flex;align-items:center;gap:3px;font-weight:bold;letter-spacing:.5px;font-size:8px;}"+
    ".pq-title .pq-tag{background:#facc15;color:#000;border-radius:3px;padding:0 3px;font-size:7px;letter-spacing:.5px;}"+
    ".pq-card.daily .pq-tag{background:#7dd3fc;}"+
    ".pq-card.chal .pq-tag{background:#fb923c;}"+
    ".pq-text{color:#e5edf5;font-size:8px;margin-top:1px;}"+
    ".pq-bar-out{height:4px;background:rgba(0,0,0,.6);border-radius:2px;margin-top:2px;overflow:hidden;}"+
    ".pq-bar-in{height:100%;width:0%;background:linear-gradient(90deg,#facc15,#fb923c);transition:width .3s;}"+
    ".pq-card.daily .pq-bar-in{background:linear-gradient(90deg,#7dd3fc,#3b82f6);}"+
    ".pq-card.chal .pq-bar-in{background:linear-gradient(90deg,#fb923c,#ef4444);}"+
    ".pq-rew{color:#cdd6e3;font-size:7px;margin-top:1px;letter-spacing:.3px;}"+
    "@media (max-width:520px){#prog-tracker{max-width:38vw;}.pq-card{padding:2px 5px;font-size:7px;}.pq-title,.pq-text,.pq-bar-out{font-size:7px;}.pq-bar-out{height:3px;}}"+
    /* Big satisfying quest-complete banner */
    "#qcomp-fx{position:fixed;top:46%;left:50%;transform:translate(-50%,-50%) scale(.6);z-index:60;pointer-events:none;background:linear-gradient(135deg,rgba(20,20,40,.94),rgba(60,30,80,.94));border:2.5px solid #facc15;border-radius:14px;padding:14px 28px;color:#fff;font-family:'Courier New',monospace;font-size:14px;font-weight:bold;text-align:center;box-shadow:0 0 36px rgba(250,204,21,.7),0 6px 24px rgba(0,0,0,.7);opacity:0;transition:opacity .3s,transform .35s cubic-bezier(.18,1.3,.5,1);text-shadow:0 1px 3px #000;letter-spacing:1.5px;min-width:180px;}"+
    "#qcomp-fx.show{opacity:1;transform:translate(-50%,-50%) scale(1);}"+
    "#qcomp-fx .qc-rew{display:block;color:#facc15;font-size:11px;margin-top:6px;letter-spacing:1px;}"+
    /* Coin readout in HUD */
    "#coin-readout{color:#facc15;font-size:9px;letter-spacing:1px;margin-top:1px;text-shadow:0 1px 2px #000;}"+
    /* Stronger hit flash + crit feedback */
    "#hit-flash.heavy{background:rgba(255,40,40,.45);}"+
    ".popup.crit{font-size:18px;color:#ff6b9d;text-shadow:0 0 8px #ff2266,0 1px 3px #000;animation:critPop .9s ease-out forwards;}"+
    "@keyframes critPop{0%{transform:translate(-50%,0) scale(.4);opacity:0;}25%{transform:translate(-50%,-12px) scale(1.4);opacity:1;}60%{transform:translate(-50%,-22px) scale(1.05);opacity:1;}100%{transform:translate(-50%,-40px) scale(.9);opacity:0;}}"+
    /* Legendary gear label */
    ".legendary-gear{box-shadow:0 0 10px #ffd700aa,inset 0 0 6px rgba(255,215,0,.35) !important;border-color:#ffd700 !important;}";
  document.head.appendChild(_css);

  // ── INJECT DOM: progression tracker + completion fx + coin readout ──
  // Tracker now lives INSIDE the #quest-overlay popup so it never shows on
  // the HUD by default — only when the player taps the 📜 Quest button.
  const _tracker=document.createElement('div');_tracker.id='prog-tracker';
  const _qBody=document.getElementById('quest-overlay-body');
  if(_qBody){_qBody.appendChild(_tracker);}else{document.body.appendChild(_tracker);_tracker.style.display='none';}
  const _qfx=document.createElement('div');_qfx.id='qcomp-fx';document.body.appendChild(_qfx);
  // Add coin readout to existing HUD
  try{const _hud=document.getElementById('hud');if(_hud&&!document.getElementById('coin-readout')){const _cr=document.createElement('div');_cr.id='coin-readout';_cr.textContent='🪙 0';_hud.appendChild(_cr);}}catch(e){}

  // ── DAILY & CHALLENGE QUEST DEFS ──
  const DAILY_POOL=[
    {key:'wood',target:30,label:'Daily: Gather Wood',hint:'Chop trees',rew:{xp:40,coin:25}},
    {key:'stone',target:20,label:'Daily: Mine Stone',hint:'Mine rock nodes',rew:{xp:40,coin:25}},
    {key:'kill',target:6,label:'Daily: Defeat Wild Pals',hint:'Use sword or pal',rew:{xp:55,coin:35,sphere:1}},
    {key:'capture',target:2,label:'Daily: Capture Pals',hint:'Throw spheres',rew:{xp:50,coin:30,sphere:1}},
    {key:'copper',target:8,label:'Daily: Mine Copper',hint:'Find copper nodes',rew:{xp:45,coin:30}},
  ];
  const CHAL_POOL=[
    {key:'kill_rare',target:1,label:'Challenge: Slay Rare Pal',hint:'Find a rare/epic pal',rew:{xp:80,coin:60,crystal_shard:1}},
    {key:'kill',target:10,label:'Challenge: Hunt 10 Pals',hint:'Anywhere',rew:{xp:90,coin:50,sphere:2}},
    {key:'wood',target:50,label:'Challenge: Lumberjack',hint:'Stockpile wood',rew:{xp:70,coin:40,tech:1}},
    {key:'capture',target:3,label:'Challenge: Master Catcher',hint:'Capture 3 pals',rew:{xp:80,coin:55,adv_sphere:1}},
    {key:'kill_legendary',target:1,label:'Challenge: Legend Slayer',hint:'Defeat a legendary pal',rew:{xp:200,coin:150,star_dust:2,tech:2}},
  ];

  // ── PROGRESSION STATE ──
  const Prog={
    daily:null,         // {def, prog, doneAt}
    challenge:null,
    dailyAssignedAt:0,  // Date.now()
    chalAssignedAt:0,
    statsLifetime:{coinsEarned:0,eventsTriggered:0,questsCompleted:0,legendaryKills:0,rareKills:0},
  };
  const DAY_MS=24*60*60*1000;
  const CHAL_TTL=45*60*1000; // challenge refreshes every 45 min real time

  function _pickRandom(arr){return arr[Math.floor(Math.random()*arr.length)];}
  function rollDaily(){const def=_pickRandom(DAILY_POOL);Prog.daily={def,prog:0,doneAt:0};Prog.dailyAssignedAt=Date.now();try{flagQuestNew();}catch(e){}}
  function rollChallenge(){const def=_pickRandom(CHAL_POOL);Prog.challenge={def,prog:0,doneAt:0};Prog.chalAssignedAt=Date.now();try{flagQuestNew();}catch(e){}}

  // ── SAVE/LOAD progression (separate localStorage key per world) ──
  function _key(){return PROG_KEY+'_'+(typeof activeWorldId!=='undefined'&&activeWorldId?activeWorldId:'global');}
  function saveProg(){try{localStorage.setItem(_key(),JSON.stringify(Prog));}catch(e){}}
  function loadProg(){try{const r=localStorage.getItem(_key());if(r){const d=JSON.parse(r);if(d&&typeof d==='object'){Object.assign(Prog,d);}}}catch(e){}}
  loadProg();
  if(!Prog.daily||!Prog.daily.def||Date.now()-Prog.dailyAssignedAt>DAY_MS)rollDaily();
  if(!Prog.challenge||!Prog.challenge.def||Date.now()-Prog.chalAssignedAt>CHAL_TTL)rollChallenge();

  // ── TRACKER UI RENDER ──
  function _rewardStr(r){const parts=[];if(r.xp)parts.push('+'+r.xp+'XP');if(r.coin)parts.push('+'+r.coin+'🪙');if(r.sphere)parts.push('+'+r.sphere+'🔮');if(r.adv_sphere)parts.push('+'+r.adv_sphere+'💠');if(r.crystal_shard)parts.push('+'+r.crystal_shard+'💎');if(r.phoenix_feather)parts.push('+'+r.phoenix_feather+'🪶');if(r.dragon_horn)parts.push('+'+r.dragon_horn+'🦴');if(r.star_dust)parts.push('+'+r.star_dust+'✨');if(r.tech)parts.push('+'+r.tech+'🔬');if(r.material&&r.materialQty)parts.push('+'+r.materialQty+(IEMOJI[r.material]||''));return parts.join(' ');}
  function renderTracker(){
    if(!_tracker)return;
    let html='';
    if(Prog.daily&&Prog.daily.def){
      const q=Prog.daily.def,p=Math.min(1,Prog.daily.prog/q.target);
      html+='<div class="pq-card daily"><div class="pq-title"><span class="pq-tag">DAILY</span> '+q.label+'</div><div class="pq-text">'+Math.min(Prog.daily.prog,q.target)+' / '+q.target+'</div><div class="pq-bar-out"><div class="pq-bar-in" style="width:'+(p*100).toFixed(0)+'%"></div></div><div class="pq-rew">'+_rewardStr(q.rew)+'</div></div>';
    }
    if(Prog.challenge&&Prog.challenge.def){
      const q=Prog.challenge.def,p=Math.min(1,Prog.challenge.prog/q.target);
      html+='<div class="pq-card chal"><div class="pq-title"><span class="pq-tag">CHAL</span> '+q.label+'</div><div class="pq-text">'+Math.min(Prog.challenge.prog,q.target)+' / '+q.target+'</div><div class="pq-bar-out"><div class="pq-bar-in" style="width:'+(p*100).toFixed(0)+'%"></div></div><div class="pq-rew">'+_rewardStr(q.rew)+'</div></div>';
    }
    _tracker.innerHTML=html;
  }
  renderTracker();

  // ── REWARD APPLY ──
  function applyRewards(r,label){
    if(!r)return;
    if(r.xp)gainPlayerXP(r.xp);
    if(r.coin){iAdd(playerInv,'coin',r.coin);Prog.statsLifetime.coinsEarned+=r.coin;}
    if(r.sphere)iAdd(playerInv,'sphere',r.sphere);
    if(r.adv_sphere)iAdd(playerInv,'adv_sphere',r.adv_sphere);
    if(r.crystal_shard)iAdd(playerInv,'crystal_shard',r.crystal_shard);
    if(r.phoenix_feather)iAdd(playerInv,'phoenix_feather',r.phoenix_feather);
    if(r.dragon_horn)iAdd(playerInv,'dragon_horn',r.dragon_horn);
    if(r.star_dust)iAdd(playerInv,'star_dust',r.star_dust);
    if(r.tech&&typeof Tech!=='undefined'){Tech.points=(Tech.points||0)+r.tech;const _pdb=document.getElementById('pdx-btn');if(_pdb)_pdb.classList.add('has-new');}
    if(r.material&&r.materialQty)iAdd(playerInv,r.material,r.materialQty);
    if(typeof updResUI==='function')updResUI();
    showQuestComplete(label||'COMPLETE!',r);
  }

  // ── BIG SATISFYING COMPLETION FX ──
  function showQuestComplete(label,r){
    if(!_qfx)return;
    _qfx.innerHTML='<div>🏆 '+label+'</div>'+(r?'<span class="qc-rew">'+_rewardStr(r)+'</span>':'');
    _qfx.classList.add('show');
    try{playSnd('pop');setTimeout(()=>playSnd('pop'),120);}catch(e){}
    // Particle burst at center of screen (translate to world coords)
    try{const _wx=PL.x,_wy=PL.y;addPart(_wx,_wy-30,'#facc15',16);addPart(_wx,_wy-30,'#ffe066',12);addPart(_wx,_wy-30,'#ffffff',8);}catch(e){}
    setTimeout(()=>{_qfx.classList.remove('show');},2200);
  }

  // ── QUEST PROGRESS HOOKS ──
  function bumpDaily(key,amt){
    if(!Prog.daily||!Prog.daily.def)return;
    if(Prog.daily.doneAt)return;
    if(Prog.daily.def.key!==key)return;
    Prog.daily.prog=Math.min(Prog.daily.def.target,Prog.daily.prog+amt);
    if(Prog.daily.prog>=Prog.daily.def.target&&!Prog.daily.doneAt){
      Prog.daily.doneAt=Date.now();
      Prog.statsLifetime.questsCompleted++;
      applyRewards(Prog.daily.def.rew,'DAILY COMPLETE');
      // Auto-roll next daily (next-day cooldown handled by tick check)
      setTimeout(()=>{rollDaily();renderTracker();saveProg();},1800);
    }
    renderTracker();saveProg();
  }
  function bumpChallenge(key,amt){
    if(!Prog.challenge||!Prog.challenge.def)return;
    if(Prog.challenge.doneAt)return;
    if(Prog.challenge.def.key!==key)return;
    Prog.challenge.prog=Math.min(Prog.challenge.def.target,Prog.challenge.prog+amt);
    if(Prog.challenge.prog>=Prog.challenge.def.target&&!Prog.challenge.doneAt){
      Prog.challenge.doneAt=Date.now();
      Prog.statsLifetime.questsCompleted++;
      applyRewards(Prog.challenge.def.rew,'CHALLENGE COMPLETE');
      setTimeout(()=>{rollChallenge();renderTracker();saveProg();},1800);
    }
    renderTracker();saveProg();
  }

  // ── EXPOSE: hook into killWild for rare/legendary kill quests ──
  // (Plain 'kill' bumps are handled by patched questProg below — avoid double-count)
  window.__sideQuestKill=function(p){
    if(!p)return;
    if(p.rarity==='rare'||p.rarity==='epic'||p.rarity==='legendary'){
      Prog.statsLifetime.rareKills++;
      bumpChallenge('kill_rare',1);
    }
    if(p.rarity==='legendary'){
      Prog.statsLifetime.legendaryKills++;
      bumpChallenge('kill_legendary',1);
    }
  };

  // ── PATCH questProg to ALSO bump daily/challenge progress ──
  // (Other strict-mode reassignments of top-level fns work elsewhere in this file, so this is safe.)
  try{
    const _origQP=questProg;
    questProg=function(type,amt){
      try{bumpDaily(type,amt||1);bumpChallenge(type,amt||1);}catch(e){}
      return _origQP(type,amt);
    };
  }catch(e){}

  // Refresh coin readout periodically
  function refreshCoinReadout(){const el=document.getElementById('coin-readout');if(!el)return;el.textContent='🪙 '+iCount(playerInv,'coin');}
  setInterval(refreshCoinReadout,800);

  // ── DAILY ROLLOVER CHECK ──
  setInterval(function(){
    const now=Date.now();
    if(Prog.daily&&Prog.daily.doneAt&&now-Prog.daily.doneAt>2000&&now-Prog.dailyAssignedAt>DAY_MS){rollDaily();renderTracker();saveProg();}
    if(Prog.challenge&&Prog.challenge.doneAt&&now-Prog.challenge.doneAt>2000&&now-Prog.chalAssignedAt>CHAL_TTL){rollChallenge();renderTracker();saveProg();}
  },5000);

  // ═══════════════════════════════
  // WORLD EVENTS — meteor, merchant, rare-pal, treasure chest
  // ═══════════════════════════════
  const WorldEvent={
    nextAt:Date.now()+(60+Math.random()*120)*1000, // first event 1-3 min in
    minInterval:180000, maxInterval:420000, // 3-7 min between events
    activeMerchant:null,        // {x,y,life,inv:[{type,price}]}
    activeChests:[],            // [{x,y,picked,life}]
  };

  function _safeSpawnLoc(){
    // Pick a location somewhat near the player but not on top
    const a=Math.random()*Math.PI*2,r=180+Math.random()*220;
    return{x:Math.max(40,Math.min(MAP_W-40,PL.x+Math.cos(a)*r)),y:Math.max(40,Math.min(MAP_H-40,PL.y+Math.sin(a)*r))};
  }

  function triggerMeteor(){
    Prog.statsLifetime.eventsTriggered++;
    if(typeof showEventBanner==='function')showEventBanner('☄️ METEOR SHOWER — rare materials raining!','#ff6644',6000);
    try{playSnd('hit');}catch(e){}
    // Drop 6-10 piles of mixed rare materials around the player over 3 seconds
    const count=6+Math.floor(Math.random()*5);
    for(let i=0;i<count;i++){
      setTimeout(function(){
        const loc=_safeSpawnLoc();
        const roll=Math.random();
        let type='copper',qty=2+Math.floor(Math.random()*3);
        if(roll<0.05){type='dragon_horn';qty=1;}
        else if(roll<0.18){type='phoenix_feather';qty=1;}
        else if(roll<0.40){type='crystal_shard';qty=1+Math.floor(Math.random()*2);}
        else if(roll<0.60){type='star_dust';qty=1+Math.floor(Math.random()*2);}
        else if(roll<0.80){type='coal';qty=2+Math.floor(Math.random()*3);}
        else{type='copper';qty=3+Math.floor(Math.random()*3);}
        spawnDrop(type,qty,loc.x,loc.y);
        // Mark as rare for glow
        const last=droppedItems[droppedItems.length-1];
        if(last&&['dragon_horn','phoenix_feather','crystal_shard','star_dust'].includes(last.type))last.rare=true;
        try{addPart(loc.x,loc.y,'#ff6644',12);addPart(loc.x,loc.y,'#ffcc44',8);}catch(e){}
        try{popAt('☄️','#ff6644',loc.x,loc.y);}catch(e){}
      },i*420);
    }
  }

  function triggerMerchant(){
    Prog.statsLifetime.eventsTriggered++;
    const loc=_safeSpawnLoc();
    WorldEvent.activeMerchant={x:loc.x,y:loc.y,life:120000,vT:0};
    if(typeof showEventBanner==='function')showEventBanner('🛒 Wandering Merchant — visit them!','#7dd3fc',5000);
    try{addPart(loc.x,loc.y,'#7dd3fc',12);}catch(e){}
  }

  function triggerRarePalSpawn(){
    Prog.statsLifetime.eventsTriggered++;
    if(typeof showEventBanner==='function')showEventBanner('🌟 Legendary Pal sighted nearby!','#ffd700',6000);
    try{
      const epicDefs=PAL_TYPES.filter(p=>p.rare);
      const rd=epicDefs[Math.floor(Math.random()*epicDefs.length)]||PAL_TYPES[0];
      const lv=Math.max(3,(PL.level||1)+1+Math.floor(Math.random()*3));
      const loc=_safeSpawnLoc();
      const rarity=Math.random()<0.3?'legendary':'epic';
      wildPals.push({def:rd,x:loc.x,y:loc.y,hp:rd.baseHp+lv*3,maxHp:rd.baseHp+lv*3,level:lv,xp:0,xpNeeded:xpToNext(lv),dead:false,id:Math.random(),aF:0,aT:0,shakeT:0,vx:0,vy:0,wT:2000,abCD:rd.ability.cd,skCD:rd.special?.cd||9999,rarity,dmgBonus:rarity==='legendary'?4:2,sizeBonus:rarity==='legendary'?6:3});
      addPart(loc.x,loc.y,rarity==='legendary'?'#ffd700':'#cc44ff',16);
      popAt('🌟 Legendary appeared!','#ffd700',loc.x,loc.y-30);
    }catch(e){}
  }

  function triggerChest(){
    Prog.statsLifetime.eventsTriggered++;
    const loc=_safeSpawnLoc();
    WorldEvent.activeChests.push({x:loc.x,y:loc.y,picked:false,life:180000,bobT:0});
    if(typeof showEventBanner==='function')showEventBanner('💰 Mystery Chest spawned — find it on the minimap!','#facc15',5500);
    try{addPart(loc.x,loc.y,'#facc15',12);}catch(e){}
  }

  function rollWorldEvent(){
    const r=Math.random();
    if(r<0.30)triggerMeteor();
    else if(r<0.55)triggerChest();
    else if(r<0.80)triggerRarePalSpawn();
    else triggerMerchant();
    WorldEvent.nextAt=Date.now()+WorldEvent.minInterval+Math.random()*(WorldEvent.maxInterval-WorldEvent.minInterval);
  }

  // World event tick: check timer + interact with merchant/chests
  function _drawWorldEvents(){
    if(typeof ctx==='undefined'||!ctx)return;
    const z=typeof ZOOM!=='undefined'?ZOOM:1;
    // Draw merchant
    const m=WorldEvent.activeMerchant;
    if(m){
      m.vT=(m.vT||0)+0.06;
      if(typeof onScreen==='function'&&onScreen(m.x-16,m.y-16,32,32)){
        const sx=wx(m.x),sy=wy(m.y);
        const bob=Math.sin(m.vT)*3*z;
        ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();ctx.ellipse(sx,sy+12*z,16*z,5*z,0,0,Math.PI*2);ctx.fill();
        const pulse=0.55+Math.sin(Date.now()*.005)*0.35;
        ctx.strokeStyle='rgba(125,211,252,'+pulse.toFixed(2)+')';ctx.lineWidth=2*z;ctx.beginPath();ctx.arc(sx,sy+bob,22*z,0,Math.PI*2);ctx.stroke();
        ctx.font=Math.round(28*z)+'px serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('🛒',sx,sy+bob);
        ctx.fillStyle='#7dd3fc';ctx.font='bold '+Math.round(7*z)+'px Courier New';ctx.fillText('MERCHANT',sx,sy-20*z+bob);
        // Show "Press E" prompt when player is in range and UI is closed
        if(WorldEvent._merchantNear&&document.getElementById('merchant-modal')?.style.display!=='flex'){
          const _pa=0.65+Math.sin(Date.now()*0.006)*0.30;
          ctx.globalAlpha=_pa;
          ctx.fillStyle='#fff';ctx.font='bold '+Math.round(8*z)+'px Courier New';
          ctx.fillText('[E] Open Shop',sx,sy+32*z+bob);
          ctx.globalAlpha=1;
        }
        ctx.textAlign='left';ctx.textBaseline='alphabetic';
      }
    }
    // Draw chests
    for(const c of WorldEvent.activeChests){
      if(c.picked)continue;
      c.bobT=(c.bobT||0)+0.05;
      if(typeof onScreen==='function'&&onScreen(c.x-12,c.y-12,24,24)){
        const sx=wx(c.x),sy=wy(c.y),bob=Math.sin(c.bobT)*2.5*z;
        ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();ctx.ellipse(sx,sy+8*z,11*z,4*z,0,0,Math.PI*2);ctx.fill();
        const pulse=0.5+Math.sin(Date.now()*.006)*0.4;
        ctx.strokeStyle='rgba(250,204,21,'+pulse.toFixed(2)+')';ctx.lineWidth=2*z;ctx.beginPath();ctx.arc(sx,sy+bob,16*z,0,Math.PI*2);ctx.stroke();
        ctx.font=Math.round(20*z)+'px serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('💰',sx,sy+bob);
        ctx.fillStyle='#facc15';ctx.font='bold '+Math.round(6*z)+'px Courier New';ctx.fillText('CHEST',sx,sy-16*z+bob);
        ctx.textAlign='left';ctx.textBaseline='alphabetic';
      }
    }
  }

  function _updateWorldEvents(dt){
    // Lifetime decay
    if(WorldEvent.activeMerchant){
      WorldEvent.activeMerchant.life-=dt;
      if(WorldEvent.activeMerchant.life<=0){WorldEvent.activeMerchant=null;if(typeof showEventBanner==='function')showEventBanner('🛒 Merchant departed','#888',2500);}
      else{
        // E-key interaction when player is near merchant
        const m=WorldEvent.activeMerchant;
        const _mdist=Math.hypot(PL.x-m.x,PL.y-m.y);
        WorldEvent._merchantNear=(_mdist<52);
        if(WorldEvent._merchantNear&&!m._traded&&(typeof keys!=='undefined')&&(keys['e']||keys['E'])){
          m._traded=true;openMerchantUI();
        }
      }
    }
    for(let i=WorldEvent.activeChests.length-1;i>=0;i--){
      const c=WorldEvent.activeChests[i];
      if(c.picked){WorldEvent.activeChests.splice(i,1);continue;}
      c.life-=dt;
      if(c.life<=0){WorldEvent.activeChests.splice(i,1);continue;}
      if(Math.hypot(PL.x-c.x,PL.y-c.y)<24){openChest(c);WorldEvent.activeChests.splice(i,1);}
    }
    if(Date.now()>=WorldEvent.nextAt)rollWorldEvent();
  }

  function openChest(c){
    c.picked=true;
    try{playSnd('pop');}catch(e){}
    if(typeof showEventBanner==='function')showEventBanner('💰 Mystery Chest opened!','#facc15',3000);
    try{addPart(c.x,c.y,'#facc15',16);addPart(c.x,c.y,'#ffe066',10);}catch(e){}
    // Always: coins + 2 random rare drops
    spawnDrop('coin',30+Math.floor(Math.random()*40),c.x,c.y);
    const pool=['crystal_shard','star_dust','phoenix_feather','sphere','adv_sphere'];
    if(Math.random()<0.15)pool.push('dragon_horn');
    for(let i=0;i<2;i++){
      const t=pool[Math.floor(Math.random()*pool.length)];
      spawnDrop(t,1+Math.floor(Math.random()*2),c.x+Math.random()*20-10,c.y+Math.random()*20-10);
      const last=droppedItems[droppedItems.length-1];
      if(last&&['dragon_horn','phoenix_feather','crystal_shard','star_dust'].includes(last.type))last.rare=true;
    }
    showQuestComplete('TREASURE FOUND',{coin:30,material:'crystal_shard',materialQty:1});
  }

  // ── MERCHANT UI (very simple modal) ──
  function openMerchantUI(){
    let modal=document.getElementById('merchant-modal');
    if(modal){modal.style.display='flex';return;}
    modal=document.createElement('div');modal.id='merchant-modal';
    modal.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.78);z-index:80;display:flex;align-items:center;justify-content:center;font-family:"Courier New",monospace;';
    const items=[
      {type:'sphere',price:8,label:'🔮 Pal Sphere'},
      {type:'adv_sphere',price:25,label:'💠 Advanced Sphere'},
      {type:'crystal_shard',price:35,label:'💎 Crystal Shard'},
      {type:'star_dust',price:18,label:'✨ Star Dust'},
      {type:'cookedMeat',price:6,label:'🍖 Cooked Meat'},
      {type:'iron',price:12,label:'🩶 Iron'},
    ];
    let html='<div style="background:linear-gradient(135deg,#1a2030,#2a1a40);border:2px solid #7dd3fc;border-radius:14px;padding:18px 16px 0 16px;max-width:88vw;width:340px;max-height:80vh;overflow-y:auto;-webkit-overflow-scrolling:touch;scroll-behavior:smooth;color:#fff;box-shadow:0 0 30px rgba(125,211,252,.4),0 6px 20px rgba(0,0,0,.7);display:flex;flex-direction:column;">'+
      '<div style="font-size:14px;font-weight:bold;color:#7dd3fc;text-align:center;letter-spacing:1.5px;margin-bottom:4px;">🛒 WANDERING MERCHANT</div>'+
      '<div style="font-size:9px;color:#cdd6e3;text-align:center;margin-bottom:10px;">Spend 🪙 coins for goods</div>'+
      '<div id="mch-coin" style="text-align:center;color:#facc15;font-size:11px;margin-bottom:8px;">Your coins: 🪙 '+iCount(playerInv,'coin')+'</div>';
    for(const it of items){
      html+='<div style="display:flex;justify-content:space-between;align-items:center;background:rgba(0,0,0,.5);border:1px solid #7dd3fc55;border-radius:6px;padding:5px 8px;margin-bottom:5px;font-size:10px;"><span>'+it.label+'</span><button class="mch-buy" data-type="'+it.type+'" data-price="'+it.price+'" style="background:#7dd3fc;color:#000;border:0;border-radius:4px;padding:3px 8px;font-weight:bold;font-size:9px;cursor:pointer;font-family:inherit;">'+it.price+'🪙</button></div>';
    }
    html+='<button id="mch-close" style="position:sticky;bottom:0;display:block;width:100%;background:#2a1a40;border-top:1px solid #7dd3fc44;color:#fff;border-left:0;border-right:0;border-bottom:0;border-radius:0 0 12px 12px;padding:8px 0;font-size:10px;font-weight:bold;cursor:pointer;font-family:inherit;letter-spacing:1px;margin-top:6px;">✕ CLOSE</button>'+
      '</div>';
    modal.innerHTML=html;
    document.body.appendChild(modal);
    modal.querySelectorAll('.mch-buy').forEach(b=>{
      b.addEventListener('click',function(){
        const t=this.getAttribute('data-type'),pr=parseInt(this.getAttribute('data-price'),10);
        if(iCount(playerInv,'coin')<pr){spawnPop('Not enough coins','#f44');return;}
        // remove coins
        let need=pr;for(let i=0;i<playerInv.length&&need>0;i++){const s=playerInv[i];if(s&&s.type==='coin'){const t2=Math.min(s.qty,need);s.qty-=t2;need-=t2;if(s.qty<=0)playerInv[i]=null;}}
        iAdd(playerInv,t,1);updResUI();playSnd('pickup');
        spawnPop('🛒 +1 '+(IEMOJI[t]||t),'#7dd3fc');
        const cd=document.getElementById('mch-coin');if(cd)cd.textContent='Your coins: 🪙 '+iCount(playerInv,'coin');
      });
    });
    modal.querySelector('#mch-close').addEventListener('click',function(){
      modal.style.display='none';
      if(typeof gamePaused!=='undefined')gamePaused=false;
      if(WorldEvent.activeMerchant)WorldEvent.activeMerchant._traded=false;
    });
    // Pause game while shop is open
    if(typeof gamePaused!=='undefined')gamePaused=true;
  }

  // ── Hook: action button intercepts Wandering Merchant (capture phase, highest priority) ──
  // Fires before doActionBtn and before the NPC hook so merchant takes precedence over attack.
  (function(){
    const ab=document.getElementById('action-btn');
    if(!ab)return;
    const handler=function(e){
      if((typeof PL!=='undefined'&&PL.dead)||(typeof inDungeon!=='undefined'&&inDungeon))return;
      const m=WorldEvent.activeMerchant;
      if(!m)return;
      const dist=Math.hypot((typeof PL!=='undefined'?PL.x:0)-m.x,(typeof PL!=='undefined'?PL.y:0)-m.y);
      if(dist<52){
        e.stopImmediatePropagation();
        e.preventDefault&&e.preventDefault();
        m._traded=false; // always allow re-open
        openMerchantUI();
      }
    };
    ab.addEventListener('click',handler,true);
    ab.addEventListener('touchstart',handler,{capture:true,passive:false});
  })();

  // Hook world event update + draw into the existing game loop via rAF
  function _eventLoop(){
    try{_updateWorldEvents(16);}catch(e){}
    requestAnimationFrame(_eventLoop);
  }
  requestAnimationFrame(_eventLoop);
  // Hook drawing to run after the main draw — uses a separate rAF that paints chest/merchant
  // Already drawn via the existing canvas because we draw inside the same ctx between frames.
  // Better: patch into the existing render loop. We hook via gameLoop tail.
  if(typeof window.__gameDrawHooks==='undefined')window.__gameDrawHooks=[];
  window.__gameDrawHooks.push(_drawWorldEvents);

  // ── PATCH gameLoop to call __gameDrawHooks at end ──
  if(typeof gameLoop==='function'&&!gameLoop.__patched){
    const _origGL=gameLoop;
    const _newGL=function(){
      _origGL.apply(this,arguments);
      try{for(const h of (window.__gameDrawHooks||[])){h();}}catch(e){}
    };
    _newGL.__patched=true;
    try{gameLoop=_newGL;}catch(e){window.gameLoop=_newGL;}
  }

  // ── PATCH drawDrops to add gold glow ring on rare drops ──
  if(typeof drawDrops==='function'&&!drawDrops.__rarePatched){
    const _origDD=drawDrops;
    const _newDD=function(){
      _origDD.apply(this,arguments);
      // Overlay extra glow on rare drops
      try{
        const z=ZOOM;
        for(const d of droppedItems){
          if(!d||!d.rare)continue;
          if(!onScreen(d.x-10,d.y-10,20,20))continue;
          const bob=Math.sin(d.bobT)*3*z;
          const pulse=0.45+Math.sin(Date.now()*.006)*0.35;
          ctx.strokeStyle='rgba(255,215,0,'+pulse.toFixed(2)+')';
          ctx.lineWidth=2*z;
          ctx.beginPath();ctx.arc(wx(d.x),wy(d.y)-2*z+bob,11*z,0,Math.PI*2);ctx.stroke();
          ctx.strokeStyle='rgba(255,235,150,'+(pulse*0.6).toFixed(2)+')';
          ctx.lineWidth=1*z;
          ctx.beginPath();ctx.arc(wx(d.x),wy(d.y)-2*z+bob,14*z,0,Math.PI*2);ctx.stroke();
        }
      }catch(e){}
    };
    _newDD.__rarePatched=true;
    try{drawDrops=_newDD;}catch(e){window.drawDrops=_newDD;}
  }

  // ── PATCH flashHitScreen to add a heavy class for big hits + screen shake hook ──
  // (We don't override default — provide a stronger variant via global)
  window.flashHeavy=function(){const el=document.getElementById('hit-flash');if(!el)return;el.classList.add('show','heavy');setTimeout(()=>{el.classList.remove('show');setTimeout(()=>el.classList.remove('heavy'),120);},140);};

  // ── EXPOSE API ──
  window.PalProg={Prog,saveProg,renderTracker,rollDaily,rollChallenge,triggerMeteor,triggerMerchant,triggerRarePalSpawn,triggerChest};

  // Periodic save of progression
  setInterval(saveProg,15000);
})();

// ═══════════════════════════════════════════════════════════════════════════
// POST-LOAD RESTORE — runs once at startup, after every additive override
// (mount, gear, sound/time/weather, progression) has been wired onto
// loadGame().  Fixes three classes of bug:
//   1. Gear bag not loaded on boot (gear override missed the initial call).
//   2. Entity arrays containing null/undefined/out-of-bounds entries.
//   3. Minimap/camera/UI stale from pre-reload state.
// Also wires the world autosave interval so it only starts after the world
// is confirmed fully restored (prevents saving a partially-initialised state).
// ═══════════════════════════════════════════════════════════════════════════
(function _postLoadRestore(){
  try{
    if(!activeWorldId)return; // no world active (start menu shown) — nothing to restore

    // ── 1. Read raw save once (shared by all sub-steps) ──────────────────
    let _d=null;
    try{
      const _raw=localStorage.getItem('palworld_save_'+activeWorldId);
      if(_raw)_d=JSON.parse(_raw);
    }catch(_e){_d=null;}

    // ── 2. Gear bag — the gear override is patched AFTER INIT, so the boot-
    //     time loadGame() call could not have run it. Apply it here as a
    //     guaranteed final sync. The gear override's own IIFE already handles
    //     legacy reconciliation; we only need the raw array restore. ────────
    if(_d&&Array.isArray(_d.gearBag)){
      try{
        gearBag=_d.gearBag;
        if(_d.equippedId){
          equippedId.weapon=_d.equippedId.weapon||null;
          equippedId.axe=_d.equippedId.axe||null;
          equippedId.pickaxe=_d.equippedId.pickaxe||null;
          equippedId.armor=_d.equippedId.armor||null;
        }
        if(typeof _d._gearGid==='number'&&_d._gearGid>0)_gearGid=_d._gearGid;
        // Re-run legacy reconciliation in case equippedId was just corrected above
        (function(){
          function _lg(slot,key){if(!key||equippedId[slot])return;const mx=DURA_MAX[key]||50;const it={id:_gearNewId(),key:key,dur:mx,max:mx,broken:false};gearBag.push(it);equippedId[slot]=it.id;}
          if(equipped.weapon)_lg('weapon',equipped.weapon);
          if(equipped.axe&&equipped.axe!=='wood')_lg('axe','axe_'+equipped.axe);
          if(equipped.pickaxe&&equipped.pickaxe!=='wood')_lg('pickaxe','pickaxe_'+equipped.pickaxe);
          if(equipped.armor)_lg('armor','ar_'+equipped.armor);
        })();
        try{if(typeof renderGearBag==='function')renderGearBag();}catch(_e){}
      }catch(_ge){}
    }

    // ── 3. Entity registry — scrub null/undefined entries; clamp positions ─
    try{
      for(let _i=basePals.length-1;_i>=0;_i--){
        const _bp=basePals[_i];
        if(!_bp||!_bp.def){basePals.splice(_i,1);continue;}
        // Assign a stable ID if one is missing
        if(!_bp.id||!isFinite(Number(_bp.id)))_bp.id=Math.random();
        // Clamp position inside map so base workers never teleport off-edge
        _bp.x=Math.max(TILE*2,Math.min(isFinite(_bp.x)?_bp.x:MAP_W/2,MAP_W-TILE*2));
        _bp.y=Math.max(TILE*2,Math.min(isFinite(_bp.y)?_bp.y:MAP_H/2,MAP_H-TILE*2));
        // Restore velocity and HP fields that older saves may have omitted
        if(!isFinite(_bp.vx))_bp.vx=0;
        if(!isFinite(_bp.vy))_bp.vy=0;
        if(!isFinite(_bp.hp)||_bp.hp<=0)_bp.hp=Math.max(1,_bp.maxHp||(_bp.def.baseHp||10));
        if(!isFinite(_bp.maxHp)||_bp.maxHp<=0)_bp.maxHp=_bp.def.baseHp||10;
      }
    }catch(_e){}
    try{
      // Normalise partyPals: undefined slots → null; validate living entries
      for(let _i=0;_i<partyPals.length;_i++){
        if(partyPals[_i]===undefined)partyPals[_i]=null;
        const _pp=partyPals[_i];
        if(!_pp)continue;
        if(!_pp.def||!_pp.def.name){partyPals[_i]=null;continue;}
        if(!isFinite(_pp.hp)||_pp.hp<0)_pp.hp=0;
        if(!isFinite(_pp.maxHp)||_pp.maxHp<=0)_pp.maxHp=_pp.def.baseHp||10;
      }
    }catch(_e){}
    try{
      // Wild pals: remove any null/undefined holes (shouldn't normally occur on
      // a fresh iframe boot, but guards against mid-session partial state)
      for(let _i=wildPals.length-1;_i>=0;_i--){
        if(!wildPals[_i]||!wildPals[_i].def)wildPals.splice(_i,1);
      }
    }catch(_e){}

    // ── 4. Player safety — final absolute clamp after all data has settled ─
    try{
      const _mw=(typeof MAP_W==='number'&&MAP_W>0)?MAP_W:2000;
      const _mh=(typeof MAP_H==='number'&&MAP_H>0)?MAP_H:2000;
      PL.x=Math.max(40,Math.min(isFinite(PL.x)?PL.x:_mw/2,_mw-40));
      PL.y=Math.max(40,Math.min(isFinite(PL.y)?PL.y:_mh/2,_mh-40));
      if(!isFinite(PL.hp)||PL.hp<=0)PL.hp=Math.max(1,PL.maxHp||20);
      if(!isFinite(PL.maxHp)||PL.maxHp<=0)PL.maxHp=20;
      if(!PL.facing)PL.facing='down';
    }catch(_e){}

    // ── 5. Minimap — force cache rebuild on first draw after restore ───────
    try{if(typeof drawMinimap==='function')drawMinimap._mmEnemyCache=null;}catch(_e){}

    // ── 6. Camera — final snap now that all entity positions are confirmed ──
    try{
      if(typeof resizeCanvas==='function')resizeCanvas();
      if(typeof visW==='function'&&VW>0&&VH>0){
        cam.x=Math.max(0,Math.min(PL.x-visW()/2,MAP_W-visW()));
        cam.y=Math.max(0,Math.min(PL.y-visH()/2,MAP_H-visH()));
      }
    }catch(_e){}

    // ── 7. UI refresh — bring all panels in sync with restored state ───────
    try{if(typeof updHPBar==='function')updHPBar();}catch(_e){}
    try{if(typeof updHungerBar==='function')updHungerBar();}catch(_e){}
    try{if(typeof updResUI==='function')updResUI();}catch(_e){}
    try{if(typeof refreshPartyBar==='function')refreshPartyBar();}catch(_e){}
    try{if(typeof updEquipPanel==='function')updEquipPanel();}catch(_e){}
    try{if(typeof applyUpgrades==='function')applyUpgrades();}catch(_e){}

    // ── 8. World autosave interval — start LAST, only once world is fully
    //     restored. Saves every 90 s when the game is actively running.
    //     Guard prevents a second interval from registering on any future
    //     hot-reload path. ──────────────────────────────────────────────────
    if(!window.__worldAutosaveRunning){
      window.__worldAutosaveRunning=true;
      setInterval(function(){
        try{
          if(typeof saveGame==='function'&&
             typeof activeWorldId!=='undefined'&&activeWorldId&&
             !gamePaused&&typeof PL!=='undefined'&&!PL.dead){
            saveGame();
          }
        }catch(_e){}
      },90000);
    }

    // ── 9. Periodic memory scrub (every 60 s) ───────────────────────────────
    // Clears any leaked DOM popup nodes, trims entity arrays that somehow
    // exceeded their caps, flushes stale loot bags and drops, resets the
    // minimap enemy cache so it rebuilds from live data.  Safe no-op when
    // arrays are already clean.
    if(!window.__memScrubRunning){
      window.__memScrubRunning=true;
      setInterval(function(){
        try{
          // 1. Orphaned popup nodes that missed their setTimeout removal
          const _pops=document.querySelectorAll('.popup');
          if(_pops.length>0&&typeof MAX_POPUPS!=='undefined'&&_pops.length>MAX_POPUPS){
            for(let _pi=0;_pi<_pops.length-MAX_POPUPS;_pi++)try{_pops[_pi].remove();}catch(_){}
          }
          // 2. Dropped items over cap (safety net for burst events)
          if(typeof droppedItems!=='undefined'&&typeof MAX_DROPPED!=='undefined'&&droppedItems.length>MAX_DROPPED){
            droppedItems.splice(0,droppedItems.length-MAX_DROPPED);
          }
          // 3. Loot bags over cap
          if(typeof lootBags!=='undefined'&&typeof LOOT_BAG_MAX!=='undefined'&&lootBags.length>LOOT_BAG_MAX){
            lootBags.splice(0,lootBags.length-LOOT_BAG_MAX);
          }
          // 4. Projectiles over cap
          if(typeof projs!=='undefined'&&typeof MAX_PROJS!=='undefined'&&projs.length>MAX_PROJS){
            projs.splice(0,projs.length-MAX_PROJS);
          }
          // 5. Particles over cap
          if(typeof particles!=='undefined'&&typeof MAX_PARTICLES!=='undefined'&&particles.length>MAX_PARTICLES){
            particles.splice(0,particles.length-MAX_PARTICLES);
          }
          // 6. Invalidate minimap enemy cache so next draw rebuilds from live arrays
          if(typeof drawMinimap==='function')drawMinimap._mmEnemyCache=null;
          // 7. Purge any wildPals/bossPals entries that are dead and overdue (belt-and-braces)
          if(typeof wildPals!=='undefined'){
            for(let _wi=wildPals.length-1;_wi>=0;_wi--){if(wildPals[_wi]&&wildPals[_wi].dead&&(wildPals[_wi]._deadT||0)>5000)wildPals.splice(_wi,1);}
          }
          if(typeof bossPals!=='undefined'){
            for(let _bi=bossPals.length-1;_bi>=0;_bi--){if(bossPals[_bi]&&bossPals[_bi].dead&&(bossPals[_bi]._deadT||0)>5000)bossPals.splice(_bi,1);}
          }
        }catch(_se){}
      },60000);
    }

  }catch(_topErr){}
})();

// ═══════════════════════════════════════════════════════════════════════════
// REINFORCEMENT — render watchdog, save validation, visibility recovery,
// resize hardening, last-resort scene reload. ADDITIVE: never blocks normal
// init; only repairs when it detects a clearly-broken state. This is the
// safety net for "world loads but nothing renders" on re-entry.
// ═══════════════════════════════════════════════════════════════════════════
(function(){
  try{
    function _safeNum(v,d){return (typeof v==='number'&&isFinite(v))?v:d;}
    // ── 1) SAVE VALIDATION — clamp PL/cam/HP into valid ranges so a corrupt
    //     save can never block rendering. Called now (boot) and after each
    //     watchdog repair.
    function _validateWorldState(){
      try{
        const mw=(typeof MAP_W==='number'&&isFinite(MAP_W))?MAP_W:2000;
        const mh=(typeof MAP_H==='number'&&isFinite(MAP_H))?MAP_H:2000;
        if(typeof PL!=='undefined'&&PL){
          PL.x=Math.max(40,Math.min(_safeNum(PL.x,mw*0.5),mw-40));
          PL.y=Math.max(40,Math.min(_safeNum(PL.y,mh*0.5),mh-40));
          if(!isFinite(PL.maxHp)||PL.maxHp<=0)PL.maxHp=20;
          if(!isFinite(PL.hp)||PL.hp<0)PL.hp=Math.max(1,PL.maxHp);
          if(PL.hp>PL.maxHp*4)PL.hp=PL.maxHp;
          if(!PL.facing)PL.facing='down';
          if(!isFinite(PL.vx))PL.vx=0;
          if(!isFinite(PL.vy))PL.vy=0;
          // FIX: unstick PL.dead — if player has HP but dead flag is stuck (e.g.
          // after a dungeon respawn race), clear it so drawPlayer renders again.
          if(PL.dead&&PL.hp>0){
            console.log('[VALIDATE] Clearing stuck PL.dead flag (hp='+PL.hp+')');
            PL.dead=false;if(!isFinite(PL.invT)||PL.invT<0)PL.invT=1500;
          }
        }
        if(typeof cam!=='undefined'&&cam){
          const px=(typeof PL!=='undefined'&&PL)?PL.x:mw*0.5;
          const py=(typeof PL!=='undefined'&&PL)?PL.y:mh*0.5;
          const vw=(typeof visW==='function')?visW():400;
          const vh=(typeof visH==='function')?visH():240;
          cam.x=_safeNum(cam.x,Math.max(0,Math.min(px-vw/2,mw-vw)));
          cam.y=_safeNum(cam.y,Math.max(0,Math.min(py-vh/2,mh-vh)));
        }
        // FIX: purge wildPals/bossPals with NaN positions — these become invisible
        // permanently (draws at NaN coordinates are silently dropped by canvas).
        if(typeof wildPals!=='undefined'&&Array.isArray(wildPals)){
          let _wpRemoved=0;
          for(let _wi=wildPals.length-1;_wi>=0;_wi--){
            const _wp=wildPals[_wi];
            if(!_wp||!isFinite(_wp.x)||!isFinite(_wp.y)||(_wp.dead&&(_wp._deadT||0)>4000)){wildPals.splice(_wi,1);_wpRemoved++;}
          }
          if(_wpRemoved)console.log('[VALIDATE] Removed '+_wpRemoved+' invalid wildPals');
        }
        if(typeof bossPals!=='undefined'&&Array.isArray(bossPals)){
          let _bpRemoved=0;
          for(let _bi=bossPals.length-1;_bi>=0;_bi--){
            const _bp=bossPals[_bi];
            if(!_bp||!isFinite(_bp.x)||!isFinite(_bp.y)||(_bp.dead&&(_bp._deadT||0)>4000)){bossPals.splice(_bi,1);_bpRemoved++;}
          }
          if(_bpRemoved)console.log('[VALIDATE] Removed '+_bpRemoved+' invalid bossPals');
        }
        // FIX: canvas context safety reset — guards against stray globalAlpha/transform
        try{
          if(typeof ctx!=='undefined'&&ctx){ctx.globalAlpha=1;ctx.setTransform(1,0,0,1,0,0);}
        }catch(_ce){}
        console.log('[VALIDATE] World state validated');
      }catch(_e){console.error('[VALIDATE] Error',_e);}
    }
    _validateWorldState();

    // ── 2) RENDER WATCHDOG — counts frames; if the loop genuinely stalls
    //     (visible tab, zero frames, no heartbeat), repairs and restarts.
    //     Capped at 5 recoveries. KEY FIX: uses _wdLoopAlive heartbeat +
    //     _wdResumeGrace cooldown to prevent duplicate loops after background
    //     throttling — the #1 cause of long-session entity invisibility.
    let _wdFrames=0,_wdLastFrames=0,_wdLastCheck=Date.now(),_wdRecoveries=0,_wdLastRestart=0;
    let _wdLoopAlive=false;  // set true on every gameLoop tick; cleared each watchdog interval
    let _wdResumeGrace=0;    // epoch ms: suppress stall checks until after this time
    if(typeof gameLoop==='function'){
      const _gl=gameLoop;
      gameLoop=function(ts){_wdFrames++;_wdLoopAlive=true;return _gl(ts);};
      try{window.gameLoop=gameLoop;}catch(_e){}
    }
    function _restartLoop(){
      try{
        if(typeof gameLoop!=='function')return;
        // CRITICAL: never start a second loop while one is alive — this is what
        // caused entities/player to disappear after tab switches in long sessions.
        if(_wdLoopAlive){console.log('[WD] Loop alive — skip restart');return;}
        console.log('[WD] Restarting stalled game loop (recovery #'+(_wdRecoveries)+')');
        try{lastT=performance.now();}catch(_e){}
        _wdResumeGrace=Date.now()+4000; // Grace window after restart
        requestAnimationFrame(gameLoop);
        _wdLastRestart=Date.now();
      }catch(_e){}
    }
    function _renderWatchdog(){
      try{
        if(document.visibilityState!=='visible')return;
        if(Date.now()<_wdResumeGrace)return; // Grace after resume/restart — skip check
        const now=Date.now();
        const elapsed=now-_wdLastCheck;_wdLastCheck=now;
        const framed=_wdFrames-_wdLastFrames;_wdLastFrames=_wdFrames;
        const wasAlive=_wdLoopAlive;_wdLoopAlive=false; // Reset heartbeat for next interval
        let needRepair=false,needRestart=false;
        // a) canvas zero-sized → resize
        try{
          const cv=typeof canvas!=='undefined'?canvas:null;
          if(cv&&(cv.width<=0||cv.height<=0||!isFinite(cv.width)||!isFinite(cv.height)))needRepair=true;
        }catch(_e){}
        // b) VW/VH gone bad → resize
        if(typeof VW!=='number'||VW<=0||typeof VH!=='number'||VH<=0)needRepair=true;
        // c) camera invalid → recenter
        try{if(typeof cam!=='undefined'&&(!isFinite(cam.x)||!isFinite(cam.y)))needRepair=true;}catch(_e){}
        // d) loop stall: no heartbeat for this full interval AND zero frames total,
        //    debounced 5s. Use wasAlive (not just framed) to avoid false positives
        //    after background throttling where RAF resumes naturally on visibility.
        if(!wasAlive&&elapsed>=3000&&framed===0&&now-_wdLastRestart>5000)needRestart=true;
        if((needRepair||needRestart)&&_wdRecoveries<5){
          _wdRecoveries++;
          console.log('[WD] Repair #'+_wdRecoveries+' needRepair='+needRepair+' needRestart='+needRestart);
          try{if(typeof resizeCanvas==='function')resizeCanvas();}catch(_e){}
          _validateWorldState();
          if(needRestart)_restartLoop();
        }
      }catch(_e){}
    }
    setInterval(_renderWatchdog,1000);

    // ── 3) VISIBILITY / FOCUS RECOVERY — when iframe returns from background
    //     (mobile tab sleep, app switch), force resize, prime dt, resume audio,
    //     and set a grace window so the watchdog doesn't fire a spurious restart
    //     before the throttled RAF loop naturally resumes.
    function _onResume(){
      try{
        if(typeof resizeCanvas==='function')resizeCanvas();
        try{lastT=performance.now();}catch(_e){}
        // Grace period: suppress watchdog stall checks for 3s after resume so
        // background-throttled RAF can naturally recover without spawning a second loop
        _wdResumeGrace=Date.now()+3000;
        // Reset frame counters AFTER setting grace so the watchdog skips this window
        _wdLastFrames=_wdFrames;_wdLastCheck=Date.now();
        _wdLoopAlive=true; // Assume alive — first resumed frame will confirm
        console.log('[RESUME] Tab/focus resumed — grace until +'+(3000)+'ms');
        try{if(typeof _getAC==='function'){const ac=_getAC();if(ac&&ac.state==='suspended')ac.resume();}}catch(_e){}
      }catch(_e){}
    }
    document.addEventListener('visibilitychange',function(){if(document.visibilityState==='visible')_onResume();});
    window.addEventListener('focus',_onResume);
    window.addEventListener('pageshow',_onResume);

    // ── 4) BELT-AND-BRACES SIZE PROBE — some browsers report 0×0 layout for
    //     a frame or two after iframe srcdoc load. Probe several times early
    //     to guarantee canvas locks to the real size before first render.
    let _probe=0;
    (function _earlyResize(){
      try{if(typeof resizeCanvas==='function')resizeCanvas();}catch(_e){}
      _probe++;if(_probe<10)setTimeout(_earlyResize,_probe<4?60:_probe<7?180:400);
    })();
    window.addEventListener('load',function(){try{if(typeof resizeCanvas==='function')resizeCanvas();}catch(_e){}});

    // ── 5) LAST-RESORT EMERGENCY RELOAD — if after 6s the loop has still
    //     produced zero frames (init genuinely failed past the early retry
    //     window), do one final clean iframe reload via the parent. Guarded
    //     by sessionStorage so it can never loop.
    setTimeout(function(){
      try{
        if(_wdFrames===0&&document.visibilityState==='visible'){
          if(typeof sessionStorage!=='undefined'&&sessionStorage.getItem('palworld_emergency_reload')!=='1'){
            sessionStorage.setItem('palworld_emergency_reload','1');
            if(typeof window.__reloadGame==='function')window.__reloadGame();
          }
        }else if(typeof sessionStorage!=='undefined'){
          sessionStorage.removeItem('palworld_emergency_reload');
        }
      }catch(_e){}
    },6000);
  }catch(_e){console.error('reinforcement init failed',_e);}
})();

// ─── STAGED LOADING — drives the progress bar through real init phases ───
window.setLoadProgress&&window.setLoadProgress(15,'Building world map...');
requestAnimationFrame(function(){
  window.setLoadProgress&&window.setLoadProgress(35,'Spawning wildlife...');
  requestAnimationFrame(function(){
    window.setLoadProgress&&window.setLoadProgress(55,'Loading inventory...');
    requestAnimationFrame(function(){
      window.setLoadProgress&&window.setLoadProgress(72,'Preparing UI...');
      requestAnimationFrame(function(){
        // Belt-and-braces: size canvas right before first frame
        try{if(typeof resizeCanvas==='function')resizeCanvas();}catch(_e){}
        // Start the actual game loop after the bar has visibly progressed
        requestAnimationFrame(gameLoop);
        window.setLoadProgress&&window.setLoadProgress(88,'Almost ready...');
        requestAnimationFrame(function(){
          // Wait one more frame so first real game frame paints
          requestAnimationFrame(function(){
            // Final readiness check: only hide loading screen once a real
            // frame has been counted by the watchdog (player+map are now drawn).
            (function _waitFirstFrame(tries){
              if(typeof window.__wdFrames==='number'){/* legacy */}
              // Read frame count off the watchdog scope via gameLoop wrapper:
              // we can't easily reach it — instead check for any of the
              // tell-tale render artifacts (canvas size + cam set).
              const ok=(function(){
                try{
                  if(typeof canvas==='undefined'||!canvas)return false;
                  if(canvas.width<=0||canvas.height<=0)return false;
                  if(typeof cam==='undefined'||!isFinite(cam.x)||!isFinite(cam.y))return false;
                  if(typeof PL==='undefined'||!PL||!isFinite(PL.x))return false;
                  return true;
                }catch(_e){return false;}
              })();
              if(ok||tries>=20){
                window.setLoadProgress&&window.setLoadProgress(100,'Welcome!');
                setTimeout(function(){window.hideLoadingScreen&&window.hideLoadingScreen();},220);
              }else{
                setTimeout(function(){_waitFirstFrame(tries+1);},120);
              }
            })(0);
          });
        });
      });
    });
  });
});
</script>
</body>
</html>`;
